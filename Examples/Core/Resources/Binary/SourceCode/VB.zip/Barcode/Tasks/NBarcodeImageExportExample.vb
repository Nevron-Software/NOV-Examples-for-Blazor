Imports System

Imports Nevron.Nov.Barcode
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Barcode
    Public Class NBarcodeImageExportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NBarcodeImageExportExampleSchema = NSchema.Create(GetType(NBarcodeImageExportExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Protected Overrides"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ImageBox = New NImageBox()
            m_ImageBox.HorizontalPlacement = ENHorizontalPlacement.Center
            m_ImageBox.VerticalPlacement = ENVerticalPlacement.Center
            Return m_ImageBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_BarcodeTextBox = New NTextBox("Nevron Software" & Environment.NewLine & Environment.NewLine & "https://www.nevron.com")

            m_BarcodeTextBox.Multiline = True
            m_BarcodeTextBox.AcceptsEnter = True
            m_BarcodeTextBox.PreferredHeight = 100
            Me.m_BarcodeTextBox.TextChanged += AddressOf OnBarcodeTextBoxTextChanged
            stack.Add(m_BarcodeTextBox)

            m_GenerateImageButton = New NButton("Generate Image")
            Me.m_GenerateImageButton.Click += AddressOf OnGenerateImageButtonClick
            stack.Add(m_GenerateImageButton)

            OnGenerateImageButtonClick(Nothing)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how export barcodes to raster images. Enter some text in the text box on the right
	and click the <b>Generate Image</b> button.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnBarcodeTextBoxTextChanged(arg As NValueChangeEventArgs)
            Dim text = CStr(arg.NewValue)
            m_GenerateImageButton.Enabled = Not Equals(text, Nothing) AndAlso text.Length > 0
        End Sub
        Private Sub OnGenerateImageButtonClick(arg As NEventArgs)
            Dim painter As NMatrixBarcodePainter = New NMatrixBarcodePainter()
            painter.Symbology = ENMatrixBarcodeSymbology.QrCode
            painter.Text = m_BarcodeTextBox.Text
            Dim qrRaster = painter.CreateRaster(100, 100, NRaster.DefaultResolution)
            Dim qrImage As NImage = New NImage(qrRaster)

            m_ImageBox.Image = qrImage
        End Sub

#End Region

#Region "Fields"

        Private m_ImageBox As NImageBox
        Private m_BarcodeTextBox As NTextBox
        Private m_GenerateImageButton As NButton

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBarcodeImageExportExample.
        ''' </summary>
        Public Shared ReadOnly NBarcodeImageExportExampleSchema As NSchema

#End Region
    End Class
End Namespace
