Imports Nevron.Nov.Barcode
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Barcode
    Public Class NCode11BarcodeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCode11BarcodeExampleSchema = NSchema.Create(GetType(NCode11BarcodeExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a linear barcode widget
            m_Barcode = New NLinearBarcode()
            m_Barcode.Symbology = ENLinearBarcodeSymbology.Code11
            m_Barcode.Text = "012345"
            m_Barcode.HorizontalPlacement = ENHorizontalPlacement.Center
            m_Barcode.VerticalPlacement = ENVerticalPlacement.Center

            Return m_Barcode
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Create the property editors
            Dim editors = NDesigner.GetDesigner(m_Barcode).CreatePropertyEditors(m_Barcode, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NBoxElement.BackgroundFillProperty, NBoxElement.TextFillProperty, NBarcode.SizeModeProperty, NBarcode.ScaleProperty)

            Dim i = 0, count = editors.Count

            While i < count
                stack.Add(editors(i))
                i += 1
            End While

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a Code 11 barcode. Use the controls on the right to change
	the appearance of the barcode widget.
</p>
"
        End Function

#End Region

#Region "Fields"

        Private m_Barcode As NLinearBarcode

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCode11BarcodeExample.
        ''' </summary>
        Public Shared ReadOnly NCode11BarcodeExampleSchema As NSchema

#End Region
    End Class
End Namespace
