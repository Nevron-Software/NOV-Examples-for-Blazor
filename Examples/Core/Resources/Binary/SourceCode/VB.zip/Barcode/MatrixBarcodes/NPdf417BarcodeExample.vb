Imports Nevron.Nov.Barcode
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Barcode
    Public Class NPdf417BarcodeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPdf417BarcodeExampleSchema = NSchema.Create(GetType(NPdf417BarcodeExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_Barcode = New NMatrixBarcode()
            m_Barcode.Symbology = ENMatrixBarcodeSymbology.Pdf417
            m_Barcode.Text = "Nevron Software"
            m_Barcode.SetBorder(1, NColor.Red)

            Return m_Barcode
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Create the property editors
            Dim editors = NDesigner.GetDesigner(m_Barcode).CreatePropertyEditors(m_Barcode, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NBoxElement.BackgroundFillProperty, NBoxElement.TextFillProperty, NBarcode.SizeModeProperty, NBarcode.ScaleProperty, NBarcode.TextProperty)

            Dim i = 0, count = editors.Count

            While i < count
                stack.Add(editors(i))
                i += 1
            End While

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create PDF 417 2D barcodes. Use the controls on the right to change
	the appearance of the barcode widget.
</p>
"
        End Function

#End Region

#Region "Fields"

        Private m_Barcode As NMatrixBarcode

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPdf417BarcodeExample.
        ''' </summary>
        Public Shared ReadOnly NPdf417BarcodeExampleSchema As NSchema

#End Region
    End Class
End Namespace
