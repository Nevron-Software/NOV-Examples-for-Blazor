Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Grid
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NGroupingSummaryRowsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NGroupingSummaryRowsExampleSchema = NSchema.Create(GetType(NGroupingSummaryRowsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a view and get its grid
            Dim view As NTableGridView = New NTableGridView()
            Dim grid = view.Grid

            ' customize the grid
            grid.AllowEdit = False

            ' bind to data source, but exclude the "PersonId" field from binding 
            grid.AutoCreateColumn += Sub(arg As NAutoCreateColumnEventArgs)
                                         If Equals(arg.FieldInfo.Name, "PersonId") Then
                                             arg.DataColumn = Nothing
                                         End If
                                     End Sub
            grid.DataSource = NDummyDataSource.CreatePersonsOrdersDataSource()

            ' create a calculated Total column
            Dim totalColumn As NCustomCalculatedColumn(Of Double) = New NCustomCalculatedColumn(Of Double)()
            totalColumn.Title = "Total"
            totalColumn.GetRowValueDelegate = Function(args As NCustomCalculatedColumnGetRowValueArgs(Of Double))
                                                  Dim price = Convert.ToDouble(args.DataSource.GetValue(args.RowIndex, "Price"))
                                                  Dim quantity = Convert.ToInt32(args.DataSource.GetValue(args.RowIndex, "Quantity"))
                                                  Return price * quantity
                                              End Function
            grid.Columns.Add(totalColumn)

            ' create a grouping rule that groups by the Product Name column
            Dim groupingRule As NGroupingRule = New NGroupingRule(grid.Columns.GetColumnByFieldName("Product Name"))

            ' create a footer summary row for the total total
            groupingRule.CreateFooterSummaryRowsDelegate = Function(args As NGroupingRuleCreateSummaryRowsArgs)
                                                               ' get the recordset for the group
                                                               Dim recordset = args.GroupRow.Recordset

                                                               ' calculate the sum of totals
                                                               Dim total As Double = 0
                                                               For i = 0 To recordset.Count - 1
                                                                   total += Convert.ToDouble(totalColumn.GetRowValue(recordset(i)))
                                                               Next

                                                               ' create the total summary row
                                                               Dim totalRow As NSummaryRow = New NSummaryRow()
                                                               totalRow.Cells = New NSummaryCellCollection()

                                                               Dim cell As NSummaryCell = New NSummaryCell()
                                                               cell.BeginXPosition.Mode = ENSpanCellBeginXPositionMode.AnchorToEndX
                                                               cell.EndXPosition.Mode = ENSpanCellEndXPositionMode.RowEndX
                                                               cell.Content = New NLabel("Grand Total: " & total.ToString("0.00"))
                                                               totalRow.Cells.Add(cell)

                                                               Return New NSummaryRow() {totalRow}
                                                           End Function
            grid.GroupingRules.Add(groupingRule)

            Return view
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates groups' summary rows and calculated columns.
</p>
<p>
    In this example we have created the <b>Total</b> <b>NCustomCalculatedColumn</b> that shows the <b>Price</b> * <b>Quantity</b> calculation.
</p>
<p>
    Additionally the we have grouped the records by <b>Product Name</b> and created a summary row for each of the groups that displays the <b>Grand Total</b> of the totals contained in the group.
</p>
"
        End Function

#End Region

#Region "Fields"



#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NGroupingSummaryRowsExample.
        ''' </summary>
        Public Shared ReadOnly NGroupingSummaryRowsExampleSchema As NSchema

#End Region
    End Class
End Namespace
