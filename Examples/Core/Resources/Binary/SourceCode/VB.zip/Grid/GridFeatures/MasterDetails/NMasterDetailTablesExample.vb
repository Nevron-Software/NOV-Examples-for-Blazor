Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Grid
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NMasterDetailTablesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMasterDetailTablesExampleSchema = NSchema.Create(GetType(NMasterDetailTablesExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a view and get its grid
            m_View = New NTableGridView()
            Dim grid = m_View.Grid

            ' bind the grid to the data source
            grid.DataSource = NDummyDataSource.CreatePersonsDataSource()

            ' configure the master grid
            grid.AllowEdit = False

            ' assign some icons to the columns
            For i = 0 To grid.Columns.Count - 1
                Dim dataColumn As NDataColumn = TryCast(grid.Columns(i), NDataColumn)
                If dataColumn Is Nothing Then Continue For

                Dim image As NImage = Nothing
                Select Case dataColumn.FieldName
                    Case "Name"
                        image = NResources.Image__16x16_Contacts_png
                    Case "Gender"
                        image = NResources.Image__16x16_Gender_png
                    Case "Birthday"
                        image = NResources.Image__16x16_Birthday_png
                    Case "Country"
                        image = NResources.Image__16x16_Globe_png
                    Case "Phone"
                        image = NResources.Image__16x16_Phone_png
                    Case "Email"
                        image = NResources.Image__16x16_Mail_png
                    Case Else
                        Continue For
                End Select

                ' NOTE: The CreateHeaderContentDelegate is invoked whenever the Title changes or the UpdateHeaderContent() is called.
                ' you can use this event to create custom column header content
                dataColumn.CreateHeaderContentDelegate = Function(theColumn As NColumn)
                                                             Dim pairBox As NPairBox = New NPairBox(image, dataColumn.Title, ENPairBoxRelation.Box1BeforeBox2)
                                                             pairBox.Spacing = 2
                                                             Return pairBox
                                                         End Function
                dataColumn.UpdateHeaderContent()
            Next

            ' get the grid master details
            Dim masterDetails = grid.MasterDetails

            ' creater the table grid detail. 
            ' NOTE: It shows information from the sales data source. the details are bound using field binding
            Dim detail As NTableGridDetail = New NTableGridDetail()
            masterDetails.Details.Add(detail)
            detail.DataSource = NDummyDataSource.CreatePersonsOrdersDataSource()

            ' configure the details grid
            detail.GridView.Grid.AllowEdit = False

            Dim masterBinding As NRelationMasterBinding = New NRelationMasterBinding()
            masterBinding.Relations.Add(New NRelation("Id", "PersonId"))
            detail.MasterBinding = masterBinding

            Return m_View
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim editors = NDesigner.GetDesigner(m_View.Grid).CreatePropertyEditors(m_View.Grid, NGrid.FrozenRowsProperty, NGrid.IntegralVScrollProperty)

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates how to show other tables data that is related to the master table rows.
</p>
<p>
    <b>NTableGridDetail</b> and <b>NTreeGridDetail</b> are master-details that can display a table or tree grid that display information from a slave data source.
</p>
<p>
    In this example we have created an <b>NTableGridDetail</b> detail that display information about each specific person orders.
    The master grid shows the <b>Persons</b> data source.
    The detail for each person are extracted from the <b>PersonOrders</b> data source and displayed as a table grid again.
</p>
"
        End Function

#End Region

#Region "Fields"

        Private m_View As NTableGridView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMasterDetailsExample.
        ''' </summary>
        Public Shared ReadOnly NMasterDetailTablesExampleSchema As NSchema

#End Region
    End Class
End Namespace
