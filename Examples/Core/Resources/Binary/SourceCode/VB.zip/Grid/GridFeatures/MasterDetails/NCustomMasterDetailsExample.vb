Imports Nevron.Nov.Grid
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NCustomMasterDetailsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCustomMasterDetailsExampleSchema = NSchema.Create(GetType(NCustomMasterDetailsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a view and get its grid
            m_View = New NTableGridView()
            Dim grid = m_View.Grid

            ' bind the grid to the data source
            grid.DataSource = NDummyDataSource.CreatePersonsDataSource()

            ' configure the master grid
            grid.AllowEdit = False

            ' assign some icons to the columns
            For i = 0 To grid.Columns.Count - 1
                Dim dataColumn As NDataColumn = TryCast(grid.Columns(i), NDataColumn)
                If dataColumn Is Nothing Then Continue For

                Dim image As NImage = Nothing
                Select Case dataColumn.FieldName
                    Case "Name"
                        image = NResources.Image__16x16_Contacts_png
                    Case "Gender"
                        image = NResources.Image__16x16_Gender_png
                    Case "Birthday"
                        image = NResources.Image__16x16_Birthday_png
                    Case "Country"
                        image = NResources.Image__16x16_Globe_png
                    Case "Phone"
                        image = NResources.Image__16x16_Phone_png
                    Case "Email"
                        image = NResources.Image__16x16_Mail_png
                    Case Else
                        Continue For
                End Select

                ' NOTE: The CreateHeaderContentDelegate is invoked whenever the Title changes or the UpdateHeaderContent() is called.
                ' you can use this event to create custom column header content
                dataColumn.CreateHeaderContentDelegate = Function(theColumn As NColumn)
                                                             Dim pairBox As NPairBox = New NPairBox(image, theColumn.Title, ENPairBoxRelation.Box1BeforeBox2)
                                                             pairBox.Spacing = 2
                                                             Return pairBox
                                                         End Function
                dataColumn.UpdateHeaderContent()
            Next

            ' create the custom detail that creates a widget displaying information about the row.
            ' NOTE: The widget is created by the OnCustomDetailCreateWidget event handler.
            Dim masterDetails = grid.MasterDetails

            Dim customDetail As NCustomDetail = New NCustomDetail()
            masterDetails.Details.Add(customDetail)

            customDetail.CreateWidgetDelegate = Function(arg As NCustomDetailCreateWidgetArgs)
                                                    ' get information about the data source row
                                                    Dim name = CStr(arg.DataSource.GetValue(arg.RowIndex, "Name"))
                                                    Dim gender As ENGender = CType(arg.DataSource.GetValue(arg.RowIndex, "Gender"), ENGender)
                                                    Dim birthday As Date = arg.DataSource.GetValue(arg.RowIndex, "Birthday")
                                                    Dim country As ENCountry = CType(arg.DataSource.GetValue(arg.RowIndex, "Country"), ENCountry)
                                                    Dim phone = CStr(arg.DataSource.GetValue(arg.RowIndex, "Phone"))
                                                    Dim email = CStr(arg.DataSource.GetValue(arg.RowIndex, "Email"))

                                                    ' display the information as a widget
                                                    Dim namePair As NPairBox = New NPairBox("Name:", name)
                                                    Dim genderPair As NPairBox = New NPairBox("Gender:", gender.ToString())
                                                    Dim birthdayPair As NPairBox = New NPairBox("Birthday:", birthday.ToString())
                                                    Dim countryPair As NPairBox = New NPairBox("Country:", country.ToString())
                                                    Dim phonePair As NPairBox = New NPairBox("Phone:", phone.ToString())
                                                    Dim emailPair As NPairBox = New NPairBox("Email:", email.ToString())

                                                    Dim image As NImageBox = New NImageBox()
                                                    Select Case gender
                                                        Case ENGender.Male
                                                            image.Image = NResources.Image__256x256_MaleIcon_jpg

                                                        Case ENGender.Female
                                                            image.Image = NResources.Image__256x256_FemaleIcon_jpg
                                                        Case Else
                                                    End Select

                                                    Dim infoStack As NStackPanel = New NStackPanel()
                                                    infoStack.VerticalSpacing = 2.0R
                                                    infoStack.Add(namePair)
                                                    infoStack.Add(genderPair)
                                                    infoStack.Add(birthdayPair)
                                                    infoStack.Add(countryPair)
                                                    infoStack.Add(phonePair)
                                                    infoStack.Add(emailPair)

                                                    Dim dock As NDockPanel = New NDockPanel()
                                                    dock.Add(image, ENDockArea.Left)
                                                    dock.Add(infoStack, ENDockArea.Center)

                                                    ' assign the widget to the event arguments.
                                                    Return dock
                                                End Function

            Return m_View
        End Function



        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim editors = NDesigner.GetDesigner(m_View.Grid).CreatePropertyEditors(m_View.Grid, NGrid.FrozenRowsProperty, NGrid.IntegralVScrollProperty)

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates how to implement custom master-details. Expand the master table rows to see details about each person.
</p>
<p>
    Custom master details are widgets that you can create in response to an event. 
    The event holds information about the data source and the row index for which a widget is needed.
    In this scenario of master-details it is up to the user to provide the widget.
</p>
"
        End Function

#End Region

#Region "Fields"

        Private m_View As NTableGridView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCustomMasterDetailsExample.
        ''' </summary>
        Public Shared ReadOnly NCustomMasterDetailsExampleSchema As NSchema

#End Region
    End Class
End Namespace
