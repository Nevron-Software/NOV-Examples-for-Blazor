Imports Nevron.Nov.Grid
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NColumnProtectionExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NColumnProtectionExampleSchema = NSchema.Create(GetType(NColumnProtectionExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_GridView = New NTableGridView()
            m_GridView.Grid.DataSource = NDummyDataSource.CreateProductsDataSource()
            m_GridView.Grid.AllowSortColumns = True
            Return m_GridView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' create the columns combo box
            If True Then
                stack.Add(New NLabel("Select Column:"))
                m_ColumnsComboBox = New NComboBox()
                stack.Add(m_ColumnsComboBox)
                For i = 0 To m_GridView.Grid.Columns.Count - 1
                    Dim column = m_GridView.Grid.Columns(i)
                    Dim item As NComboBoxItem = New NComboBoxItem(column.Title)
                    item.Tag = column
                    m_ColumnsComboBox.Items.Add(item)
                Next

                Me.m_ColumnsComboBox.SelectedIndexChanged += AddressOf OnColumnsComboBoxSelectedIndexChanged

                ' create the columns 
                m_ColumnPropertiesHolder = New NContentHolder()
                stack.Add(New NGroupBox("Selected Column Properties", m_ColumnPropertiesHolder))
            End If

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the column properties that affect the operations, which the user can perform with the column (e.g column protection).
<p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnColumnsComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim item = m_ColumnsComboBox.SelectedItem
            If item Is Nothing Then
                m_ColumnPropertiesHolder.Content = Nothing
                Return
            End If

            Dim column As NColumn = item.Tag

            Dim columnPropertiesStack As NStackPanel = New NStackPanel()
            m_ColumnPropertiesHolder.Content = New NUniSizeBoxGroup(columnPropertiesStack)

            Dim designer = NDesigner.GetDesigner(column)
            Dim editors = designer.CreatePropertyEditors(column, NColumn.AllowFilterProperty, NColumn.AllowSortProperty, NColumn.AllowGroupProperty, NColumn.AllowFormatProperty, NColumn.AllowEditProperty, NColumn.AllowReorderProperty, NColumn.AllowResizeProperty)

            For i = 0 To editors.Count - 1
                columnPropertiesStack.Add(editors(i))
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_GridView As NTableGridView
        Private m_ColumnsComboBox As NComboBox
        Private m_ColumnPropertiesHolder As NContentHolder

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NColumnProtectionExample.
        ''' </summary>
        Public Shared ReadOnly NColumnProtectionExampleSchema As NSchema

#End Region
    End Class
End Namespace
