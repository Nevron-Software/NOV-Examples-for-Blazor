Imports System
Imports Nevron.Nov.Grid
Imports Nevron.Nov.Data
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NExtendedColumnEditorsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NExtendedColumnEditorsExampleSchema = NSchema.Create(GetType(NExtendedColumnEditorsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a view and get its grid
            Dim view As NTableGridView = New NTableGridView()
            Dim grid = view.Grid

            grid.AllowEdit = True

            ' create persons order data source
            Dim personOrders As NDataSource = NDummyDataSource.CreatePersonsOrdersDataSource()

            ' get the min and max price. We will use it in the progress bars.
            Dim min, max As Object
            personOrders.TryGetMin("Price", min)
            personOrders.TryGetMax("Price", max)

            grid.AutoCreateColumn += Sub(args As NAutoCreateColumnEventArgs)
                                         If Equals(args.FieldInfo.Name, "Price") Then
                                             ' create a progress bar column format for the Price field
                                             Dim sliderColumnEditor As NSliderColumnEditor = New NSliderColumnEditor()
                                             args.DataColumn.Editor = sliderColumnEditor
                                             args.DataColumn.WidthMode = ENColumnWidthMode.Fixed
                                             args.DataColumn.FixedWidth = 150
                                         End If
                                     End Sub

            grid.DataSource = personOrders
            Return view
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the extended column editors. 
</p>
<p>
    Extended column editors are editors, which are not automatically assigned to data columns during data binding.
    Instead it is up to the user to assign these editors to specific columns.
</p>
<p>
    In this example we have assigned the <b>NSliderColumnEditor</b> to the <b>Price</b> column.
</p>
"
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NExtendedColumnEditorsExample.
        ''' </summary>
        Public Shared ReadOnly NExtendedColumnEditorsExampleSchema As NSchema

#End Region
    End Class
End Namespace
