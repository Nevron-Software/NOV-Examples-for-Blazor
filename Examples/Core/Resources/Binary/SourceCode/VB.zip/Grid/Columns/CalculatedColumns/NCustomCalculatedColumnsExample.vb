Imports System
Imports Nevron.Nov.Grid
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NCustomCalculatedColumnsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCustomCalculatedColumnsExampleSchema = NSchema.Create(GetType(NCustomCalculatedColumnsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_GridView = New NTableGridView()
            Dim grid = m_GridView.Grid

            ' bind the grid to the data source
            grid.DataSource = NDummyDataSource.CreatePersonsOrdersDataSource()

            ' add an event calculated column of type Double
            Dim totalColumn As NCustomCalculatedColumn(Of Double) = New NCustomCalculatedColumn(Of Double)()
            totalColumn.Title = "Total"
            totalColumn.GetRowValueDelegate += Function(arg As NCustomCalculatedColumnGetRowValueArgs(Of Double))
                                                   ' calculate a RowValue for the RowIndex
                                                   Dim price = Convert.ToDouble(arg.DataSource.GetValue(arg.RowIndex, "Price"))
                                                   Dim quantity = Convert.ToDouble(arg.DataSource.GetValue(arg.RowIndex, "Quantity"))
                                                   Return price * quantity
                                               End Function
            totalColumn.Format.BackgroundFill = New NColorFill(NColor.SeaShell)
            grid.Columns.Add(totalColumn)

            Return m_GridView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates custom calculated columns.
</p>
<p>
    Custom calculated columns are represented by the <b>NCustomCalculatedColumn</b> class. 
    It exposes a <b>GetRowValueDelegate</b> delegate, which is called whenever the column must provide a value for a specific row.
    Thus it is up to the user to provide a row value for a specific row.
</p>
<p>
    In the example the <b>Total</b> column is a custom calculated column that is calculated as {<b>Price</b>*<b>Quantity</b>}.
</p>"
        End Function

#End Region

#Region "Fields"

        Private m_GridView As NTableGridView


#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCustomCalculatedColumnsExample.
        ''' </summary>
        Public Shared ReadOnly NCustomCalculatedColumnsExampleSchema As NSchema

#End Region
    End Class
End Namespace
