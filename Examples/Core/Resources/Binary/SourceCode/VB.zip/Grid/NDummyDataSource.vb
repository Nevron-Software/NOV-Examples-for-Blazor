Imports System
Imports Nevron.Nov.Data

Namespace Nevron.Nov.Examples.Grid
    Public Enum ENGender
        Male
        Female
    End Enum

    Public Enum ENCountry
        USA
        UK
        Germany
        France
        Russia
        Italy
        Canada
        China
        Japan
        India
    End Enum

    Public Enum ENJobTitle
        President
        VicePresident
        SalesManager
        SalesRepresentative
        LeadDevelop
        SeniorDeveloper
        JuniorDeveloper
    End Enum

    ''' <summary>
    ''' A static class for creating dummy data sources used in the grid examples.
    ''' </summary>
    Public Module NDummyDataSource
        Private dataTable As NDataTable

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="count"></param>
        ''' <returns></returns>
        Public Function CreateCompanySalesDataSource(Optional count As Integer = 10000) As NDataSource
            dataTable = New NMemoryDataTable("CompanySales", New NFieldInfo() {New NFieldInfo("Id", GetType(Integer)), New NFieldInfo("Company", GetType(String)), New NFieldInfo("Sales", GetType(Double)), New NFieldInfo("Profit", GetType(Double))})

            For i = 0 To count - 1
                Call dataTable.AddRow(i, RandomCompanyName(), RandomDouble(500, 5000), RandomDouble(100, 1000))
            Next

            Return New NDataSource(dataTable)
        End Function
        ''' <summary>
        ''' Creates a products data source.
        ''' </summary>
        Public Function CreateProductsDataSource() As NDataSource
            Dim dataTable As NMemoryDataTable = New NMemoryDataTable("Products", New NFieldInfo() {New NFieldInfo("Id", GetType(Integer)), New NFieldInfo("Name", GetType(String)), New NFieldInfo("Price", GetType(Double))})

            For i = 0 To ProductInfos.Length - 1
                Dim productInfo = ProductInfos(i)
                dataTable.AddRow(i, productInfo.Name, productInfo.Price)
            Next

            Return New NDataSource(dataTable)
        End Function
        ''' <summary>
        ''' Creates a persons data source.
        ''' </summary>
        Public Function CreatePersonsDataSource() As NDataSource
            Dim dataTable As NMemoryDataTable = New NMemoryDataTable("Persons", New NFieldInfo() {New NFieldInfo("Id", GetType(Integer)), New NFieldInfo("Name", GetType(String), True), New NFieldInfo("Gender", GetType(ENGender), True), New NFieldInfo("Birthday", GetType(Date), True), New NFieldInfo("Country", GetType(ENCountry), True), New NFieldInfo("Phone", GetType(String), True), New NFieldInfo("Email", GetType(String), True)})

            For i = 0 To PersonInfos.Length - 1
                Dim info = PersonInfos(i)
                dataTable.AddRow(i, info.Name, info.Gender, info.Birthday, info.Country, info.Phone, info.Email)              ' id
                ' name
                ' gender
                ' birthday
                ' country
                ' pnone
                ' email
            Next

            Return New NDataSource(dataTable)
        End Function
        ''' <summary>
        ''' Creates a persons order data source.
        ''' </summary>
        Public Function CreatePersonsOrdersDataSource() As NDataSource
            Dim dataTable As NMemoryDataTable = New NMemoryDataTable("PersonsOrders", New NFieldInfo() {New NFieldInfo("PersonId", GetType(Integer)), New NFieldInfo("Product Name", GetType(String)), New NFieldInfo("Product Name1", GetType(String)), New NFieldInfo("Ship To Country", GetType(ENCountry)), New NFieldInfo("Ship To Country1", GetType(ENCountry)), New NFieldInfo("Ship To City", GetType(String)), New NFieldInfo("Ship To City1", GetType(String)), New NFieldInfo("Ship To Address", GetType(String)), New NFieldInfo("Ship To Address1", GetType(String)), New NFieldInfo("Price", GetType(Double)), New NFieldInfo("Price1", GetType(Double)), New NFieldInfo("Quantity", GetType(Integer))})

            For i = 0 To 9999
                Dim addressInfo As NAddressInfo = RandomAddressInfo()
                Dim productInfo As NProductInfo = RandomProductInfo()


                dataTable.AddRow(RandomPersonIndex(), productInfo.Name, productInfo.Name, addressInfo.Country, addressInfo.Country, addressInfo.City, addressInfo.City, addressInfo.Address, addressInfo.Address, productInfo.Price, productInfo.Price, Random.Next(5) + 1)    ' person id
                ' product name
                ' product name
                ' ship to country 
                ' ship to country 
                ' ship to city
                ' ship to city
                ' ship to address
                ' ship to address
                ' price
                ' price
                ' quantity
            Next

            Return New NDataSource(dataTable)
        End Function

#Region "Static Fields"

        Private Random As Random = New Random()

#End Region

#Region "Numbers"

        ''' <summary>
        ''' Creates a random double in the specified range.
        ''' </summary>
        ''' <paramname="min"></param>
        ''' <paramname="max"></param>
        ''' <returns></returns>
        Public Function RandomDouble(min As Integer, max As Integer) As Double
            Dim range = max - min
            Dim value = Random.Next(range)
            Return min + value
        End Function
        ''' <summary>
        ''' Creates a random Int32 in the specified range.
        ''' </summary>
        ''' <paramname="min"></param>
        ''' <paramname="max"></param>
        ''' <returns></returns>
        Public Function RandomInt32(min As Integer, max As Integer) As Integer
            Dim range = max - min
            Dim value = Random.Next(range)
            Return min + value
        End Function

#End Region

#Region "Company Names"

        ''' <summary>
        ''' Picks a random Company Name from the CompanyNames array.
        ''' </summary>
        ''' <returns></returns>
        Public Function RandomCompanyName() As String
            Dim count = CompanyNames.Length
            Dim index = Random.Next(count)
            Return CompanyNames(NMath.Clamp(0, count - 1, index))
        End Function
        ''' <summary>
        ''' List of dummy company names.
        ''' </summary>
        Public CompanyNames As String() = New String() {"Feugiat Metus Foundation", "Ligula Consectetuer Foundation", "Non LLC", "Tincidunt Institute", "Sollicitudin A Malesuada Industries", "Ornare In Faucibus Industries", "In Faucibus Industries", "Iaculis Aliquet Diam Company", "Porttitor Interdum LLC", "Egestas Duis Ltd", "Vel Turpis Aliquam LLC", "Ullamcorper Velit Associates", "Arcu Associates", "Sapien Aenean Massa PC", "Convallis Dolor Quisque PC", "A Ultricies Adipiscing Corp.", "Enim Corporation", "Luctus Sit Amet Consulting", "Eu PC", "Dui Nec Urna PC", "Pede Nonummy Consulting", "Vestibulum Mauris Company", "Consequat Ltd", "Mi Lacinia Mattis LLC", "Ultrices Vivamus Rhoncus PC", "Nec Ante Blandit LLP", "Sollicitudin Commodo Ipsum Corp.", "Diam Company", "Orci Corporation", "Tristique Pharetra Corporation", "Blandit Nam Limited", "Magna A Consulting", "Commodo Auctor Velit Ltd", "Donec Corporation", "Est Nunc Ullamcorper Foundation", "Accumsan Industries", "Ullamcorper Viverra LLC", "Ornare Ltd", "Pharetra Ltd", "Praesent Eu Institute", "Orci Tincidunt Incorporated", "Urna Vivamus Molestie Institute", "Ante Bibendum Company", "Aliquam Enim Nec Company", "Sem PC", "Euismod Est Limited", "Orci Lobortis Augue PC", "Curabitur Massa Vestibulum Institute", "Velit LLP", "Risus Foundation", "Sed Industries", "Dignissim Tempor Company", "Facilisis Corporation", "Aenean Massa Company", "Arcu Imperdiet Corp.", "Aliquam Corporation", "Nulla Facilisi Sed Associates", "Aliquam Arcu Aliquam Associates", "Ligula Incorporated", "Egestas Urna Justo Limited", "At Ltd", "Vivamus Sit Amet Corporation", "Lacus Aliquam Rutrum Company", "Enim Sit LLC", "Turpis Ltd", "Etiam Bibendum Fermentum Company", "Ultrices Iaculis Incorporated", "Penatibus Et Magnis Incorporated", "Aliquam Rutrum Industries", "Fringilla LLP", "Nonummy Fusce Corporation", "Nibh Vulputate Mauris Incorporated", "Praesent PC", "Lorem Ut Aliquam Consulting", "Est Incorporated", "Nisl Maecenas Corp.", "Lorem Sit Amet Ltd", "Lorem Company", "Risus Donec Egestas Corporation", "Sit Corporation", "Vulputate Associates", "Imperdiet Dictum Ltd", "Et Magna Praesent Incorporated", "Sem Eget LLP", "Rutrum Eu Incorporated", "Lorem Consulting", "Nisl Sem Consequat Industries", "Cubilia Curae; Industries", "Enim Corp.", "Arcu Corp.", "Suspendisse Tristique Neque Corp.", "Ut LLP", "Condimentum Donec Industries", "Aliquet Vel Vulputate Limited", "Imperdiet Institute", "Dictum Limited", "Duis Limited", "Augue Ac LLC", "Condimentum Donec Limited", "Consequat Company"}

#End Region

#Region "Person Infos"

        ''' <summary>
        ''' Picks a random Index in the PersonInfos array.
        ''' </summary>
        ''' <returns></returns>
        Public Function RandomPersonIndex() As Integer
            Dim count = PersonInfos.Length
            Dim index = Random.Next(count)
            Return NMath.Clamp(0, count - 1, index)
        End Function
        ''' <summary>
        ''' Picks a random NPersonInfo in the PersonInfos array.
        ''' </summary>
        ''' <returns></returns>
        Public Function RandomPersonInfo() As NPersonInfo
            Return PersonInfos(RandomPersonIndex())
        End Function
        ''' <summary>
        ''' List of dummy person names.
        ''' </summary>
        Public PersonInfos As NPersonInfo() = New NPersonInfo() {New NPersonInfo("Jinny Collazo", ENGender.Female), New NPersonInfo("John Duke", ENGender.Male), New NPersonInfo("Kellie Ferrell", ENGender.Female), New NPersonInfo("Sibyl Woosley", ENGender.Female), New NPersonInfo("Kourtney Mattoon", ENGender.Female), New NPersonInfo("Bruce Fail", ENGender.Male), New NPersonInfo("Dario Karl", ENGender.Male), New NPersonInfo("Aliza Sermons", ENGender.Female), New NPersonInfo("Sung Trout", ENGender.Male), New NPersonInfo("Barb Stiner", ENGender.Female), New NPersonInfo("Ashlie Bynum", ENGender.Female), New NPersonInfo("Carola Saeed", ENGender.Female), New NPersonInfo("Brunilda Hermanson", ENGender.Female), New NPersonInfo("Lois Capel", ENGender.Male), New NPersonInfo("Jerome Moody", ENGender.Male), New NPersonInfo("Booker Quach", ENGender.Male), New NPersonInfo("Malcolm Luckett", ENGender.Male), New NPersonInfo("Mana Snapp", ENGender.Female), New NPersonInfo("Georgianna Leung", ENGender.Female), New NPersonInfo("Romana Gentle", ENGender.Female), New NPersonInfo("Garfield Tranmer", ENGender.Male), New NPersonInfo("Rossana Heintzelman", ENGender.Female), New NPersonInfo("Carmina Vanorden", ENGender.Female), New NPersonInfo("Roger Patten", ENGender.Male), New NPersonInfo("Cleopatra Morrill", ENGender.Female), New NPersonInfo("Tammara Cumberbatch", ENGender.Female), New NPersonInfo("Vita Trinh", ENGender.Female), New NPersonInfo("Evangeline Aguinaldo", ENGender.Female), New NPersonInfo("Angelo Arzola", ENGender.Male), New NPersonInfo("Reynaldo Manahan", ENGender.Male), New NPersonInfo("Luis Peoples", ENGender.Male), New NPersonInfo("Sheena Fritsch", ENGender.Female), New NPersonInfo("Isaiah Key", ENGender.Female), New NPersonInfo("Sunny Vath", ENGender.Male), New NPersonInfo("Isidro Monsen", ENGender.Male), New NPersonInfo("Mariko Ek", ENGender.Female), New NPersonInfo("Jessenia Northup", ENGender.Female), New NPersonInfo("Cordie Lesage", ENGender.Female), New NPersonInfo("Henrietta Fuentes", ENGender.Female), New NPersonInfo("Han Snover", ENGender.Male), New NPersonInfo("Alesia Pearman", ENGender.Female), New NPersonInfo("Mai Czapla", ENGender.Female), New NPersonInfo("Maryam Torgersen", ENGender.Female), New NPersonInfo("Ken Vaca", ENGender.Male), New NPersonInfo("Martina Matson", ENGender.Female), New NPersonInfo("Blanche Desrochers", ENGender.Female), New NPersonInfo("Rosie Griffing", ENGender.Female), New NPersonInfo("Nona Mccroskey", ENGender.Female), New NPersonInfo("Arnold Mayen", ENGender.Male), New NPersonInfo("Yulanda Wenner", ENGender.Female)}











        ''' <summary>
        ''' Represents a fictional person information.
        ''' </summary>
        Public Class NPersonInfo
            Public Sub New(name As String, gender As ENGender)
                Me.Name = name
                Me.Gender = gender

                ' random birthday of 20-50 year olds
                Dim days = Random.Next(30 * 365) + 20 * 365
                Birthday = Date.Now - New TimeSpan(days, 0, 0, 0)

                ' random country
                Country = CType(Random.[Next](NEnum.GetValues(GetType(ENCountry)).Length), ENCountry)

                ' random phone
                Dim areaCode = Random.Next(999)
                Dim firstPhonePart = Random.Next(999)
                Dim secondPhonePart = Random.Next(9999)
                Phone = String.Format("({0})-{1}-{2}", areaCode.ToString("000"), firstPhonePart.ToString("000"), secondPhonePart.ToString("0000"))

                ' email
                Email = Me.Name.ToLower().Replace(" ", ".") & "@domain.com"
            End Sub

            Public Name As String
            Public Gender As ENGender
            Public Birthday As Date
            Public Country As ENCountry
            Public Phone As String
            Public Email As String
        End Class

#End Region

#Region "Product Names"

        ''' <summary>
        ''' Picks a random Product Name from the ProductNames array.
        ''' </summary>
        ''' <returns></returns>
        Public Function RandomProductInfo() As NProductInfo
            Return ProductInfos(RandomProductIndex())
        End Function
        ''' <summary>
        ''' Picks a random Index
        ''' </summary>
        ''' <returns></returns>
        Public Function RandomProductIndex() As Integer
            Dim count = ProductInfos.Length
            Dim index = Random.Next(count)
            Return NMath.Clamp(0, count - 1, index)
        End Function
        ''' <summary>
        ''' List of dummy product names.
        ''' </summary>
        Public ProductInfos As NProductInfo() = New NProductInfo() {New NProductInfo("Dingtincof"), New NProductInfo("Conremdox"), New NProductInfo("Sonlight"), New NProductInfo("Vivatom"), New NProductInfo("Trans Tax"), New NProductInfo("Super Matdox"), New NProductInfo("Geodomflex"), New NProductInfo("Re Zootop"), New NProductInfo("Hot-Lam"), New NProductInfo("Single-Top"), New NProductInfo("Tranhome"), New NProductInfo("Gravenimhold"), New NProductInfo("Zun Zimtam"), New NProductInfo("Ancore"), New NProductInfo("Zun Keydom"), New NProductInfo("Ontodex"), New NProductInfo("Freshdox"), New NProductInfo("Yearair"), New NProductInfo("Lam-Dox"), New NProductInfo("Toughcom"), New NProductInfo("Zoo Ing"), New NProductInfo("Aptax"), New NProductInfo("Statfan"), New NProductInfo("Joykix"), New NProductInfo("Indigolam"), New NProductInfo("Hattom")}
        ''' <summary>
        ''' Represents a fictional product
        ''' </summary>
        Public Class NProductInfo
            Public Sub New(name As String)
                Me.Name = name
                Price = (CDbl(Random.Next(8000)) + 2000) / 100
            End Sub
            Public Name As String
            Public Price As Double
        End Class

#End Region

#Region "Address Info"

        ''' <summary>
        ''' Picks a random NAddressInfo AddressInfo from the AddressInfos array
        ''' </summary>
        ''' <returns></returns>
        Public Function RandomAddressInfo() As NAddressInfo
            Return AddressInfos(RandomAddressIndex())
        End Function
        ''' <summary>
        ''' Picks a random index in the AddressInfos array
        ''' </summary>
        ''' <returns></returns>
        Public Function RandomAddressIndex() As Integer
            Dim count = AddressInfos.Length
            Dim index = Random.Next(count)
            Return NMath.Clamp(0, count - 1, index)
        End Function
        ''' <summary>
        ''' Array of fictional addresses
        ''' </summary>
        ' USA



        ' UK



        ' Germany



        ' France



        ' Russia



        ' Italy



        ' Canada



        ' China



        ' Japan



        ' India


        Public AddressInfos As NAddressInfo() = New NAddressInfo() {New NAddressInfo(ENCountry.USA, "New York", "7414 Park Place"), New NAddressInfo(ENCountry.USA, "New York", "1394 Bayberry Drive"), New NAddressInfo(ENCountry.USA, "New York", "9436 Parker Street"), New NAddressInfo(ENCountry.USA, "Los Angeles", "2101 William Street"), New NAddressInfo(ENCountry.USA, "Los Angeles", "5073 Eagle Street"), New NAddressInfo(ENCountry.USA, "Los Angeles", "439 Atlantic Avenue"), New NAddressInfo(ENCountry.USA, "Chicago", "245 Beech Street"), New NAddressInfo(ENCountry.USA, "Chicago", "420 Hamilton Road"), New NAddressInfo(ENCountry.USA, "Chicago", "540 Maple Lane "), New NAddressInfo(ENCountry.UK, "London", "854 Lawrence Street"), New NAddressInfo(ENCountry.UK, "London", "13 Park Street"), New NAddressInfo(ENCountry.UK, "London", "461 Front Street North"), New NAddressInfo(ENCountry.UK, "Birmingham", "281 4th Street North"), New NAddressInfo(ENCountry.UK, "Birmingham", "49 Division Street"), New NAddressInfo(ENCountry.UK, "Birmingham", "848 8th Street South"), New NAddressInfo(ENCountry.UK, "Leeds", "334 Catherine Street"), New NAddressInfo(ENCountry.UK, "Leeds", "885 Grant Street"), New NAddressInfo(ENCountry.UK, "Leeds", "468 Main Street"), New NAddressInfo(ENCountry.Germany, "Berlin", "Fischerinsel 81"), New NAddressInfo(ENCountry.Germany, "Berlin", "Budapester Strasse 14"), New NAddressInfo(ENCountry.Germany, "Berlin", "Knesebeckstrasse 1"), New NAddressInfo(ENCountry.Germany, "Hamburg", "Gotzkowskystrasse 74"), New NAddressInfo(ENCountry.Germany, "Hamburg", "Prenzlauer Allee 42"), New NAddressInfo(ENCountry.Germany, "Hamburg", "Am Borsigturm 60"), New NAddressInfo(ENCountry.Germany, "Munich", "An der Schillingbrucke 98"), New NAddressInfo(ENCountry.Germany, "Munich", "Rankestraße 2"), New NAddressInfo(ENCountry.Germany, "Munich", "An der Schillingbrucke 97"), New NAddressInfo(ENCountry.France, "Paris", "87, Rue de Strasbourg"), New NAddressInfo(ENCountry.France, "Paris", "73, place Stanislas"), New NAddressInfo(ENCountry.France, "Paris", "67, avenue Ferdinand de Lesseps"), New NAddressInfo(ENCountry.France, "Marseille", "30, rue Gontier-Patin"), New NAddressInfo(ENCountry.France, "Marseille", "65, rue Gontier-Patin"), New NAddressInfo(ENCountry.France, "Marseille", "20, rue Grande Fusterie"), New NAddressInfo(ENCountry.France, "Lyon", "57, Rue St Ferréol"), New NAddressInfo(ENCountry.France, "Lyon", "25, boulevard de Prague"), New NAddressInfo(ENCountry.France, "Lyon", "25, Avenue des Tuileries"), New NAddressInfo(ENCountry.Russia, "Moscow", "ul. Podgorska 67"), New NAddressInfo(ENCountry.Russia, "Moscow", "ul. Boleslawa 63"), New NAddressInfo(ENCountry.Russia, "Moscow", "ul. Dukielska 105"), New NAddressInfo(ENCountry.Russia, "Saint Petersburg", "ul. Uri Lubelsky 2"), New NAddressInfo(ENCountry.Russia, "Saint Petersburg", "ul. Tehniku 23"), New NAddressInfo(ENCountry.Russia, "Saint Petersburg", "ul. Ana Kolska 89"), New NAddressInfo(ENCountry.Russia, "Novosibirsk", "ul. Sobranie 45"), New NAddressInfo(ENCountry.Russia, "Novosibirsk", "ul. Pobeda 68"), New NAddressInfo(ENCountry.Russia, "Novosibirsk", "ul. Kolarski Les 46"), New NAddressInfo(ENCountry.Italy, "Rome", "Via Santa Teresa degli Scalzi, 55"), New NAddressInfo(ENCountry.Italy, "Rome", "Via Agostino Depretis, 110"), New NAddressInfo(ENCountry.Italy, "Rome", "Via Firenze, 59"), New NAddressInfo(ENCountry.Italy, "Milan", "Via Torricelli, 137"), New NAddressInfo(ENCountry.Italy, "Milan", "Via Nazario Sauro, 125"), New NAddressInfo(ENCountry.Italy, "Milan", "Via Zannoni, 19"), New NAddressInfo(ENCountry.Italy, "Naples", "Via del Caggio, 55"), New NAddressInfo(ENCountry.Italy, "Naples", "Corso Porta Borsari, 71"), New NAddressInfo(ENCountry.Italy, "Naples", "Via Santa Maria di Costantinopoli, 55"), New NAddressInfo(ENCountry.Canada, "Toronto", "1696 Heritage Drive"), New NAddressInfo(ENCountry.Canada, "Toronto", "592 Sturgeon Drive"), New NAddressInfo(ENCountry.Canada, "Toronto", "2188 York St"), New NAddressInfo(ENCountry.Canada, "Montreal", "4875 Bloor Street"), New NAddressInfo(ENCountry.Canada, "Montreal", "2458 Hammarskjold Dr"), New NAddressInfo(ENCountry.Canada, "Montreal", "3384 James Street"), New NAddressInfo(ENCountry.Canada, "Calgary", "4454 rue Saint-Édouard"), New NAddressInfo(ENCountry.Canada, "Calgary", "628 Merivale Road"), New NAddressInfo(ENCountry.Canada, "Calgary", "4748 Exmouth Street"), New NAddressInfo(ENCountry.China, "Shanghai", "No. 1234, 1241, Yun He Zhen Jie Fang Lu"), New NAddressInfo(ENCountry.China, "Shanghai", "No. 3452, 1983, 1013, Nan Yuan Lu"), New NAddressInfo(ENCountry.China, "Shanghai", "No. 8985, 1028, Feng Cun Wang Bo Zi"), New NAddressInfo(ENCountry.China, "Beijing", "No. 1034, 1179, Lin Jiang San Cun"), New NAddressInfo(ENCountry.China, "Beijing", "No. 1781, 1212, Fu Xing Hou Jie"), New NAddressInfo(ENCountry.China, "Beijing", "No. 1462, 1143, Qun Li Xiang"), New NAddressInfo(ENCountry.China, "Tianjin", "No. 1896, 1278, Bei Gang Gong Ye Lou"), New NAddressInfo(ENCountry.China, "Tianjin", "No. 1174, 1035, Xu Cheng Zhen Dui Bao Xiang"), New NAddressInfo(ENCountry.China, "Tianjin", "No. 1979, 1045, Nan Shen Gou"), New NAddressInfo(ENCountry.Japan, "Tokyo", "293-1086, Kozukayamate, Tarumi-ku Kobe-shi"), New NAddressInfo(ENCountry.Japan, "Tokyo", "493-1081, Takanodaiminami, Sugito-machi Kitakatsushika-gun"), New NAddressInfo(ENCountry.Japan, "Tokyo", "137-1285, Mizunaka, Takayama-mura Kamitakai-gun"), New NAddressInfo(ENCountry.Japan, "Yokohama", "185-1227, Mizuho, Hanamigawa-ku Chiba-shi"), New NAddressInfo(ENCountry.Japan, "Yokohama", "233-1273, Shimogamo Kodonocho, Sakyo-ku Kyoto-shi"), New NAddressInfo(ENCountry.Japan, "Yokohama", "396-1162, Nakata, Noheji-machi Kamikita-gun"), New NAddressInfo(ENCountry.Japan, "Osaka", "230-1058, Honen, Shirakawa-shi"), New NAddressInfo(ENCountry.Japan, "Osaka", "234-1267, Sechibarucho Akakoba, Sasebo-shi"), New NAddressInfo(ENCountry.Japan, "Osaka", "189-1273, Yorozuyamachi, Nagasaki-shi"), New NAddressInfo(ENCountry.India, "Bombay", "Kismat Nagar, Kurla West, Mumba, 173021"), New NAddressInfo(ENCountry.India, "Bombay", "Friends Colony, Hallow Pul, Kurla West, 573201"), New NAddressInfo(ENCountry.India, "Bombay", "Hallow Pul, Kurla West, 273001"), New NAddressInfo(ENCountry.India, "Calcutta", "Maulana Ishaque Street, Ar Rashidiyyah, General Ganj, 733051"), New NAddressInfo(ENCountry.India, "Calcutta", "Ar Rashidiyyah, General Ganj, Kanpur, 567825"), New NAddressInfo(ENCountry.India, "Calcutta", "General Ganj, Kanpur, Uttar Pradesh, 837547"), New NAddressInfo(ENCountry.India, "Delhi", "George Town Rd, George Town, Allahabad, 273001"), New NAddressInfo(ENCountry.India, "Delhi", "Hubli - Gadag Rd, Railway Colony, 123456"), New NAddressInfo(ENCountry.India, "Delhi", "Akshaibar Singh Marg, Golghar, Gorakhpur, 223152")}
        ''' <summary>
        ''' Represents a fictional address.
        ''' </summary>
        Public Class NAddressInfo
            Public Sub New(country As ENCountry, city As String, address As String)
                Me.Country = country
                Me.City = city
                Me.Address = address
            End Sub
            Public Country As ENCountry
            Public City As String
            Public Address As String
        End Class

#End Region
    End Module
End Namespace
