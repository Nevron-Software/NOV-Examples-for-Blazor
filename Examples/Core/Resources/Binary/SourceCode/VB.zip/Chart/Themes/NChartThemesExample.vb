Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Chart Themes Example
    ''' </summary>
    Public Class NChartThemesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NChartThemesExampleSchema = NSchema.Create(GetType(NChartThemesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ChartView = New NChartView()
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Chart Themes"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' add a bar series
            Dim random As Random = New Random()
            For i = 0 To 5
                Dim bar As NBarSeries = New NBarSeries()
                bar.Name = "Bar" & i.ToString()
                bar.MultiBarMode = ENMultiBarMode.Clustered
                bar.DataLabelStyle = New NDataLabelStyle(False)
                bar.ValueFormatter = New NNumericValueFormatter("0.###")
                chart.Series.Add(bar)

                For j = 0 To 5
                    bar.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
                Next
            Next

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return m_ChartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_ChartThemesComboBox = New NComboBox()
            m_ChartThemesComboBox.FillFromEnum(Of ENChartPalette)()
            Me.m_ChartThemesComboBox.SelectedIndexChanged += AddressOf OnChartThemesComboBoxSelectedIndexChanged
            stack.Add(m_ChartThemesComboBox)

            m_ColorDataPointsCheckBox = New NCheckBox("Color Data Points")
            Me.m_ColorDataPointsCheckBox.CheckedChanged += AddressOf OnColorDataPointsCheckBoxCheckedChanged
            stack.Add(m_ColorDataPointsCheckBox)

            m_ChartThemesComboBox.SelectedIndex = CInt(ENChartPalette.Autumn)
            m_ColorDataPointsCheckBox.Checked = True

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to apply different chart color themes.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnColorDataPointsCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(CType(m_ChartThemesComboBox.SelectedIndex, ENChartPalette), m_ColorDataPointsCheckBox.Checked))
        End Sub

        Private Sub OnChartThemesComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(CType(m_ChartThemesComboBox.SelectedIndex, ENChartPalette), m_ColorDataPointsCheckBox.Checked))
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView
        Private m_ChartThemesComboBox As NComboBox
        Private m_ColorDataPointsCheckBox As NCheckBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NChartThemesExampleSchema As NSchema

#End Region
    End Class
End Namespace
