Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Scatter Funnel Example
    ''' </summary>
    Public Class NScatterFunnel3DExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NScatterFunnel3DExampleSchema = NSchema.Create(GetType(NScatterFunnel3DExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateFunnelChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Scatter Funnel 3D"

            Dim funnelChart = CType(chartView.Surface.Charts(0), NFunnelChart)
            funnelChart.Enable3D = True
            funnelChart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.BrightCameraLight)
            funnelChart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            funnelChart.Interactor = New NInteractor(New NTrackballTool())

            m_FunnelSeries = New NFunnelSeries()
            m_FunnelSeries.UseXValues = True
            m_FunnelSeries.Shape = ENFunnelShape.Rectangle
            m_FunnelSeries.DataLabelStyle = New NDataLabelStyle(True)
            m_FunnelSeries.DataLabelStyle.VertAlign = ENVerticalAlignment.Center
            m_FunnelSeries.LabelMode = ENFunnelLabelMode.LeftAligned

            funnelChart.Series.Add(m_FunnelSeries)

            GenerateData()

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim funnelShapeCombo As NComboBox = New NComboBox()
            funnelShapeCombo.FillFromEnum(Of ENFunnelShape)()
            funnelShapeCombo.SelectedIndexChanged += AddressOf OnFunnelShapeComboSelectedIndexChanged
            funnelShapeCombo.SelectedIndex = CInt(ENFunnelShape.Rectangle)
            stack.Add(NPairBox.Create("Funnel Shape:", funnelShapeCombo))

            Dim labelAligmentModeCombo As NComboBox = New NComboBox()
            labelAligmentModeCombo.FillFromEnum(Of ENFunnelLabelMode)()
            labelAligmentModeCombo.SelectedIndexChanged += AddressOf OnLabelAligmentModeComboSelectedIndexChanged
            labelAligmentModeCombo.SelectedIndex = CInt(ENFunnelLabelMode.Center)
            stack.Add(NPairBox.Create("Label Alignment:", labelAligmentModeCombo))

            Dim labelArrowLengthUpDown As NNumericUpDown = New NNumericUpDown()
            labelArrowLengthUpDown.Value = m_FunnelSeries.LabelArrowLength
            labelArrowLengthUpDown.ValueChanged += AddressOf OnLabelArrowLengthUpDownValueChanged
            stack.Add(NPairBox.Create("Label Arrow Length:", labelArrowLengthUpDown))

            Dim pointGapUpDown As NNumericUpDown = New NNumericUpDown()
            pointGapUpDown.Value = m_FunnelSeries.PointGapPercent
            pointGapUpDown.ValueChanged += AddressOf OnPointGapUpDownValueChanged
            stack.Add(NPairBox.Create("Point Gap Percent:", pointGapUpDown))

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a scatter 3D funnel chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnLabelArrowLengthUpDownValueChanged(arg As NValueChangeEventArgs)
            m_FunnelSeries.LabelArrowLength = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnLabelAligmentModeComboSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_FunnelSeries.LabelMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENFunnelLabelMode)
        End Sub

        Private Sub OnPointGapUpDownValueChanged(arg As NValueChangeEventArgs)
            m_FunnelSeries.PointGapPercent = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnFunnelShapeComboSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_FunnelSeries.Shape = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENFunnelShape)
        End Sub

#End Region

#Region "Implementation"

        Private Sub GenerateData()
            m_FunnelSeries.DataPoints.Clear()

            Dim dSizeX As Double = 100

            Dim random As Random = New Random()

            For i = 0 To 11
                m_FunnelSeries.DataPoints.Add(New NFunnelDataPoint(random.Next(100) + 1, dSizeX))

                dSizeX -= random.NextDouble() * 9
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_FunnelSeries As NFunnelSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NScatterFunnel3DExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateFunnelChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Funnel)
            Return chartView
        End Function

#End Region
    End Class
End Namespace
