Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard HighLow Example
    ''' </summary>
    Public Class NStandardHighLowExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardHighLowExampleSchema = NSchema.Create(GetType(NStandardHighLowExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard High Low"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True

            m_HighLow = New NHighLowSeries()
            m_HighLow.Name = "High-Low Series"
            m_HighLow.HighFill = New NColorFill(NColor.Gray)
            m_HighLow.LowFill = New NColorFill(NColor.Orange)
            m_HighLow.HighStroke = New NStroke(2, NColor.Black)
            m_HighLow.LowStroke = New NStroke(2, NColor.Red)
            m_HighLow.Stroke = New NStroke(2, NColor.Black)
            m_HighLow.DataLabelStyle = New NDataLabelStyle(False)
            m_HighLow.Palette = New NTwoColorPalette(NColor.Red, NColor.Green)

            GenerateData()

            m_Chart.Series.Add(m_HighLow)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim appearanceModeComboBox As NComboBox = New NComboBox()
            appearanceModeComboBox.FillFromEnum(Of ENHighLowAppearanceMode)()
            appearanceModeComboBox.SelectedIndexChanged += AddressOf OnAppearanceModeComboBoxSelectedIndexChanged
            appearanceModeComboBox.SelectedIndex = CInt(ENHighLowAppearanceMode.HighLow)
            stack.Add(NPairBox.Create("Appearance Mode:", appearanceModeComboBox))

            Dim showDropLinesCheckBox As NCheckBox = New NCheckBox("Show Droplines")
            showDropLinesCheckBox.CheckedChanged += AddressOf OnShowDropLinesCheckBoxCheckedChanged
            stack.Add(showDropLinesCheckBox)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard high low chart.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub GenerateData()
            m_HighLow.DataPoints.Clear()

            Dim random As Random = New Random()

            For i = 0 To 19
                Dim d1 As Double = Math.Log(i + 1) + 0.1 * random.NextDouble()
                Dim d2 As Double = d1 + Math.Cos(0.33 * i) + 0.1 * random.NextDouble()

                m_HighLow.DataPoints.Add(New NHighLowDataPoint(d1, d2))
            Next
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnAppearanceModeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_HighLow.AppearanceMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENHighLowAppearanceMode)
        End Sub

        Private Sub OnShowDropLinesCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_HighLow.ShowDropLines = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Fields"

        Private m_HighLow As NHighLowSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardHighLowExampleSchema As NSchema

#End Region
    End Class
End Namespace
