Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Stick Stock Example
    ''' </summary>
    Public Class NStickStockExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStickStockExampleSchema = NSchema.Create(GetType(NStickStockExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Stick Stock"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' setup X axis
            Dim axis = m_Chart.Axes(ENCartesianAxis.PrimaryX)

            axis.Scale = New NValueTimelineScale()

            ' setup primary Y axis
            axis = m_Chart.Axes(ENCartesianAxis.PrimaryY)
            Dim linearScale = CType(axis.Scale, NLinearScale)

            ' configure ticks and grid lines
            linearScale.MajorGridLines.Stroke = New NStroke(NColor.LightGray)
            linearScale.InnerMajorTicks.Visible = False

            ' add interlaced stripe 
            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Fill = New NColorFill(NColor.Beige)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' Setup the stock series
            m_Stock = New NStockSeries()
            m_Chart.Series.Add(m_Stock)

            m_Stock.DataLabelStyle = New NDataLabelStyle(False)
            m_Stock.CandleShape = ENCandleShape.Stick
            m_Stock.CandleWidth = 4
            m_Stock.UseXValues = True

            GenerateData()

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)


            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a stick stock chart.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub GenerateData()
            ' generate data for 30 weeks
            Dim dtNow = Date.Now
            Dim dtEnd As Date = New DateTime(dtNow.Year, dtNow.Month, dtNow.Day, 7, 0, 0, 0)
            Dim dtStart As Date = NDateTimeUnit.Week.Add(dtEnd, -30)
            Dim span As NDateTimeSpan = New NDateTimeSpan(1, NDateTimeUnit.Day)

            Dim count As Long = span.GetSpanCountInRange(New NDateTimeRange(dtStart, dtEnd))

            Dim open, high, low, close As Double

            m_Stock.DataPoints.Clear()
            Dim random As Random = New Random()

            Dim prevClose As Double = 100

            For nIndex As Integer = 0 To count - 1
                open = prevClose

                If prevClose < 25 OrElse random.NextDouble() > 0.5 Then
                    ' upward price change
                    close = open + (2 + (random.NextDouble() * 20))
                    high = close + (random.NextDouble() * 10)
                    low = open - (random.NextDouble() * 10)
                Else
                    ' downward price change
                    close = open - (2 + (random.NextDouble() * 20))
                    high = open + (random.NextDouble() * 10)
                    low = close - (random.NextDouble() * 10)
                End If

                If low < 1 Then
                    low = 1
                End If

                prevClose = close

                m_Stock.DataPoints.Add(New NStockDataPoint(NDateTimeHelpers.ToOADate(dtNow), open, close, high, low))
                dtNow = span.Add(dtNow)
            Next
        End Sub

#End Region

#Region "Event Handlers"


#End Region

#Region "Fields"

        Private m_Stock As NStockSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NStickStockExampleSchema As NSchema

#End Region
    End Class
End Namespace
