Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Bar Example
    ''' </summary>
    Public Class NStandardBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardBarExampleSchema = NSchema.Create(GetType(NStandardBarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Bar"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' setup a bar series
            m_Bar = New NBarSeries()
            m_Bar.Name = "Bar Series"
            m_Bar.InflateMargins = True
            m_Bar.UseXValues = False

            m_Bar.Shadow = New NShadow(NColor.LightGray, 2, 2)

            ' add some data to the bar series
            m_Bar.LegendView.Mode = ENSeriesLegendMode.DataPoints
            m_Bar.DataPoints.Add(New NBarDataPoint(18, "C++"))
            m_Bar.DataPoints.Add(New NBarDataPoint(15, "Ruby"))
            m_Bar.DataPoints.Add(New NBarDataPoint(21, "Python"))
            m_Bar.DataPoints.Add(New NBarDataPoint(23, "Java"))
            m_Bar.DataPoints.Add(New NBarDataPoint(27, "Javascript"))
            m_Bar.DataPoints.Add(New NBarDataPoint(29, "C#"))
            m_Bar.DataPoints.Add(New NBarDataPoint(26, "PHP"))

            chart.Series.Add(m_Bar)

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim originModeComboBox As NComboBox = New NComboBox()
            originModeComboBox.FillFromEnum(Of ENSeriesOriginMode)()
            originModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnOriginModeComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Origin Mode: ", originModeComboBox))

            Dim customOriginUpDown As NNumericUpDown = New NNumericUpDown()
            customOriginUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnCustomOriginUpDownValueChanged)
            stack.Add(NPairBox.Create("Custom Origin: ", customOriginUpDown))

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard bar chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCustomOriginUpDownValueChanged(arg As NValueChangeEventArgs)
            m_Bar.CustomOrigin = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnOriginModeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_Bar.OriginMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENSeriesOriginMode)
        End Sub

#End Region

#Region "Fields"

        Private m_Bar As NBarSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardBarExampleSchema As NSchema

#End Region
    End Class
End Namespace
