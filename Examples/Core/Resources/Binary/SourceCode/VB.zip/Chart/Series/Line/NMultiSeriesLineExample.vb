Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Multi Series Line Example
    ''' </summary>
    Public Class NMultiSeriesLineExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NMultiSeriesLineExampleSchema = NSchema.Create(GetType(NMultiSeriesLineExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Multi Series Line Chart"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup chart
            m_Chart.Enable3D = True
            m_Chart.ModelWidth = 60
            m_Chart.ModelHeight = 25
            m_Chart.ModelDepth = 45
            m_Chart.Projection.ProjectionType = ENProjectionType.Perspective
            m_Chart.Projection.Elevation = 28
            m_Chart.Projection.Rotation = -17
            m_Chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.GlitterLeft)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.Standard)

            ' add interlaced stripe to the Y axis
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.SetShowAtWall(ENChartWall.Back, True)
            strip.SetShowAtWall(ENChartWall.Left, True)
            strip.Interlaced = True
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NStandardScale).Strips.Add(strip)

            ' show the X axis gridlines
            Dim ordinalScale As NOrdinalScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale, NOrdinalScale)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)

            ' add the first line
            m_Line1 = New NLineSeries()
            m_Chart.Series.Add(m_Line1)
            m_Line1.MultiLineMode = ENMultiLineMode.Series
            m_Line1.LineSegmentShape = ENLineSegmentShape.Tape
            m_Line1.DepthPercent = 50
            m_Line1.Name = "Line 1"

            ' add the second line
            m_Line2 = New NLineSeries()
            m_Chart.Series.Add(m_Line2)
            m_Line2.MultiLineMode = ENMultiLineMode.Series
            m_Line2.LineSegmentShape = ENLineSegmentShape.Tape
            m_Line2.DepthPercent = 50
            m_Line2.Name = "Line 2"

            ' add the third line
            m_Line3 = New NLineSeries()
            m_Chart.Series.Add(m_Line3)
            m_Line3.MultiLineMode = ENMultiLineMode.Series
            m_Line3.LineSegmentShape = ENLineSegmentShape.Tape
            m_Line3.DepthPercent = 50
            m_Line3.Name = "Line 3"

            GenerateData()

            ' apply style sheet
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Fresh, False))

            Return chartView
        End Function

        Private Sub GenerateData()
            Dim random As Random = New Random()

            For i = 0 To 6
                m_Line1.DataPoints.Add(New NLineDataPoint(random.Next(100)))
                m_Line2.DataPoints.Add(New NLineDataPoint(random.Next(100)))
                m_Line3.DataPoints.Add(New NLineDataPoint(random.Next(100)))
            Next
        End Sub

        Private Sub NewDataButton_Click(sender As Object, e As EventArgs)
            GenerateData()
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim chartDepthScrollBar As NHScrollBar = New NHScrollBar()
            chartDepthScrollBar.Value = m_Chart.ModelDepth
            chartDepthScrollBar.ValueChanged += AddressOf ChartDepthScrollBar_ValueChanged
            stack.Add(NPairBox.Create("Chart Depth:", chartDepthScrollBar))

            Dim lineDepthScrollBar As NHScrollBar = New NHScrollBar()
            lineDepthScrollBar.Value = m_Line1.DepthPercent
            lineDepthScrollBar.ValueChanged += AddressOf LineDepthScrollBar_ValueChanged
            stack.Add(NPairBox.Create("Line Depth:", lineDepthScrollBar))

            Return group
        End Function

        Private Sub LineDepthScrollBar_ValueChanged(arg As NValueChangeEventArgs)
            Dim depthPercent = Convert.ToSingle(arg.NewValue)

            m_Line1.DepthPercent = depthPercent
            m_Line2.DepthPercent = depthPercent
            m_Line3.DepthPercent = depthPercent
        End Sub

        Private Sub ChartDepthScrollBar_ValueChanged(arg As NValueChangeEventArgs)
            m_Chart.ModelDepth = Convert.ToSingle(arg.NewValue)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a multi-series line chart where lines occupy a specified percentage of their category.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Line1 As NLineSeries
        Private m_Line2 As NLineSeries
        Private m_Line3 As NLineSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NMultiSeriesLineExampleSchema As NSchema

#End Region
    End Class
End Namespace
