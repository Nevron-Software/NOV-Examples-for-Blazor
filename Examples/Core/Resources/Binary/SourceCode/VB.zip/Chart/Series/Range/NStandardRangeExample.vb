Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Range Example
    ''' </summary>
    Public Class NStandardRangeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardRangeExampleSchema = NSchema.Create(GetType(NStandardRangeExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Range"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' setup X axis
            Dim xScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale

            xScale.MajorGridLines.Visible = True

            ' setup Y axis
            Dim yScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
            yScale.MajorGridLines.Visible = True

            ' add interlaced stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            yScale.Strips.Add(strip)

            ' setup shape series
            m_Range = New NRangeSeries()
            m_Chart.Series.Add(m_Range)

            m_Range.DataLabelStyle = New NDataLabelStyle(False)
            m_Range.UseXValues = True
            m_Range.Fill = New NColorFill(NColor.DarkOrange)
            m_Range.Stroke = New NStroke(NColor.DarkRed)

            ' fill data
            Dim intervals = New Double() {5, 5, 5, 5, 5, 5, 5, 5, 5, 15, 30, 60}
            Dim values = New Double() {4180, 13687, 18618, 19634, 17981, 7190, 16369, 3212, 4122, 9200, 6461, 3435}

            Dim count = Math.Min(intervals.Length, values.Length)
            Dim x As Double = 0

            For i = 0 To count - 1
                Dim interval = intervals(i)
                Dim value = values(i)

                Dim x1 = x
                Dim y1 As Double = 0

                x += interval
                Dim x2 = x
                Dim y2 = value / interval

                m_Range.DataPoints.Add(New NRangeDataPoint(x1, y1, x2, y2))
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim rangeShapeComboBox As NComboBox = New NComboBox()
            rangeShapeComboBox.FillFromEnum(Of ENBarShape)()
            rangeShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRangeShapeComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Range Shape: ", rangeShapeComboBox))

            Dim showDataLabels As NCheckBox = New NCheckBox("Show Data Labels")
            showDataLabels.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowDataLabelsCheckedChanged)
            stack.Add(showDataLabels)

            rangeShapeComboBox.SelectedIndex = CInt(ENBarShape.Rectangle)
            showDataLabels.Checked = False

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard range chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnShowDataLabelsCheckedChanged(arg As NValueChangeEventArgs)
            If TryCast(arg.TargetNode, NCheckBox).Checked Then
                m_Range.DataLabelStyle = New NDataLabelStyle(True)
                m_Range.DataLabelStyle.Format = "<y2>"
            Else
                m_Range.DataLabelStyle = New NDataLabelStyle(False)
            End If
        End Sub

        Private Sub OnRangeShapeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_Range.Shape = CType(TryCast(arg.TargetNode, NComboBox).SelectedIndex, ENBarShape)
        End Sub

#End Region

#Region "Fields"

        Private m_Range As NRangeSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardRangeExampleSchema As NSchema

#End Region
    End Class
End Namespace
