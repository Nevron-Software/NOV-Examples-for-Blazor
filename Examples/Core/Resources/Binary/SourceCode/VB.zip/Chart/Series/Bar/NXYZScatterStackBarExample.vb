Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Cluster Bar Example
    ''' </summary>
    Public Class NXYZScatterStackBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NXYZScatterStackBarExampleSchema = NSchema.Create(GetType(NXYZScatterStackBarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "XYZ Scatter Stack"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.Standard)

            ' configure title
            chartView.Surface.Titles(0).Text = "XYZ Stack Bar"

            ' set predefined projection and lighting
            m_Chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            m_Chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.BrightCameraLight)
            m_Chart.ModelWidth = 50
            m_Chart.ModelHeight = 35
            m_Chart.ModelDepth = 50
            m_Chart.Enable3D = True
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            ' configure the axes
            Dim linearScale As NLinearScale = New NLinearScale()
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = linearScale
            linearScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            linearScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)

            linearScale = New NLinearScale()
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = linearScale
            linearScale.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            linearScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)

            ' add interlace stripes to the Y axis
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.SetShowAtWall(ENChartWall.Back, True)
            stripStyle.SetShowAtWall(ENChartWall.Left, True)
            stripStyle.Interlaced = True
            linearScale.Strips.Add(stripStyle)

            linearScale = New NLinearScale()
            m_Chart.Axes(ENCartesianAxis.Depth).Scale = New NOrdinalScale()

            linearScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            linearScale.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)

            AddBarSeries(m_Chart, ENMultiBarMode.Series)
            AddBarSeries(m_Chart, ENMultiBarMode.Stacked)
            AddBarSeries(m_Chart, ENMultiBarMode.Stacked)
            AddBarSeries(m_Chart, ENMultiBarMode.Stacked)

            OnNewDataButtonClick(Nothing)

            Return chartView
        End Function

        Private Sub AddBarSeries(chart As NCartesianChart, mode As ENMultiBarMode)
            Dim bar As NBarSeries = New NBarSeries()
            chart.Series.Add(bar)
            bar.WidthSizeMode = ENBarSizeMode.Fixed
            bar.DepthSizeMode = ENBarSizeMode.Fixed
            bar.MultiBarMode = mode
            bar.UseXValues = True
            bar.UseZValues = True
            bar.InflateMargins = True
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim propertyStack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(propertyStack)

            Dim newDataButton As NButton = New NButton("New Data")
            newDataButton.Click += AddressOf OnNewDataButtonClick
            propertyStack.Add(newDataButton)

            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a cluster bar chart.</p>"
        End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates a new data label style object
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateDataLabelStyle() As NDataLabelStyle
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()

            dataLabelStyle.Format = "<value>"

            Return dataLabelStyle
        End Function

        Private Sub GenerateXYZData(bar As NBarSeries)
            bar.DataPoints.Clear()

            Dim random As Random = New Random()

            For i = 0 To c_DataPointCount - 1
                Dim dataPoint As NBarDataPoint = New NBarDataPoint()

                dataPoint.X = random.NextDouble() * 5
                dataPoint.Z = random.NextDouble() * 5
                dataPoint.Y = random.NextDouble()

                bar.DataPoints.Add(dataPoint)
            Next
        End Sub

        Private Sub GenerateYData(bar As NBarSeries)
            bar.DataPoints.Clear()

            Dim random As Random = New Random()

            For i = 0 To c_DataPointCount - 1
                bar.DataPoints.Add(New NBarDataPoint(random.NextDouble()))
            Next
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnNewDataButtonClick(arg As NEventArgs)
            For i = 0 To m_Chart.Series.Count - 1
                Dim bar = CType(m_Chart.Series(i), NBarSeries)

                If i = 0 Then
                    ' the master series needs Y, X and Z values
                    GenerateXYZData(bar)
                Else
                    ' the other series need only Y values
                    GenerateYData(bar)
                End If
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Static Fields"

        Private Const c_DataPointCount As Integer = 10

#End Region

#Region "Schema"

        Public Shared ReadOnly NXYZScatterStackBarExampleSchema As NSchema

#End Region
    End Class
End Namespace
