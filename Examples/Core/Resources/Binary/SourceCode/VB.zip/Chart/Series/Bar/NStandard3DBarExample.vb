Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Bar Example
    ''' </summary>
    Public Class NStandard3DBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandard3DBarExampleSchema = NSchema.Create(GetType(NStandard3DBarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard 3D Bar"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.Enable3D = True
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.YLinearXZOrdinal)

            chart.Axes(ENCartesianAxis.Depth).Visible = True
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.Perspective1)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.GlitterLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' setup a bar series
            m_Bar = New NBarSeries()
            m_Bar.Name = "Bar Series"
            m_Bar.InflateMargins = True
            m_Bar.UseXValues = False

            m_Bar.Shadow = New NShadow(NColor.LightGray, 2, 2)

            ' add some data to the bar series
            m_Bar.LegendView.Mode = ENSeriesLegendMode.DataPoints
            m_Bar.DataPoints.Add(New NBarDataPoint(18, "C++"))
            m_Bar.DataPoints.Add(New NBarDataPoint(15, "Ruby"))
            m_Bar.DataPoints.Add(New NBarDataPoint(21, "Python"))
            m_Bar.DataPoints.Add(New NBarDataPoint(23, "Java"))
            m_Bar.DataPoints.Add(New NBarDataPoint(27, "Javascript"))
            m_Bar.DataPoints.Add(New NBarDataPoint(29, "C#"))
            m_Bar.DataPoints.Add(New NBarDataPoint(26, "PHP"))

            chart.Series.Add(m_Bar)

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            If True Then
                Dim originModeComboBox As NComboBox = New NComboBox()
                originModeComboBox.FillFromEnum(Of ENSeriesOriginMode)()
                originModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnOriginModeComboBoxSelectedIndexChanged)
                stack.Add(NPairBox.Create("Origin Mode: ", originModeComboBox))
            End If

            If True Then
                Dim customOriginUpDown As NNumericUpDown = New NNumericUpDown()
                customOriginUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnCustomOriginUpDownValueChanged)
                stack.Add(NPairBox.Create("Custom Origin: ", customOriginUpDown))
            End If

            If True Then
                Dim barShapeCompboBox As NComboBox = New NComboBox()
                barShapeCompboBox.FillFromEnum(Of ENBarShape)()
                barShapeCompboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnBarShapeComboBoxSelectedIndexChanged)
                stack.Add(NPairBox.Create("Bar Shape: ", barShapeCompboBox))
            End If

            If True Then
                Dim widthPercentScrollbar As NHScrollBar = New NHScrollBar()
                widthPercentScrollbar.Minimum = 0
                widthPercentScrollbar.Maximum = 100
                widthPercentScrollbar.ValueChanged += AddressOf OnWidthPercentScrollbarValueChanged
                widthPercentScrollbar.Value = 20
                stack.Add(NPairBox.Create("Width Gap %: ", widthPercentScrollbar))
            End If

            If True Then
                Dim depthPercentScrollbar As NHScrollBar = New NHScrollBar()
                depthPercentScrollbar.Minimum = 0
                depthPercentScrollbar.Maximum = 100
                depthPercentScrollbar.ValueChanged += AddressOf OnDepthPercentScrollbarValueChanged
                depthPercentScrollbar.Value = 20
                stack.Add(NPairBox.Create("Depth Gap %: ", depthPercentScrollbar))
            End If

            Return boxGroup
        End Function



        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard 3D bar chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCustomOriginUpDownValueChanged(arg As NValueChangeEventArgs)
            m_Bar.CustomOrigin = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnOriginModeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_Bar.OriginMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENSeriesOriginMode)
        End Sub

        Private Sub OnBarShapeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_Bar.Shape = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENBarShape)
        End Sub

        Private Sub OnWidthPercentScrollbarValueChanged(arg As NValueChangeEventArgs)
            m_Bar.WidthGapFactor = CType(arg.TargetNode, NHScrollBar).Value / 100
        End Sub

        Private Sub OnDepthPercentScrollbarValueChanged(arg As NValueChangeEventArgs)
            m_Bar.DepthGapFactor = CType(arg.TargetNode, NHScrollBar).Value / 100
        End Sub

#End Region

#Region "Fields"

        Private m_Bar As NBarSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandard3DBarExampleSchema As NSchema

#End Region
    End Class
End Namespace
