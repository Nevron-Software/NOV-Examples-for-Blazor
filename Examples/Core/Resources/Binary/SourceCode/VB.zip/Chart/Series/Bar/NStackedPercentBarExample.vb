Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Stacked Percent Bar Example
    ''' </summary>
    Public Class NStackedPercentBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStackedPercentBarExampleSchema = NSchema.Create(GetType(NStackedPercentBarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Stacked Percent Bar"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            linearScale.Labels.TextProvider = New NFormattedScaleLabelTextProvider(New NNumericValueFormatter("P"))
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            linearScale.Strips.Add(stripStyle)

            ' add the first bar
            m_Bar1 = New NBarSeries()
            m_Bar1.Name = "Bar1"
            m_Bar1.MultiBarMode = ENMultiBarMode.Series
            chart.Series.Add(m_Bar1)

            ' add the second bar
            m_Bar2 = New NBarSeries()
            m_Bar2.Name = "Bar2"
            m_Bar2.MultiBarMode = ENMultiBarMode.StackedPercent
            chart.Series.Add(m_Bar2)

            ' add the third bar
            m_Bar3 = New NBarSeries()
            m_Bar3.Name = "Bar3"
            m_Bar3.MultiBarMode = ENMultiBarMode.StackedPercent
            chart.Series.Add(m_Bar3)

            ' setup value formatting
            m_Bar1.ValueFormatter = New NNumericValueFormatter("0.###")
            m_Bar2.ValueFormatter = New NNumericValueFormatter("0.###")
            m_Bar3.ValueFormatter = New NNumericValueFormatter("0.###")

            ' position data labels in the center of the bars
            m_Bar1.DataLabelStyle = CreateDataLabelStyle()
            m_Bar2.DataLabelStyle = CreateDataLabelStyle()
            m_Bar3.DataLabelStyle = CreateDataLabelStyle()

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            ' pass some data
            OnPositiveDataButtonClick(Nothing)

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim firstBarLabelFormatComboBox As NComboBox = CreateLabelFormatComboBox()
            firstBarLabelFormatComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFirstBarLabelFormatComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("First Bar Label Format: ", firstBarLabelFormatComboBox))

            Dim secondBarLabelFormatComboBox As NComboBox = CreateLabelFormatComboBox()
            secondBarLabelFormatComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSecondBarLabelFormatComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Second Bar Label Format: ", secondBarLabelFormatComboBox))

            Dim thirdBarLabelFormatComboBox As NComboBox = CreateLabelFormatComboBox()
            thirdBarLabelFormatComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnThirdBarLabelFormatComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Third Bar Label Format: ", thirdBarLabelFormatComboBox))

            Dim positiveDataButton As NButton = New NButton("Positive Values")
            positiveDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnPositiveDataButtonClick)
            stack.Add(positiveDataButton)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a stacked percent bar chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnFirstBarLabelFormatComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim comboBox = CType(arg.TargetNode, NComboBox)
            m_Bar1.DataLabelStyle.Format = CStr(comboBox.Items(comboBox.SelectedIndex).Tag)
        End Sub

        Private Sub OnSecondBarLabelFormatComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim comboBox = CType(arg.TargetNode, NComboBox)
            m_Bar2.DataLabelStyle.Format = CStr(comboBox.Items(comboBox.SelectedIndex).Tag)
        End Sub

        Private Sub OnThirdBarLabelFormatComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim comboBox = CType(arg.TargetNode, NComboBox)
            m_Bar3.DataLabelStyle.Format = CStr(comboBox.Items(comboBox.SelectedIndex).Tag)
        End Sub

        Private Sub OnPositiveDataButtonClick(arg As NEventArgs)
            m_Bar1.DataPoints.Clear()
            m_Bar2.DataPoints.Clear()
            m_Bar3.DataPoints.Clear()

            Dim random As Random = New Random()
            For i = 0 To 11
                m_Bar1.DataPoints.Add(New NBarDataPoint(random.Next(90) + 10))
                m_Bar2.DataPoints.Add(New NBarDataPoint(random.Next(90) + 10))
                m_Bar3.DataPoints.Add(New NBarDataPoint(random.Next(90) + 10))
            Next
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates a new data label style object
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateDataLabelStyle() As NDataLabelStyle
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()

            dataLabelStyle.VertAlign = ENVerticalAlignment.Center
            dataLabelStyle.ArrowLength = 0

            Return dataLabelStyle
        End Function
        ''' <summary>
        ''' Gets a format string from the specified index
        ''' </summary>
        ''' <paramname="index"></param>
        ''' <returns></returns>
        Private Function GetFormatStringFromIndex(index As Integer) As String
            Select Case index
                Case 0
                    Return "<value>"

                Case 1
                    Return "<total>"

                Case 2
                    Return "<cumulative>"

                Case 3
                    Return "<percent>"
                Case Else
                    Return ""
            End Select
        End Function
        ''' <summary>
        ''' Creates a label format combo box
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateLabelFormatComboBox() As NComboBox
            Dim comboBox As NComboBox = New NComboBox()

            Dim comboBoxItem As NComboBoxItem = New NComboBoxItem("Value")
            comboBoxItem.Tag = "<value>"
            comboBox.Items.Add(comboBoxItem)

            comboBoxItem = New NComboBoxItem("Total")
            comboBoxItem.Tag = "<total>"
            comboBox.Items.Add(comboBoxItem)

            comboBoxItem = New NComboBoxItem("Cumulative")
            comboBoxItem.Tag = "<cumulative>"
            comboBox.Items.Add(comboBoxItem)

            comboBoxItem = New NComboBoxItem("Percent")
            comboBoxItem.Tag = "<percent>"
            comboBox.Items.Add(comboBoxItem)

            comboBox.SelectedIndex = 0

            Return comboBox
        End Function

#End Region

#Region "Fields"

        Private m_Bar1 As NBarSeries
        Private m_Bar2 As NBarSeries
        Private m_Bar3 As NBarSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NStackedPercentBarExampleSchema As NSchema

#End Region
    End Class
End Namespace
