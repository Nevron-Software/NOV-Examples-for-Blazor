Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Doughnut Pie Example
    ''' </summary>
    Public Class NDoughnutPie3DExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NDoughnutPie3DExampleSchema = NSchema.Create(GetType(NDoughnutPie3DExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreatePieChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Doughnut Pie 3D"

            ' configure chart
            m_PieChart = CType(chartView.Surface.Charts(0), NPieChart)
            m_PieChart.Enable3D = True
            m_PieChart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.BrightCameraLight)
            m_PieChart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveElevated)
            m_PieChart.Interactor = New NInteractor(New NTrackballTool())

            m_PieChart.BeginRadiusPercent = 20
            m_PieChart.LabelLayout.EnableInitialPositioning = False
            Dim labels = New String() {"Ships", "Trains", "Automobiles", "Airplanes"}

            Dim random As Random = New Random()

            For i = 0 To 3
                Dim pieSeries As NPieSeries = New NPieSeries()

                ' create a small detachment between pie rings
                pieSeries.BeginRadiusPercent = 10
                pieSeries.PieSegmentShape = ENPieSegmentShape.Ring


                m_PieChart.Series.Add(pieSeries)
                m_PieChart.DockSpiderLabelsToSides = True

                Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle(True)
                dataLabelStyle.ArrowLength = 0
                dataLabelStyle.ArrowPointerLength = 0
                dataLabelStyle.Format = "<percent>"
                dataLabelStyle.TextStyle.HorzAlign = ENTextHorzAlign.Center
                dataLabelStyle.TextStyle.VertAlign = ENTextVertAlign.Center

                pieSeries.DataLabelStyle = dataLabelStyle

                If i = 0 Then
                    pieSeries.LegendView.Mode = ENSeriesLegendMode.DataPoints
                    pieSeries.LegendView.Format = "<label>"
                Else
                    pieSeries.LegendView.Mode = ENSeriesLegendMode.None
                End If

                pieSeries.LabelMode = ENPieLabelMode.Center

                For j = 0 To labels.Length - 1
                    pieSeries.DataPoints.Add(New NPieDataPoint(20 + random.Next(100), labels(j)))
                Next
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim beginAngleUpDown As NNumericUpDown = New NNumericUpDown()
            beginAngleUpDown.Value = m_PieChart.BeginAngle
            beginAngleUpDown.ValueChanged += AddressOf OnBeginAngleUpDownValueChanged
            stack.Add(NPairBox.Create("Begin Angle:", beginAngleUpDown))

            Dim sweepAngleUpDown As NNumericUpDown = New NNumericUpDown()
            sweepAngleUpDown.Value = m_PieChart.SweepAngle
            sweepAngleUpDown.Minimum = -360
            sweepAngleUpDown.Maximum = 360
            sweepAngleUpDown.ValueChanged += AddressOf OnSweepAngleUpDownValueChanged
            stack.Add(NPairBox.Create("Sweep Angle:", sweepAngleUpDown))

            Dim pieShapeComboBox As NComboBox = New NComboBox()
            pieShapeComboBox.FillFromEnum(Of ENPieSegmentShape)()
            pieShapeComboBox.SelectedIndexChanged += AddressOf OnPieShapeComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Pie Shape:", pieShapeComboBox))
            pieShapeComboBox.SelectedIndex = CInt(ENPieSegmentShape.SmoothEdgeRing)

            Dim pieEdgePercentUpDown As NNumericUpDown = New NNumericUpDown()
            stack.Add(NPairBox.Create("Pie Edge Percent:", pieEdgePercentUpDown))
            pieEdgePercentUpDown.ValueChanged += AddressOf OnPieEdgePercentUpDownValueChanged

            Dim enableLabelAdjustmentCheckBox As NCheckBox = New NCheckBox("Enable Label Adjustment")
            enableLabelAdjustmentCheckBox.CheckedChanged += AddressOf OnEnableLabelAdjustmentCheckBoxCheckedChanged
            enableLabelAdjustmentCheckBox.Checked = True
            stack.Add(enableLabelAdjustmentCheckBox)

            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a doughnut pie chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnBeginAngleUpDownValueChanged(arg As NValueChangeEventArgs)
            m_PieChart.BeginAngle = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnSweepAngleUpDownValueChanged(arg As NValueChangeEventArgs)
            m_PieChart.SweepAngle = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnEnableLabelAdjustmentCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_PieChart.LabelLayout.EnableLabelAdjustment = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnPieShapeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            For i = 0 To m_PieChart.Series.Count - 1
                CType(m_PieChart.Series(i), NPieSeries).PieSegmentShape = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENPieSegmentShape)
            Next
        End Sub

        Private Sub OnPieEdgePercentUpDownValueChanged(arg As NValueChangeEventArgs)
            For i = 0 To m_PieChart.Series.Count - 1
                CType(m_PieChart.Series(i), NPieSeries).PieEdgePercent = CSng(CType(arg.TargetNode, NNumericUpDown).Value)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_PieChart As NPieChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NDoughnutPie3DExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreatePieChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Pie)
            Return chartView
        End Function

#End Region
    End Class
End Namespace
