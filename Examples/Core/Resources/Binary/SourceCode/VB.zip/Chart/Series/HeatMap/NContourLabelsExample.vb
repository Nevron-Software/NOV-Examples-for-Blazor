Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Controur Labels Example
    ''' </summary>
    Public Class NContourLabelsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NContourLabelsExampleSchema = NSchema.Create(GetType(NContourLabelsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Contour Chart"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            m_HeatMap = New NHeatMapSeries()
            chart.Series.Add(m_HeatMap)

            m_HeatMap.Palette = New NColorValuePalette(New NColorValuePair() {New NColorValuePair(0.0, NColor.Purple), New NColorValuePair(1.5, NColor.MediumSlateBlue), New NColorValuePair(3.0, NColor.CornflowerBlue), New NColorValuePair(4.5, NColor.LimeGreen), New NColorValuePair(6.0, NColor.LightGreen), New NColorValuePair(7.5, NColor.Yellow), New NColorValuePair(9.0, NColor.Orange), New NColorValuePair(10.5, NColor.Red)})

            ' make sure contour labels are visible
            m_HeatMap.ContourLabelStyle.Visible = True
            m_HeatMap.ContourDisplayMode = ENContourDisplayMode.Contour
            m_HeatMap.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_HeatMap.LegendView.Format = "<level_value>"

            GenerateData()

            Return chartView
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim showContourLabelsCheckBox As NCheckBox = New NCheckBox()
            showContourLabelsCheckBox.CheckedChanged += AddressOf OnShowContourLabelsCheckBoxCheckedChanged
            showContourLabelsCheckBox.Checked = True
            stack.Add(NPairBox.Create("Show Contour Labels:", showContourLabelsCheckBox))

            Dim allowLabelsToFlipCheckBox As NCheckBox = New NCheckBox()
            allowLabelsToFlipCheckBox.CheckedChanged += AddressOf AllowLabelsToFlipCheckBoxCheckedChanged
            allowLabelsToFlipCheckBox.Checked = False
            stack.Add(NPairBox.Create("Allow Labels To Flip:", allowLabelsToFlipCheckBox))

            Dim showLabelBackgroundCheckBox As NCheckBox = New NCheckBox()
            showLabelBackgroundCheckBox.CheckedChanged += AddressOf OnShowLabelBackgroundCheckBoxCheckedChanged
            showLabelBackgroundCheckBox.Checked = True
            stack.Add(NPairBox.Create("Show Label Background:", showLabelBackgroundCheckBox))

            Dim clipContourCheckBox As NCheckBox = New NCheckBox()
            clipContourCheckBox.CheckedChanged += AddressOf OnClipContourCheckBoxCheckedChanged
            clipContourCheckBox.Checked = True
            stack.Add(NPairBox.Create("Clip Contour:", clipContourCheckBox))

            Dim labelDistanceUpDown As NNumericUpDown = New NNumericUpDown()
            labelDistanceUpDown.ValueChanged += AddressOf OnLabelDistanceUpDownValueChanged
            labelDistanceUpDown.Value = 80
            stack.Add(NPairBox.Create("Label Distance:", labelDistanceUpDown))

            Return boxGroup
        End Function

        Private Sub AllowLabelsToFlipCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_HeatMap.ContourLabelStyle.AllowLabelToFlip = CBool(arg.NewValue)
        End Sub

        Private Sub OnLabelDistanceUpDownValueChanged(arg As NValueChangeEventArgs)
            m_HeatMap.ContourLabelStyle.LabelDistance = CDbl(arg.NewValue)
        End Sub

        Private Sub OnClipContourCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_HeatMap.ContourLabelStyle.ClipContour = CBool(arg.NewValue)
        End Sub

        Private Sub OnShowLabelBackgroundCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_HeatMap.ContourLabelStyle.TextStyle.Background.Visible = CBool(arg.NewValue)
        End Sub

        Private Sub OnAllowLabelsCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_HeatMap.ContourLabelStyle.AllowLabelToFlip = CBool(arg.NewValue)
        End Sub

        Private Sub OnShowContourLabelsCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_HeatMap.ContourLabelStyle.Visible = CBool(arg.NewValue)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates the capabilities of the heat map to display labels at each contour line.</p>"
        End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' 
        ''' </summary>
        Private Sub GenerateData()
            Dim data = m_HeatMap.Data

            Dim GridStepX = 300
            Dim GridStepY = 300
            data.Size = New NSizeI(GridStepX, GridStepY)

            Const dIntervalX = 10.0
            Const dIntervalZ = 10.0
            Dim dIncrementX = dIntervalX / GridStepX
            Dim dIncrementZ = dIntervalZ / GridStepY

            Dim y, x, z As Double

            z = -(dIntervalZ / 2)

            Dim col = 0

            While col < GridStepX
                x = -(dIntervalX / 2)

                Dim row = 0

                While row < GridStepY
                    y = 10 - Math.Sqrt(x * x + z * z + 2)
                    y += 3.0 * Math.Sin(x) * Math.Cos(z)

                    data.SetValue(row, col, y)
                    row += 1
                    x += dIncrementX
                End While

                col += 1
                z += dIncrementZ
            End While
        End Sub

#End Region

#Region "Fields"

        Private m_HeatMap As NHeatMapSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NContourLabelsExampleSchema As NSchema

#End Region
    End Class
End Namespace
