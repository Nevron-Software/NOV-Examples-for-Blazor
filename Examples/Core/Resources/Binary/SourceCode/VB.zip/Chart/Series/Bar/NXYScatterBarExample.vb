Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' XY Scatter Bar Example
    ''' </summary>
    Public Class NXYScatterBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NXYScatterBarExampleSchema = NSchema.Create(GetType(NXYScatterBarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "XY Scatter Bar"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' add interlaced stripe to the Y axis
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            chart.Axes(ENCartesianAxis.PrimaryY).Scale.Strips.Add(stripStyle)

            m_Bar = New NBarSeries()
            chart.Series.Add(m_Bar)

            m_Bar.DataLabelStyle = New NDataLabelStyle(False)
            m_Bar.InflateMargins = True
            m_Bar.WidthSizeMode = ENBarSizeMode.Fixed
            m_Bar.Width = 20

            m_Bar.Name = "Bar Series"
            m_Bar.UseXValues = True

            ' add xy values
            m_Bar.DataPoints.Add(New NBarDataPoint(15, 10))
            m_Bar.DataPoints.Add(New NBarDataPoint(25, 23))
            m_Bar.DataPoints.Add(New NBarDataPoint(45, 12))
            m_Bar.DataPoints.Add(New NBarDataPoint(55, 21))
            m_Bar.DataPoints.Add(New NBarDataPoint(61, 16))
            m_Bar.DataPoints.Add(New NBarDataPoint(67, 19))
            m_Bar.DataPoints.Add(New NBarDataPoint(72, 11))

            Return chartView
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim changeXValuesButton As NButton = New NButton("Change X Values")
            changeXValuesButton.Click += AddressOf OnChangeXValuesButtonClick
            stack.Add(changeXValuesButton)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a xy scatter bar chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChangeXValuesButtonClick(arg As NEventArgs)
            Dim random As Random = New Random()
            m_Bar.DataPoints(0).X = random.Next(10)

            For i = 1 To m_Bar.DataPoints.Count - 1
                m_Bar.DataPoints(i).X = m_Bar.DataPoints(i - 1).X + random.Next(1, 10)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Bar As NBarSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NXYScatterBarExampleSchema As NSchema

#End Region
    End Class
End Namespace
