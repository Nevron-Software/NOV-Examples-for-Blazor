
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Range Fill Styles Example
    ''' </summary>
    Public Class NRangeFillStylesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NRangeFillStylesExampleSchema = NSchema.Create(GetType(NRangeFillStylesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Tallest Buildings in the World"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' setup X axis
            Dim xScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale

            xScale.Labels.Visible = False
            xScale.InnerMajorTicks.Visible = False
            xScale.OuterMajorTicks.Visible = False
            xScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.Logical
            xScale.LogicalInflate = New NRange(10, 10)

            ' setup Y axis
            Dim yScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            yScale.MajorGridLines.Visible = True

            ' add interlaced stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            yScale.Strips.Add(strip)

            ' setup shape series
            Dim rangeSeries As NRangeSeries = New NRangeSeries()
            chart.Series.Add(rangeSeries)
            chart.FitMode = ENCartesianChartFitMode.Aspect
            chart.Aspect = 1

            rangeSeries.DataLabelStyle = New NDataLabelStyle(False)
            rangeSeries.UseXValues = True
            rangeSeries.LegendView.Mode = ENSeriesLegendMode.None

            ' fill data
            Dim buildingNames = New String() {"Jeddah Tower", "Burj Khalifa", "Abraj Al Bait", "Taipei 101", "Zifeng Tower"}
            Dim countryNames = New String() {"Saudi Arabia", "UAE", "Saudi Arabia", "Taiwan", "China"}

            Dim legend = chartView.Surface.Legends(0)
            legend.Mode = ENLegendMode.Custom
            legend.Header = New NLabel("Some of World's Tallest Buildings")
            Dim xOffset As Double = 0

            For i = 0 To buildingNames.Length - 1
                Dim buildingImageResourceName = "RIMG_Buildings_" & buildingNames(i).Replace(" ", "") & "_emf"
                Dim buildingImage = NImage.FromResource(NResources.Instance.GetResource(buildingImageResourceName))

                ' add data point
                Dim rangeDataPoint As NRangeDataPoint = New NRangeDataPoint()

                Dim buildingWidth = buildingImage.Width / 2
                Dim buildingHeight = buildingImage.Height / 2

                rangeDataPoint.X = xOffset
                rangeDataPoint.X2 = xOffset + buildingWidth

                rangeDataPoint.Y = 0
                rangeDataPoint.Y2 = buildingHeight
                rangeDataPoint.Fill = New NImageFill(buildingImage)

                rangeSeries.DataPoints.Add(rangeDataPoint)

                Dim customRangeLabel As NCustomRangeLabel = New NCustomRangeLabel(New NRange(rangeDataPoint.X, rangeDataPoint.X2), buildingNames(i))
                customRangeLabel.LabelStyle.TickMode = ENRangeLabelTickMode.Separators
                customRangeLabel.LabelStyle.FitMode = ENRangeLabelFitMode.Wrap Or ENRangeLabelFitMode.AutoFlip
                xScale.CustomLabels.Add(customRangeLabel)

                xOffset += buildingWidth + 10

                ' add legend item
                Dim buildingCountryResourceName = "RIMG_Buildings_" & countryNames(i).Replace(" ", "") & "_emf"
                Dim buildingCountryImage = NImage.FromResource(NResources.Instance.GetResource(buildingCountryResourceName))
                Dim buildingCountryImageBox As NImageBox = New NImageBox(buildingCountryImage)
                buildingCountryImageBox.PreferredSize = New NSize(40, 30)

                legend.Items.Add(New NPairBox(buildingCountryImageBox, New NLabel(buildingNames(i) & ", " & countryNames(i))))
            Next

            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demostrates how to apply different fill styles to range elements, as well as the ability of the control to use vector images in WMF, EMF and EMF+ formats.</p>"
        End Function

#End Region

#Region "Fields"

#End Region

#Region "Schema"

        Public Shared ReadOnly NRangeFillStylesExampleSchema As NSchema

#End Region
    End Class
End Namespace
