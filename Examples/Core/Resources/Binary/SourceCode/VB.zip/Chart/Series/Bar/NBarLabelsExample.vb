Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Bar Labels Example
    ''' </summary>
    Public Class NBarLabelsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NBarLabelsExampleSchema = NSchema.Create(GetType(NBarLabelsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Bar Labels"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' configure Y axis
            Dim scaleY As NLinearScale = New NLinearScale()
            scaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dash
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = scaleY

            ' add interlaced stripe for Y axis
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            scaleY.Strips.Add(stripStyle)

            ' bar series
            m_Bar = New NBarSeries()
            m_Bar.ValueFormatter = New NNumericValueFormatter("0.000")
            m_Chart.Series.Add(m_Bar)

            m_Bar.Fill = New NColorFill(NColor.DarkOrange)

            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.Visible = True
            dataLabelStyle.VertAlign = ENVerticalAlignment.Top
            dataLabelStyle.ArrowLength = 20
            dataLabelStyle.Format = "<value>"

            m_Bar.DataLabelStyle = dataLabelStyle

            ' enable initial labels positioning
            m_Chart.LabelLayout.EnableInitialPositioning = True

            ' enable label adjustment
            m_Chart.LabelLayout.EnableLabelAdjustment = True

            ' use only "top" location for the labels
            m_Bar.LabelLayout.UseLabelLocations = True
            m_Bar.LabelLayout.LabelLocations = New NDomArray(Of ENLabelLocation)(New ENLabelLocation() {ENLabelLocation.Top})
            m_Bar.LabelLayout.OutOfBoundsLocationMode = ENOutOfBoundsLocationMode.PushWithinBounds
            m_Bar.LabelLayout.InvertLocationsIfIgnored = True

            ' protect data points from being overlapped
            m_Bar.LabelLayout.EnableDataPointSafeguard = True
            m_Bar.LabelLayout.DataPointSafeguardSize = New NSize(2, 2)

            ' fill with random data
            OnGenerateDataButtonClick(Nothing)

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_EnableInitialPositioningCheckBox = New NCheckBox("Enable Initial Positioning")
            m_EnableInitialPositioningCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableInitialPositioningCheckBoxCheckedChanged)
            stack.Add(m_EnableInitialPositioningCheckBox)

            m_RemoveOverlappedLabelsCheckBox = New NCheckBox("Remove Overlapped Labels")
            m_RemoveOverlappedLabelsCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRemoveOverlappedLabelsCheckBoxCheckedChanged)
            stack.Add(m_RemoveOverlappedLabelsCheckBox)

            m_EnableLabelAdjustmentCheckBox = New NCheckBox("Enable Label Adjustment")
            m_EnableLabelAdjustmentCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableLabelAdjustmentCheckBoxCheckedChanged)
            stack.Add(m_EnableLabelAdjustmentCheckBox)

            m_LocationsComboBox = New NComboBox()
            m_LocationsComboBox.Items.Add(New NComboBoxItem("Top"))
            m_LocationsComboBox.Items.Add(New NComboBoxItem("Top - Bottom"))
            m_LocationsComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnLocationsComboBoxSelectedIndexChanged)
            stack.Add(m_LocationsComboBox)

            Dim generateDataButton As NButton = New NButton("Generate Data")
            generateDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnGenerateDataButtonClick)
            stack.Add(generateDataButton)

            m_EnableInitialPositioningCheckBox.Checked = True
            m_RemoveOverlappedLabelsCheckBox.Checked = True
            m_EnableLabelAdjustmentCheckBox.Checked = True
            m_LocationsComboBox.SelectedIndex = 0

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how automatic data label layout works with bar data labels.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEnableLabelAdjustmentCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_Chart.LabelLayout.EnableLabelAdjustment = m_EnableLabelAdjustmentCheckBox.Checked
        End Sub

        Private Sub OnRemoveOverlappedLabelsCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_Chart.LabelLayout.RemoveOverlappedLabels = m_RemoveOverlappedLabelsCheckBox.Checked
        End Sub

        Private Sub OnEnableInitialPositioningCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_RemoveOverlappedLabelsCheckBox.Enabled = m_EnableInitialPositioningCheckBox.Checked
            m_LocationsComboBox.Enabled = m_EnableInitialPositioningCheckBox.Checked

            m_Chart.LabelLayout.EnableInitialPositioning = m_EnableInitialPositioningCheckBox.Checked
        End Sub

        Private Sub OnLocationsComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim locations As ENLabelLocation()

            Select Case m_LocationsComboBox.SelectedIndex
                Case 0
                    locations = New ENLabelLocation() {ENLabelLocation.Top}

                Case 1
                    locations = New ENLabelLocation() {ENLabelLocation.Top, ENLabelLocation.Bottom}
                Case Else
                    NDebug.Assert(False)
                    locations = Nothing
            End Select

            m_Bar.LabelLayout.LabelLocations = New NDomArray(Of ENLabelLocation)(locations)
        End Sub

        Private Sub OnGenerateDataButtonClick(arg As NEventArgs)
            m_Bar.DataPoints.Clear()

            Dim random As Random = New Random()
            For i = 0 To 29
                Dim value As Double = Math.Sin(i * 0.2) * 10 + random.NextDouble() * 4

                m_Bar.DataPoints.Add(New NBarDataPoint(value))
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Bar As NBarSeries

        Private m_EnableInitialPositioningCheckBox As NCheckBox
        Private m_RemoveOverlappedLabelsCheckBox As NCheckBox
        Private m_EnableLabelAdjustmentCheckBox As NCheckBox
        Private m_LocationsComboBox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NBarLabelsExampleSchema As NSchema

#End Region
    End Class
End Namespace
