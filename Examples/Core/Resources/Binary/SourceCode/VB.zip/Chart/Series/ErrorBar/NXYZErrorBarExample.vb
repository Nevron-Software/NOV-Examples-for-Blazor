Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Error Bar Example
    ''' </summary>
    Public Class NXYZErrorBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NXYZErrorBarExampleSchema = NSchema.Create(GetType(NXYZErrorBarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "XYZ Scatter Error Bar"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.Enable3D = True
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.GlitterLeft)
            chart.FitMode = ENCartesianChartFitMode.Aspect
            chart.ModelDepth = 55.0F
            chart.ModelWidth = 55.0F
            chart.ModelHeight = 55.0F

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYZLinear)
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup the x axis
            Dim scaleX As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale
            scaleX.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            scaleX.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)

            ' setup the y axis
            Dim scaleY As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scaleY.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            scaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            scaleY.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            scaleY.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)

            ' add interlace stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            strip.SetShowAtWall(ENChartWall.Back, True)
            strip.SetShowAtWall(ENChartWall.Left, True)
            scaleY.Strips.Add(strip)

            ' setup the z axis
            Dim scaleZ As NLinearScale = chart.Axes(ENCartesianAxis.Depth).Scale
            scaleZ.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            scaleZ.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)

            ' add an error bar series
            m_ErrorBar = New NErrorBarSeries()
            chart.Series.Add(m_ErrorBar)

            m_ErrorBar.Stroke = New NStroke(NColor.Black)
            m_ErrorBar.Fill = New NColorFill(NColor.DarkBlue)
            m_ErrorBar.Size = 10

            m_ErrorBar.UseXValues = True
            m_ErrorBar.UseZValues = True

            GenerateNewData()

            ' chartView.Document.StyleSheets.ApplyTheme(new NChartTheme(ENChartPalette.Bright, false));

            Return chartView
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim inflateMarginsCheckBox As NCheckBox = New NCheckBox("Inflate Margins")
            inflateMarginsCheckBox.CheckedChanged += AddressOf OnInflateMarginsCheckBoxCheckedChanged
            inflateMarginsCheckBox.Checked = True
            stack.Add(inflateMarginsCheckBox)

            Dim showUpperXErrorCheckBox As NCheckBox = New NCheckBox("Show Upper X Error")
            showUpperXErrorCheckBox.CheckedChanged += AddressOf OnShowUpperXErrorCheckBoxCheckedChanged
            showUpperXErrorCheckBox.Checked = True
            stack.Add(showUpperXErrorCheckBox)

            Dim showLowerXErrorCheckBox As NCheckBox = New NCheckBox("Show Lower X Error")
            showLowerXErrorCheckBox.CheckedChanged += AddressOf OnShowLowerXErrorCheckBoxCheckedChanged
            showLowerXErrorCheckBox.Checked = True
            stack.Add(showLowerXErrorCheckBox)

            Dim xErrorSizeUpDown As NNumericUpDown = New NNumericUpDown()
            xErrorSizeUpDown.Value = m_ErrorBar.XErrorSize
            xErrorSizeUpDown.ValueChanged += AddressOf OnXErrorSizeUpDownValueChanged
            stack.Add(NPairBox.Create("X Error Size:", xErrorSizeUpDown))

            Dim showUpperYErrorCheckBox As NCheckBox = New NCheckBox("Show Upper Y Error")
            showUpperYErrorCheckBox.CheckedChanged += AddressOf OnShowUpperYErrorCheckBoxCheckedChanged
            showUpperYErrorCheckBox.Checked = True
            stack.Add(showUpperYErrorCheckBox)

            Dim showLowerYErrorCheckBox As NCheckBox = New NCheckBox("Show Lower Y Error")
            showLowerYErrorCheckBox.CheckedChanged += AddressOf OnShowLowerYErrorCheckBoxCheckedChanged
            showLowerYErrorCheckBox.Checked = True
            stack.Add(showLowerYErrorCheckBox)

            Dim yErrorSizeUpDown As NNumericUpDown = New NNumericUpDown()
            yErrorSizeUpDown.Value = m_ErrorBar.YErrorSize
            yErrorSizeUpDown.ValueChanged += AddressOf OnYErrorSizeUpDownValueChanged
            stack.Add(NPairBox.Create("X Error Size:", yErrorSizeUpDown))

            '
            Dim showUpperZErrorCheckBox As NCheckBox = New NCheckBox("Show Upper Z Error")
            showUpperZErrorCheckBox.CheckedChanged += AddressOf OnShowUpperZErrorCheckBoxCheckedChanged
            showUpperZErrorCheckBox.Checked = True
            stack.Add(showUpperZErrorCheckBox)

            Dim showLowerZErrorCheckBox As NCheckBox = New NCheckBox("Show Lower Z Error")
            showLowerZErrorCheckBox.CheckedChanged += AddressOf OnShowLowerZErrorCheckBoxCheckedChanged
            showLowerZErrorCheckBox.Checked = True
            stack.Add(showLowerZErrorCheckBox)

            Dim zErrorSizeUpDown As NNumericUpDown = New NNumericUpDown()
            zErrorSizeUpDown.Value = m_ErrorBar.YErrorSize
            zErrorSizeUpDown.ValueChanged += AddressOf OnZErrorSizeUpDownValueChanged
            stack.Add(NPairBox.Create("Z Error Size:", zErrorSizeUpDown))

            Dim changeDataButton As NButton = New NButton("Change Data")
            changeDataButton.Click += AddressOf OnChangeDataButtonClick
            stack.Add(changeDataButton)

            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates a XYZ Error Bar chart. XYZ Errors bars indicate the uncertainty in the X, Y and Z values. You can use the controls to modify different properties of the error bar series like error whisker size, upper / lower error visibility etc.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub GenerateNewData()
            m_ErrorBar.DataPoints.Clear()

            Dim random As Random = New Random()

            For i = 0 To 9
                Dim y As Double = 20 + random.NextDouble() * 30
                Dim x As Double = 20 + random.NextDouble() * 30
                Dim z As Double = 20 + random.NextDouble() * 30

                Dim lowerXError As Double = (2 + 2 * random.NextDouble())
                Dim upperXError As Double = (2 + 2 * random.NextDouble())

                Dim lowerYError As Double = (2 + 2 * random.NextDouble())
                Dim upperYError As Double = (2 + 2 * random.NextDouble())

                Dim lowerZError As Double = (2 + 2 * random.NextDouble())
                Dim upperZError As Double = (2 + 2 * random.NextDouble())

                m_ErrorBar.DataPoints.Add(New NErrorBarDataPoint(x, y, z, upperXError, lowerXError, upperYError, lowerYError, upperZError, lowerZError))
            Next
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnChangeDataButtonClick(arg As NEventArgs)
            GenerateNewData()
        End Sub

        Private Sub OnInflateMarginsCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_ErrorBar.InflateMargins = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnXErrorSizeUpDownValueChanged(arg As NValueChangeEventArgs)
            m_ErrorBar.XErrorSize = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnShowLowerXErrorCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_ErrorBar.ShowLowerXError = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnShowUpperXErrorCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_ErrorBar.ShowUpperXError = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnYErrorSizeUpDownValueChanged(arg As NValueChangeEventArgs)
            m_ErrorBar.YErrorSize = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnShowLowerYErrorCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_ErrorBar.ShowLowerYError = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnShowUpperYErrorCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_ErrorBar.ShowUpperYError = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnZErrorSizeUpDownValueChanged(arg As NValueChangeEventArgs)
            m_ErrorBar.ZErrorSize = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnShowLowerZErrorCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_ErrorBar.ShowLowerZError = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnShowUpperZErrorCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_ErrorBar.ShowUpperZError = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Fields"

        Private m_ErrorBar As NErrorBarSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NXYZErrorBarExampleSchema As NSchema

#End Region
    End Class
End Namespace
