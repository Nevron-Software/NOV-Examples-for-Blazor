
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Three Renko Example
    ''' </summary>
    Public Class NRenkoExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NRenkoExampleSchema = NSchema.Create(GetType(NRenkoExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Renko"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            Dim scaleY As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale

            ' add interlace stripe
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            scaleY.Strips.Add(stripStyle)

            ' setup X axis
            Dim priceScale As NPriceTimeScale = New NPriceTimeScale()
            priceScale.InnerMajorTicks.Stroke = New NStroke(0.0, NColor.Black)
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = priceScale

            ' setup line break series
            m_RenkoSeries = New NRenkoSeries()
            m_RenkoSeries.BoxSize = 1
            m_RenkoSeries.UseXValues = True
            chart.Series.Add(m_RenkoSeries)

            GenerateData(m_RenkoSeries)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim boxWidthPercentUpDown As NNumericUpDown = New NNumericUpDown()
            boxWidthPercentUpDown.Minimum = 0
            boxWidthPercentUpDown.Maximum = 100
            boxWidthPercentUpDown.Value = m_RenkoSeries.BoxWidthPercent
            boxWidthPercentUpDown.ValueChanged += AddressOf OnBoxWidthPercentUpDownValueChanged
            stack.Add(NPairBox.Create("Box Width Percent:", boxWidthPercentUpDown))

            Dim boxSizePercentUpDownUpDown As NNumericUpDown = New NNumericUpDown()
            boxSizePercentUpDownUpDown.Minimum = 1
            boxSizePercentUpDownUpDown.Maximum = 100
            boxSizePercentUpDownUpDown.Value = m_RenkoSeries.BoxSize
            boxSizePercentUpDownUpDown.ValueChanged += AddressOf OnBoxSizePercentUpDownUpDownValueChanged
            boxSizePercentUpDownUpDown.DecimalPlaces = 0
            stack.Add(NPairBox.Create("Number of Lines to Break:", boxSizePercentUpDownUpDown))

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the functionality of the renko series.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub GenerateData(renkoSeries As NRenkoSeries)
            Dim dataGenerator As NStockDataGenerator = New NStockDataGenerator(New NRange(50, 350), 0.002, 2)
            dataGenerator.Reset()

            Dim dt = Date.Now

            For i = 0 To 99
                renkoSeries.DataPoints.Add(New NRenkoDataPoint(NDateTimeHelpers.ToOADate(dt), dataGenerator.GetNextValue()))

                dt = dt.AddDays(1)
            Next
        End Sub

#End Region

#Region "Event Handlers"


        Private Sub OnBoxSizePercentUpDownUpDownValueChanged(arg As NValueChangeEventArgs)
            m_RenkoSeries.BoxSize = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnBoxWidthPercentUpDownValueChanged(arg As NValueChangeEventArgs)
            m_RenkoSeries.BoxWidthPercent = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

#End Region

#Region "Fields"

        Private m_RenkoSeries As NRenkoSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NRenkoExampleSchema As NSchema

#End Region
    End Class
End Namespace
