Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Examples.Framework
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard 3D Line Example
    ''' </summary>
    Public Class NStandardLine3DExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardLine3DExampleSchema = NSchema.Create(GetType(NStandardLine3DExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Line 3D"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.Enable3D = True
            m_Chart.ModelWidth = 65
            m_Chart.ModelHeight = 40

            m_Chart.Projection.SetPredefinedProjection(ENPredefinedProjection.Perspective2)
            m_Chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.GlitterLeft)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.Standard)
            m_Chart.Axes(ENCartesianAxis.Depth).Visible = False
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            ' add interlaced stripe to the Y axis
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            strip.SetShowAtWall(ENChartWall.Back, True)
            strip.SetShowAtWall(ENChartWall.Left, True)
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Strips.Add(strip)

            m_Line = New NLineSeries()
            m_Chart.Series.Add(m_Line)

            m_Line.Name = "Line Series"
            m_Line.InflateMargins = True
            m_Line.DataLabelStyle = New NDataLabelStyle("<value>")
            m_Line.MarkerStyle = New NMarkerStyle(New NSize(4, 4))

            Dim random As Random = New Random()

            For i = 0 To 7
                m_Line.DataPoints.Add(New NLineDataPoint(random.Next(80) + 20))
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim lineStyleCombo As NComboBox = New NComboBox()
            lineStyleCombo.FillFromEnum(Of ENLineSegmentShape)()
            lineStyleCombo.SelectedIndexChanged += AddressOf OnLineStyleComboSelectedIndexChanged
            stack.Add(NPairBox.Create("Line Segment Shape:", lineStyleCombo))

            m_LineStrokeButton = New NButton("Line Stroke...")
            Me.m_LineStrokeButton.Click += AddressOf OnLineStrokeButtonClick
            stack.Add(m_LineStrokeButton)

            m_LineFillButton = New NButton("Line Fill...")
            Me.m_LineFillButton.Click += AddressOf OnLineFillButtonClick
            stack.Add(m_LineFillButton)

            m_LineDepthScrollBar = New NHScrollBar()
            m_LineDepthScrollBar.Minimum = 0
            m_LineDepthScrollBar.Maximum = 100
            Me.m_LineDepthScrollBar.ValueChanged += AddressOf OnLineDepthScrollBarValueChanged
            m_LineDepthScrollBar.Value = 50
            stack.Add(NPairBox.Create("Line Depth:", m_LineDepthScrollBar))

            m_LineSizeScrollBar = New NHScrollBar()
            m_LineSizeScrollBar.Minimum = 0
            m_LineSizeScrollBar.Maximum = 5.0F
            m_LineSizeScrollBar.SmallChange = 0.1F
            m_LineSizeScrollBar.LargeChange = 0.2F
            Me.m_LineSizeScrollBar.ValueChanged += AddressOf OnLineSizeScrollBarValueChanged
            m_LineSizeScrollBar.Value = 2.0F
            stack.Add(NPairBox.Create("Line Size:", m_LineSizeScrollBar))

            lineStyleCombo.SelectedIndex = CInt(ENLineSegmentShape.Tape)

            Return group
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnLineDepthScrollBarValueChanged(arg As NValueChangeEventArgs)
            m_Line.DepthPercent = Convert.ToSingle(arg.NewValue)
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnLineSizeScrollBarValueChanged(arg As NValueChangeEventArgs)
            m_Line.LineSize = Convert.ToSingle(arg.NewValue)
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnLineFillButtonClick(arg As NEventArgs)
            Try
                Dim node As NNode = m_Line.Fill
                Dim editorWindow = NEditorWindow.CreateForInstance(node, Nothing, Me.DisplayWindow, Nothing)

                If TypeOf node Is NStyleNodeCollectionTree Then
                    editorWindow.PreferredSize = New NSize(500, 360)
                End If

                editorWindow.Open()
            Catch ex As Exception
                NTrace.WriteException("OnShowDesignerClick failed.", ex)
            End Try
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnLineStrokeButtonClick(arg As NEventArgs)
            Try
                Dim node As NNode = m_Line.Stroke
                Dim editorWindow = NEditorWindow.CreateForInstance(node, Nothing, Me.DisplayWindow, Nothing)

                If TypeOf node Is NStyleNodeCollectionTree Then
                    editorWindow.PreferredSize = New NSize(500, 360)
                End If

                editorWindow.Open()
            Catch ex As Exception
                NTrace.WriteException("OnShowDesignerClick failed.", ex)
            End Try
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnLineStyleComboSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_Line.LineSegmentShape = CType(arg.NewValue, ENLineSegmentShape)

            Select Case m_Line.LineSegmentShape
                Case ENLineSegmentShape.Line ' simple line
                    m_LineDepthScrollBar.Enabled = False
                    m_LineSizeScrollBar.Enabled = False
                    m_LineFillButton.Enabled = False
                    SetupTubeMarkers(m_Line.MarkerStyle)

                Case ENLineSegmentShape.Tape ' tape
                    m_LineDepthScrollBar.Enabled = True
                    m_LineSizeScrollBar.Enabled = False
                    m_LineFillButton.Enabled = True
                    SetupTapeMarkers(m_Line.MarkerStyle)

                Case ENLineSegmentShape.Tube ' tube
                    m_LineDepthScrollBar.Enabled = False
                    m_LineSizeScrollBar.Enabled = True
                    m_LineFillButton.Enabled = True
                    SetupTubeMarkers(m_Line.MarkerStyle)
            End Select
        End Sub

        Private Sub SetupTapeMarkers(marker As NMarkerStyle)
            marker.Shape = ENPointShape3D.Cylinder
            marker.AutoDepth = True
            marker.AutoDepthPercent = 120
        End Sub

        Private Sub SetupTubeMarkers(marker As NMarkerStyle)
            marker.Shape = ENPointShape3D.Sphere
            marker.AutoDepth = False
            marker.Width = 10
            marker.Height = 10
            marker.Depth = 10
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard 3D line chart.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Line As NLineSeries

        Private m_LineStrokeButton As NButton
        Private m_LineFillButton As NButton
        Private m_LineDepthScrollBar As NHScrollBar
        Private m_LineSizeScrollBar As NHScrollBar

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardLine3DExampleSchema As NSchema

#End Region
    End Class
End Namespace
