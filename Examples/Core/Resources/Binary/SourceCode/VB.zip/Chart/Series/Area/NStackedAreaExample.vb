Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Stacked Area Example
    ''' </summary>
    Public Class NStackedAreaExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStackedAreaExampleSchema = NSchema.Create(GetType(NStackedAreaExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ChartView = New NChartView()
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Stacked Area"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' setup X axis
            Dim scaleX As NOrdinalScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale
            scaleX.InflateContentRange = False

            ' add interlaced stripe for Y axis
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True

            Dim scaleY As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scaleY.Strips.Add(strip)

            ' add the first area
            m_Area1 = New NAreaSeries()
            m_Area1.MultiAreaMode = ENMultiAreaMode.Series
            m_Area1.Name = "Product A"
            m_Area1.DataLabelStyle = New NDataLabelStyle()
            chart.Series.Add(m_Area1)
            SetupDataLabels(m_Area1)

            ' add the second Area
            m_Area2 = New NAreaSeries()
            m_Area2.MultiAreaMode = ENMultiAreaMode.Stacked
            m_Area2.Name = "Product B"
            m_Area2.DataLabelStyle = New NDataLabelStyle()
            chart.Series.Add(m_Area2)
            SetupDataLabels(m_Area2)

            ' add the third Area
            m_Area3 = New NAreaSeries()
            m_Area3.MultiAreaMode = ENMultiAreaMode.Stacked
            m_Area3.Name = "Product C"
            m_Area3.DataLabelStyle = New NDataLabelStyle()
            chart.Series.Add(m_Area3)
            SetupDataLabels(m_Area3)

            ' fill with random data
            Dim random As Random = New Random()
            For i = 0 To 9
                m_Area1.DataPoints.Add(New NAreaDataPoint(random.Next(20, 50)))
                m_Area2.DataPoints.Add(New NAreaDataPoint(random.Next(20, 50)))
                m_Area3.DataPoints.Add(New NAreaDataPoint(random.Next(20, 50)))
            Next

            Return m_ChartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim stackModeComboBox As NComboBox = New NComboBox()
            stackModeComboBox.Items.Add(New NComboBoxItem("Stacked"))
            stackModeComboBox.Items.Add(New NComboBoxItem("Stacked Percent"))
            stackModeComboBox.SelectedIndex = 0
            stackModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnStackModeComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Stack Mode: ", stackModeComboBox))

            Dim showDataLabelsCheckBox As NCheckBox = New NCheckBox("Show Data Labels")
            showDataLabelsCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowDataLabelsCheckedChanged)
            stack.Add(showDataLabelsCheckBox)

            m_Area1LabelFormatCombox = CreateLabelsCombo()
            m_Area1LabelFormatCombox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnArea1LabelFormatComboxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Area 1 Label Format: ", m_Area1LabelFormatCombox))

            m_Area2LabelFormatCombox = CreateLabelsCombo()
            m_Area2LabelFormatCombox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnArea2LabelFormatComboxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Area 2 Label Format: ", m_Area2LabelFormatCombox))

            m_Area3LabelFormatCombox = CreateLabelsCombo()
            m_Area3LabelFormatCombox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnArea3LabelFormatComboxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Area 3 Label Format: ", m_Area3LabelFormatCombox))

            showDataLabelsCheckBox.Checked = True

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a stacked area chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnStackModeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            Dim scale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale

            Select Case CType(arg.TargetNode, NComboBox).SelectedIndex
                Case 0
                    m_Area2.MultiAreaMode = ENMultiAreaMode.Stacked
                    m_Area3.MultiAreaMode = ENMultiAreaMode.Stacked
                    scale.Labels.TextProvider = New NFormattedScaleLabelTextProvider(New NNumericValueFormatter(ENNumericValueFormat.General))

                Case 1
                    m_Area2.MultiAreaMode = ENMultiAreaMode.StackedPercent
                    m_Area3.MultiAreaMode = ENMultiAreaMode.StackedPercent
                    scale.Labels.TextProvider = New NFormattedScaleLabelTextProvider(New NNumericValueFormatter(ENNumericValueFormat.Percentage))
            End Select
        End Sub

        Private Sub OnShowDataLabelsCheckedChanged(arg As NValueChangeEventArgs)
            Dim showDataLabelsCheckBox = CType(arg.TargetNode, NCheckBox)

            m_Area1.DataLabelStyle.Visible = showDataLabelsCheckBox.Checked
            m_Area2.DataLabelStyle.Visible = showDataLabelsCheckBox.Checked
            m_Area3.DataLabelStyle.Visible = showDataLabelsCheckBox.Checked

            m_Area1LabelFormatCombox.Enabled = showDataLabelsCheckBox.Checked
            m_Area2LabelFormatCombox.Enabled = showDataLabelsCheckBox.Checked
            m_Area3LabelFormatCombox.Enabled = showDataLabelsCheckBox.Checked
        End Sub

        Private Sub OnArea1LabelFormatComboxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_Area1.DataLabelStyle.Format = GetFormatStringFromIndex(m_Area1LabelFormatCombox.SelectedIndex)
        End Sub

        Private Sub OnArea2LabelFormatComboxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_Area2.DataLabelStyle.Format = GetFormatStringFromIndex(m_Area2LabelFormatCombox.SelectedIndex)
        End Sub

        Private Sub OnArea3LabelFormatComboxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_Area3.DataLabelStyle.Format = GetFormatStringFromIndex(m_Area3LabelFormatCombox.SelectedIndex)
        End Sub

#End Region

#Region "Implementation"

        Private Function GetFormatStringFromIndex(index As Integer) As String
            Select Case index
                Case 0
                    Return "<value>"

                Case 1
                    Return "<total>"

                Case 2
                    Return "<cumulative>"

                Case 3
                    Return "<percent>"
                Case Else
                    Return ""
            End Select
        End Function

        Private Function CreateLabelsCombo() As NComboBox
            Dim comboBox As NComboBox = New NComboBox()

            comboBox.Items.Add(New NComboBoxItem("Value"))
            comboBox.Items.Add(New NComboBoxItem("Total"))
            comboBox.Items.Add(New NComboBoxItem("Cumulative"))
            comboBox.Items.Add(New NComboBoxItem("Percent"))
            comboBox.SelectedIndex = 0

            Return comboBox
        End Function

        Private Sub SetupDataLabels(area As NAreaSeries)
            Dim dataLabel = area.DataLabelStyle

            dataLabel.ArrowLength = 0
            dataLabel.VertAlign = ENVerticalAlignment.Center
            dataLabel.TextStyle.Background.Padding = New NMargins(5)
            dataLabel.TextStyle.Font = New NFont("Arial", 8, ENFontStyle.Bold)
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView

        Private m_Area1 As NAreaSeries
        Private m_Area2 As NAreaSeries
        Private m_Area3 As NAreaSeries

        Private m_Area1LabelFormatCombox As NComboBox
        Private m_Area2LabelFormatCombox As NComboBox
        Private m_Area3LabelFormatCombox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NStackedAreaExampleSchema As NSchema

#End Region
    End Class
End Namespace
