Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Funnel Example
    ''' </summary>
    Public Class NStandardFunnelExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardFunnelExampleSchema = NSchema.Create(GetType(NStandardFunnelExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateFunnelChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Funnel"

            Dim funnelChart = CType(chartView.Surface.Charts(0), NFunnelChart)

            m_FunnelSeries = New NFunnelSeries()
            funnelChart.Series.Add(m_FunnelSeries)

            m_FunnelSeries.DataPoints.Add(New NFunnelDataPoint(20.0, "Awareness"))
            m_FunnelSeries.DataPoints.Add(New NFunnelDataPoint(10.0, "First Hear"))
            m_FunnelSeries.DataPoints.Add(New NFunnelDataPoint(15.0, "Further Learn"))
            m_FunnelSeries.DataPoints.Add(New NFunnelDataPoint(7.0, "Liking"))
            m_FunnelSeries.DataPoints.Add(New NFunnelDataPoint(28.0, "Decision"))
            m_FunnelSeries.DataLabelStyle = New NDataLabelStyle(True)
            m_FunnelSeries.DataLabelStyle.VertAlign = ENVerticalAlignment.Center


            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim funnelShapeCombo As NComboBox = New NComboBox()
            funnelShapeCombo.FillFromEnum(Of ENFunnelShape)()
            funnelShapeCombo.SelectedIndexChanged += AddressOf OnFunnelShapeComboSelectedIndexChanged
            funnelShapeCombo.SelectedIndex = CInt(ENFunnelShape.Trapezoid)
            stack.Add(NPairBox.Create("Funnel Shape:", funnelShapeCombo))

            Dim labelAligmentModeCombo As NComboBox = New NComboBox()
            labelAligmentModeCombo.FillFromEnum(Of ENFunnelLabelMode)()
            labelAligmentModeCombo.SelectedIndexChanged += AddressOf OnLabelAligmentModeComboSelectedIndexChanged
            labelAligmentModeCombo.SelectedIndex = CInt(ENFunnelLabelMode.Center)
            stack.Add(NPairBox.Create("Label Alignment:", labelAligmentModeCombo))

            Dim labelArrowLengthUpDown As NNumericUpDown = New NNumericUpDown()
            labelArrowLengthUpDown.Value = m_FunnelSeries.LabelArrowLength
            labelArrowLengthUpDown.ValueChanged += AddressOf OnLabelArrowLengthUpDownValueChanged
            stack.Add(NPairBox.Create("Label Arrow Length:", labelArrowLengthUpDown))

            Dim pointGapUpDown As NNumericUpDown = New NNumericUpDown()
            pointGapUpDown.Value = m_FunnelSeries.PointGapPercent
            pointGapUpDown.ValueChanged += AddressOf OnPointGapUpDownValueChanged
            stack.Add(NPairBox.Create("Point Gap Percent:", pointGapUpDown))

            Dim neckHeightPercentUpDown As NNumericUpDown = New NNumericUpDown()
            neckHeightPercentUpDown.Value = m_FunnelSeries.NeckHeightPercent
            neckHeightPercentUpDown.ValueChanged += AddressOf OnNeckHeightPercentUpDownValueChanged
            stack.Add(NPairBox.Create("Neck Height Percent:", neckHeightPercentUpDown))

            Dim neckWidthPercentUpDown As NNumericUpDown = New NNumericUpDown()
            neckWidthPercentUpDown.Value = m_FunnelSeries.NeckWidthPercent
            neckWidthPercentUpDown.ValueChanged += AddressOf OnNeckWidthPercentUpDownValueChanged
            stack.Add(NPairBox.Create("Neck Width Percent:", neckWidthPercentUpDown))

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard funnel chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnLabelArrowLengthUpDownValueChanged(arg As NValueChangeEventArgs)
            m_FunnelSeries.LabelArrowLength = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnLabelAligmentModeComboSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_FunnelSeries.LabelMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENFunnelLabelMode)
        End Sub

        Private Sub OnPointGapUpDownValueChanged(arg As NValueChangeEventArgs)
            m_FunnelSeries.PointGapPercent = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnFunnelShapeComboSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_FunnelSeries.Shape = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENFunnelShape)
        End Sub

        Private Sub OnNeckHeightPercentUpDownValueChanged(arg As NValueChangeEventArgs)
            m_FunnelSeries.NeckHeightPercent = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnNeckWidthPercentUpDownValueChanged(arg As NValueChangeEventArgs)
            m_FunnelSeries.NeckWidthPercent = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

#End Region

#Region "Fields"

        Private m_FunnelSeries As NFunnelSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardFunnelExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateFunnelChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Funnel)
            Return chartView
        End Function

#End Region
    End Class
End Namespace
