Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Stacked Line 3D Example
    ''' </summary>
    Public Class NStackedLine3DExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStackedLine3DExampleSchema = NSchema.Create(GetType(NStackedLine3DExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Stacked Line 3D"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.Enable3D = True
            m_Chart.ModelWidth = 65
            m_Chart.ModelHeight = 40

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.Standard)
            m_Chart.Projection.SetPredefinedProjection(ENPredefinedProjection.Perspective2)
            m_Chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.GlitterLeft)
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            ' add interlaced stripe to the Y axis
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Strips.Add(stripStyle)

            ' add the first line
            m_Line1 = CreateLineSeries("Line 1", ENMultiLineMode.Series)
            m_Line1.LegendView.Mode = ENSeriesLegendMode.SeriesVisibility
            m_Chart.Series.Add(m_Line1)

            ' add the second line
            m_Line2 = CreateLineSeries("Line 2", ENMultiLineMode.Stacked)
            m_Line2.LegendView.Mode = ENSeriesLegendMode.SeriesVisibility
            m_Chart.Series.Add(m_Line2)

            ' add the third line
            m_Line3 = CreateLineSeries("Line 3", ENMultiLineMode.Stacked)
            m_Line3.LegendView.Mode = ENSeriesLegendMode.SeriesVisibility
            m_Chart.Series.Add(m_Line3)

            ' positive data
            OnPositiveDataButtonClick(Nothing)

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim positiveDataButton As NButton = New NButton("Positive Values")
            positiveDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnPositiveDataButtonClick)
            stack.Add(positiveDataButton)

            Dim positiveAndNegativeDataButton As NButton = New NButton("Positive and Negative Values")
            positiveAndNegativeDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnPositiveAndNegativeDataButtonClick)
            stack.Add(positiveAndNegativeDataButton)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a stacked line chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnPositiveAndNegativeDataButtonClick(arg As NEventArgs)
            m_Line1.DataPoints.Clear()
            m_Line2.DataPoints.Clear()
            m_Line3.DataPoints.Clear()

            Dim random As Random = New Random()
            For i = 0 To 11
                m_Line1.DataPoints.Add(New NLineDataPoint(random.Next(100) - 50))
                m_Line2.DataPoints.Add(New NLineDataPoint(random.Next(100) - 50))
                m_Line3.DataPoints.Add(New NLineDataPoint(random.Next(100) - 50))
            Next
        End Sub

        Private Sub OnPositiveDataButtonClick(arg As NEventArgs)
            m_Line1.DataPoints.Clear()
            m_Line2.DataPoints.Clear()
            m_Line3.DataPoints.Clear()

            Dim random As Random = New Random()
            For i = 0 To 11
                m_Line1.DataPoints.Add(New NLineDataPoint(random.Next(90) + 10))
                m_Line2.DataPoints.Add(New NLineDataPoint(random.Next(90) + 10))
                m_Line3.DataPoints.Add(New NLineDataPoint(random.Next(90) + 10))
            Next
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates a new line series
        ''' </summary>
        ''' <paramname="name"></param>
        ''' <paramname="multiLineMode"></param>
        ''' <returns></returns>
        Private Function CreateLineSeries(name As String, multiLineMode As ENMultiLineMode) As NLineSeries
            Dim line As NLineSeries = New NLineSeries()

            line.Name = name
            line.LineSegmentShape = ENLineSegmentShape.Tape

            line.MultiLineMode = multiLineMode

            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.ArrowLength = 0
            line.DataLabelStyle = dataLabelStyle

            Return line
        End Function

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

        Private m_Line1 As NLineSeries
        Private m_Line2 As NLineSeries
        Private m_Line3 As NLineSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NStackedLine3DExampleSchema As NSchema

#End Region
    End Class
End Namespace
