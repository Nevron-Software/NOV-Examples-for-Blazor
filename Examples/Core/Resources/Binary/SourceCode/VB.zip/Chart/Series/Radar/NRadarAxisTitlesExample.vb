Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Radar axis titles example
    ''' </summary>
    Public Class NRadarAxisTitlesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NRadarAxisTitlesExampleSchema = NSchema.Create(GetType(NRadarAxisTitlesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateRadarChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Radar Axis Titles"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NRadarChart)

            AddAxis("Vitamin A")
            AddAxis("Vitamin B1")
            AddAxis("Vitamin B2")
            AddAxis("Vitamin B6")
            AddAxis("Vitamin B12")
            AddAxis("Vitamin C")
            AddAxis("Vitamin D")
            AddAxis("Vitamin E")

            Dim radarScale = CType(m_Chart.Axes(0).Scale, NLinearScale)
            radarScale.MajorGridLines.Visible = True

            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            radarScale.Strips.Add(strip)

            ' create the radar series
            m_RadarArea1 = New NRadarAreaSeries()
            m_Chart.Series.Add(m_RadarArea1)
            m_RadarArea1.Name = "Series 1"
            m_RadarArea1.DataLabelStyle = New NDataLabelStyle(False)
            m_RadarArea1.DataLabelStyle.Format = "<value>"

            m_RadarArea2 = New NRadarAreaSeries()
            m_Chart.Series.Add(m_RadarArea2)
            m_RadarArea2.Name = "Series 2"
            m_RadarArea2.DataLabelStyle = New NDataLabelStyle(False)

            ' fill random data
            Dim random As Random = New Random()

            For i = 0 To 7
                m_RadarArea1.DataPoints.Add(New NRadarAreaDataPoint(random.Next(50, 90)))
                m_RadarArea2.DataPoints.Add(New NRadarAreaDataPoint(random.Next(0, 100)))
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim beginAngleUpDown As NNumericUpDown = New NNumericUpDown()
            beginAngleUpDown.ValueChanged += AddressOf OnBeginAngleUpDownValueChanged
            beginAngleUpDown.Value = 90
            stack.Add(NPairBox.Create("Begin Angle:", beginAngleUpDown))

            Dim titleAngleModeComboBox As NComboBox = New NComboBox()
            titleAngleModeComboBox.FillFromEnum(Of ENScaleLabelAngleMode)()
            titleAngleModeComboBox.SelectedIndexChanged += AddressOf OnTitleAngleModeComboBoxSelectedIndexChanged
            titleAngleModeComboBox.SelectedIndex = CInt(ENScaleLabelAngleMode.Scale)
            stack.Add(NPairBox.Create("Title Angle Mode:", titleAngleModeComboBox))

            Dim titleAngleUpDown As NNumericUpDown = New NNumericUpDown()
            titleAngleUpDown.ValueChanged += AddressOf OnTitleAngleUpDownValueChanged
            titleAngleUpDown.Value = 0
            stack.Add(NPairBox.Create("Title Angle:", titleAngleUpDown))

            Dim allowLabelsToFlipCheckBox As NCheckBox = New NCheckBox("Allow Labels to Flip")
            allowLabelsToFlipCheckBox.CheckedChanged += AddressOf OnAllowLabelsToFlipCheckBoxCheckedChanged
            allowLabelsToFlipCheckBox.Checked = False
            stack.Add(allowLabelsToFlipCheckBox)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to set radar axis titles.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnBeginAngleUpDownValueChanged(arg As NValueChangeEventArgs)
            m_Chart.BeginAngle = New NAngle(CType(arg.TargetNode, NNumericUpDown).Value, NUnit.Degree)
        End Sub

        Private Sub OnTitleAngleModeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            For i = 0 To m_Chart.Axes.Count - 1
                Dim oldTitleAngle As NScaleLabelAngle = m_Chart.Axes(CInt(i)).TitleAngle
                m_Chart.Axes(i).TitleAngle = New NScaleLabelAngle(CType(arg.TargetNode, NComboBox).SelectedIndex, oldTitleAngle.CustomAngle)
            Next
        End Sub

        Private Sub OnTitleAngleUpDownValueChanged(arg As NValueChangeEventArgs)
            For i = 0 To m_Chart.Axes.Count - 1
                Dim oldTitleAngle As NScaleLabelAngle = m_Chart.Axes(CInt(i)).TitleAngle
                m_Chart.Axes(i).TitleAngle = New NScaleLabelAngle(oldTitleAngle.LabelAngleMode, CType(arg.TargetNode, NNumericUpDown).Value)
            Next
        End Sub
        Private Sub OnAllowLabelsToFlipCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            For i = 0 To m_Chart.Axes.Count - 1
                Dim titleAngle As NScaleLabelAngle = m_Chart.Axes(CInt(i)).TitleAngle
                titleAngle.AllowTextFlip = CType(arg.TargetNode, NCheckBox).Checked
                m_Chart.Axes(i).TitleAngle = titleAngle
            Next
        End Sub

#End Region

#Region "Implementation"

        Private Sub AddAxis(title As String)
            Dim axis As NRadarAxis = New NRadarAxis()

            ' set title
            axis.Title = title
            '			axis.TitleTextStyle.TextFormat = TextFormat.XML;

            ' setup scale
            Dim linearScale = CType(axis.Scale, NLinearScale)

            If m_Chart.Axes.Count = 0 Then
                ' if the first axis then configure grid style and stripes
                linearScale.MajorGridLines.Stroke = New NStroke(1, NColor.Gainsboro, ENDashStyle.Dot)

                ' add interlaced stripe
                Dim strip As NScaleStrip = New NScaleStrip()
                strip.Fill = New NColorFill(NColor.FromRGBA(200, 200, 200, 64))
                strip.Interlaced = True
                linearScale.Strips.Add(strip)
            Else
                ' hide labels
                linearScale.Labels.Visible = False
            End If

            m_Chart.Axes.Add(axis)
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NRadarChart
        Private m_RadarArea1 As NRadarAreaSeries
        Private m_RadarArea2 As NRadarAreaSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NRadarAxisTitlesExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateRadarChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Radar)
            Return chartView
        End Function

#End Region
    End Class
End Namespace
