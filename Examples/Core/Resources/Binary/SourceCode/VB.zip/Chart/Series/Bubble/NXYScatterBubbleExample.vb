Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Bubble Example
    ''' </summary>
    Public Class NXYScatterBubbleExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NXYScatterBubbleExampleSchema = NSchema.Create(GetType(NXYScatterBubbleExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "XY Scatter Bubble"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' configure the chart
            Dim yScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale

            yScale.MajorGridLines = New NScaleGridLines()
            yScale.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot

            ' add interlace stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            yScale.Strips.Add(strip)

            Dim xScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale
            xScale.MajorGridLines = New NScaleGridLines()
            xScale.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot

            ' add a bubble series
            m_Bubble = New NBubbleSeries()

            m_Bubble = New NBubbleSeries()
            m_Bubble.DataLabelStyle = New NDataLabelStyle(False)
            m_Bubble.LegendView.Format = "<label>"
            m_Bubble.LegendView.Mode = ENSeriesLegendMode.DataPoints
            m_Bubble.UseXValues = True

            m_Bubble.DataPoints.Add(New NBubbleDataPoint(27, 51, 1147995904, "India"))
            m_Bubble.DataPoints.Add(New NBubbleDataPoint(50, 67, 1321851888, "China"))
            m_Bubble.DataPoints.Add(New NBubbleDataPoint(76, 22, 109955400, "Mexico"))
            m_Bubble.DataPoints.Add(New NBubbleDataPoint(210, 9, 142008838, "Russia"))
            m_Bubble.DataPoints.Add(New NBubbleDataPoint(360, 4, 305843000, "USA"))
            m_Bubble.DataPoints.Add(New NBubbleDataPoint(470, 5, 33560000, "Canada"))

            m_Chart.Series.Add(m_Bubble)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim bubbleShapeComboBox As NComboBox = New NComboBox()
            bubbleShapeComboBox.FillFromEnum(Of ENPointShape3D)()
            bubbleShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnBubbleShapeComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Bubble Shape: ", bubbleShapeComboBox))
            bubbleShapeComboBox.SelectedIndex = CInt(ENPointShape3D.Ellipse)

            Dim minBubbleSizeUpDown As NNumericUpDown = New NNumericUpDown()
            minBubbleSizeUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMinBubbleSizeUpDownValueChanged)
            stack.Add(NPairBox.Create("Min Bubble Size:", minBubbleSizeUpDown))
            minBubbleSizeUpDown.Value = 50

            Dim maxBubbleSizeUpDown As NNumericUpDown = New NNumericUpDown()
            maxBubbleSizeUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMaxBubbleSizeUpDownValueChanged)
            stack.Add(NPairBox.Create("Max Bubble Size:", maxBubbleSizeUpDown))
            maxBubbleSizeUpDown.Value = 200

            Dim inflateMarginsCheckBox As NCheckBox = New NCheckBox()
            inflateMarginsCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnInflateMarginsCheckBoxCheckedChanged)
            stack.Add(NPairBox.Create("Inflate Margins: ", inflateMarginsCheckBox))
            inflateMarginsCheckBox.Checked = True

            Dim changeYValuesButton As NButton = New NButton("Change Y Values")
            changeYValuesButton.Click += New [Function](Of NEventArgs)(AddressOf OnChangeYValuesButtonClick)
            stack.Add(changeYValuesButton)

            Dim changeXValuesButton As NButton = New NButton("Change X Values")
            changeXValuesButton.Click += New [Function](Of NEventArgs)(AddressOf OnChangeXValuesButtonClick)
            stack.Add(changeXValuesButton)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a xy scatter bubble chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnBubbleShapeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_Bubble.Shape = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENPointShape3D)
        End Sub

        Private Sub OnInflateMarginsCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_Bubble.InflateMargins = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnMaxBubbleSizeUpDownValueChanged(arg As NValueChangeEventArgs)
            m_Bubble.MaxSize = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnMinBubbleSizeUpDownValueChanged(arg As NValueChangeEventArgs)
            m_Bubble.MinSize = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnChangeXValuesButtonClick(arg As NEventArgs)
            Dim random As Random = New Random()

            For i = 0 To m_Bubble.DataPoints.Count - 1
                m_Bubble.DataPoints(i).X = random.Next(-100, 100)
            Next
        End Sub

        Private Sub OnChangeYValuesButtonClick(arg As NEventArgs)
            Dim random As Random = New Random()

            For i = 0 To m_Bubble.DataPoints.Count - 1
                m_Bubble.DataPoints(i).Value = random.Next(-100, 100)
            Next
        End Sub


#End Region

#Region "Fields"

        Private m_Bubble As NBubbleSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NXYScatterBubbleExampleSchema As NSchema

#End Region
    End Class
End Namespace
