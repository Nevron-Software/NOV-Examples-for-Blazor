Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Export
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    Public Class NRasterImageExportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NRasterImageExportExampleSchema = NSchema.Create(GetType(NRasterImageExportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ChartView = New NChartView()
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Raster Image Export Example"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYZLinear)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.BrightCameraLight)
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup X axis
            Dim xScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale

            xScale.MajorGridLines.Visible = True

            ' setup Y axis
            Dim yScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            yScale.MajorGridLines.Visible = True

            ' add interlaced stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            yScale.Strips.Add(strip)

            ' setup shape series
            Dim range As NRangeSeries = New NRangeSeries()
            chart.Series.Add(range)

            range.DataLabelStyle = New NDataLabelStyle(False)
            range.UseXValues = True
            range.Fill = New NColorFill(NColor.DarkOrange)
            range.Stroke = New NStroke(NColor.DarkRed)

            ' fill data
            Dim intervals = New Double() {5, 5, 5, 5, 5, 5, 5, 5, 5, 15, 30, 60}
            Dim values = New Double() {4180, 13687, 18618, 19634, 17981, 7190, 16369, 3212, 4122, 9200, 6461, 3435}

            Dim count = Math.Min(intervals.Length, values.Length)
            Dim x As Double = 0

            For i = 0 To count - 1
                Dim interval = intervals(i)
                Dim value = values(i)

                Dim x1 = x
                Dim y1 As Double = 0

                x += interval
                Dim x2 = x
                Dim y2 = value / interval

                range.DataPoints.Add(New NRangeDataPoint(x1, y1, x2, y2))
            Next

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return m_ChartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim enable3DCheckBox As NCheckBox = New NCheckBox("Enable 3D")
            enable3DCheckBox.CheckedChanged += AddressOf OnEnable3DCheckBoxCheckedChanged
            enable3DCheckBox.Checked = True
            stack.Add(enable3DCheckBox)

            Dim copyImageToClipboardButton As NButton = New NButton("Copy Image to Clipboard")
            copyImageToClipboardButton.Click += AddressOf CopyImageToClipboardButton_Click
            stack.Add(copyImageToClipboardButton)

            Dim saveAsImageFileButton As NButton = New NButton("Save as Image File...")
            saveAsImageFileButton.Click += AddressOf SaveAsImageFileButton_Click
            stack.Add(saveAsImageFileButton)

            Dim showExportDialogButton As NButton = New NButton("Show Export Dialog...")
            showExportDialogButton.Click += AddressOf ShowExportDialogButton_Click
            stack.Add(showExportDialogButton)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to export images to the clipboard or file selected from an open file dialog.
	You can also use the <b>SaveToFile</b> and <b>SaveToStream</b> methods of the image exporter class to save
	to stream or file directly. The format of the image in this case is determined by the file extension.
</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEnable3DCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_ChartView.Surface.Charts(0).Enable3D = CBool(arg.NewValue)
        End Sub
        Private Sub CopyImageToClipboardButton_Click(arg As NEventArgs)
            Call NEditorWindow.CreateForInstance(m_ChartView.Surface.Charts(0), Nothing, Nothing, Nothing).Open()
            'NChartRasterImageExporter rasterImageExporter = new NChartRasterImageExporter(m_ChartView.Content);
            'rasterImageExporter.CopyToClipboard();
        End Sub
        Private Sub SaveAsImageFileButton_Click(arg As NEventArgs)
            Dim rasterImageExporter As NChartRasterImageExporter = New NChartRasterImageExporter(m_ChartView.Content)
            rasterImageExporter.SaveAsImage()
        End Sub
        Private Sub ShowExportDialogButton_Click(arg As NEventArgs)
            Dim rasterImageExporter As NChartRasterImageExporter = New NChartRasterImageExporter(m_ChartView.Content)
            rasterImageExporter.ShowDialog(m_ChartView.DisplayWindow, True)
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView

#End Region

#Region "Schema"

        Public Shared ReadOnly NRasterImageExportExampleSchema As NSchema

#End Region
    End Class
End Namespace
