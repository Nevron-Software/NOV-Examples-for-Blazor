Imports System
Imports System.IO

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Formats
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Serialization Example
    ''' </summary>
    Public Class NSerializationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NSerializationExampleSchema = NSchema.Create(GetType(NSerializationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ChartView = New NChartView()
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Serialization"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            linearScale.Strips.Add(stripStyle)

            ' add the first bar
            m_Bar1 = New NBarSeries()
            m_Bar1.Name = "Bar1"
            m_Bar1.MultiBarMode = ENMultiBarMode.Series
            m_Bar1.DataLabelStyle = New NDataLabelStyle(False)
            chart.Series.Add(m_Bar1)

            ' add the second bar
            m_Bar2 = New NBarSeries()
            m_Bar2.Name = "Bar2"
            m_Bar2.MultiBarMode = ENMultiBarMode.Stacked
            m_Bar2.DataLabelStyle = New NDataLabelStyle(False)
            chart.Series.Add(m_Bar2)

            ' add the third bar
            m_Bar3 = New NBarSeries()
            m_Bar3.Name = "Bar3"
            m_Bar3.MultiBarMode = ENMultiBarMode.Stacked
            m_Bar3.DataLabelStyle = New NDataLabelStyle(False)
            chart.Series.Add(m_Bar3)

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            FillRandomData()

            Return m_ChartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim changeDataButton As NButton = New NButton("Change Data")
            changeDataButton.Click += AddressOf OnChangeDataButtonClick
            stack.Add(changeDataButton)

            Dim saveStateToFileButton As NButton = New NButton("Save State To File...")
            saveStateToFileButton.Click += AddressOf OnSaveStateToFileButtonClick
            stack.Add(saveStateToFileButton)

            Dim loadStateFromFileButton As NButton = New NButton("Load State From File...")
            loadStateFromFileButton.Click += AddressOf OnLoadStateFromFileButtonClick
            stack.Add(loadStateFromFileButton)

            Dim saveStateToStreamButton As NButton = New NButton("Save State To Stream")
            saveStateToStreamButton.Click += AddressOf OnSaveStateToStreamButtonClick
            stack.Add(saveStateToStreamButton)

            Dim loadStateFromStreamButton As NButton = New NButton("Load State from Stream")
            loadStateFromStreamButton.Click += AddressOf OnLoadStateFromStreamButtonClick
            stack.Add(loadStateFromStreamButton)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to save / load the chart state from a file or stream.</p>"
        End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' 
        ''' </summary>
        Private Sub FillRandomData()
            Dim barSeriesList As NList(Of NBarSeries) = New NList(Of NBarSeries)()

            ' collect all bar series in the view
            For chartIndex = 0 To m_ChartView.Surface.Charts.Length - 1
                Dim chart = CType(m_ChartView.Surface.Charts(chartIndex), NCartesianChart)

                For seriesIndex = 0 To chart.Series.Count - 1
                    Dim barSeries As NBarSeries = TryCast(chart.Series(seriesIndex), NBarSeries)

                    If barSeries IsNot Nothing Then
                        barSeriesList.Add(barSeries)
                        barSeries.DataPoints.Clear()
                    End If
                Next
            Next

            ' fill all bar series with random data
            Dim random As Random = New Random()
            For i = 0 To 4
                For j = 0 To barSeriesList.Count - 1
                    Dim barSeries = barSeriesList(j)
                    barSeries.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
                Next
            Next
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnLoadStateFromFileButtonClick(arg As NEventArgs)
            m_ChartView.OpenFileAsync()
        End Sub

        Private Sub OnSaveStateToFileButtonClick(arg As NEventArgs)
            m_ChartView.SaveAsAsync()
        End Sub

        Private Sub OnLoadStateFromStreamButtonClick(arg As NEventArgs)
            If m_Stream IsNot Nothing Then
                m_Stream.Seek(0, SeekOrigin.Begin)
                m_ChartView.LoadFromStreamAsync(m_Stream)
            End If
        End Sub

        Private Sub OnSaveStateToStreamButtonClick(arg As NEventArgs)
            m_Stream = New MemoryStream()
            m_ChartView.SaveToStreamAsync(m_Stream, NChartFormat.NevronXml)
        End Sub

        Private Sub OnChangeDataButtonClick(arg As NEventArgs)
            FillRandomData()
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView
        Private m_Bar1 As NBarSeries
        Private m_Bar2 As NBarSeries
        Private m_Bar3 As NBarSeries
        Private m_Stream As MemoryStream

#End Region

#Region "Schema"

        Public Shared ReadOnly NSerializationExampleSchema As NSchema

#End Region
    End Class
End Namespace
