Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System
Imports Nevron.Nov.Layout

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Custom Legend Items Example
    ''' </summary>
    Public Class NCustomLegendItemsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NCustomLegendItemsExampleSchema = NSchema.Create(GetType(NCustomLegendItemsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Dim dockPanel As NDockPanel = New NDockPanel()

            ' set a chart title
            Dim header As NLabel = New NLabel("Legend Custom Items")
            NDockLayout.SetDockArea(header, ENDockArea.Top)
            header.Margins = New NMargins(0, 10, 0, 10)
            dockPanel.AddChild(header)

            Dim container As NDockPanel = New NDockPanel()
            NDockLayout.SetDockArea(container, ENDockArea.Center)
            container.Margins = New NMargins(10, 10, 10, 10)
            container.BackgroundFill = New NColorFill(NColor.Cyan)
            dockPanel.AddChild(container)

            ' configure the legend
            CreateCustomLegend1(container)
            CreateCustomLegend2(container)
            CreateCustomLegend3(container)

            chartView.Surface.Content = dockPanel

            Return chartView
        End Function
        ''' <summary>
        ''' Creates the example controls
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to add custom legend items.</p>"
        End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="container"></param>
        Private Sub CreateCustomLegend1(container As NDockPanel)
            Dim markShapesLegend = CreateLegend(container, "Mark Shapes")

            Dim markShapes = [Enum].GetValues(GetType(ENLegendMarkShape))
            Dim palette = NChartPalette.GetColors(ENChartPalette.Fresh)

            For i = 0 To markShapes.Length - 1
                Dim markShape As ENLegendMarkShape = markShapes.GetValue(i)

                Dim markFill As NFill = New NColorFill(palette(i Mod palette.Length))
                Dim legendItemSymbol As NWidget = NLegend.CreateLegendSymbol(markShape, New NSize(20, 20), New NMargins(2), markFill, New NStroke(NColor.Black), New NStroke(NColor.Black))
                Dim legendItemLabel As NLabel = New NLabel(markShape.ToString())
                legendItemLabel.Margins = New NMargins(2)

                markShapesLegend.Items.Add(New NPairBox(legendItemSymbol, legendItemLabel))
            Next
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="container"></param>
        Private Sub CreateCustomLegend2(container As NDockPanel)
            Dim markShapesNoStroke = CreateLegend(container, "Mark Shapes (No stroke)")

            Dim markShapes = [Enum].GetValues(GetType(ENLegendMarkShape))
            Dim palette = NChartPalette.GetColors(ENChartPalette.Fresh)

            For i = 0 To markShapes.Length - 1
                Dim markShape As ENLegendMarkShape = markShapes.GetValue(i)

                Dim markFill As NFill = New NColorFill(palette(i Mod palette.Length))
                Dim legendItemSymbol As NWidget = NLegend.CreateLegendSymbol(markShape, New NSize(20, 20), New NMargins(2), markFill, Nothing, Nothing)

                Dim legendItemLabel As NLabel = New NLabel(markShape.ToString())
                legendItemLabel.Margins = New NMargins(2)

                markShapesNoStroke.Items.Add(New NPairBox(legendItemSymbol, legendItemLabel))
            Next
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="container"></param>
        Private Sub CreateCustomLegend3(container As NDockPanel)
            Dim markShapesBackground = CreateLegend(container, "Mark Shapes (Margins, Background)")

            Dim markShapes = [Enum].GetValues(GetType(ENLegendMarkShape))
            Dim palette = NChartPalette.GetColors(ENChartPalette.Fresh)

            For i = 0 To markShapes.Length - 1
                Dim markShape As ENLegendMarkShape = markShapes.GetValue(i)

                Dim legendItemSymbol As NWidget = NLegend.CreateLegendSymbol(markShape, New NSize(20, 20), New NMargins(2), New NColorFill(NColor.White), Nothing, Nothing)

                Dim legendItemLabel As NLabel = New NLabel(markShape.ToString())
                legendItemLabel.TextFill = New NColorFill(NColor.White)
                legendItemLabel.Font = New NFont("Arial", 10 + i)
                legendItemLabel.Margins = New NMargins(2)

                Dim legendItem As NPairBox = New NPairBox(legendItemSymbol, legendItemLabel)
                legendItem.BackgroundFill = New NColorFill(palette(i Mod palette.Length))
                legendItem.Margins = New NMargins(4)

                markShapesBackground.Items.Add(legendItem)
            Next
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="container"></param>
        ''' <paramname="title"></param>
        ''' <returns></returns>
        Private Function CreateLegend(container As NDockPanel, title As String) As NLegend
            ' configure the legend
            Dim legend As NLegend = New NLegend()
            legend.Header = New NLabel(title)
            legend.Mode = ENLegendMode.Custom
            legend.ExpandMode = ENLegendExpandMode.ColsOnly
            NDockLayout.SetDockArea(legend, ENDockArea.Top)

            container.AddChild(legend)

            Return legend
        End Function

#End Region

#Region "Fields"


#End Region

#Region "Schema"

        Public Shared ReadOnly NCustomLegendItemsExampleSchema As NSchema

#End Region
    End Class
End Namespace
