Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Legend Layout Example
    ''' </summary>
    Public Class NLegendLayoutExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NLegendLayoutExampleSchema = NSchema.Create(GetType(NLegendLayoutExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ChartView = New NChartView()
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Legend Layout"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' add a bar series
            Dim bar1 As NBarSeries = New NBarSeries()
            bar1.Name = "Bar1"
            bar1.MultiBarMode = ENMultiBarMode.Series
            bar1.LegendView.Mode = ENSeriesLegendMode.DataPoints
            bar1.DataLabelStyle = New NDataLabelStyle(False)
            bar1.ValueFormatter = New NNumericValueFormatter("0.###")
            chart.Series.Add(bar1)

            ' add another bar series
            Dim bar2 As NBarSeries = New NBarSeries()
            bar2.Name = "Bar2"
            bar2.MultiBarMode = ENMultiBarMode.Clustered
            bar2.LegendView.Mode = ENSeriesLegendMode.DataPoints
            bar2.DataLabelStyle = New NDataLabelStyle(False)
            bar2.ValueFormatter = New NNumericValueFormatter("0.###")
            chart.Series.Add(bar2)

            ' add another bar series
            Dim bar3 As NBarSeries = New NBarSeries()
            bar3.Name = "Bar2"
            bar3.MultiBarMode = ENMultiBarMode.Clustered
            bar3.LegendView.Mode = ENSeriesLegendMode.DataPoints
            bar3.DataLabelStyle = New NDataLabelStyle(False)
            bar3.ValueFormatter = New NNumericValueFormatter("0.###")
            chart.Series.Add(bar3)

            Dim random As Random = New Random()
            For i = 0 To 4
                bar1.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
                bar2.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
                bar3.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
            Next

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return m_ChartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim legendExpandModeComboBox As NComboBox = New NComboBox()
            legendExpandModeComboBox.FillFromEnum(Of ENLegendExpandMode)()
            legendExpandModeComboBox.SelectedIndexChanged += AddressOf OnLegendExpandModeComboBoxSelectedIndexChanged
            legendExpandModeComboBox.SelectedIndex = CInt(ENLegendExpandMode.RowsOnly)
            stack.Add(NPairBox.Create("Expand Mode: ", legendExpandModeComboBox))

            m_RowCountUpDown = New NNumericUpDown()
            m_RowCountUpDown.Enabled = False
            m_RowCountUpDown.Minimum = 1
            m_RowCountUpDown.Value = 1
            Me.m_RowCountUpDown.ValueChanged += AddressOf OnRowCountUpDownValueChanged
            stack.Add(NPairBox.Create("Row Count: ", m_RowCountUpDown))

            m_ColCountUpDown = New NNumericUpDown()
            m_ColCountUpDown.Enabled = False
            m_ColCountUpDown.Minimum = 1
            m_ColCountUpDown.Value = 1
            Me.m_ColCountUpDown.ValueChanged += AddressOf OnColCountUpDownValueChanged
            stack.Add(NPairBox.Create("Col Count: ", m_ColCountUpDown))

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates different settings related to legend layout.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnRowCountUpDownValueChanged(arg As NValueChangeEventArgs)
            m_ChartView.Surface.Legends(0).RowCount = CInt(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnColCountUpDownValueChanged(arg As NValueChangeEventArgs)
            m_ChartView.Surface.Legends(0).ColCount = CInt(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnLegendExpandModeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_ChartView.Surface.Legends(0).ExpandMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENLegendExpandMode)

            Select Case m_ChartView.Surface.Legends(CInt(0)).ExpandMode
                Case ENLegendExpandMode.ColsFixed
                    m_ColCountUpDown.Enabled = True
                    m_RowCountUpDown.Enabled = False
                Case ENLegendExpandMode.RowsFixed
                    m_ColCountUpDown.Enabled = False
                    m_RowCountUpDown.Enabled = True
                Case Else
                    m_ColCountUpDown.Enabled = False
                    m_RowCountUpDown.Enabled = False

            End Select
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView
        Private m_ColCountUpDown As NNumericUpDown
        Private m_RowCountUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NLegendLayoutExampleSchema As NSchema

#End Region
    End Class
End Namespace
