Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Legend Layout Example
    ''' </summary>
    Public Class NMultipleLegendsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NMultipleLegendsExampleSchema = NSchema.Create(GetType(NMultipleLegendsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ChartView = New NChartView()

            Dim dockPanel As NDockPanel = New NDockPanel()
            m_ChartView.Surface.Content = dockPanel

            Dim label As NLabel = New NLabel()
            label.Margins = New NMargins(10)
            label.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 12)
            label.TextFill = New NColorFill(NColor.Black)
            label.TextAlignment = ENContentAlignment.MiddleCenter
            label.Text = "Multiple Legends"
            NDockLayout.SetDockArea(label, ENDockArea.Top)
            dockPanel.AddChild(label)

            ' stack panel holding content
            Dim stackPanel As NStackPanel = New NStackPanel()
            stackPanel.UniformHeights = ENUniformSize.Max
            stackPanel.FillMode = ENStackFillMode.Equal
            stackPanel.FitMode = ENStackFitMode.Equal
            NDockLayout.SetDockArea(stackPanel, ENDockArea.Center)
            dockPanel.AddChild(stackPanel)

            ' first group of pie + legend
            Dim firstGroupPanel As NDockPanel = New NDockPanel()
            stackPanel.AddChild(firstGroupPanel)

            m_PieChart1 = CreatePieChart()
            m_Legend1 = CreateLegend()

            m_PieChart1.Legend = m_Legend1

            firstGroupPanel.AddChild(m_Legend1)
            firstGroupPanel.AddChild(m_PieChart1)

            ' second group of pie + legend
            Dim secondGroupPanel As NDockPanel = New NDockPanel()
            stackPanel.AddChild(secondGroupPanel)

            ' setup the volume chart
            m_PieChart2 = CreatePieChart()
            m_Legend2 = CreateLegend()

            m_PieChart2.Legend = m_Legend2

            secondGroupPanel.AddChild(m_Legend2)
            secondGroupPanel.AddChild(m_PieChart2)

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))

            Return m_ChartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim useTwoLegendsCheckBox As NCheckBox = New NCheckBox("Use Two Legends")
            useTwoLegendsCheckBox.Checked = True
            useTwoLegendsCheckBox.CheckedChanged += AddressOf OnUseTwoLegendsCheckBoxCheckedChanged
            stack.Add(useTwoLegendsCheckBox)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to display series data on different legends.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateLegend() As NLegend
            Dim legend As NLegend = New NLegend()

            NDockLayout.SetDockArea(legend, ENDockArea.Center)

            legend.HorizontalPlacement = ENHorizontalPlacement.Right
            legend.VerticalPlacement = ENVerticalPlacement.Top

            Return legend
        End Function

        Private Function CreatePieChart() As NPieChart
            Dim pieChart As NPieChart = New NPieChart()
            NDockLayout.SetDockArea(pieChart, ENDockArea.Center)
            pieChart.Margins = New NMargins(10, 0, 10, 10)

            Dim pieSeries As NPieSeries = New NPieSeries()
            pieChart.Series.Add(pieSeries)
            pieChart.DockSpiderLabelsToSides = False

            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.ArrowLength = 15
            dataLabelStyle.ArrowPointerLength = 0
            pieSeries.DataLabelStyle = dataLabelStyle

            pieSeries.LabelMode = ENPieLabelMode.Spider
            pieSeries.LegendView.Mode = ENSeriesLegendMode.DataPoints
            pieSeries.LegendView.Format = "<label> <percent>"

            pieSeries.DataPoints.Add(New NPieDataPoint(24, "Cars"))
            pieSeries.DataPoints.Add(New NPieDataPoint(18, "Airplanes"))
            pieSeries.DataPoints.Add(New NPieDataPoint(32, "Trains"))
            pieSeries.DataPoints.Add(New NPieDataPoint(23, "Ships"))
            pieSeries.DataPoints.Add(New NPieDataPoint(19, "Buses"))

            Return pieChart
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnUseTwoLegendsCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            If CType(arg.TargetNode, NCheckBox).Checked Then
                m_PieChart1.Legend = m_Legend1
                m_PieChart2.Legend = m_Legend2
            Else
                m_PieChart1.Legend = m_Legend1
                m_PieChart2.Legend = m_Legend1
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView
        Private m_PieChart1 As NPieChart
        Private m_Legend1 As NLegend
        Private m_PieChart2 As NPieChart
        Private m_Legend2 As NLegend

#End Region

#Region "Schema"

        Public Shared ReadOnly NMultipleLegendsExampleSchema As NSchema

#End Region
    End Class
End Namespace
