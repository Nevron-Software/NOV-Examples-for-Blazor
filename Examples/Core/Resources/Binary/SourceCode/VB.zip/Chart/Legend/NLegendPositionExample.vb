Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Legend Position Example
    ''' </summary>
    Public Class NLegendPositionExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NLegendPositionExampleSchema = NSchema.Create(GetType(NLegendPositionExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ChartView = New NChartView()
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Legend Layout"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' add a bar series
            Dim bar1 As NBarSeries = New NBarSeries()
            bar1.Name = "Bar1"
            bar1.MultiBarMode = ENMultiBarMode.Series
            bar1.LegendView.Mode = ENSeriesLegendMode.DataPoints
            bar1.DataLabelStyle = New NDataLabelStyle(False)
            bar1.ValueFormatter = New NNumericValueFormatter("0.###")
            chart.Series.Add(bar1)

            Dim random As Random = New Random()

            For i = 0 To 4
                bar1.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
            Next

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return m_ChartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim legendDockAreaComboBox As NComboBox = New NComboBox()
            legendDockAreaComboBox.FillFromEnum(Of ENDockArea)()
            legendDockAreaComboBox.SelectedIndexChanged += AddressOf OnLegendDockAreaComboBoxSelectedIndexChanged
            legendDockAreaComboBox.SelectedIndex = CInt(ENDockArea.Right)
            stack.Add(NPairBox.Create("Dock Area: ", legendDockAreaComboBox))

            Dim dockInsideChartPlotCheckBox As NCheckBox = New NCheckBox("Dock in Chart Plot Area")
            dockInsideChartPlotCheckBox.CheckedChanged += AddressOf OnDockInsideChartPlotCheckBoxCheckedChanged
            stack.Add(dockInsideChartPlotCheckBox)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to position the legend.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnDockInsideChartPlotCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            Dim legend = m_ChartView.Surface.Legends(0)
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            legend.ParentNode.RemoveChild(legend)

            If CType(arg.TargetNode, NCheckBox).Checked Then
                ' dock the legend inside the chart
                Dim dockPanel As NDockPanel = New NDockPanel()
                chart.Content = dockPanel
                dockPanel.Add(legend)
            Else
                ' dock the legend inside the chart
                Dim content As NDockPanel = TryCast(m_ChartView.Surface.Content, NDockPanel)
                content.Add(legend)
            End If
        End Sub

        Private Sub OnLegendDockAreaComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim dockArea As ENDockArea = CType(arg.TargetNode, NComboBox).SelectedIndex
            Dim legend = m_ChartView.Surface.Legends(0)

            ' adjust the legend layout / position accordingly to the dock area
            Select Case dockArea
                Case ENDockArea.Left
                    legend.ExpandMode = ENLegendExpandMode.RowsOnly
                    legend.VerticalPlacement = ENVerticalPlacement.Center
                Case ENDockArea.Top
                    legend.ExpandMode = ENLegendExpandMode.ColsOnly
                    legend.HorizontalPlacement = ENHorizontalPlacement.Center
                Case ENDockArea.Right
                    legend.ExpandMode = ENLegendExpandMode.RowsOnly
                    legend.VerticalPlacement = ENVerticalPlacement.Center
                Case ENDockArea.Bottom
                    legend.ExpandMode = ENLegendExpandMode.ColsOnly
                    legend.HorizontalPlacement = ENHorizontalPlacement.Center
                Case ENDockArea.Center
                    legend.ExpandMode = ENLegendExpandMode.RowsOnly
                    legend.HorizontalPlacement = ENHorizontalPlacement.Center
                    legend.VerticalPlacement = ENVerticalPlacement.Center
            End Select

            NDockLayout.SetDockArea(legend, dockArea)
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView

#End Region

#Region "Schema"

        Public Shared ReadOnly NLegendPositionExampleSchema As NSchema

#End Region
    End Class
End Namespace
