Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Interactive Legend Example
    ''' </summary>
    Public Class NInteractiveLegendExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NInteractiveLegendExampleSchema = NSchema.Create(GetType(NInteractiveLegendExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Interactive Legend"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            linearScale.Strips.Add(stripStyle)

            ' add the first bar
            Dim bar1 As NBarSeries = New NBarSeries()
            bar1.Name = "Bar1"
            bar1.MultiBarMode = ENMultiBarMode.Series
            bar1.LegendView.Mode = ENSeriesLegendMode.SeriesVisibility
            chart.Series.Add(bar1)

            ' add the second bar
            Dim bar2 As NBarSeries = New NBarSeries()
            bar2.Name = "Bar2"
            bar2.MultiBarMode = ENMultiBarMode.Stacked
            bar2.LegendView.Mode = ENSeriesLegendMode.SeriesVisibility
            chart.Series.Add(bar2)

            ' add the third bar
            Dim bar3 As NBarSeries = New NBarSeries()
            bar3.Name = "Bar3"
            bar3.MultiBarMode = ENMultiBarMode.Stacked
            bar3.LegendView.Mode = ENSeriesLegendMode.SeriesVisibility
            chart.Series.Add(bar3)

            ' setup value formatting
            bar1.ValueFormatter = New NNumericValueFormatter("0.###")
            bar2.ValueFormatter = New NNumericValueFormatter("0.###")
            bar3.ValueFormatter = New NNumericValueFormatter("0.###")

            ' position data labels in the center of the bars
            bar1.DataLabelStyle = CreateDataLabelStyle()
            bar2.DataLabelStyle = CreateDataLabelStyle()
            bar3.DataLabelStyle = CreateDataLabelStyle()

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            ' pass some random data
            Dim random As Random = New Random()
            For i = 0 To 11
                bar1.DataPoints.Add(New NBarDataPoint(random.Next(90) + 10))
                bar2.DataPoints.Add(New NBarDataPoint(random.Next(90) + 10))
                bar3.DataPoints.Add(New NBarDataPoint(random.Next(90) + 10))
            Next


            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create an interactive legend.</p>"
        End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates a new data label style object
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateDataLabelStyle() As NDataLabelStyle
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()

            dataLabelStyle.VertAlign = ENVerticalAlignment.Center
            dataLabelStyle.ArrowLength = 0

            Return dataLabelStyle
        End Function

#End Region

#Region "Event Handlers"


#End Region

#Region "Fields"


#End Region

#Region "Schema"

        Public Shared ReadOnly NInteractiveLegendExampleSchema As NSchema

#End Region
    End Class
End Namespace
