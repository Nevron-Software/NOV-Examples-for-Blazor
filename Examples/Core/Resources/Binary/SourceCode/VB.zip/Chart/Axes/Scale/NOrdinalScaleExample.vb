Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Ordinal Scale Example
    ''' </summary>
    Public Class NOrdinalScaleExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NOrdinalScaleExampleSchema = NSchema.Create(GetType(NOrdinalScaleExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Ordinal Scale"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlaced stripe to the Y axis
            Dim linearScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
            Dim stripStyle As NScaleStrip = New NScaleStrip()
            stripStyle.Fill = New NColorFill(NColor.Beige)
            stripStyle.Interlaced = True
            linearScale.Strips.Add(stripStyle)

            ' add some series
            Dim dataItemsCount = 6
            Dim bar As NBarSeries = New NBarSeries()

            bar.InflateMargins = True
            bar.DataLabelStyle = New NDataLabelStyle(False)

            Dim random As Random = New Random()

            For i = 0 To dataItemsCount - 1
                bar.DataPoints.Add(New NBarDataPoint(random.Next(10, 30)))
            Next

            m_Chart.Series.Add(bar)

            Dim ordinalScale As NOrdinalScale = m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale
            ordinalScale.Labels.OverlapResolveLayouts = New NDomArray(Of ENLevelLabelsLayout)(New ENLevelLabelsLayout() {ENLevelLabelsLayout.AutoScale})

            Dim labels As NList(Of String) = New NList(Of String)()
            For j = 0 To dataItemsCount - 1
                labels.Add("Category " & j.ToString())
            Next

            ordinalScale.Labels.TextProvider = New NOrdinalScaleLabelTextProvider(labels)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim displayDataPointsBetweenTicksCheckBox As NCheckBox = New NCheckBox("Display Data Points Between Ticks")
            displayDataPointsBetweenTicksCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnDisplayDataPointsBetweenTicksCheckBoxCheckedChanged)
            displayDataPointsBetweenTicksCheckBox.Checked = True
            stack.Add(displayDataPointsBetweenTicksCheckBox)

            Dim autoLabelsCheckBox As NCheckBox = New NCheckBox("Auto Labels")
            autoLabelsCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnAutoLabelsCheckBoxCheckedChanged)
            autoLabelsCheckBox.Checked = True
            stack.Add(autoLabelsCheckBox)

            Dim invertedCheckBox As NCheckBox = New NCheckBox("Inverted")
            invertedCheckBox.CheckedChanged += AddressOf OnInvertedCheckBoxCheckedChanged
            invertedCheckBox.Checked = False
            stack.Add(invertedCheckBox)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create an ordinal scale.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnAutoLabelsCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            If CType(arg.TargetNode, NCheckBox).Checked Then
                CType(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale, NOrdinalScale).Labels.TextProvider = New NFormattedScaleLabelTextProvider(New NNumericValueFormatter())
            Else
                Dim labels As NList(Of String) = New NList(Of String)()
                Dim dataPointCount = CType(m_Chart.Series(0), NBarSeries).DataPoints.Count

                For j = 0 To dataPointCount - 1
                    labels.Add("Category " & j.ToString())
                Next

                CType(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale, NOrdinalScale).Labels.TextProvider = New NOrdinalScaleLabelTextProvider(labels)
            End If
        End Sub

        Private Sub OnDisplayDataPointsBetweenTicksCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale, NOrdinalScale).DisplayDataPointsBetweenTicks = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnInvertedCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale, NOrdinalScale).Invert = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Implementation"


#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NOrdinalScaleExampleSchema As NSchema

#End Region
    End Class
End Namespace
