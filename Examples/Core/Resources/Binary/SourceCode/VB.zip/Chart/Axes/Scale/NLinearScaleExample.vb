Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Linear Scale Example
    ''' </summary>
    Public Class NLinearScaleExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NLinearScaleExampleSchema = NSchema.Create(GetType(NLinearScaleExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Linear Scale"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' configure the y axis
            Dim linearScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale

            Dim majorGrid As NScaleGridLines = New NScaleGridLines()
            majorGrid.Stroke = New NStroke(1, NColor.DarkGray, ENDashStyle.Dot)
            linearScale.MajorGridLines = majorGrid

            ' add a strip line style
            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Fill = New NColorFill(NColor.Beige)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            Dim line As NLineSeries = New NLineSeries()
            m_Chart.Series.Add(line)

            Dim random As Random = New Random()
            For i = 0 To 6
                line.DataPoints.Add(New NLineDataPoint(random.Next(-100, 100)))
            Next

            line.LegendView.Mode = ENSeriesLegendMode.None
            line.InflateMargins = True

            ' assign marker
            Dim markerStyle As NMarkerStyle = New NMarkerStyle()

            markerStyle.Visible = True
            markerStyle.Shape = ENPointShape3D.Ellipse
            markerStyle.Size = New NSize(6, 6)

            line.MarkerStyle = markerStyle

            ' assign data label style
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()

            dataLabelStyle.Format = "<value>"
            dataLabelStyle.ArrowStroke.Color = NColor.CornflowerBlue

            line.DataLabelStyle = dataLabelStyle

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_MajorTickModeComboBox = New NComboBox()
            m_MajorTickModeComboBox.FillFromEnum(Of ENMajorTickMode)()
            m_MajorTickModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMajorTickModeComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Major Tick Mode:", m_MajorTickModeComboBox))

            m_MinDistanceUpDown = New NNumericUpDown()
            m_MinDistanceUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMinDistanceUpDownValueChanged)
            stack.Add(NPairBox.Create("Min Distance:", m_MinDistanceUpDown))
            m_MinDistanceUpDown.Value = 25

            m_MaxCountNumericUpDown = New NNumericUpDown()
            m_MaxCountNumericUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMaxCountNumericUpDownValueChanged)
            stack.Add(NPairBox.Create("Max Count:", m_MaxCountNumericUpDown))
            m_MaxCountNumericUpDown.Value = 10

            m_CustomStepUpDown = New NNumericUpDown()
            m_CustomStepUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnCustomStepUpDownValueChanged)
            stack.Add(NPairBox.Create("Custom Step:", m_CustomStepUpDown))
            m_CustomStepUpDown.Value = 1

            Dim invertedCheckBox As NCheckBox = New NCheckBox("Inverted")
            invertedCheckBox.CheckedChanged += AddressOf OnInvertedCheckBoxCheckedChanged
            invertedCheckBox.Checked = False
            stack.Add(invertedCheckBox)

            Dim generateRandomDataButton As NButton = New NButton("Generate Random Data")
            generateRandomDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnGenerateRandomDataButtonClick)
            stack.Add(generateRandomDataButton)

            m_MajorTickModeComboBox.SelectedIndex = CInt(ENMajorTickMode.AutoMinDistance)
            OnMajorTickModeComboBoxSelectedIndexChanged(Nothing)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a linear (numeric) scale.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnInvertedCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).Invert = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnGenerateRandomDataButtonClick(arg As NEventArgs)
            Dim line = CType(m_Chart.Series(0), NLineSeries)

            line.DataPoints.Clear()

            Dim random As Random = New Random()
            For i = 0 To 9
                line.DataPoints.Add(New NLineDataPoint(random.Next(100)))
            Next
        End Sub

        Private Sub OnCustomStepUpDownValueChanged(arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).CustomStep = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnMinDistanceUpDownValueChanged(arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).MinTickDistance = CInt(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnMaxCountNumericUpDownValueChanged(arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).MaxTickCount = CInt(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnMajorTickModeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim majorTickMode As ENMajorTickMode = m_MajorTickModeComboBox.SelectedIndex

            m_MaxCountNumericUpDown.Enabled = majorTickMode Is ENMajorTickMode.AutoMaxCount
            m_MinDistanceUpDown.Enabled = majorTickMode Is ENMajorTickMode.AutoMinDistance
            m_CustomStepUpDown.Enabled = majorTickMode Is ENMajorTickMode.CustomStep

            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).MajorTickMode = majorTickMode
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

        Private m_MajorTickModeComboBox As NComboBox
        Private m_MaxCountNumericUpDown As NNumericUpDown
        Private m_MinDistanceUpDown As NNumericUpDown
        Private m_CustomStepUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NLinearScaleExampleSchema As NSchema

#End Region
    End Class
End Namespace
