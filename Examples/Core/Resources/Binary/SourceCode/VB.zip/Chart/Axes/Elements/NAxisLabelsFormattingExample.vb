Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis labels orientation example
    ''' </summary>
    Public Class NAxisLabelsFormattingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisLabelsFormattingExampleSchema = NSchema.Create(GetType(NAxisLabelsFormattingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Axis Labels Formatting"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            'linearScale.Strips.Add(strip);

            ' setup a bar series
            Dim bar As NBarSeries = New NBarSeries()
            bar.Name = "Bar Series"
            bar.InflateMargins = True
            bar.UseXValues = False
            bar.DataLabelStyle = New NDataLabelStyle(False)

            ' add some data to the bar series
            bar.LegendView.Mode = ENSeriesLegendMode.DataPoints
            bar.DataPoints.Add(New NBarDataPoint(18, "C++"))
            bar.DataPoints.Add(New NBarDataPoint(15, "Ruby"))
            bar.DataPoints.Add(New NBarDataPoint(21, "Python"))
            bar.DataPoints.Add(New NBarDataPoint(23, "Java"))
            bar.DataPoints.Add(New NBarDataPoint(27, "Javascript"))
            bar.DataPoints.Add(New NBarDataPoint(29, "C#"))
            bar.DataPoints.Add(New NBarDataPoint(26, "PHP"))

            m_Chart.Series.Add(bar)

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim yAxisDecimalPlaces As NNumericUpDown = New NNumericUpDown()
            yAxisDecimalPlaces.Minimum = 0
            yAxisDecimalPlaces.ValueChanged += AddressOf OnYAxisDecimalPlacesValueChanged
            stack.Add(NPairBox.Create("Y Axis Decimal Places:", yAxisDecimalPlaces))

            Dim useCustomXAxisLabels As NCheckBox = New NCheckBox("Use Custom X Axis Labels")
            useCustomXAxisLabels.CheckedChanged += AddressOf OnUseCustomXAxisLabelsCheckedChanged
            stack.Add(useCustomXAxisLabels)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to apply different formatting to axis labels.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnUseCustomXAxisLabelsCheckedChanged(arg As NValueChangeEventArgs)
            Dim ordinalScale As NOrdinalScale = m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale
            If CType(arg.TargetNode, NCheckBox).Checked Then
                ordinalScale.Labels.TextProvider = New NOrdinalScaleLabelTextProvider(New String() {"C++", "Ruby", "Python", "Java", "Javascript", "C#", "PHP"})
            Else
                ordinalScale.Labels.TextProvider = New NFormattedScaleLabelTextProvider(New NNumericValueFormatter(ENNumericValueFormat.Arabic))
            End If
        End Sub

        Private Sub OnYAxisDecimalPlacesValueChanged(arg As NValueChangeEventArgs)
            Dim decimalPlaces As Integer = CType(arg.TargetNode, NNumericUpDown).Value

            Dim format = "."
            For i = 0 To decimalPlaces - 1
                format += "0"
            Next

            Dim linearScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
            linearScale.Labels.TextProvider = New NFormattedScaleLabelTextProvider(New NNumericValueFormatter(format))
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisLabelsFormattingExampleSchema As NSchema

#End Region
    End Class
End Namespace
