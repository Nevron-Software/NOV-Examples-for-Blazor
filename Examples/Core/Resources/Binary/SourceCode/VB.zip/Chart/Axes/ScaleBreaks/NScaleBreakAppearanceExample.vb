Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Scale Break Appearance Examples
    ''' </summary>
    Public Class NScaleBreakAppearanceExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NScaleBreakAppearanceExampleSchema = NSchema.Create(GetType(NScaleBreakAppearanceExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Scale Breaks Appearance"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.Padding = New NMargins(20)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            m_Chart.PlotFill = New NStockGradientFill(NColor.White, NColor.DarkGray)

            ' configure scale
            Dim yScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
            yScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick

            m_ScaleBreak = New NAutoScaleBreak(0.4F)
            m_ScaleBreak.PositionMode = ENScaleBreakPositionMode.Percent

            yScale.ScaleBreaks.Add(m_ScaleBreak)

            ' add an interlaced strip to the Y axis
            Dim interlacedStrip As NScaleStrip = New NScaleStrip()
            interlacedStrip.Interlaced = True
            interlacedStrip.Fill = New NColorFill(NColor.Beige)
            yScale.Strips.Add(interlacedStrip)

            ' Create some data with a peak in it
            Dim bar As NBarSeries = New NBarSeries()
            m_Chart.Series.Add(bar)
            bar.DataLabelStyle = New NDataLabelStyle(False)

            ' fill in some data so that it contains several peaks of data
            Dim random As Random = New Random()
            For i = 0 To 7
                bar.DataPoints.Add(New NBarDataPoint(random.Next(30)))
            Next

            For i = 0 To 4
                bar.DataPoints.Add(New NBarDataPoint(300 + random.Next(50)))
            Next

            For i = 0 To 7
                bar.DataPoints.Add(New NBarDataPoint(random.Next(30)))
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim styleComboBox As NComboBox = New NComboBox()
            styleComboBox.FillFromEnum(Of ENScaleBreakStyle)()
            styleComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnStyleComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Style:", styleComboBox))
            styleComboBox.SelectedIndex = CInt(ENScaleBreakStyle.Wave)

            Dim patternComboBox As NComboBox = New NComboBox()
            patternComboBox.FillFromEnum(Of ENScaleBreakPattern)()
            patternComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnPatternComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Pattern:", patternComboBox))

            Dim horzStepUpDown As NNumericUpDown = New NNumericUpDown()
            horzStepUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnHorzStepUpDownValueChanged)
            stack.Add(NPairBox.Create("Horz Step:", horzStepUpDown))
            horzStepUpDown.Value = 20

            Dim vertStepUpDown As NNumericUpDown = New NNumericUpDown()
            vertStepUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnVertStepUpDownValueChanged)
            stack.Add(NPairBox.Create("Vert Step:", vertStepUpDown))
            vertStepUpDown.Value = 10

            Dim lengthUpDown As NNumericUpDown = New NNumericUpDown()
            lengthUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnLengthUpDownValueChanged)
            stack.Add(NPairBox.Create("Length:", lengthUpDown))
            lengthUpDown.Value = 10

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to change the appearance of scale breaks.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnLengthUpDownValueChanged(arg As NValueChangeEventArgs)
            m_ScaleBreak.Length = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnVertStepUpDownValueChanged(arg As NValueChangeEventArgs)
            m_ScaleBreak.VertStep = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnHorzStepUpDownValueChanged(arg As NValueChangeEventArgs)
            m_ScaleBreak.HorzStep = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnPatternComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_ScaleBreak.Pattern = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENScaleBreakPattern)
        End Sub

        Private Sub OnStyleComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_ScaleBreak.Style = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENScaleBreakStyle)
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_ScaleBreak As NScaleBreak

#End Region

#Region "Schema"

        Public Shared ReadOnly NScaleBreakAppearanceExampleSchema As NSchema

#End Region
    End Class
End Namespace
