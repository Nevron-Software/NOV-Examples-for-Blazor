Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Custom Scale Breaks Example
    ''' </summary>
    Public Class NCustomScaleBreaksExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NCustomScaleBreaksExampleSchema = NSchema.Create(GetType(NCustomScaleBreaksExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Custom Scale Breaks"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            Dim random As Random = New Random()

            ' create three random point series
            For i = 0 To 2
                Dim point As NPointSeries = New NPointSeries()
                point.UseXValues = True

                point.DataLabelStyle = New NDataLabelStyle(False)
                point.Size = 5

                ' fill in some random data
                For j = 0 To 29
                    point.DataPoints.Add(New NPointDataPoint(5 + random.Next(90), 5 + random.Next(90)))
                Next

                m_Chart.Series.Add(point)
            Next

            ' create scale breaks

            Dim xScale As NScale = m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale

            m_FirstHorzScaleBreak = CreateCustomScaleBreak(NColor.Orange, New NRange(10, 20))
            xScale.ScaleBreaks.Add(m_FirstHorzScaleBreak)

            m_SecondHorzScaleBreak = CreateCustomScaleBreak(NColor.Green, New NRange(80, 90))
            xScale.ScaleBreaks.Add(m_SecondHorzScaleBreak)

            Dim yScale As NScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale

            m_FirstVertScaleBreak = CreateCustomScaleBreak(NColor.Red, New NRange(10, 20))
            yScale.ScaleBreaks.Add(m_FirstVertScaleBreak)

            m_SecondVertScaleBreak = CreateCustomScaleBreak(NColor.Blue, New NRange(80, 90))
            yScale.ScaleBreaks.Add(m_SecondVertScaleBreak)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            stack.Add(New NLabel("First Horizontal Scale Break"))

            Dim firstHScaleBreakBegin As NNumericUpDown = New NNumericUpDown()
            firstHScaleBreakBegin.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFirstHScaleBreakBeginValueChanged)
            stack.Add(NPairBox.Create("Begin:", firstHScaleBreakBegin))

            Dim firstHScaleBreakEnd As NNumericUpDown = New NNumericUpDown()
            firstHScaleBreakEnd.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFirstHScaleBreakEndValueChanged)
            stack.Add(NPairBox.Create("End:", firstHScaleBreakEnd))

            stack.Add(New NLabel("Second Horizontal Scale Break"))

            Dim secondHScaleBreakBegin As NNumericUpDown = New NNumericUpDown()
            secondHScaleBreakBegin.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSecondHScaleBreakBeginValueChanged)
            stack.Add(NPairBox.Create("Begin:", secondHScaleBreakBegin))

            Dim secondHScaleBreakEnd As NNumericUpDown = New NNumericUpDown()
            secondHScaleBreakEnd.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSecondHScaleBreakEndValueChanged)
            stack.Add(NPairBox.Create("End:", secondHScaleBreakEnd))

            stack.Add(New NLabel("First Vertical Scale Break"))

            Dim firstVScaleBreakBegin As NNumericUpDown = New NNumericUpDown()
            firstVScaleBreakBegin.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFirstVScaleBreakBeginValueChanged)
            stack.Add(NPairBox.Create("Begin:", firstVScaleBreakBegin))

            Dim firstVScaleBreakEnd As NNumericUpDown = New NNumericUpDown()
            firstVScaleBreakEnd.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFirstVScaleBreakEndValueChanged)
            stack.Add(NPairBox.Create("End:", firstVScaleBreakEnd))

            stack.Add(New NLabel("Second Vertical Scale Break"))

            Dim secondVScaleBreakBegin As NNumericUpDown = New NNumericUpDown()
            secondVScaleBreakBegin.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSecondVScaleBreakBeginValueChanged)
            stack.Add(NPairBox.Create("Begin:", secondVScaleBreakBegin))

            Dim secondVScaleBreakEnd As NNumericUpDown = New NNumericUpDown()
            secondVScaleBreakEnd.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSecondVScaleBreakEndValueChanged)
            stack.Add(NPairBox.Create("End:", secondVScaleBreakEnd))

            firstHScaleBreakBegin.Value = 10
            firstHScaleBreakEnd.Value = 20

            secondHScaleBreakBegin.Value = 80
            secondHScaleBreakEnd.Value = 90

            firstVScaleBreakBegin.Value = 10
            firstVScaleBreakEnd.Value = 20

            secondVScaleBreakBegin.Value = 80
            secondVScaleBreakEnd.Value = 90

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to add custom scale breaks.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateCustomScaleBreak(color As NColor, range As NRange) As NCustomScaleBreak
            Dim scaleBreak As NCustomScaleBreak = New NCustomScaleBreak()

            scaleBreak.Fill = New NColorFill(New NColor(color, 124))
            scaleBreak.Length = 10
            scaleBreak.Range = range

            Return scaleBreak
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSecondVScaleBreakEndValueChanged(arg As NValueChangeEventArgs)
            m_SecondVertScaleBreak.Range = New NRange(m_SecondVertScaleBreak.Range.Begin, CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnSecondVScaleBreakBeginValueChanged(arg As NValueChangeEventArgs)
            m_SecondVertScaleBreak.Range = New NRange(CType(arg.TargetNode, NNumericUpDown).Value, m_SecondVertScaleBreak.Range.End)
        End Sub

        Private Sub OnFirstVScaleBreakEndValueChanged(arg As NValueChangeEventArgs)
            m_FirstVertScaleBreak.Range = New NRange(m_FirstVertScaleBreak.Range.Begin, CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnFirstVScaleBreakBeginValueChanged(arg As NValueChangeEventArgs)
            m_FirstVertScaleBreak.Range = New NRange(CType(arg.TargetNode, NNumericUpDown).Value, m_FirstVertScaleBreak.Range.End)
        End Sub

        Private Sub OnSecondHScaleBreakEndValueChanged(arg As NValueChangeEventArgs)
            m_SecondHorzScaleBreak.Range = New NRange(m_SecondHorzScaleBreak.Range.Begin, CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnSecondHScaleBreakBeginValueChanged(arg As NValueChangeEventArgs)
            m_SecondHorzScaleBreak.Range = New NRange(CType(arg.TargetNode, NNumericUpDown).Value, m_SecondHorzScaleBreak.Range.End)
        End Sub

        Private Sub OnFirstHScaleBreakEndValueChanged(arg As NValueChangeEventArgs)
            m_FirstHorzScaleBreak.Range = New NRange(m_FirstHorzScaleBreak.Range.Begin, CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnFirstHScaleBreakBeginValueChanged(arg As NValueChangeEventArgs)
            m_FirstHorzScaleBreak.Range = New NRange(CType(arg.TargetNode, NNumericUpDown).Value, m_FirstHorzScaleBreak.Range.End)
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

        Private m_FirstHorzScaleBreak As NCustomScaleBreak
        Private m_SecondHorzScaleBreak As NCustomScaleBreak
        Private m_FirstVertScaleBreak As NCustomScaleBreak
        Private m_SecondVertScaleBreak As NCustomScaleBreak

#End Region

#Region "Schema"

        Public Shared ReadOnly NCustomScaleBreaksExampleSchema As NSchema

#End Region
    End Class
End Namespace
