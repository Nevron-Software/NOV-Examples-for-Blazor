Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Daily Schdule Work Calendar Example
    ''' </summary>
    Public Class NDailyScheduleWorkCalendarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NDailyScheduleWorkCalendarExampleSchema = NSchema.Create(GetType(NDailyScheduleWorkCalendarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Daily Schedule Work Calendar"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            Dim ranges As NRangeSeries = New NRangeSeries()
            m_Chart.Series.Add(ranges)

            ranges.DataLabelStyle = New NDataLabelStyle(False)
            ranges.UseXValues = True

            Dim dt As Date = New DateTime(2014, 4, 14)
            Dim rand As Random = New Random()

            Dim rangeTimeline As NRangeTimelineScale = New NRangeTimelineScale()
            rangeTimeline.EnableCalendar = True
            rangeTimeline.InflateViewRangeEnd = False
            rangeTimeline.InflateViewRangeBegin = False
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = rangeTimeline

            Dim yScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
            yScale.MajorGridLines.Visible = True

            ' add interlaced strip
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            yScale.Strips.Add(strip)

            yScale.Title.Text = "Daily Workload in %"

            Dim workCalendar = rangeTimeline.Calendar
            Dim dateTimeRangeRule As NDateTimeRangeRule = Nothing

            For i = 0 To 119
                Dim hourOfTheDay = i Mod 24

                If hourOfTheDay < 8 OrElse hourOfTheDay > 18 Then
                    Dim curDate As Date = New DateTime(dt.Year, dt.Month, dt.Day, 0, 0, 0)

                    If dateTimeRangeRule IsNot Nothing Then
                        If dateTimeRangeRule.Range.Begin <> curDate Then
                            dateTimeRangeRule = Nothing
                        End If
                    End If

                    If dateTimeRangeRule Is Nothing Then
                        dateTimeRangeRule = New NDateTimeRangeRule(New NDateTimeRange(curDate, curDate + New TimeSpan(24, 0, 0)), True)
                        workCalendar.Rules.Add(dateTimeRangeRule)
                    End If

                    dateTimeRangeRule.Schedule.SetHourRange(dt.Hour, dt.Hour + 1, True)
                Else
                    ranges.DataPoints.Add(New NRangeDataPoint(NDateTimeHelpers.ToOADate(dt), 0, NDateTimeHelpers.ToOADate(dt + New TimeSpan(1, 0, 0)), rand.NextDouble() * 70 + 30.0R))
                End If

                dt += New TimeSpan(1, 0, 0)
            Next

            ConfigureInteractivity(m_Chart)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim enableWorkCalendarCheckBox As NCheckBox = New NCheckBox("Enable Work Calendar")
            enableWorkCalendarCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableWorkCalendarCheckBoxCheckedChanged)
            enableWorkCalendarCheckBox.Checked = True
            stack.Add(enableWorkCalendarCheckBox)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to use the daily schedule of the work calendar in order to skip hourly ranges for which there is no data.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEnableWorkCalendarCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale, NRangeTimelineScale).EnableCalendar = TryCast(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Implementation"

        Private Sub ConfigureInteractivity(chart As NChart)
            Dim interactor As NInteractor = New NInteractor()

            Dim rectangleZoomTool As NRectangleZoomTool = New NRectangleZoomTool()
            rectangleZoomTool.VerticalValueSnapper = New NAxisRulerMinMaxSnapper()
            interactor.Add(rectangleZoomTool)

            Dim dataPanTool As NDataPanTool = New NDataPanTool()
            dataPanTool.StartMouseButtonEvent = ENMouseButtonEvent.RightButtonDown
            dataPanTool.EndMouseButtonEvent = ENMouseButtonEvent.RightButtonUp
            interactor.Add(dataPanTool)

            chart.Interactor = interactor
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Static"

        Public Shared ReadOnly NDailyScheduleWorkCalendarExampleSchema As NSchema

#End Region
    End Class
End Namespace
