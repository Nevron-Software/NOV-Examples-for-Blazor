Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis View Range Example
    ''' </summary>
    Public Class NSynchronizedAxesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NSynchronizedAxesExampleSchema = NSchema.Create(GetType(NSynchronizedAxesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Axis View Range"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.PrimaryAndSecondaryLinear)

            ' configure axes

            Dim primaryX = m_Chart.Axes(ENCartesianAxis.PrimaryX)
            Dim secondaryX = m_Chart.Axes(ENCartesianAxis.SecondaryX)
            Dim primaryY = m_Chart.Axes(ENCartesianAxis.PrimaryY)
            Dim secondaryY = m_Chart.Axes(ENCartesianAxis.SecondaryY)

            primaryX.Scale.Title.Text = "Primary X"
            primaryY.Scale.Title.Text = "Primary Y"
            secondaryX.Scale.Title.Text = "Secondary X"
            secondaryY.Scale.Title.Text = "Secondary Y"

            primaryX.SynchronizedAxes = New NDomArray(Of NNodeRef)(New NNodeRef(secondaryX))
            primaryY.SynchronizedAxes = New NDomArray(Of NNodeRef)(New NNodeRef(secondaryY))

            secondaryX.VisibilityMode = ENAxisVisibilityMode.Visible
            secondaryY.VisibilityMode = ENAxisVisibilityMode.Visible

            OnChangeDataButtonClick(Nothing)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim changeDataButton As NButton = New NButton("Change Data")
            changeDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnChangeDataButtonClick)
            stack.Add(changeDataButton)


            Return boxGroup
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to synchronize the ranges of two or more axes.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChangeDataButtonClick(arg As NEventArgs)
            m_Chart.Series.Clear()

            ' setup bar series
            Dim point As NPointSeries = New NPointSeries()
            point.UseXValues = True
            m_Chart.Series.Add(point)

            point.DataLabelStyle = New NDataLabelStyle(False)

            ' fill in some data so that it contains several peaks of data
            Dim random As Random = New Random()

            For i = 0 To 24
                Dim value As Double = random.NextDouble() * 100
                Dim xvalue As Double = random.NextDouble() * 100

                Dim dataPoint As NPointDataPoint = New NPointDataPoint(value, xvalue)
                point.DataPoints.Add(dataPoint)
            Next
        End Sub

#End Region

#Region "Implementation"

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

        Private m_ViewRangeMode As NComboBox
        Private m_ViewRangeBegin As NNumericUpDown
        Private m_ViewRangeEnd As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NSynchronizedAxesExampleSchema As NSchema

#End Region
    End Class
End Namespace
