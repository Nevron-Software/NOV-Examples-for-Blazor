Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis View Range Example
    ''' </summary>
    Public Class NAxisViewRangeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisViewRangeExampleSchema = NSchema.Create(GetType(NAxisViewRangeExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Axis View Range"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            m_Chart.Axes(ENCartesianAxis.PrimaryY).ClipMode = ENAxisClipMode.Auto

            ' configure scale
            Dim yScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
            yScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            yScale.MinTickDistance = 30

            ' add an interlaced strip to the Y axis
            Dim interlacedStrip As NScaleStrip = New NScaleStrip()
            interlacedStrip.Interlaced = True
            interlacedStrip.Fill = New NColorFill(NColor.Beige)
            yScale.Strips.Add(interlacedStrip)

            OnChangeDataButtonClick(Nothing)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_ViewRangeMode = New NComboBox()
            m_ViewRangeMode.FillFromEnum(Of ENAxisViewRangeMode)()
            Me.m_ViewRangeMode.SelectedIndexChanged += AddressOf OnViewRangeModeSelectedIndexChanged
            m_ViewRangeMode.SelectedIndex = CInt(ENAxisViewRangeMode.Auto)
            stack.Add(NPairBox.Create("View Range Mode:", m_ViewRangeMode))

            m_ViewRangeMinValue = New NNumericUpDown()
            Me.m_ViewRangeMinValue.ValueChanged += AddressOf OnViewRangeMinValueChanged
            m_ViewRangeMinValue.Value = 20
            stack.Add(NPairBox.Create("View Range Min:", m_ViewRangeMinValue))

            m_ViewRangeMaxValue = New NNumericUpDown()
            Me.m_ViewRangeMaxValue.ValueChanged += AddressOf OnViewRangMaxValueChanged
            m_ViewRangeMaxValue.Value = 80
            stack.Add(NPairBox.Create("View Range Max:", m_ViewRangeMaxValue))

            Dim changeDataButton As NButton = New NButton("Change Data")
            changeDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnChangeDataButtonClick)
            stack.Add(changeDataButton)

            Return boxGroup
        End Function

        Private Sub OnViewRangeMinValueChanged(arg As NValueChangeEventArgs)
            m_Chart.Axes(ENCartesianAxis.PrimaryY).MinViewRangeValue = m_ViewRangeMinValue.Value
        End Sub

        Private Sub OnViewRangMaxValueChanged(arg As NValueChangeEventArgs)
            m_Chart.Axes(ENCartesianAxis.PrimaryY).MaxViewRangeValue = m_ViewRangeMaxValue.Value
        End Sub

        Private Sub OnViewRangeModeSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim viewRangeMode As ENAxisViewRangeMode = m_ViewRangeMode.SelectedIndex
            m_Chart.Axes(ENCartesianAxis.PrimaryY).ViewRangeMode = viewRangeMode

            Select Case viewRangeMode
                Case ENAxisViewRangeMode.Auto
                    m_ViewRangeMinValue.Enabled = False
                    m_ViewRangeMaxValue.Enabled = False
                Case ENAxisViewRangeMode.FixedMin
                    m_ViewRangeMinValue.Enabled = True
                    m_ViewRangeMaxValue.Enabled = False
                Case ENAxisViewRangeMode.FixedMax
                    m_ViewRangeMinValue.Enabled = False
                    m_ViewRangeMaxValue.Enabled = True
                Case ENAxisViewRangeMode.FixedRange
                    m_ViewRangeMinValue.Enabled = True
                    m_ViewRangeMaxValue.Enabled = True
            End Select
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to explicitly set the axis view range.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChangeDataButtonClick(arg As NEventArgs)
            m_Chart.Series.Clear()

            ' setup bar series
            Dim bar As NBarSeries = New NBarSeries()
            m_Chart.Series.Add(bar)

            bar.DataLabelStyle = New NDataLabelStyle(False)
            bar.Stroke = New NStroke(1.5F, NColor.DarkGreen)

            ' fill in some data so that it contains several peaks of data
            Dim random As Random = New Random()

            For i = 0 To 24
                Dim value As Double = random.NextDouble() * 100

                Dim dataPoint As NBarDataPoint = New NBarDataPoint(value)
                bar.DataPoints.Add(dataPoint)
            Next
        End Sub


#End Region

#Region "Implementation"

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

        Private m_ViewRangeMode As NComboBox
        Private m_ViewRangeMinValue As NNumericUpDown
        Private m_ViewRangeMaxValue As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisViewRangeExampleSchema As NSchema

#End Region
    End Class
End Namespace
