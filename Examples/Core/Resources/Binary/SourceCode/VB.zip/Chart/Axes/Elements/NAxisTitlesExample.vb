Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis titles example.
    ''' </summary>
    Public Class NAxisTitlesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisTitlesExampleSchema = NSchema.Create(GetType(NAxisTitlesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            chartView.Surface.Titles(0).Text = "Axis Titles"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)
            Dim scaleY As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale

            ' add interlaced stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            scaleY.Strips.Add(strip)

            Dim scaleX As NOrdinalScale = m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale

            ' create dummy data
            Dim bar As NBarSeries = New NBarSeries()
            bar.Name = "Bars"
            Dim random As Random = New Random()
            For i = 0 To 9
                bar.DataPoints.Add(New NBarDataPoint(random.Next(100)))
            Next

            m_Chart.Series.Add(bar)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            stack.Add(New NLabel("X Axis Title"))
            Dim xAxisTitleTextBox As NTextBox = New NTextBox()
            xAxisTitleTextBox.TextChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnXAxisTitleTextBoxTextChanged)
            stack.Add(NPairBox.Create("Text:", xAxisTitleTextBox))
            xAxisTitleTextBox.Text = "X Axis Title"

            Dim xOffsetUpDown As NNumericUpDown = New NNumericUpDown()
            xOffsetUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnXOffsetUpDownValueChanged)
            stack.Add(NPairBox.Create("Offset:", xOffsetUpDown))
            xOffsetUpDown.Value = 10

            Dim xAlignmentCombo As NComboBox = New NComboBox()
            xAlignmentCombo.FillFromEnum(Of ENHorizontalAlignment)()
            xAlignmentCombo.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnXAlignmentComboSelectedIndexChanged)
            stack.Add(NPairBox.Create("Offset:", xAlignmentCombo))
            xAlignmentCombo.SelectedIndex = CInt(ENHorizontalAlignment.Center)

            stack.Add(New NLabel("Y Axis Title"))

            Dim yAxisTitleTextBox As NTextBox = New NTextBox()
            yAxisTitleTextBox.TextChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnYAxisTitleTextBoxTextChanged)
            stack.Add(NPairBox.Create("Text:", yAxisTitleTextBox))
            yAxisTitleTextBox.Text = "Y Axis Title"

            Dim yOffsetUpDown As NNumericUpDown = New NNumericUpDown()
            yOffsetUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnYOffsetUpDownValueChanged)
            stack.Add(NPairBox.Create("Offset:", yOffsetUpDown))
            yOffsetUpDown.Value = 10

            Dim yAlignmentCombo As NComboBox = New NComboBox()
            yAlignmentCombo.FillFromEnum(Of ENHorizontalAlignment)()
            yAlignmentCombo.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnYAlignmentComboSelectedIndexChanged)
            stack.Add(NPairBox.Create("Offset:", yAlignmentCombo))
            yAlignmentCombo.SelectedIndex = CInt(ENHorizontalAlignment.Center)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the most important features of the axis titles.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Shared Sub SetAlignment(title As NScaleTitle, alignment As ENHorizontalAlignment)
            title.RulerAlignment = alignment

            Select Case alignment
                Case ENHorizontalAlignment.Left
                    title.ContentAlignment = ENContentAlignment.MiddleLeft
                Case ENHorizontalAlignment.Center
                    title.ContentAlignment = ENContentAlignment.MiddleCenter
                Case ENHorizontalAlignment.Right
                    title.ContentAlignment = ENContentAlignment.MiddleRight
            End Select
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnXAxisTitleTextBoxTextChanged(arg As NValueChangeEventArgs)
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale.Title.Text = CType(arg.TargetNode, NTextBox).Text
        End Sub

        Private Sub OnXOffsetUpDownValueChanged(arg As NValueChangeEventArgs)
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale.Title.Offset = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnXAlignmentComboSelectedIndexChanged(arg As NValueChangeEventArgs)
            NAxisTitlesExample.SetAlignment(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale.Title, CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENHorizontalAlignment))
        End Sub

        Private Sub OnYAxisTitleTextBoxTextChanged(arg As NValueChangeEventArgs)
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Title.Text = CType(arg.TargetNode, NTextBox).Text
        End Sub

        Private Sub OnYOffsetUpDownValueChanged(arg As NValueChangeEventArgs)
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Title.Offset = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnYAlignmentComboSelectedIndexChanged(arg As NValueChangeEventArgs)
            NAxisTitlesExample.SetAlignment(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Title, CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENHorizontalAlignment))
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisTitlesExampleSchema As NSchema

#End Region
    End Class
End Namespace
