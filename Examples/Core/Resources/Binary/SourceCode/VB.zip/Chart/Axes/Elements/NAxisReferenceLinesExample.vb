Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis docking example
    ''' </summary>
    Public Class NAxisReferenceLinesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisReferenceLinesExampleSchema = NSchema.Create(GetType(NAxisReferenceLinesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Axis Reference Lines"

            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' configure the y scale
            Dim yScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale

            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            yScale.Strips.Add(stripStyle)

            yScale.MajorGridLines.Visible = True

            ' Create a point series
            Dim point As NPointSeries = New NPointSeries()
            point.InflateMargins = True
            point.UseXValues = True
            point.Name = "Series 1"
            chart.Series.Add(point)

            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.Visible = False
            point.DataLabelStyle = dataLabelStyle

            ' Add some data
            Dim yValues = New Double() {31, 67, 12, 84, 90}
            Dim xValues = New Double() {5, 36, 51, 76, 93}

            For i = 0 To yValues.Length - 1
                point.DataPoints.Add(New NPointDataPoint(xValues(i), yValues(i)))
            Next

            ' Add a constline for the left axis
            m_XReferenceLine = New NAxisReferenceLine()
            m_XReferenceLine.Stroke = New NStroke(1, NColor.Red)
            m_XReferenceLine.Value = 40
            m_XReferenceLine.Text = "X Reference Line"
            m_XReferenceLine.TextStyle = New NTextStyle()
            m_XReferenceLine.TextStyle.Fill = New NColorFill(NColor.Red)
            chart.Axes(ENCartesianAxis.PrimaryX).ReferenceLines.Add(m_XReferenceLine)

            ' Add a constline for the bottom axis
            m_YReferenceLine = New NAxisReferenceLine()
            m_YReferenceLine.Stroke = New NStroke(1, NColor.Green)
            m_YReferenceLine.Value = 60
            m_YReferenceLine.Text = "Y Reference Line"
            m_YReferenceLine.TextStyle = New NTextStyle()
            m_YReferenceLine.TextStyle.Fill = New NColorFill(NColor.Green)
            chart.Axes(ENCartesianAxis.PrimaryY).ReferenceLines.Add(m_YReferenceLine)

            ' apply style sheet
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            stack.Add(New NLabel("Y Axis Reference Line"))

            Dim yReferenceLineValueUpDown As NNumericUpDown = New NNumericUpDown()
            yReferenceLineValueUpDown.ValueChanged += AddressOf OnYReferenceLineValueUpDownValueChanged
            yReferenceLineValueUpDown.Value = m_YReferenceLine.Value
            stack.Add(NPairBox.Create("Value:", yReferenceLineValueUpDown))

            Dim yReferenceLineIncludeInAxisRangeCheckBox As NCheckBox = New NCheckBox("Include Value in Axis Range")
            yReferenceLineIncludeInAxisRangeCheckBox.Checked = m_YReferenceLine.IncludeValueInAxisRange
            yReferenceLineIncludeInAxisRangeCheckBox.CheckedChanged += AddressOf OnYReferenceLineIncludeInAxisRangeCheckBoxCheckedChanged
            stack.Add(yReferenceLineIncludeInAxisRangeCheckBox)

            Dim yReferenceLinePaintAfterSeriesCheckBox As NCheckBox = New NCheckBox("Paint After Series")
            yReferenceLinePaintAfterSeriesCheckBox.Checked = m_YReferenceLine.PaintAfterChartContent
            yReferenceLinePaintAfterSeriesCheckBox.CheckedChanged += AddressOf OnYReferenceLinePaintAfterSeriesCheckBoxCheckedChanged
            stack.Add(yReferenceLinePaintAfterSeriesCheckBox)

            Dim yTextAlignmentComboBox As NComboBox = New NComboBox()
            yTextAlignmentComboBox.FillFromEnum(Of ENContentAlignment)()
            yTextAlignmentComboBox.SelectedIndex = m_YReferenceLine.TextAlignment
            yTextAlignmentComboBox.SelectedIndexChanged += AddressOf OnYTextAlignmentComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Text Alignment:", yTextAlignmentComboBox))

            stack.Add(New NLabel("X Axis Reference Line"))

            Dim xReferenceLineValueUpDown As NNumericUpDown = New NNumericUpDown()
            xReferenceLineValueUpDown.Value = m_XReferenceLine.Value
            xReferenceLineValueUpDown.ValueChanged += AddressOf OnXReferenceLineValueUpDownValueChanged
            stack.Add(NPairBox.Create("Value:", xReferenceLineValueUpDown))

            Dim xReferenceLinePaintAfterSeriesCheckBox As NCheckBox = New NCheckBox("Paint After Series")
            xReferenceLinePaintAfterSeriesCheckBox.Checked = m_XReferenceLine.PaintAfterChartContent
            xReferenceLinePaintAfterSeriesCheckBox.CheckedChanged += AddressOf OnXReferenceLinePaintAfterSeriesCheckBoxCheckedChanged
            stack.Add(xReferenceLinePaintAfterSeriesCheckBox)

            Dim xReferenceLineIncludeInAxisRangeCheckBox As NCheckBox = New NCheckBox("Include Value in Axis Range")
            xReferenceLineIncludeInAxisRangeCheckBox.Checked = m_YReferenceLine.IncludeValueInAxisRange
            xReferenceLineIncludeInAxisRangeCheckBox.CheckedChanged += AddressOf OnXReferenceLineIncludeInAxisRangeCheckBoxCheckedChanged
            stack.Add(xReferenceLineIncludeInAxisRangeCheckBox)

            Dim xTextAlignmentComboBox As NComboBox = New NComboBox()
            xTextAlignmentComboBox.FillFromEnum(Of ENContentAlignment)()
            xTextAlignmentComboBox.SelectedIndex = m_XReferenceLine.TextAlignment
            xTextAlignmentComboBox.SelectedIndexChanged += AddressOf OnXTextAlignmentComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Text Alignment:", xTextAlignmentComboBox))

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to add axis reference lines.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnXReferenceLineValueUpDownValueChanged(arg As NValueChangeEventArgs)
            m_XReferenceLine.Value = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnXReferenceLineIncludeInAxisRangeCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_XReferenceLine.IncludeValueInAxisRange = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnXReferenceLinePaintAfterSeriesCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_XReferenceLine.PaintAfterChartContent = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnXTextAlignmentComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_XReferenceLine.TextAlignment = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENContentAlignment)
        End Sub

        Private Sub OnYReferenceLineValueUpDownValueChanged(arg As NValueChangeEventArgs)
            m_YReferenceLine.Value = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnYReferenceLineIncludeInAxisRangeCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_YReferenceLine.IncludeValueInAxisRange = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnYReferenceLinePaintAfterSeriesCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_YReferenceLine.PaintAfterChartContent = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnYTextAlignmentComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_YReferenceLine.TextAlignment = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENContentAlignment)
        End Sub

#End Region

#Region "Fields"

        Private m_XReferenceLine As NAxisReferenceLine
        Private m_YReferenceLine As NAxisReferenceLine

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisReferenceLinesExampleSchema As NSchema

#End Region
    End Class
End Namespace
