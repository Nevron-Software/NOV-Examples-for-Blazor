Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Demonstrates how to position polar angle axes
    ''' </summary>
    Public Class NPolarAngleAxisPositionExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NPolarAngleAxisPositionExampleSchema = NSchema.Create(GetType(NPolarAngleAxisPositionExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreatePolarChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Polar Angle Axis Position"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NPolarChart)

            m_Chart.SetPredefinedPolarAxes(ENPredefinedPolarAxes.AngleSecondaryAngleValue)

            ' setup chart
            m_Chart.InnerRadius = 40

            ' create a polar line series
            Dim series1 As NPolarLineSeries = New NPolarLineSeries()
            m_Chart.Series.Add(series1)
            series1.Name = "Series 1"
            series1.CloseContour = True
            series1.DataLabelStyle = New NDataLabelStyle(False)
            series1.MarkerStyle = New NMarkerStyle(False)
            series1.UseXValues = True
            Curve1(series1, 50)

            ' create a polar line series
            Dim series2 As NPolarLineSeries = New NPolarLineSeries()
            m_Chart.Series.Add(series2)
            series2.Name = "Series 2"
            series2.CloseContour = True
            series2.DataLabelStyle = New NDataLabelStyle(False)
            series2.MarkerStyle = New NMarkerStyle(False)
            series2.UseXValues = True
            Curve2(series2, 100)

            ' setup polar axis
            Dim linearScale As NLinearScale = m_Chart.Axes(ENPolarAxis.PrimaryValue).Scale
            linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            linearScale.InflateViewRangeBegin = True
            linearScale.InflateViewRangeEnd = True
            linearScale.MajorGridLines.Visible = True
            linearScale.MajorGridLines.Stroke = New NStroke(1, NColor.Gray, ENDashStyle.Solid)

            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Fill = New NColorFill(NColor.Beige)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' setup polar angle axis
            Dim degreeScale As NAngularScale = m_Chart.Axes(ENPolarAxis.PrimaryAngle).Scale

            degreeScale.MajorGridLines.Visible = True
            degreeScale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)

            ' add a second value axes
            Dim valueAxis = m_Chart.Axes(ENPolarAxis.PrimaryValue)

            m_RedAxis = m_Chart.Axes(ENPolarAxis.PrimaryAngle)
            m_GreenAxis = m_Chart.Axes(ENPolarAxis.SecondaryAngle)

            Dim gradScale As NAngularScale = New NAngularScale()
            gradScale.AngleUnit = NUnit.Grad
            gradScale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)

            m_GreenAxis.Scale = gradScale

            Dim greenAxisCrossing As NValueAxisCrossing = New NValueAxisCrossing(m_RedAxis, 70)
            Dim greenCrossAnchor As NCrossPolarAxisAnchor = New NCrossPolarAxisAnchor(greenAxisCrossing, ENPolarAxisOrientation.Angle, ENScaleOrientation.Right)

            m_GreenAxis.Anchor = greenCrossAnchor

            m_RedAxis.Anchor = New NDockPolarAxisAnchor(ENPolarAxisDockZone.OuterRim)

            Dim redAxisCrossing As NValueAxisCrossing = New NValueAxisCrossing(m_RedAxis, 90)
            Dim redCrossAnchor As NCrossPolarAxisAnchor = New NCrossPolarAxisAnchor(redAxisCrossing, ENPolarAxisOrientation.Value, ENScaleOrientation.Auto)

            m_Chart.Axes(ENPolarAxis.PrimaryValue).Anchor = redCrossAnchor

            ' apply style sheet
            ' color code the axes and series after the stylesheet is applied
            m_RedAxis.Scale.SetColor(NColor.Red)
            m_GreenAxis.Scale.SetColor(NColor.Green)

            series2.ValueAxis = m_GreenAxis

            Return chartView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            ' begin angle
            Dim beginAngleUpDown As NNumericUpDown = New NNumericUpDown()
            beginAngleUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnBeginAngleUpDownValueChanged)
            stack.Add(NPairBox.Create("Begin Angle:", beginAngleUpDown))

            ' red axis controls
            stack.Add(New NLabel("Degree Axis (Red):"))

            Dim dockRedAxisCheckBox As NCheckBox = New NCheckBox("Dock")
            stack.Add(dockRedAxisCheckBox)

            m_RedAxisCrossValueUpDown = New NNumericUpDown()
            stack.Add(NPairBox.Create("Cross Value:", m_RedAxisCrossValueUpDown))

            ' green axis controls
            stack.Add(New NLabel("Grad Axis (Green):"))

            Dim dockGreenAxisCheckBox As NCheckBox = New NCheckBox("Dock")
            stack.Add(dockGreenAxisCheckBox)

            m_GreenAxisCrossValueUpDown = New NNumericUpDown()
            stack.Add(NPairBox.Create("Cross Value:", m_GreenAxisCrossValueUpDown))

            ' wire events
            dockRedAxisCheckBox.CheckedChanged += AddressOf OnDockRedAxisCheckBoxCheckedChanged
            Me.m_RedAxisCrossValueUpDown.ValueChanged += AddressOf OnRedAxisCrossValueUpDownValueChanged
            dockGreenAxisCheckBox.CheckedChanged += AddressOf OnDockGreenAxisCheckBoxCheckedChanged
            Me.m_GreenAxisCrossValueUpDown.ValueChanged += AddressOf OnGreenAxisCrossValueUpDownValueChanged

            ' init values
            m_RedAxisCrossValueUpDown.Value = 50
            dockRedAxisCheckBox.Checked = True

            dockGreenAxisCheckBox.Checked = False
            m_GreenAxisCrossValueUpDown.Value = 70

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to control the polar angle axis position.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnBeginAngleUpDownValueChanged(arg As NValueChangeEventArgs)
            m_Chart.BeginAngle = New NAngle(CType(arg.TargetNode, NNumericUpDown).Value, NUnit.Degree)
        End Sub

        Private Sub OnDockGreenAxisCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            If CType(arg.TargetNode, NCheckBox).Checked Then
                m_GreenAxis.Anchor = New NDockPolarAxisAnchor(ENPolarAxisDockZone.OuterRim)
                m_GreenAxisCrossValueUpDown.Enabled = False
            Else
                Dim axisAnchor As NCrossPolarAxisAnchor = New NCrossPolarAxisAnchor(ENPolarAxisOrientation.Angle, ENScaleOrientation.Auto)
                axisAnchor.Crossing = New NValueAxisCrossing(m_Chart.Axes(ENPolarAxis.PrimaryValue), m_GreenAxisCrossValueUpDown.Value)
                m_GreenAxis.Anchor = axisAnchor

                m_GreenAxisCrossValueUpDown.Enabled = True
            End If
        End Sub

        Private Sub OnGreenAxisCrossValueUpDownValueChanged(arg As NValueChangeEventArgs)
            Dim axisAnchor As NCrossPolarAxisAnchor = New NCrossPolarAxisAnchor(ENPolarAxisOrientation.Angle, ENScaleOrientation.Auto)
            axisAnchor.Crossing = New NValueAxisCrossing(m_Chart.Axes(ENPolarAxis.PrimaryValue), m_GreenAxisCrossValueUpDown.Value)
            m_GreenAxis.Anchor = axisAnchor
        End Sub

        Private Sub OnDockRedAxisCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            If CType(arg.TargetNode, NCheckBox).Checked Then
                m_RedAxis.Anchor = New NDockPolarAxisAnchor(ENPolarAxisDockZone.OuterRim)
                m_RedAxisCrossValueUpDown.Enabled = False
            Else
                Dim axisAnchor As NCrossPolarAxisAnchor = New NCrossPolarAxisAnchor(ENPolarAxisOrientation.Angle, ENScaleOrientation.Auto)
                axisAnchor.Crossing = New NValueAxisCrossing(m_Chart.Axes(ENPolarAxis.PrimaryValue), m_RedAxisCrossValueUpDown.Value)
                m_RedAxis.Anchor = axisAnchor

                m_RedAxisCrossValueUpDown.Enabled = True
            End If
        End Sub

        Private Sub OnRedAxisCrossValueUpDownValueChanged(arg As NValueChangeEventArgs)
            Dim axisAnchor As NCrossPolarAxisAnchor = New NCrossPolarAxisAnchor(ENPolarAxisOrientation.Angle, ENScaleOrientation.Auto)
            axisAnchor.Crossing = New NValueAxisCrossing(m_Chart.Axes(ENPolarAxis.PrimaryValue), m_RedAxisCrossValueUpDown.Value)
            m_RedAxis.Anchor = axisAnchor
        End Sub

#End Region

#Region "Implementation"

        Friend Shared Sub Curve1(series As NPolarLineSeries, count As Integer)
            series.DataPoints.Clear()

            Dim angleStep = 2 * Math.PI / count

            For i = 0 To count - 1
                Dim angle = i * angleStep
                Dim radius = 100 * Math.Cos(angle)

                series.DataPoints.Add(New NPolarLineDataPoint(angle * 180 / Math.PI, radius))
            Next
        End Sub

        Friend Shared Sub Curve2(series As NPolarLineSeries, count As Integer)
            series.DataPoints.Clear()

            Dim angleStep = 2 * Math.PI / count

            For i = 0 To count - 1
                Dim angle = i * angleStep
                Dim radius = 33 + 100 * Math.Sin(2 * angle) + 1.7 * Math.Cos(2 * angle)

                radius = Math.Abs(radius)

                series.DataPoints.Add(New NPolarLineDataPoint(angle * 180 / Math.PI, radius))
            Next

        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NPolarChart

        Private m_RedAxis As NPolarAxis
        Private m_GreenAxis As NPolarAxis

        Private m_GreenAxisCrossValueUpDown As NNumericUpDown
        Private m_RedAxisCrossValueUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NPolarAngleAxisPositionExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreatePolarChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Polar)
            Return chartView
        End Function

#End Region
    End Class
End Namespace
