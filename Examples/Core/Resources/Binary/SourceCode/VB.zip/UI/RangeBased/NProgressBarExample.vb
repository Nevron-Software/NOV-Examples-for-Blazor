Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NProgressBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NProgressBarExampleSchema = NSchema.Create(GetType(NProgressBarExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.VerticalPlacement = ENVerticalPlacement.Top

            ' Horizontal progress bar
            m_HorizontalProgressBar = New NProgressBar()
            m_HorizontalProgressBar.Style = ENProgressBarStyle.Horizontal
            m_HorizontalProgressBar.Mode = DefaultMode
            m_HorizontalProgressBar.Value = DefaultValue
            m_HorizontalProgressBar.BufferedValue = DefaultBufferedValue
            m_HorizontalProgressBar.PreferredSize = New NSize(300, 30)
            m_HorizontalProgressBar.VerticalPlacement = ENVerticalPlacement.Top
            stack.Add(New NGroupBox("Horizontal", m_HorizontalProgressBar))

            ' Vertical progress bar
            m_VerticalProgressBar = New NProgressBar()
            m_VerticalProgressBar.Style = ENProgressBarStyle.Vertical
            m_VerticalProgressBar.Mode = DefaultMode
            m_VerticalProgressBar.Value = DefaultValue
            m_VerticalProgressBar.BufferedValue = DefaultBufferedValue
            m_VerticalProgressBar.PreferredSize = New NSize(30, 300)
            m_VerticalProgressBar.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.Add(New NGroupBox("Vertical", m_VerticalProgressBar))

            ' Circular progress bar - 50% rim
            m_CircularProgressBar1 = New NProgressBar()
            m_CircularProgressBar1.Style = ENProgressBarStyle.Circular
            m_CircularProgressBar1.Mode = DefaultMode
            m_CircularProgressBar1.Value = DefaultValue
            m_CircularProgressBar1.BufferedValue = DefaultBufferedValue
            m_CircularProgressBar1.PreferredSize = New NSize(150, 150)

            ' Circular progress bar - 100% rim
            m_CircularProgressBar2 = New NProgressBar()
            m_CircularProgressBar2.Style = ENProgressBarStyle.Circular
            m_CircularProgressBar2.Mode = DefaultMode
            m_CircularProgressBar2.Value = DefaultValue
            m_CircularProgressBar2.BufferedValue = DefaultBufferedValue
            m_CircularProgressBar2.RimWidthPercent = 100
            m_CircularProgressBar2.PreferredSize = New NSize(150, 150)

            Dim pairBox As NPairBox = New NPairBox(m_CircularProgressBar1, m_CircularProgressBar2)
            pairBox.Spacing = 30

            stack.Add(New NGroupBox("Circular", pairBox))

            ' Create the Progress bars array
            m_ProgressBars = New NProgressBar(3) {}
            m_ProgressBars(0) = m_HorizontalProgressBar
            m_ProgressBars(1) = m_VerticalProgressBar
            m_ProgressBars(2) = m_CircularProgressBar1
            m_ProgressBars(3) = m_CircularProgressBar2

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.Direction = ENHVDirection.TopToBottom

            ' The Mode combo box
            Dim comboBox As NComboBox = New NComboBox()
            comboBox.FillFromEnum(Of ENProgressBarMode)()
            comboBox.SelectedIndex = m_HorizontalProgressBar.Mode
            comboBox.SelectedIndexChanged += AddressOf OnModeSelected
            stack.Add(NPairBox.Create("Mode:", comboBox))

            ' The Label style combo box
            comboBox = New NComboBox()
            comboBox.FillFromEnum(Of ENProgressBarLabelStyle)()
            comboBox.SelectedIndex = m_HorizontalProgressBar.LabelStyle
            comboBox.SelectedIndexChanged += AddressOf OnLabelStyleSelected
            stack.Add(NPairBox.Create("Label Style:", comboBox))

            ' The Value numeric up down
            Dim valueUpDown As NNumericUpDown = New NNumericUpDown(0, 100, DefaultValue)
            valueUpDown.ValueChanged += AddressOf OnValueChanged

            m_ValuePairBox = NPairBox.Create("Value:", valueUpDown)
            stack.Add(m_ValuePairBox)

            ' The Buffered value numeric up down
            Dim bufferedValueUpDown As NNumericUpDown = New NNumericUpDown(0, 100, DefaultBufferedValue)
            bufferedValueUpDown.ValueChanged += AddressOf OnBufferedValueChanged

            m_BufferedValuePairBox = NPairBox.Create("Buffered Value:", bufferedValueUpDown)
            stack.Add(m_BufferedValuePairBox)

            ' The Indeterminate part size numeric up down
            Dim indeterminateSizeUpDown As NNumericUpDown = New NNumericUpDown(1, 100, 25)
            indeterminateSizeUpDown.ValueChanged += AddressOf OnIndeterminateSizeUpDownValueChanged

            m_IndeterminatePartSizePairBox = NPairBox.Create("Indeterminate Size (%):", indeterminateSizeUpDown)
            stack.Add(m_IndeterminatePartSizePairBox)

            ' The Animation speed numeric up down
            Dim animationSpeedUpDown As NNumericUpDown = New NNumericUpDown(0.1, 99, 2)
            animationSpeedUpDown.DecimalPlaces = 1
            animationSpeedUpDown.Step = 0.1
            animationSpeedUpDown.ValueChanged += AddressOf OnAnimationSpeedUpDownValueChanged

            m_AnimationSpeedPairBox = NPairBox.Create("Animation Speed (%):", animationSpeedUpDown)
            stack.Add(m_AnimationSpeedPairBox)

            ' Update controls visibility
            UpdateControlsVisibility(DefaultMode)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use progress bars. The progress bar is a widget that
	fills to indicate the progress of an operation. The <b>Style</b> property determines whether
	it is horizontally, vertically oriented or circular. The <b>Minimum</b> and <b>Maximum</b> properties
	determine the start and the end of the operation and the <b>Value</b> property indicates its current progress.
	All progress bars can have a label and its style is controlled through the <b>LabelStyle</b> property.
	Circular progress bars let you specify the width of their rim in percent relative to the size of the
	progress bar as this example demonstrates.
</p>
<p>
	The <b>Mode</b> property determines the progress bar mode and can be:
</p>
<ul>
	<li><b>Determinate</b> - the progress bar shows the progress of an operation from 0 to 100%. This is the default mode.</li>
	<li><b>Indeterminate</b> - the progress bar shows an animation indicating that a long-running operation is executing. No specific
		progress is shown. This mode should be used for operations whose progress cannot be estimated, for example a long-running database query.</li>
	<li><b>Buffered</b> - the progress bar shows the progress of an operation from 0 to 100%. It also additionally shows the buffered
		value of the operation with a lighter color. The buffered value is specified through the <b>BufferedValue</b> property.</li>
</ul>
"
        End Function

#End Region

#Region "Implementation"

        Private Sub UpdateControlsVisibility(mode As ENProgressBarMode)
            Select Case mode
                Case ENProgressBarMode.Determinate
                    m_ValuePairBox.Visibility = ENVisibility.Visible
                    m_BufferedValuePairBox.Visibility = ENVisibility.Collapsed
                    m_IndeterminatePartSizePairBox.Visibility = ENVisibility.Collapsed
                    m_AnimationSpeedPairBox.Visibility = ENVisibility.Collapsed
                Case ENProgressBarMode.Indeterminate
                    m_ValuePairBox.Visibility = ENVisibility.Collapsed
                    m_BufferedValuePairBox.Visibility = ENVisibility.Collapsed
                    m_IndeterminatePartSizePairBox.Visibility = ENVisibility.Visible
                    m_AnimationSpeedPairBox.Visibility = ENVisibility.Visible
                Case ENProgressBarMode.Buffered
                    m_ValuePairBox.Visibility = ENVisibility.Visible
                    m_BufferedValuePairBox.Visibility = ENVisibility.Visible
                    m_IndeterminatePartSizePairBox.Visibility = ENVisibility.Collapsed
                    m_AnimationSpeedPairBox.Visibility = ENVisibility.Collapsed
            End Select
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnModeSelected(arg As NValueChangeEventArgs)
            Dim mode As ENProgressBarMode = arg.NewValue
            For i = 0 To m_ProgressBars.Length - 1
                m_ProgressBars(i).Mode = mode
            Next

            UpdateControlsVisibility(mode)
        End Sub
        Private Sub OnLabelStyleSelected(arg As NValueChangeEventArgs)
            Dim labelStyle As ENProgressBarLabelStyle = arg.NewValue
            For i = 0 To m_ProgressBars.Length - 1
                m_ProgressBars(i).LabelStyle = labelStyle
            Next
        End Sub
        Private Sub OnValueChanged(args As NValueChangeEventArgs)
            Dim value As Double = args.NewValue
            For i = 0 To m_ProgressBars.Length - 1
                m_ProgressBars(i).Value = value
            Next
        End Sub
        Private Sub OnBufferedValueChanged(args As NValueChangeEventArgs)
            Dim bufferedValue As Double = args.NewValue
            For i = 0 To m_ProgressBars.Length - 1
                m_ProgressBars(i).BufferedValue = bufferedValue
            Next
        End Sub
        Private Sub OnIndeterminateSizeUpDownValueChanged(arg As NValueChangeEventArgs)
            Dim indeterminateSize As Double = arg.NewValue
            For i = 0 To m_ProgressBars.Length - 1
                m_ProgressBars(i).IndeterminatePartSizePercent = indeterminateSize
            Next

        End Sub
        Private Sub OnAnimationSpeedUpDownValueChanged(arg As NValueChangeEventArgs)
            Dim animationSpeed As Double = arg.NewValue
            For i = 0 To m_ProgressBars.Length - 1
                m_ProgressBars(i).AnimationSpeed = animationSpeed
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_HorizontalProgressBar As NProgressBar
        Private m_VerticalProgressBar As NProgressBar
        Private m_CircularProgressBar1 As NProgressBar
        Private m_CircularProgressBar2 As NProgressBar
        Private m_ProgressBars As NProgressBar()

        Private m_ValuePairBox As NPairBox
        Private m_BufferedValuePairBox As NPairBox
        Private m_IndeterminatePartSizePairBox As NPairBox
        Private m_AnimationSpeedPairBox As NPairBox

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NProgressBarExample.
        ''' </summary>
        Public Shared ReadOnly NProgressBarExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const DefaultMode As ENProgressBarMode = ENProgressBarMode.Buffered
        Private Const DefaultValue As Double = 40
        Private Const DefaultBufferedValue As Double = 60

#End Region
    End Class
End Namespace
