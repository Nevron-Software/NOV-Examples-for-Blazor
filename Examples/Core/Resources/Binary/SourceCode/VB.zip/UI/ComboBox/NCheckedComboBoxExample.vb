Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NCheckedComboBoxExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCheckedComboBoxExampleSchema = NSchema.Create(GetType(NCheckedComboBoxExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.VerticalPlacement = ENVerticalPlacement.Top
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.Padding = New NMargins(5)

            Dim headerLabel As NLabel = New NLabel("Geography Test")
            headerLabel.HorizontalPlacement = ENHorizontalPlacement.Center
            NStylePropertyEx.SetRelativeFontSize(headerLabel, ENRelativeFontSize.XXLarge)  ' was huge
            stack.Add(headerLabel)

            Dim contentLabel As NLabel = New NLabel("Place a check on the countries located in Europe and select the one whose capital is Berlin:")
            NStylePropertyEx.SetRelativeFontSize(contentLabel, ENRelativeFontSize.Large) ' was medium
            stack.Add(contentLabel)

            ' Create a combo box with check boxes
            Dim comboBox As NCheckedComboBox = New NCheckedComboBox()
            comboBox.HorizontalPlacement = ENHorizontalPlacement.Left

            comboBox.AddCheckBoxItem("Argentina", False)
            comboBox.AddCheckBoxItem("Bulgaria", True)
            comboBox.AddCheckBoxItem("Canada", False)
            comboBox.AddCheckBoxItem("Germany", True)
            comboBox.AddCheckBoxItem("Japan", False)
            comboBox.AddCheckBoxItem("Mexico", False)
            comboBox.AddCheckBoxItem("Spain", True)
            comboBox.AddCheckBoxItem("USA", False)

            stack.Add(comboBox)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a class that inherits from NComboBox and has check boxes in the combo box items.
</p>
"
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCheckedComboBoxExample.
        ''' </summary>
        Public Shared ReadOnly NCheckedComboBoxExampleSchema As NSchema

#End Region
    End Class
End Namespace
