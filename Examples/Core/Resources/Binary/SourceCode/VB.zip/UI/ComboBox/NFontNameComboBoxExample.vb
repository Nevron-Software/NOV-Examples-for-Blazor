Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NFontNameComboBoxExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NFontNameComboBoxExampleSchema = NSchema.Create(GetType(NFontNameComboBoxExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Overrides - Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create the combo box
            m_FontNameComboBox = New NFontNameThumbnailComboBox()

            m_FontNameComboBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_FontNameComboBox.VerticalPlacement = ENVerticalPlacement.Top
            m_FontNameComboBox.DropDownStyle = ENComboBoxStyle.DropDownList

            ' select the first item
            m_FontNameComboBox.SelectedIndex = 0
            m_FontNameComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFontNameChanged)

            Return m_FontNameComboBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Create the commands
            Dim selectFontNameTitle As NLabel = New NLabel("Selected Font Name:")
            stack.Add(selectFontNameTitle)

            m_SelectFontName = New NLabel("")
            stack.Add(m_SelectFontName)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to use the built-in font name combo box, which allows the user to select a font name from the list of available fonts.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnFontNameChanged(args As NValueChangeEventArgs)
            Dim comboBox = CType(args.TargetNode, NFontNameThumbnailComboBox)
            m_SelectFontName.Text = comboBox.SelectedFontName
        End Sub

#End Region

#Region "Fields"

        Private m_FontNameComboBox As NFontNameThumbnailComboBox
        Private m_SelectFontName As NLabel

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NFontNameComboBoxExample.
        ''' </summary>
        Public Shared ReadOnly NFontNameComboBoxExampleSchema As NSchema

#End Region
    End Class
End Namespace
