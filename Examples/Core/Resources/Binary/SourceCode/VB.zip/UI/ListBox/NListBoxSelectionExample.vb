Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NListBoxSelectionExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NListBoxSelectionExampleSchema = NSchema.Create(GetType(NListBoxSelectionExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a list box
            m_ListBox = New NListBox()
            m_ListBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ListBox.PreferredSize = New NSize(200, 400)

            ' Add some items
            For i = 0 To 99
                m_ListBox.Items.Add(New NListBoxItem("Item " & i.ToString()))
            Next

            ' Hook to list box selection events
            m_ListBox.Selection.Selected += New [Function](Of NSelectEventArgs(Of NListBoxItem))(AddressOf OnListBoxItemSelected)
            m_ListBox.Selection.Deselected += New [Function](Of NSelectEventArgs(Of NListBoxItem))(AddressOf OnListBoxItemDeselected)

            Return m_ListBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create the properties group box
            Dim propertiesStack As NStackPanel = New NStackPanel()
            Dim editors = NDesigner.GetDesigner(m_ListBox).CreatePropertyEditors(m_ListBox, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty)

            Dim i = 0, count = editors.Count

            While i < count
                propertiesStack.Add(editors(i))
                i += 1
            End While

            Dim editor = NDesigner.GetDesigner(m_ListBox.Selection).CreatePropertyEditor(m_ListBox.Selection, NListBoxSelection.ModeProperty)
            Dim label As NLabel = CType(editor.GetDescendants(New NInstanceOfSchemaFilter(NLabel.NLabelSchema))(0), NLabel)
            label.Text = "Selection Mode:"
            propertiesStack.Add(editor)

            Dim propertiesGroupBox As NGroupBox = New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack))
            stack.Add(propertiesGroupBox)

            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to work with list box selection. You can change the selection mode
	using the ""Selection Mode"" combo box on the right. When in <b>Multiple</b> selection mode you
	can hold &lt;Shift&gt; or &lt;Ctrl&gt; to select multiple items from the list box.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnListBoxItemSelected(args As NSelectEventArgs(Of NListBoxItem))
            Dim item = args.Item
            Dim index As Integer = item.GetAggregationInfo().Index
            m_EventsLog.LogEvent("Selected Item: " & index.ToString())
        End Sub
        Private Sub OnListBoxItemDeselected(args As NSelectEventArgs(Of NListBoxItem))
            Dim item = args.Item
            Dim index As Integer = item.GetAggregationInfo().Index
            m_EventsLog.LogEvent("Deselected Item: " & index.ToString())
        End Sub

#End Region

#Region "Fields"

        Private m_ListBox As NListBox
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NListBoxSelectionExample.
        ''' </summary>
        Public Shared ReadOnly NListBoxSelectionExampleSchema As NSchema

#End Region
    End Class
End Namespace
