Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NListBoxItemsManipulationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NListBoxItemsManipulationExampleSchema = NSchema.Create(GetType(NListBoxItemsManipulationExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a list box
            m_ListBox = New NListBox()
            m_ListBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ListBox.PreferredSize = New NSize(200, 400)

            ' Add some items
            For i = 0 To 9
                Dim item As NListBoxItem = New NListBoxItem("Item " & i.ToString())
                item.Tag = i
                m_ListBox.Items.Add(item)
            Next

            ' Hook to list box selection events
            m_ListBox.Selection.Selected += New [Function](Of NSelectEventArgs(Of NListBoxItem))(AddressOf OnListBoxItemSelected)
            m_ListBox.Selection.Deselected += New [Function](Of NSelectEventArgs(Of NListBoxItem))(AddressOf OnListBoxItemDeselected)

            Return m_ListBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create the commands group box
            stack.Add(CreateCommandsGroupBox())

            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a simple list box with text only list box items and how to add/remove items.
	You can use the buttons on the right to add/remove items from the list box's <b>Items</b> collection.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateCommandsGroupBox() As NGroupBox
            Dim commandsStack As NStackPanel = New NStackPanel()

            ' Create the command buttons
            m_AddButton = New NButton("Add Item")
            m_AddButton.Click += New [Function](Of NEventArgs)(AddressOf OnAddButtonClick)
            commandsStack.Add(m_AddButton)

            m_RemoveSelectedButton = New NButton("Remove Selected")
            m_RemoveSelectedButton.Enabled = False
            m_RemoveSelectedButton.Click += New [Function](Of NEventArgs)(AddressOf OnRemoveSelectedButtonClick)
            commandsStack.Add(m_RemoveSelectedButton)

            m_RemoveAllButton = New NButton("Remove All")
            m_RemoveAllButton.Click += New [Function](Of NEventArgs)(AddressOf OnRemoveAllButtonClick)
            commandsStack.Add(m_RemoveAllButton)

            ' Create the commands group box
            Dim commmandsGroupBox As NGroupBox = New NGroupBox("Commands")
            commmandsGroupBox.Content = commandsStack
            Return commmandsGroupBox
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnListBoxItemSelected(args As NSelectEventArgs(Of NListBoxItem))
            m_RemoveSelectedButton.Enabled = True

            Dim item = args.Item
            m_EventsLog.LogEvent("Selected Item: " & item.Tag.ToString())
        End Sub
        Private Sub OnListBoxItemDeselected(args As NSelectEventArgs(Of NListBoxItem))
            Dim item = args.Item
            m_EventsLog.LogEvent("Deselected Item: " & item.Tag.ToString())
        End Sub

        Private Sub OnAddButtonClick(args As NEventArgs)
            Dim index As Integer
            Dim value = "0"
            If m_ListBox.Items.Count > 0 Then
                Dim lastItem = m_ListBox.Items(m_ListBox.Items.Count - 1)
                Dim label As NLabel = CType(lastItem.GetDescendants(New NInstanceOfSchemaFilter(NLabel.NLabelSchema))(0), NLabel)
                value = label.Text
                value = value.Remove(0, value.LastIndexOf(" "c) + 1)
            End If

            ' Add an item with the calculated index
            index = Integer.Parse(value) + 1
            Dim item As NListBoxItem = New NListBoxItem("Item " & index.ToString())
            item.Tag = index
            m_ListBox.Items.Add(item)

            If m_ListBox.Items.Count = 1 Then
                m_RemoveAllButton.Enabled = True
            End If
        End Sub
        Private Sub OnRemoveSelectedButtonClick(args As NEventArgs)
            Dim selected = m_ListBox.Selection.SelectedItems
            For i = 0 To selected.Count - 1
                m_ListBox.Items.Remove(selected(i))
            Next

            If m_ListBox.Items.Count = 0 Then
                m_RemoveAllButton.Enabled = False
                m_RemoveSelectedButton.Enabled = False
            End If
        End Sub
        Private Sub OnRemoveAllButtonClick(args As NEventArgs)
            m_ListBox.Items.Clear()
            m_RemoveAllButton.Enabled = False
            m_RemoveSelectedButton.Enabled = False
        End Sub

#End Region

#Region "Fields"

        Private m_ListBox As NListBox
        Private m_EventsLog As NExampleEventsLog

        Private m_AddButton As NButton
        Private m_RemoveSelectedButton As NButton
        Private m_RemoveAllButton As NButton

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NListBoxItemsManipulationExample.
        ''' </summary>
        Public Shared ReadOnly NListBoxItemsManipulationExampleSchema As NSchema

#End Region
    End Class
End Namespace
