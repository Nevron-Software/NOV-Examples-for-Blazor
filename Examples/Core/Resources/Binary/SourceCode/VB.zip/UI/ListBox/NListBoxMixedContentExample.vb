Imports System
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NListBoxMixedContentExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NListBoxMixedContentExampleSchema = NSchema.Create(GetType(NListBoxMixedContentExample), NExampleBase.NExampleBaseSchema)

            ' Properties
            ContentTypeProperty = NListBoxMixedContentExampleSchema.AddSlot("ContentType", GetType(ENListBoxContentType), defaultContentType)
            ContentTypeProperty.AddValueChangedCallback(Sub(t As NNode, d As NValueChangeData) CType(t, NListBoxMixedContentExample).OnContentTypeChanged(d))

            ' Designer
            Call NListBoxMixedContentExampleSchema.SetMetaUnit(New NDesignerMetaUnit(GetType(NListBoxMixedContentDesigner)))
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the value of the ContentType property.
        ''' </summary>
        Public Property ContentType As ENListBoxContentType
            Get
                Return CType(GetValue(ContentTypeProperty), ENListBoxContentType)
            End Get
            Set(value As ENListBoxContentType)
                SetValue(ContentTypeProperty, value)
            End Set
        End Property

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a list box
            m_ListBox = New NListBox()
            m_ListBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ListBox.PreferredSize = New NSize(200, 400)

            ' Fill the image Box
            FillWithImageCheckBoxAndTitle()

            ' Hook to list box selection events
            m_ListBox.Selection.Selected += New [Function](Of NSelectEventArgs(Of NListBoxItem))(AddressOf OnListBoxItemSelected)
            m_ListBox.Selection.Deselected += New [Function](Of NSelectEventArgs(Of NListBoxItem))(AddressOf OnListBoxItemDeselected)

            Return m_ListBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create the content type group box
            Dim contentTypePropertyEditor = NDesigner.GetDesigner(Me).CreatePropertyEditor(Me, ContentTypeProperty)
            stack.Add(contentTypePropertyEditor)

            ' Create the properties group box
            Dim propertiesStack As NStackPanel = New NStackPanel()
            Dim editors = NDesigner.GetDesigner(m_ListBox).CreatePropertyEditors(m_ListBox, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NScrollContentBase.HScrollModeProperty, NScrollContentBase.VScrollModeProperty, NScrollContentBase.NoScrollHAlignProperty, NScrollContentBase.NoScrollVAlignProperty, NListBox.IntegralVScrollProperty)

            Dim i = 0, count = editors.Count

            While i < count
                propertiesStack.Add(editors(i))
                i += 1
            End While

            Dim propertiesGroupBox As NGroupBox = New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack))
            stack.Add(propertiesGroupBox)

            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a list box and add items with various content to it - text only items, items with image and text,
	checkable items and so on. Using the controls to the right you can modify the appearance and the behavior of the list box.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateListBoxItem(index As Integer, hasCheckBox As Boolean, hasImage As Boolean) As NListBoxItem
            Dim text As String = "Item " & index.ToString()
            If hasCheckBox = False AndAlso hasImage = False Then Return New NListBoxItem(text)

            Dim stack As NStackPanel = New NStackPanel()
            stack.Direction = ENHVDirection.LeftToRight
            stack.HorizontalSpacing = 3

            If hasCheckBox Then
                Dim checkBox As NCheckBox = New NCheckBox()
                checkBox.VerticalPlacement = ENVerticalPlacement.Center
                stack.Add(checkBox)
            End If

            If hasImage Then
                Dim imageName = ImageNames(index Mod ImageNames.Length)
                Dim icon As NImage = New NImage(New NEmbeddedResourceRef(NResources.Instance, "RIMG__16x16_" & imageName & "_png"))

                Dim imageBox As NImageBox = New NImageBox(icon)
                imageBox.HorizontalPlacement = ENHorizontalPlacement.Center
                imageBox.VerticalPlacement = ENVerticalPlacement.Center

                stack.Add(imageBox)
            End If

            Dim label As NLabel = New NLabel(text)
            label.VerticalPlacement = ENVerticalPlacement.Center
            stack.Add(label)

            Return New NListBoxItem(stack)
        End Function
        Private Sub FillWithImageCheckBoxAndTitle()
            m_ListBox.Items.Clear()

            For i = 0 To 99
                Dim index As Integer = (i Mod 32) / 8
                Dim checkBox = index = 1 OrElse index = 3
                Dim image = index = 2 OrElse index = 3

                m_ListBox.Items.Add(CreateListBoxItem(i, checkBox, image))
            Next
        End Sub

        Private Function CreateDetailedListBoxItem(index As Integer) As NListBoxItem
            Dim dock As NDockPanel = New NDockPanel()
            dock.HorizontalSpacing = 3
            dock.Padding = New NMargins(0, 2, 0, 2)

            ' Add the image
            Dim imageName = ImageNames(index Mod ImageNames.Length)
            Dim icon As NImage = New NImage(New NEmbeddedResourceRef(NResources.Instance, "RIMG__24x24_" & imageName & "_png"))

            Dim imageBox As NImageBox = New NImageBox(icon)
            imageBox.HorizontalPlacement = ENHorizontalPlacement.Center
            imageBox.VerticalPlacement = ENVerticalPlacement.Center
            NDockLayout.SetDockArea(imageBox, ENDockArea.Left)

            dock.Add(imageBox)

            ' Add the title
            Dim titleLabel As NLabel = New NLabel("Item " & index.ToString())
            titleLabel.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 10, ENFontStyle.Bold)
            NDockLayout.SetDockArea(titleLabel, ENDockArea.Top)
            dock.AddChild(titleLabel)

            ' Add the description
            Dim descriptionLabel As NLabel = New NLabel("This is item " & index.ToString() & "'s description.")
            NDockLayout.SetDockArea(descriptionLabel, ENDockArea.Center)
            dock.AddChild(descriptionLabel)

            Return New NListBoxItem(dock)
        End Function
        Private Sub FillWithImageTitleAndDetails()
            m_ListBox.Items.Clear()

            For i = 0 To 99
                m_ListBox.Items.Add(CreateDetailedListBoxItem(i))
            Next
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnListBoxItemSelected(args As NSelectEventArgs(Of NListBoxItem))
            Dim item = args.Item
            Dim index As Integer = item.GetAggregationInfo().Index
            m_EventsLog.LogEvent("Selected Item: " & index.ToString())
        End Sub
        Private Sub OnListBoxItemDeselected(args As NSelectEventArgs(Of NListBoxItem))
            Dim item = args.Item
            Dim index As Integer = item.GetAggregationInfo().Index
            m_EventsLog.LogEvent("Deselected Item: " & index.ToString())
        End Sub
        ''' <summary>
        ''' Called when the ContentType property has changed.
        ''' </summary>
        ''' <paramname="data"></param>
        Private Sub OnContentTypeChanged(data As NValueChangeData)
            Select Case data.NewValue
                Case ENListBoxContentType.ImageCheckBoxAndTitle
                    FillWithImageCheckBoxAndTitle()
                Case ENListBoxContentType.ImageTitleAndDetails
                    FillWithImageTitleAndDetails()
                Case Else
                    Throw New Exception("New ENListBoxContentType?")
            End Select
        End Sub

#End Region

#Region "Fields"

        Private m_ListBox As NListBox
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NListBoxMixedContentExample.
        ''' </summary>
        Public Shared ReadOnly NListBoxMixedContentExampleSchema As NSchema
        ''' <summary>
        ''' Reference to the ContentType property.
        ''' </summary>
        Public Shared ReadOnly ContentTypeProperty As NProperty

#End Region

#Region "Constants"

        Private Const defaultContentType As ENListBoxContentType = ENListBoxContentType.ImageCheckBoxAndTitle

        Private Shared ReadOnly ImageNames As String() = New String() {"Calendar", "Contacts", "Folders", "Journal", "Mail", "Notes", "Shortcuts", "Tasks"}

#End Region

#Region "Nested Types"

        Public Enum ENListBoxContentType
            ImageCheckBoxAndTitle
            ImageTitleAndDetails
        End Enum

        ''' <summary>
        ''' Designer for NListBoxMixedContent.
        ''' </summary>
        Public Class NListBoxMixedContentDesigner
            Inherits NDesigner
            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
                MyBase.SetPropertyEditor(ContentTypeProperty, NEnumPropertyEditor.VerticalRadioGroupTemplate)
            End Sub
        End Class

#End Region
    End Class
End Namespace
