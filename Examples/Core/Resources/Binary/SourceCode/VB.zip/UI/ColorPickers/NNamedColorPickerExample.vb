Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NNamedColorPickerExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NNamedColorPickerExampleSchema = NSchema.Create(GetType(NNamedColorPickerExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_NamedColorPicker = New NNamedColorPicker()
            m_NamedColorPicker.PreferredWidth = 300
            m_NamedColorPicker.HorizontalPlacement = ENHorizontalPlacement.Left
            m_NamedColorPicker.VerticalPlacement = ENVerticalPlacement.Fit
            Me.m_NamedColorPicker.SelectedColorChanged += AddressOf OnNamedColorPickerSelectedColorChanged

            Return m_NamedColorPicker
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' add come property editors
            Dim editors = NDesigner.GetDesigner(m_NamedColorPicker).CreatePropertyEditors(m_NamedColorPicker, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty)

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            ' create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use a NOV named color picker.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnNamedColorPickerSelectedColorChanged(arg As NColor)
            m_EventsLog.LogEvent(NColor.GetNameOrHex(arg))
        End Sub

#End Region

#Region "Fields"

        Private m_NamedColorPicker As NNamedColorPicker
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NNamedColorPickerExample.
        ''' </summary>
        Public Shared ReadOnly NNamedColorPickerExampleSchema As NSchema

#End Region
    End Class
End Namespace
