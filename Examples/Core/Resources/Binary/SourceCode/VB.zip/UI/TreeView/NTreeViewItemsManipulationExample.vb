Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NTreeViewItemsManipulationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTreeViewItemsManipulationExampleSchema = NSchema.Create(GetType(NTreeViewItemsManipulationExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the tree view
            m_TreeView = New NTreeView()
            m_TreeView.HorizontalPlacement = ENHorizontalPlacement.Left
            ' Check whether the application is in touch mode and set the width of the tree view.
            Dim touchMode = NApplication.Desktop.TouchMode
            m_TreeView.PreferredWidth = If(touchMode, 300, 200)

            ' Add some items
            For i = 0 To 31
                Dim checkBox = i >= 8 AndAlso i < 16 OrElse i >= 24
                Dim image = i >= 16

                Dim l1Item = CreateTreeViewItem(String.Format("Item {0}", i))
                m_TreeView.Items.Add(l1Item)

                For j = 0 To 7
                    Dim l2Item = CreateTreeViewItem(String.Format("Item {0}.{1}", i, j))
                    l1Item.Items.Add(l2Item)

                    For k = 0 To 1
                        Dim l3Item = CreateTreeViewItem(String.Format("Item {0}.{1}.{2}", i, j, k))
                        l2Item.Items.Add(l3Item)
                    Next
                Next
            Next

            ' Hook to the tree view events
            m_TreeView.SelectedPathChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnTreeViewSelectedPathChanged)
            Return m_TreeView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create the commands group box
            stack.Add(CreateCommandsGroupBox())

            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a simple tree view with text only items and how to add/remove items.
	You can use the buttons on the right to add/remove items from the tree view.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateTreeViewItem(text As String) As NTreeViewItem
            Dim item As NTreeViewItem = New NTreeViewItem(text)
            item.Tag = text
            item.ExpandedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnTreeViewItemExpandedChanged)
            Return item
        End Function
        Private Function CreateCommandsGroupBox() As NGroupBox
            Dim commandsStack As NStackPanel = New NStackPanel()

            ' Create the command buttons
            m_AddButton = New NButton("Add Child Item")
            m_AddButton.Click += New [Function](Of NEventArgs)(AddressOf OnAddButtonClicked)
            commandsStack.Add(m_AddButton)

            m_InsertBeforeButton = New NButton("Insert Item Before")
            m_InsertBeforeButton.Click += New [Function](Of NEventArgs)(AddressOf OnAddButtonClicked)
            commandsStack.Add(m_InsertBeforeButton)

            m_InsertAfterButton = New NButton("Insert Item After")
            m_InsertAfterButton.Click += New [Function](Of NEventArgs)(AddressOf OnAddButtonClicked)
            commandsStack.Add(m_InsertAfterButton)

            Dim expandAllButton As NButton = New NButton("Expand All")
            expandAllButton.Margins = New NMargins(0, 15, 0, 0)
            expandAllButton.Click += New [Function](Of NEventArgs)(AddressOf OnExpandAllClicked)
            commandsStack.Add(expandAllButton)

            Dim collapseAllButton As NButton = New NButton("Collapse All")
            collapseAllButton.Margins = New NMargins(0, 0, 0, 15)
            collapseAllButton.Click += New [Function](Of NEventArgs)(AddressOf OnCollapseAllClicked)
            commandsStack.Add(collapseAllButton)

            m_RemoveSelectedButton = New NButton("Remove Selected")
            m_RemoveSelectedButton.Click += New [Function](Of NEventArgs)(AddressOf OnRemoveSelectedButtonClicked)
            commandsStack.Add(m_RemoveSelectedButton)

            m_RemoveChildrenButton = New NButton("Remove Children")
            m_RemoveChildrenButton.Click += New [Function](Of NEventArgs)(AddressOf OnRemoveChildrenButtonClicked)
            commandsStack.Add(m_RemoveChildrenButton)

            m_RemoveAllButton = New NButton("Remove All")
            m_RemoveAllButton.Click += New [Function](Of NEventArgs)(AddressOf OnRemoveAllButtonClicked)
            commandsStack.Add(m_RemoveAllButton)

            ' Create the commands group box
            Dim commmandsGroupBox As NGroupBox = New NGroupBox("Commands")
            commmandsGroupBox.Content = commandsStack

            UpdateButtonsState()
            Return commmandsGroupBox
        End Function
        Private Sub UpdateButtonsState()
            Dim selectedItem = m_TreeView.SelectedItem
            If selectedItem Is Nothing Then
                m_InsertBeforeButton.Enabled = False
                m_InsertAfterButton.Enabled = False
                m_RemoveSelectedButton.Enabled = False
                m_RemoveChildrenButton.Enabled = False
            Else
                m_InsertBeforeButton.Enabled = True
                m_InsertAfterButton.Enabled = True
                m_RemoveSelectedButton.Enabled = True
                m_RemoveChildrenButton.Enabled = selectedItem.Items.Count > 0
            End If
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnAddButtonClicked(args As NEventArgs)
            Dim selItem = m_TreeView.SelectedItem
            Dim text As String = If(selItem Is Nothing, "Item " & m_TreeView.Items.Count.ToString(), selItem.Tag.ToString())

            If args.TargetNode Is m_AddButton Then
                If selItem Is Nothing Then
                    ' Add the item as a last item in the tree view
                    m_TreeView.Items.Add(CreateTreeViewItem(text))
                Else
                    ' Add the item as a last item in the selected item
                    text += "." & selItem.Items.Count.ToString()
                    selItem.Items.Add(CreateTreeViewItem(text))
                End If
            ElseIf args.TargetNode Is m_InsertBeforeButton Then
                ' Insert the item before the selected one
                Dim items = CType(selItem.ParentNode, NTreeViewItemCollection)
                text += ".Before"
                items.Insert(selItem.IndexInParent, CreateTreeViewItem(text))
            ElseIf args.TargetNode Is m_InsertAfterButton Then
                ' Insert the item after the selected one
                Dim items = CType(selItem.ParentNode, NTreeViewItemCollection)
                text += ".After"
                items.Insert(selItem.IndexInParent + 1, CreateTreeViewItem(text))
            End If

            If m_TreeView.Items.Count = 1 Then
                m_RemoveAllButton.Enabled = True
            End If
        End Sub
        Private Sub OnRemoveSelectedButtonClicked(args As NEventArgs)
            Dim selectedItem = m_TreeView.SelectedItem
            If selectedItem Is Nothing Then Return

            selectedItem.ParentNode.RemoveChild(selectedItem)
        End Sub
        Private Sub OnRemoveChildrenButtonClicked(arg1 As NEventArgs)
            Dim selectedItem = m_TreeView.SelectedItem
            If selectedItem Is Nothing Then Return

            selectedItem.Items.RemoveAllChildren()
            m_RemoveChildrenButton.Enabled = False
        End Sub
        Private Sub OnRemoveAllButtonClicked(args As NEventArgs)
            m_TreeView.Items.Clear()
            m_RemoveAllButton.Enabled = False
        End Sub
        Private Sub OnExpandAllClicked(args As NEventArgs)
            Dim treeIterator = m_TreeView.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, NIsFilter(Of NNode, NTreeViewItem).Instance)
            Dim itemIterator As INIterator(Of NTreeViewItem) = New NAsIterator(Of NNode, NTreeViewItem)(treeIterator)

            While itemIterator.MoveNext()
                itemIterator.Current.Expanded = True
            End While
        End Sub
        Private Sub OnCollapseAllClicked(args As NEventArgs)
            Dim treeIterator = m_TreeView.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, NIsFilter(Of NNode, NTreeViewItem).Instance)
            Dim itemIterator As INIterator(Of NTreeViewItem) = New NAsIterator(Of NNode, NTreeViewItem)(treeIterator)

            While itemIterator.MoveNext()
                itemIterator.Current.Expanded = False
            End While
        End Sub

        Private Sub OnTreeViewSelectedPathChanged(args As NValueChangeEventArgs)
            UpdateButtonsState()

            Dim selectedItem = m_TreeView.SelectedItem
            If selectedItem IsNot Nothing Then
                m_EventsLog.LogEvent("Selected: " & selectedItem.Tag.ToString())
            End If
        End Sub
        Private Sub OnTreeViewItemExpandedChanged(args As NValueChangeEventArgs)
            Dim item = CType(args.TargetNode, NTreeViewItem)
            If item.Expanded Then
                m_EventsLog.LogEvent("Expanded: " & item.Tag.ToString())
            Else
                m_EventsLog.LogEvent("Collapsed: " & item.Tag.ToString())
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_AddButton As NButton
        Private m_InsertBeforeButton As NButton
        Private m_InsertAfterButton As NButton
        Private m_RemoveSelectedButton As NButton
        Private m_RemoveChildrenButton As NButton
        Private m_RemoveAllButton As NButton

        Private m_TreeView As NTreeView
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTreeViewItemsManipulationExample.
        ''' </summary>
        Public Shared ReadOnly NTreeViewItemsManipulationExampleSchema As NSchema

#End Region
    End Class
End Namespace
