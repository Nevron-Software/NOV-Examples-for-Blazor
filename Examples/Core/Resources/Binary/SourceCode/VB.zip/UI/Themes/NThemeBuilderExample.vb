
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.UI.ThemeBuilder

Namespace Nevron.Nov.Examples.UI
    Public Class NThemeBuilderExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NThemeBuilderExampleSchema = NSchema.Create(GetType(NThemeBuilderExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim showThemeBuilderButton As NButton = New NButton("Open NOV Theme Builder")
            showThemeBuilderButton.Margins = New NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing)
            showThemeBuilderButton.HorizontalPlacement = ENHorizontalPlacement.Left
            showThemeBuilderButton.VerticalPlacement = ENVerticalPlacement.Top
            showThemeBuilderButton.Click += AddressOf OnShowThemeBuilderButtonClick
            NStylePropertyEx.SetRelativeFontSize(showThemeBuilderButton, ENRelativeFontSize.Large)

            Return showThemeBuilderButton
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to open the NOV Theme Builder via code. Click the <b>Open NOV Theme Builder</b> button
to show the theme builder in a new window.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnShowThemeBuilderButtonClick(arg As NEventArgs)
            ' Create a Theme Builder widget
            Dim themeBuilderWidget As NThemeBuilderWidget = New NThemeBuilderWidget()

            ' Create and open a top level window with the Theme Builder widget
            Dim window = NApplication.CreateTopLevelWindow(DisplayWindow)
            window.StartPosition = ENWindowStartPosition.CenterScreen
            window.PreferredSize = New NSize(1000, 700)
            window.SetupApplicationWindow("NOV Theme Builder")
            window.Modal = True
            window.Content = themeBuilderWidget

            ' Open the window and show the Theme Builder start up dialog
            window.Open()
            themeBuilderWidget.ShowStartUpDialog()
        End Sub

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NThemeBuilderExample.
        ''' </summary>
        Public Shared ReadOnly NThemeBuilderExampleSchema As NSchema

#End Region
    End Class
End Namespace
