Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NContextMenuExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NContextMenuExampleSchema = NSchema.Create(GetType(NContextMenuExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_TextChecked = New Boolean() {True, True, False}
            m_ImageAndTextChecked = New Boolean() {True, False, True}

            Dim leftStack As NStackPanel = New NStackPanel()
            leftStack.Add(CreateWidget("Text Only", New CreateMenuDelegate(AddressOf CreateTextContextMenu)))
            leftStack.Add(CreateWidget("Image and Text", New CreateMenuDelegate(AddressOf CreateImageAndTextContextMenu)))
            leftStack.Add(CreateWidget("Checkable Text Only", New CreateMenuDelegate(AddressOf CreateCheckableTextContextMenu)))
            leftStack.Add(CreateWidget("Checkable Image And Text", New CreateMenuDelegate(AddressOf CreateCheckableImageAndTextContextMenu)))

            Dim rightStack As NStackPanel = New NStackPanel()
            rightStack.Add(CreateWidget("Text Only", New CreateMenuDelegate(AddressOf CreateTextContextMenu)))
            rightStack.Add(CreateWidget("Image and Text", New CreateMenuDelegate(AddressOf CreateImageAndTextContextMenu)))
            rightStack.Add(CreateWidget("Checkable Text Only", New CreateMenuDelegate(AddressOf CreateCheckableTextContextMenu)))
            rightStack.Add(CreateWidget("Checkable Image And Text", New CreateMenuDelegate(AddressOf CreateCheckableImageAndTextContextMenu)))

            Dim stack As NStackPanel = New NStackPanel()
            stack.Direction = ENHVDirection.LeftToRight
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.VerticalPlacement = ENVerticalPlacement.Top
            stack.HorizontalSpacing = 10

            stack.Add(New NGroupBox("Left Button Context Menu", leftStack))
            stack.Add(New NGroupBox("Right Button Context Menu", rightStack))

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create context menus. It creates several widgets and a context menu
	for each of them. The example shows how to create different types of menu items such as text only
	menu items, menu items with image and text, checkable text only menu items and checkable image and
	text menu items.
</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateWidget(text As String, createMenuDelegate As CreateMenuDelegate) As NWidget
            Dim label As NLabel = New NLabel(text)
            label.HorizontalPlacement = ENHorizontalPlacement.Center
            label.VerticalPlacement = ENVerticalPlacement.Center
            label.TextFill = New NColorFill(NColor.Black)

            Dim widget As NContentHolder = New NContentHolder(label)
            widget.HorizontalPlacement = ENHorizontalPlacement.Left
            widget.VerticalPlacement = ENVerticalPlacement.Top
            widget.BackgroundFill = New NColorFill(NColor.PapayaWhip)
            widget.Border = NBorder.CreateFilledBorder(NColor.Black)
            widget.BorderThickness = New NMargins(1)
            widget.PreferredSize = New NSize(200, 100)
            widget.Tag = createMenuDelegate
            widget.MouseDown += New [Function](Of NMouseButtonEventArgs)(AddressOf OnTargetWidgetMouseDown)

            Return widget
        End Function

        Private Function CreateTextContextMenu() As NMenu
            Dim contextMenu As NMenu = New NMenu()
            For i = 0 To 2
                contextMenu.Items.Add(New NMenuItem("Option " & (i + 1).ToString()))
            Next

            Return contextMenu
        End Function
        Private Function CreateImageAndTextContextMenu() As NMenu
            Dim contextMenu As NMenu = New NMenu()
            For i = 0 To 2
                contextMenu.Items.Add(New NMenuItem(MenuItemImages(i), "Option " & (i + 1).ToString()))
            Next

            Return contextMenu
        End Function
        Private Function CreateCheckableTextContextMenu() As NMenu
            Dim contextMenu As NMenu = New NMenu()
            For i = 0 To 2
                Dim menuItem As NCheckableMenuItem = New NCheckableMenuItem(Nothing, "Option " & (i + 1).ToString(), m_TextChecked(i))
                menuItem.Tag = i
                menuItem.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnTextCheckableMenuItemCheckedChanged)
                contextMenu.Items.Add(menuItem)
            Next

            Return contextMenu
        End Function
        Private Function CreateCheckableImageAndTextContextMenu() As NMenu
            Dim contextMenu As NMenu = New NMenu()

            For i = 0 To 2
                Dim menuItem As NCheckableMenuItem = New NCheckableMenuItem(MenuItemImages(i), "Option " & (i + 1).ToString(), m_ImageAndTextChecked(i))
                menuItem.Tag = i
                menuItem.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnImageAndTextCheckableMenuItemCheckedChanged)
                contextMenu.Items.Add(menuItem)
            Next

            Return contextMenu
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnTextCheckableMenuItemCheckedChanged(args As NValueChangeEventArgs)
            Dim index As Integer = args.CurrentTargetNode.Tag
            m_TextChecked(index) = CBool(args.NewValue)
        End Sub
        Private Sub OnImageAndTextCheckableMenuItemCheckedChanged(args As NValueChangeEventArgs)
            Dim index As Integer = args.CurrentTargetNode.Tag
            m_ImageAndTextChecked(index) = CBool(args.NewValue)
        End Sub
        Private Sub OnTargetWidgetMouseDown(args As NMouseButtonEventArgs)
            Dim ownerGroupBox = CType(args.CurrentTargetNode.GetFirstAncestor(NGroupBox.NGroupBoxSchema), NGroupBox)
            Dim groupBoxTitle = CType(ownerGroupBox.Header.Content, NLabel).Text

            If groupBoxTitle.StartsWith("Left") AndAlso args.Button IsNot ENMouseButtons.Left OrElse groupBoxTitle.StartsWith("Right") AndAlso args.Button IsNot ENMouseButtons.Right Then Return

            ' Mark the event as handled
            args.Cancel = True

            ' Create and show the popup
            Dim createMenuDelegate = CType(args.CurrentTargetNode.Tag, CreateMenuDelegate)
            Dim contextMenu As NMenu = createMenuDelegate()
            Call NPopupWindow.OpenInContext(New NPopupWindow(contextMenu), args.CurrentTargetNode, args.ScreenPosition)
        End Sub

#End Region

#Region "Fields"

        Private m_TextChecked As Boolean()
        Private m_ImageAndTextChecked As Boolean()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NContextMenuExample.
        ''' </summary>
        Public Shared ReadOnly NContextMenuExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly MenuItemImages As NImage() = New NImage() {NResources.Image__16x16_Calendar_png, NResources.Image__16x16_Contacts_png, NResources.Image__16x16_Mail_png}

#End Region

#Region "Nested Types"

        Private Delegate Function CreateMenuDelegate() As NMenu

#End Region
    End Class
End Namespace
