Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NCursorsExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NCursorsExampleSchema = NSchema.Create(GetType(NCursorsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim predefinedCursors As Array = NEnum.GetValues(GetType(ENPredefinedCursor))

            Dim stack As NStackPanel = New NStackPanel()

            Dim predefinedGroupBox As NGroupBox = New NGroupBox("Predefined")
            stack.Add(predefinedGroupBox)

            Dim splitter As NSplitter = New NSplitter()
            splitter.SplitMode = ENSplitterSplitMode.Proportional
            splitter.SplitFactor = 0.5R
            predefinedGroupBox.Content = splitter

            For i = 0 To 1
                Dim pstack As NStackPanel = New NStackPanel()
                pstack.VerticalSpacing = 1
                Select Case i
                    Case 0
                        splitter.Pane1.Content = New NGroupBox("Use Native If Possible", pstack)
                    Case 1
                        splitter.Pane2.Content = New NGroupBox("Use Built-In", pstack)
                    Case Else
                        Throw New Exception("More cases?")
                End Select

                For j = 0 To predefinedCursors.Length - 1
                    Dim predefinedCursor As ENPredefinedCursor = predefinedCursors.GetValue(j)
                    Dim element As NWidget = Me.CreateDemoElement(NStringHelpers.InsertSpacesBeforeUppersAndDigits(predefinedCursor.ToString()))
                    element.Cursor = New NCursor(predefinedCursor, i = 0)
                    pstack.Add(element)
                Next
            Next

            Dim customElement = CreateDemoElement("Custom")
            customElement.Cursor = NResources.Cursor_CustomCursor_cur

            Dim customGroupBox As NGroupBox = New NGroupBox("Custom", customElement)
            stack.Add(customGroupBox)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example shows how to use cursors. NOV supports 2 types of cursors - <b>predefined</b> and <b>custom</b>. Predefined cursors can
	be native or built-in. A custom cursor can be loaded from a stream or you can manually specify the values of its pixels.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateDemoElement(text As String) As NWidget
            Dim element As NContentHolder = New NContentHolder(text)
            element.Border = NBorder.CreateFilledBorder(NColor.Black, 2, 5)
            element.BorderThickness = New NMargins(1)
            element.BackgroundFill = New NColorFill(NColor.PapayaWhip)
            element.TextFill = New NColorFill(NColor.Black)
            element.Padding = New NMargins(1)
            Return element
        End Function

#End Region

#Region "Schema"

        Public Shared ReadOnly NCursorsExampleSchema As NSchema

#End Region
    End Class
End Namespace
