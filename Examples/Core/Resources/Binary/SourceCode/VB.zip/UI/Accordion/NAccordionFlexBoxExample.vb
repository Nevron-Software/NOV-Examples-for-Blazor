Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NAccordionFlexBoxExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NAccordionFlexBoxExampleSchema = NSchema.Create(GetType(NAccordionFlexBoxExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create an accordion
            m_Accordion = New NAccordion()
            m_Accordion.HorizontalPlacement = ENHorizontalPlacement.Left
            m_Accordion.MinWidth = 300
            m_Accordion.SetBorder(1, NColor.Red)

            ' Create an accordion flex box panel to hold the expandable sections of the accordion.
            ' Note that the accordion is designed like a radio button group, allowing the user to use any layout 
            ' to arrange the expandable sections managed by the accordion.
            Dim panel As NAccordionFlexBoxPanel = New NAccordionFlexBoxPanel()
            m_Accordion.Content = panel

            ' Create the sections
            panel.Add(CreateAccordionSection(NResources.Image__16x16_Mail_png, "Mail", CreateMailTreeView(), False))
            panel.Add(CreateAccordionSection(NResources.Image__16x16_Calendar_png, "Calendar", CreateCalendar(), True))
            panel.Add(CreateAccordionSection(NResources.Image__16x16_Contacts_png, "Contacts", CreateContactsTreeView(), False))
            panel.Add(CreateAccordionSection(NResources.Image__16x16_Tasks_png, "Tasks", CreateTasksView(), False))

            Return m_Accordion
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' properties
            Dim properties = New NProperty() {NAccordion.ShowSymbolProperty}
            Dim editors = NDesigner.GetDesigner(m_Accordion).CreatePropertyEditors(m_Accordion, properties)
            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            ' create the events list box
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how make the expanded section of an Accordion widget to occupy the whole available area.
    To do that you should set the <b>Content</b> property of the accordion to an <b>NAccordionFlexBoxPanel</b> instance
    and then add expandable sections to that accordion flex box panel. Red border is set to the accordion, so that you
    can see its bounds.
</p>
"
        End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates an accordion section.
        ''' </summary>
        ''' <paramname="image"></param>
        ''' <paramname="text"></param>
        ''' <paramname="content"></param>
        ''' <paramname="expanded"></param>
        ''' <returns></returns>
        Private Function CreateAccordionSection(image As NImage, text As String, content As NWidget, expanded As Boolean) As NExpandableSection
            Dim header = NPairBox.Create(image, text)
            Dim section As NExpandableSection = New NExpandableSection(header, content)
            section.Expanded = expanded

            Return section
        End Function

        ''' <summary>
        ''' Creates a dummy tree view, that contains the items of an imaginary Mail
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateMailTreeView() As NTreeView
            Dim treeView As NTreeView = New NTreeView()
            Dim rootItem = CreateTreeViewItem("Personal Folers", NResources.Image__16x16_folderHome_png)
            treeView.Items.Add(rootItem)
            Dim texts = New String() {"Deleted Items", "Drafts", "Inbox", "Junk E-mails", "Outbox", "RSS Feeds", "Sent Items", "Search Folders"}







            Dim icons = New NImage() {NResources.Image__16x16_folderDeleted_png, NResources.Image__16x16_folderDrafts_png, NResources.Image__16x16_folderInbox_png, NResources.Image__16x16_folderJunk_png, NResources.Image__16x16_folderOutbox_png, NResources.Image__16x16_folderRss_png, NResources.Image__16x16_folderSent_png, NResources.Image__16x16_folderSearch_png}

            For i = 0 To texts.Length - 1
                rootItem.Items.Add(CreateTreeViewItem(texts(i), icons(i)))
            Next

            treeView.ExpandAll(True)
            treeView.BorderThickness = New NMargins(0)

            Return treeView
        End Function
        ''' <summary>
        ''' Creates the Contacts tree view
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateContactsTreeView() As NTreeView
            Dim names = New String() {"Emily Swan", "John Smith", "Lindsay Collier", "Kevin Johnson", "Shannon Flynn"}
            Return SetupTreeView(names, NResources.Image__16x16_Contacts_png)
        End Function
        ''' <summary>
        ''' Creates a dummy callendar for the Calendar section.
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateCalendar() As NCalendar
            Dim calendar As NCalendar = New NCalendar()
            calendar.VerticalPlacement = ENVerticalPlacement.Top
            calendar.Margins = New NMargins(10)
            calendar.BorderThickness = New NMargins(0)

            Return calendar
        End Function
        ''' <summary>
        ''' Creates the Tasks tree view
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateTasksView() As NTreeView
            Dim tasks = New String() {"Meet John", "Montly report", "Pickup kids", "Make backup"}
            Return SetupTreeView(tasks, NResources.Image__16x16_Tasks_png)
        End Function

        Private Function SetupTreeView(texts As String(), image As NImage) As NTreeView
            Dim treeView As NTreeView = New NTreeView()
            treeView.BorderThickness = New NMargins(0)
            For i = 0 To texts.Length - 1
                treeView.Items.Add(Me.CreateTreeViewItem(texts(i), CType(image.DeepClone(), NImage)))
            Next

            Return treeView
        End Function
        ''' <summary>
        ''' Creates a tree view item.
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <paramname="icon"></param>
        ''' <returns></returns>
        Private Function CreateTreeViewItem(text As String, icon As NImage) As NTreeViewItem
            Dim stack As NStackPanel = New NStackPanel()
            stack.Direction = ENHVDirection.LeftToRight
            stack.HorizontalSpacing = 3

            If icon IsNot Nothing Then
                Dim imageBox As NImageBox = New NImageBox(icon)
                imageBox.HorizontalPlacement = ENHorizontalPlacement.Center
                imageBox.VerticalPlacement = ENVerticalPlacement.Center

                stack.Add(imageBox)
            End If

            If Not String.IsNullOrEmpty(text) Then
                Dim label As NLabel = New NLabel(text)
                label.VerticalPlacement = ENVerticalPlacement.Center
                stack.Add(label)
            End If

            Dim item As NTreeViewItem = New NTreeViewItem(stack)
            item.Margins = New NMargins(0, 5)

            Return item
        End Function

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog
        Private m_Accordion As NAccordion

#End Region

#Region "Schema"

        Public Shared ReadOnly NAccordionFlexBoxExampleSchema As NSchema

#End Region
    End Class
End Namespace
