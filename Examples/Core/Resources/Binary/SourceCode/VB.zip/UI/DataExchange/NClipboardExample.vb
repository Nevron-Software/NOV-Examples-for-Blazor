Imports System.Globalization
Imports System.IO

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.Formats
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NClipboardExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NClipboardExampleSchema = NSchema.Create(GetType(NClipboardExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim tab As NTab = New NTab()
            tab.HeadersPosition = ENTabHeadersPosition.Left

            tab.TabPages.Add(New NTabPage("Clipboard Text", CreateTextDemo()))
            tab.TabPages.Add(New NTabPage("Clipboard RTF", CreateRTFDemo()))
            tab.TabPages.Add(New NTabPage("Clipboard Raster", CreateRasterDemo()))

            Return tab
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>The example demonstrates how to use Clipboard in NOV. Click the <b>Set Clipboard Text</b> button to set the text of the text box
to the clipboard and clear the text box. Click <b>Get Clipboard Text</b> to load the text from the clipboard to the text box. The same
goes for the rich text and the images examples.</p>"
        End Function

#End Region

#Region "Implementation - Text"

        Private Function CreateTextDemo() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            Dim setTextButton As NButton = New NButton("Set Clipboard Text")
            setTextButton.Click += New [Function](Of NEventArgs)(AddressOf OnSetTextButtonClick)

            Dim getTextButton As NButton = New NButton("Get Clipboard Text")
            getTextButton.Click += New [Function](Of NEventArgs)(AddressOf OnGetTextButtonClick)

            Dim pairBox As NPairBox = New NPairBox(setTextButton, getTextButton)
            pairBox.HorizontalPlacement = ENHorizontalPlacement.Left
            pairBox.Spacing = NDesign.HorizontalSpacing
            stack.Add(pairBox)

            m_TextBox = New NTextBox()
            m_TextBox.Text = "This is some text. You can edit it or enter more if you want." & vbLf & vbLf & "When ready click the ""Set Clipboard Text"" button to move it to the clipboard."
            m_TextBox.Multiline = True
            stack.Add(m_TextBox)

            Return stack
        End Function
        Private Sub OnGetTextButtonClick(args As NEventArgs)
            Dim dataObject As NDataObject = NClipboard.GetDataObject()
            Dim data = dataObject.GetData(NDataFormat.TextFormatString)
            If data IsNot Nothing Then
                m_TextBox.Text = CStr(data)
            End If
        End Sub
        Private Sub OnSetTextButtonClick(args As NEventArgs)
            Dim dataObject As NDataObject = New NDataObject()
            dataObject.SetData(NDataFormat.TextFormatString, m_TextBox.Text)
            NClipboard.SetDataObject(dataObject)

            m_TextBox.Text = "Text box content moved to clipboard."
        End Sub

#End Region

#Region "Implementation - Rich Text"

        Private Function CreateRTFDemo() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            Dim setButton As NButton = New NButton("Set Clipboard RTF")
            setButton.Click += New [Function](Of NEventArgs)(AddressOf OnSetRTFButtonClick)

            Dim getButton As NButton = New NButton("Get Clipboard RTF")
            getButton.Click += New [Function](Of NEventArgs)(AddressOf OnGetRTFButtonClick)

            Dim pairBox As NPairBox = New NPairBox(setButton, getButton)
            pairBox.HorizontalPlacement = ENHorizontalPlacement.Left
            pairBox.Spacing = NDesign.HorizontalSpacing
            stack.Add(pairBox)

            ' Create a rich text view and some content
            m_RichText = New NRichTextView()
            m_RichText.PreferredSize = New NSize(400, 300)

            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            Dim table As NTable = New NTable(2, 2)
            table.AllowSpacingBetweenCells = False

            section.Blocks.Add(table)
            For i = 0 To 3
                Dim cell = table.Rows(i / 2).Cells(i Mod 2)
                cell.Border = NBorder.CreateFilledBorder(NColor.Black)
                cell.BorderThickness = New NMargins(1)
                Dim paragraph = CType(cell.Blocks(0), NParagraph)
                paragraph.Inlines.Add(New NTextInline("Cell " & (i + 1).ToString(CultureInfo.InvariantCulture)))
            Next

            stack.Add(m_RichText)
            Return stack
        End Function
        Private Sub OnGetRTFButtonClick(args As NEventArgs)
            Dim dataObject As NDataObject = NClipboard.GetDataObject()
            Dim data As Byte() = dataObject.GetRTF()
            If data IsNot Nothing Then
                m_RichText.LoadFromStreamAsync(New MemoryStream(data), NTextFormat.Rtf)
            End If
        End Sub
        Private Sub OnSetRTFButtonClick(args As NEventArgs)
            Dim dataObject As NDataObject = New NDataObject()
            Using stream As MemoryStream = New MemoryStream()
                m_RichText.SaveToStreamAsync(stream, NTextFormat.Rtf)
                dataObject.SetData(NDataFormat.RTFFormat, stream.ToArray())
                NClipboard.SetDataObject(dataObject)
            End Using

            ' Clear the rich text
            m_RichText.Content.Sections.Clear()

            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            section.Blocks.Add(New NParagraph("Rich text content moved to clipboard."))
        End Sub

#End Region

#Region "Implementation - Images"

        Private Function CreateRasterDemo() As NWidget
            Dim rasterStack As NStackPanel = New NStackPanel()
            rasterStack.FillMode = ENStackFillMode.Last
            rasterStack.FitMode = ENStackFitMode.Last

            ' create the controls that demonstrate how to place image content on the clipboard
            If True Then
                Dim setRastersGroupBox As NGroupBox = New NGroupBox("Setting images on the clipboard")
                rasterStack.Add(setRastersGroupBox)

                Dim setRastersStack As NStackPanel = New NStackPanel()
                setRastersStack.Direction = ENHVDirection.LeftToRight
                setRastersGroupBox.Content = setRastersStack

                For i = 0 To 2
                    Dim pair As NPairBox = New NPairBox()

                    Select Case i
                        Case 0
                            pair.Box1 = New NImageBox(NResources.Image__48x48_Book_png)
                        Case 1
                            pair.Box1 = New NImageBox(NResources.Image__48x48_Clock_png)
                        Case 2
                            pair.Box1 = New NImageBox(NResources.Image__48x48_Darts_png)
                    End Select

                    pair.Box2 = New NLabel("Set me on the clipboard")
                    pair.Box2.HorizontalPlacement = ENHorizontalPlacement.Center
                    pair.BoxesRelation = ENPairBoxRelation.Box1AboveBox2

                    Dim setRasterButton As NButton = New NButton(pair)
                    setRasterButton.Tag = i
                    setRasterButton.Click += New [Function](Of NEventArgs)(AddressOf OnSetRasterButtonClick)
                    setRastersStack.Add(setRasterButton)
                Next
            End If

            ' create the controls that demonstrate how to get image content from the clipboard
            If True Then
                Dim getRastersGroupBox As NGroupBox = New NGroupBox("Getting images from the clipboard")
                rasterStack.Add(getRastersGroupBox)

                Dim getRastersStack As NStackPanel = New NStackPanel()
                getRastersStack.FillMode = ENStackFillMode.Last
                getRastersStack.FitMode = ENStackFitMode.Last
                getRastersGroupBox.Content = getRastersStack

                m_ImageBox = New NImageBox()
                m_ImageBox.Margins = New NMargins(10)
                m_ImageBox.Border = NBorder.CreateFilledBorder(NColor.Black)
                m_ImageBox.BorderThickness = New NMargins(1)
                m_ImageBox.Visibility = ENVisibility.Hidden

                Dim getRasterButton As NButton = New NButton("Get image from the clipboard")
                getRasterButton.HorizontalPlacement = ENHorizontalPlacement.Left
                getRasterButton.Click += New [Function](Of NEventArgs)(AddressOf OnGetRasterButtonClick)
                getRastersStack.Add(getRasterButton)

                Dim scrollContent As NScrollContent = New NScrollContent()
                scrollContent.BackgroundFill = New NHatchFill(ENHatchStyle.LargeCheckerBoard, NColor.Gray, NColor.LightGray)
                scrollContent.Content = m_ImageBox
                scrollContent.NoScrollHAlign = ENNoScrollHAlign.Left
                scrollContent.NoScrollVAlign = ENNoScrollVAlign.Top
                getRastersStack.Add(scrollContent)
            End If

            Return rasterStack
        End Function
        Private Sub OnSetRasterButtonClick(args As NEventArgs)
            ' get a raster to place on the clipbar
            Dim raster As NRaster = Nothing
            Select Case args.TargetNode.Tag
                Case 0
                    raster = NResources.Image__48x48_Book_png.ImageSource.CreateRaster()
                Case 1
                    raster = NResources.Image__48x48_Clock_png.ImageSource.CreateRaster()
                Case 2
                    raster = NResources.Image__48x48_Darts_png.ImageSource.CreateRaster()
            End Select

            ' create a data object
            Dim dataObject As NDataObject = New NDataObject()
            dataObject.SetData(NDataFormat.RasterFormat, raster)

            ' set it on the clipboard
            NClipboard.SetDataObject(dataObject)
        End Sub
        Private Sub OnGetRasterButtonClick(args As NEventArgs)
            ' get a data object from the clipboard
            Dim dataObject As NDataObject = NClipboard.GetDataObject()

            ' try get a raster from the data object
            Dim data = dataObject.GetData(NDataFormat.RasterFormat)
            If data Is Nothing Then Return

            ' place it inside the image box
            Dim raster As NRaster = data
            m_ImageBox.Image = New NImage(raster)
            m_ImageBox.Visibility = ENVisibility.Visible
        End Sub

#End Region

#Region "Fields"

        Private m_TextBox As NTextBox
        Private m_RichText As NRichTextView
        Private m_ImageBox As NImageBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NClipboardExampleSchema As NSchema

#End Region
    End Class
End Namespace
