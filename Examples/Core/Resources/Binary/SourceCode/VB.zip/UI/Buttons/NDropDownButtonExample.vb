Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NDropDownButtonExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NDropDownButtonExampleSchema = NSchema.Create(GetType(NDropDownButtonExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Protected Overrides - Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_DropDownButton = New NDropDownButton(NPairBox.Create(NResources.Image__16x16_Calendar_png, "Event"))
            m_DropDownButton.HorizontalPlacement = ENHorizontalPlacement.Left
            m_DropDownButton.VerticalPlacement = ENVerticalPlacement.Top
            m_DropDownButton.Margins = New NMargins(0, NDesign.VerticalSpacing, 0, 0)

            ' Create the drop down button Popup content
            Dim popupStack As NStackPanel = New NStackPanel()
            popupStack.Padding = New NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing)
            popupStack.Add(New NLabel("Event Date:"))
            popupStack.Add(New NCalendar())
            popupStack.Add(New NLabel("Event Color:"))
            popupStack.Add(New NPaletteColorPicker())

            Dim buttonStrip As NButtonStrip = New NButtonStrip()
            buttonStrip.AddOKCancelButtons()
            popupStack.Add(buttonStrip)

            m_DropDownButton.Popup.Content = popupStack

            Return m_DropDownButton
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_DropDownButton).CreatePropertyEditors(m_DropDownButton, NInputElement.EnabledProperty, NStylePropertyEx.ExtendedLookPropertyEx)

            ' Change the text of the extended look property editor
            Dim label As NLabel = CType(editors(0).GetFirstDescendant(New NInstanceOfSchemaFilter(NLabel.NLabelSchema)), NLabel)
            label.Text = "Extended Look:"

            Dim stack As NStackPanel = New NStackPanel()
            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a drop down button and set the content of its popup.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_DropDownButton As NDropDownButton

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDropDownButtonExample.
        ''' </summary>
        Public Shared ReadOnly NDropDownButtonExampleSchema As NSchema

#End Region
    End Class
End Namespace
