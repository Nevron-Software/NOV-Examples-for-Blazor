Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.Editors

Namespace Nevron.Nov.Examples.UI
    Public Class NNavigationBarFirstLookExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NNavigationBarFirstLookExampleSchema = NSchema.Create(GetType(NNavigationBarFirstLookExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a list box
            m_NavigationBar = New NNavigationBar()
            m_NavigationBar.HorizontalPlacement = ENHorizontalPlacement.Left
            m_NavigationBar.VerticalPlacement = ENVerticalPlacement.Fit

            ' create the Outlook Bar Panes
            CreateNavigationBarPane("Mail", "Mail", NResources.Image__24x24_Mail_png, NResources.Image__16x16_Mail_png, New NLabel("Mail Content"))
            CreateNavigationBarPane("Calendar", "Calendar", NResources.Image__24x24_Calendar_png, NResources.Image__16x16_Calendar_png, New NLabel("Calendar Content"))
            CreateNavigationBarPane("Contacts", "Contacts", NResources.Image__24x24_Contacts_png, NResources.Image__16x16_Contacts_png, New NLabel("Contacts Content"))
            CreateNavigationBarPane("Tasks", "Tasks", NResources.Image__24x24_Tasks_png, NResources.Image__16x16_Tasks_png, New NLabel("Tasks Content"))
            CreateNavigationBarPane("Notes", "Notes", NResources.Image__24x24_Notes_png, NResources.Image__16x16_Notes_png, New NLabel("Notes Content"))
            CreateNavigationBarPane("Folders", "Folders", NResources.Image__24x24_Folders_png, NResources.Image__16x16_Folders_png, New NLabel("Folders Content"))
            CreateNavigationBarPane("Shortcuts", "Shortcuts", NResources.Image__24x24_Shortcuts_png, NResources.Image__16x16_Shortcuts_png, New NLabel("Shortcuts Content"))

            ' Hook to list box selection events
            Me.m_NavigationBar.SelectedIndexChanged += AddressOf OnNavigationBarSelectedIndexChanged

            Return m_NavigationBar
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create the properties group box
            stack.Add(CreatePropertiesGroupBox())

            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a simple NavigationBar and populate it with items. You can use the controls
	on the right to modify various properties of the NavigationBar.
</p>
"
        End Function

        Private Function CreateNavigationBarPane(title As String, tooltip As String, largeImage As NImage, smallImage As NImage, content As NWidget) As NNavigationBarPane
            Dim pane As NNavigationBarPane = New NNavigationBarPane()

            ' set pane content
            pane.Content = content
            pane.Image = CType(smallImage.DeepClone(), NImage)
            pane.Text = title

            ' set header content
            Dim titleLabel As NLabel = New NLabel(title)
            titleLabel.VerticalPlacement = ENVerticalPlacement.Fit

            Dim headerContent As NPairBox = New NPairBox(largeImage, titleLabel)
            headerContent.Spacing = 2
            pane.Header.Content = headerContent
            pane.Header.Tooltip = New NTooltip(tooltip)

            ' set icon content
            pane.Icon.Content = New NImageBox(smallImage)
            pane.Icon.Tooltip = New NTooltip(tooltip)

            ' add the pane
            m_NavigationBar.Panes.Add(pane)
            Return pane
        End Function
        Private Sub OnNavigationBarSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_EventsLog.LogEvent("Selected Index " & m_NavigationBar.SelectedIndex.ToString())
        End Sub

#End Region

#Region "Implementation"

        Private Function CreatePropertiesGroupBox() As NGroupBox
            Dim propertiesStack As NStackPanel = New NStackPanel()

            Dim editors = NDesigner.GetDesigner(m_NavigationBar).CreatePropertyEditors(m_NavigationBar, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NNavigationBar.VisibleHeadersCountProperty, NNavigationBar.HeadersPaddingProperty, NNavigationBar.HeadersSpacingProperty, NNavigationBar.IconsPaddingProperty, NNavigationBar.IconsSpacingProperty)

            Dim i = 0, count = editors.Count

            While i < count
                propertiesStack.Add(editors(i))
                i += 1
            End While

            Dim propertiesGroupBox As NGroupBox = New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack))
            Return propertiesGroupBox
        End Function

#End Region

#Region "Event Handlers"

#End Region

#Region "Fields"

        Private m_NavigationBar As NNavigationBar
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NNavigationBarFirstLookExample.
        ''' </summary>
        Public Shared ReadOnly NNavigationBarFirstLookExampleSchema As NSchema

#End Region
    End Class
End Namespace
