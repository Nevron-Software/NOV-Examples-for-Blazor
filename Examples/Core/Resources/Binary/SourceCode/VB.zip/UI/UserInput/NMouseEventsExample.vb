Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NMouseEventsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMouseEventsExampleSchema = NSchema.Create(GetType(NMouseEventsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_Canvas = New NCanvas()
            Me.m_Canvas.PrePaint += AddressOf OnCanvasPrePaint

            ' subscribe for mouse events
            Me.m_Canvas.MouseDown += AddressOf OnCanvasMouseDown
            Me.m_Canvas.MouseUp += AddressOf OnCanvasMouseUp
            Me.m_Canvas.MouseMove += AddressOf OnCanvasMouseMove
            Me.m_Canvas.MouseWheel += AddressOf OnCanvasMouseWheel
            Me.m_Canvas.MouseIn += AddressOf OnCanvasMouseIn
            Me.m_Canvas.MouseOut += AddressOf OnCanvasMouseOut
            Me.m_Canvas.GotMouseCapture += AddressOf OnCanvasGotMouseCapture
            Me.m_Canvas.LostMouseCapture += AddressOf OnCanvasLostMouseCapture

            Return m_Canvas
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FitMode = ENStackFitMode.Last
            stack.FillMode = ENStackFillMode.Last

            ' track move events
            m_LogMoveEventsCheck = New NCheckBox("Track Move Events")
            stack.Add(m_LogMoveEventsCheck)

            ' capture mouse on left mouse down
            m_CaptureMouseOnLeftMouseDown = New NCheckBox("Capture Mouse on Left MouseDown")
            stack.Add(m_CaptureMouseOnLeftMouseDown)

            ' capture mouse on right mouse down
            m_CaptureMouseOnRightMouseDown = New NCheckBox("Capture Mouse on Right MouseDown")
            stack.Add(m_CaptureMouseOnRightMouseDown)

            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	Demonstrates the mouse support in NOV. Click and move the mouse over the canvas to explore the mouse events that NOV sends to the application.
    Mouse support is available to most desktop enviroments.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(arg As NCanvasPaintEventArgs)
            Dim visitor = arg.PaintVisitor

            ' paint background
            visitor.SetFill(NColor.Ivory)
            visitor.PaintRectangle(m_Canvas.GetContentEdge())

            ' paint mouse
            If NMouse.IsOver(m_Canvas) Then
                ' define some metrics first
                Dim buttonWidth As Double = 10
                Dim buttonHeight As Double = 15
                Dim buttonsOffset As Double = 5
                Dim pointerSize As NSize = New NSize(5, 5)
                Dim buttonsCenter As NPoint = New NPoint(m_MouseLocation.X, m_MouseLocation.Y + buttonsOffset + buttonHeight / 2)
                Dim buttonsFrame = NRectangle.FromCenterAndSize(buttonsCenter, buttonWidth * 3, buttonHeight)

                ' paint left button, if down
                If m_LeftMouseDown Then
                    Dim buttonRect As NRectangle = New NRectangle(buttonsFrame.Left, buttonsFrame.Top, buttonWidth, buttonHeight)
                    visitor.SetFill(NColor.Red)
                    visitor.PaintRectangle(buttonRect)
                End If

                ' paint middle button, if down
                If m_MiddleMouseDown Then
                    Dim buttonRect As NRectangle = New NRectangle(buttonsFrame.Left + buttonWidth, buttonsFrame.Top, buttonWidth, buttonHeight)
                    visitor.SetFill(NColor.Green)
                    visitor.PaintRectangle(buttonRect)
                End If

                ' paint right button, if down
                If m_RightMouseDown Then
                    Dim buttonRect As NRectangle = New NRectangle(buttonsFrame.Right - buttonWidth, buttonsFrame.Top, buttonWidth, buttonHeight)
                    visitor.SetFill(NColor.Blue)
                    visitor.PaintRectangle(buttonRect)
                End If

                ' paint mouse pointer and buttons frame
                visitor.ClearStyles()
                visitor.SetStroke(New NStroke(NColor.Black))

                visitor.PaintEllipse(NRectangle.FromCenterAndSize(m_MouseLocation, pointerSize))
                visitor.PaintRectangle(buttonsFrame)

                Dim leftSeparator = buttonsCenter.X - buttonWidth / 2
                visitor.PaintLine(leftSeparator, buttonsFrame.Top, leftSeparator, buttonsFrame.Bottom)

                Dim rightSeparator = buttonsCenter.X + buttonWidth / 2
                visitor.PaintLine(rightSeparator, buttonsFrame.Top, rightSeparator, buttonsFrame.Bottom)
            End If

            ' paint capture frame
            If NMouse.IsCaptured(m_Canvas) Then
                Dim outerRect As NRectangle = m_Canvas.GetContentEdge()
                Dim innerRect = outerRect
                innerRect.Deflate(3)

                Dim path As NGraphicsPath = New NGraphicsPath()
                path.AddRectangle(outerRect)
                path.AddRectangle(innerRect)

                visitor.ClearStyles()
                visitor.SetFill(NColor.Red)
                visitor.PaintPath(path)
            End If
        End Sub

        Private Sub OnCanvasMouseMove(arg As NMouseEventArgs)
            ' log event
            If m_LogMoveEventsCheck.Checked Then
                m_EventsLog.LogEvent(String.Format("Mouse Move. Position X: {0}, Y; {1}", m_MouseLocation.X, m_MouseLocation.Y))
            End If

            ' update mouse location
            m_MouseLocation = arg.CurrentTargetPosition
            m_Canvas.InvalidateDisplay()
        End Sub
        Private Sub OnCanvasMouseUp(arg As NMouseButtonEventArgs)
            m_EventsLog.LogEvent("Mouse Up. Button: " & arg.Button.ToString())

            Select Case arg.Button
                Case ENMouseButtons.Left
                    m_LeftMouseDown = False

                Case ENMouseButtons.Right
                    m_RightMouseDown = False

                Case ENMouseButtons.Middle
                    m_MiddleMouseDown = False
                Case Else
            End Select

            m_Canvas.InvalidateDisplay()
        End Sub
        Private Sub OnCanvasMouseDown(arg As NMouseButtonEventArgs)
            m_EventsLog.LogEvent("Mouse Down. Button: " & arg.Button.ToString())

            Select Case arg.Button
                Case ENMouseButtons.Left
                    m_LeftMouseDown = True

                    If m_CaptureMouseOnLeftMouseDown.Checked Then
                        m_Canvas.CaptureMouse()
                    End If

                Case ENMouseButtons.Right
                    m_RightMouseDown = True

                    If m_CaptureMouseOnRightMouseDown.Checked Then
                        m_Canvas.CaptureMouse()
                    End If

                Case ENMouseButtons.Middle
                    m_MiddleMouseDown = True
                Case Else
            End Select

            m_Canvas.InvalidateDisplay()
        End Sub
        Private Sub OnCanvasMouseWheel(arg As NMouseWheelEventArgs)
            m_EventsLog.LogEvent("Mouse Wheel. Delta: " & arg.Delta.ToString())
        End Sub

        Private Sub OnCanvasMouseOut(arg As NMouseOverChangeEventArgs)
            m_EventsLog.LogEvent("Mouse Out")
            m_Canvas.InvalidateDisplay()
        End Sub
        Private Sub OnCanvasMouseIn(arg As NMouseOverChangeEventArgs)
            m_EventsLog.LogEvent("Mouse In")
            m_Canvas.InvalidateDisplay()
        End Sub

        Private Sub OnCanvasGotMouseCapture(arg As NMouseCaptureChangeEventArgs)
            m_EventsLog.LogEvent("Got Mouse Capture")
            m_Canvas.InvalidateDisplay()
        End Sub
        Private Sub OnCanvasLostMouseCapture(arg As NMouseCaptureChangeEventArgs)
            m_EventsLog.LogEvent("Lost Mouse Capture")
            m_Canvas.InvalidateDisplay()
        End Sub

#End Region

#Region "Fields"

        Private m_LogMoveEventsCheck As NCheckBox
        Private m_CaptureMouseOnLeftMouseDown As NCheckBox
        Private m_CaptureMouseOnRightMouseDown As NCheckBox
        Private m_Canvas As NCanvas
        Private m_EventsLog As NExampleEventsLog

        Private m_MouseLocation As NPoint
        Private m_LeftMouseDown As Boolean
        Private m_MiddleMouseDown As Boolean
        Private m_RightMouseDown As Boolean

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMouseEventsExample.
        ''' </summary>
        Public Shared ReadOnly NMouseEventsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const EnglishLanguageName As String = "English (US)"
        Private Const BulgarianLanguageName As String = "Bulgarian"
        Private Const GermanLanguageName As String = "German"

#End Region
    End Class
End Namespace
