Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NTimeSpanBoxExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTimeSpanBoxExampleSchema = NSchema.Create(GetType(NTimeSpanBoxExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim timeSpanBox As NTimeSpanBox = New NTimeSpanBox()
            timeSpanBox.HorizontalPlacement = ENHorizontalPlacement.Left
            timeSpanBox.VerticalPlacement = ENVerticalPlacement.Top

            ' Add some time spans to the box
            timeSpanBox.AddItem(TimeSpan.MinValue)
            timeSpanBox.AddItem(TimeSpan.Zero)

            timeSpanBox.AddItem(TimeSpan.FromMinutes(10))
            timeSpanBox.AddItem(TimeSpan.FromMinutes(15))
            timeSpanBox.AddItem(TimeSpan.FromMinutes(30))

            timeSpanBox.AddItem(TimeSpan.FromHours(1))
            timeSpanBox.AddItem(TimeSpan.FromHours(1.5))
            timeSpanBox.AddItem(TimeSpan.FromHours(2))
            timeSpanBox.AddItem(TimeSpan.FromHours(3))
            timeSpanBox.AddItem(TimeSpan.FromHours(6))
            timeSpanBox.AddItem(TimeSpan.FromHours(8))
            timeSpanBox.AddItem(TimeSpan.FromHours(12))

            timeSpanBox.AddItem(TimeSpan.FromDays(1))
            timeSpanBox.AddItem(TimeSpan.FromDays(1.5))
            timeSpanBox.AddItem(TimeSpan.FromDays(2))

            ' Add the "Custom..." option
            timeSpanBox.AddCustomItem()

            ' Select the first item
            timeSpanBox.SelectedIndex = 0

            ' Subscribe to the SelectedIndex changed event
            timeSpanBox.SelectedIndexChanged += AddressOf OnTimeSpanBoxSelectedIndexChanged

            Return timeSpanBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            m_EventsLog = New NExampleEventsLog()
            Return m_EventsLog
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and configure a time span box. Using the controls on the right you can
	modify various aspects of the time span box.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnTimeSpanBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim timeSpanBox = CType(arg.TargetNode, NTimeSpanBox)

            ' Log the selected time span
            Dim timeSpan As TimeSpan = timeSpanBox.SelectedTimeSpan
            If timeSpan <> TimeSpan.MinValue Then
                m_EventsLog.LogEvent("Selected time span: " & timeSpan.ToString())
            Else
                m_EventsLog.LogEvent("Selected time span: none")
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTimeSpanBoxExample.
        ''' </summary>
        Public Shared ReadOnly NTimeSpanBoxExampleSchema As NSchema

#End Region
    End Class
End Namespace
