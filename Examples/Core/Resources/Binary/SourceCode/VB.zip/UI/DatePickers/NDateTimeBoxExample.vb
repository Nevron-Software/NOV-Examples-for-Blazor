Imports System
Imports System.Collections.Generic
Imports System.Globalization

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NDateTimeBoxExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NDateTimeBoxExampleSchema = NSchema.Create(GetType(NDateTimeBoxExample), NExampleBase.NExampleBaseSchema)

            ' Fill the list of cultures
            Dim cultureNames = New String() {"en-US", "en-GB", "fr-FR", "de-DE", "es-ES", "ru-RU", "zh-CN", "ja-JP", "it-IT", "hi-IN", "ar-AE", "he-IL", "id-ID", "ko-KR", "pt-BR", "sv-SE", "tr-TR", "pt-BR", "bg-BG", "ro-RO", "pl-PL", "nl-NL", "cs-CZ"}
            Cultures = New NList(Of CultureInfo)()

            Dim i = 0, count = cultureNames.Length

            While i < count
                Dim cultureInfo As CultureInfo
                Try
                    cultureInfo = New CultureInfo(cultureNames(i))
                Catch
                    cultureInfo = Nothing
                End Try

                If cultureInfo IsNot Nothing AndAlso Cultures.Contains(cultureInfo) = False Then
                    Cultures.Add(cultureInfo)
                End If

                i += 1
            End While

            ' Sort the cultures by their English name
            Call Cultures.Sort(New NCultureNameComparer())
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_DateTimeBox = New NDateTimeBox()
            m_DateTimeBox.VerticalPlacement = ENVerticalPlacement.Top
            m_DateTimeBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_DateTimeBox.SelectedDateChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnDateTimeBoxSelectedColorChanged)

            Return m_DateTimeBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            Dim groupBox As NGroupBox = New NGroupBox("Culture:")
            stack.Add(groupBox)
            groupBox.Margins = New NMargins(0, 0, 0, 10)

            ' add the cultures combo box
            Dim selectedIndex = -1
            Dim combo As NComboBox = New NComboBox()
            Dim i = 0, count = Cultures.Count

            While i < count
                Dim culture = Cultures(i)
                Dim item As NComboBoxItem = New NComboBoxItem(culture.EnglishName)
                item.Tag = culture.Name
                combo.Items.Add(item)

                If Equals(culture.Name, m_DateTimeBox.CultureName) Then
                    selectedIndex = i
                End If

                i += 1
            End While

            groupBox.Content = combo
            combo.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnCultureComboSelectedIndexChanged)
            Dim editors = NDesigner.GetDesigner(m_DateTimeBox).CreatePropertyEditors(m_DateTimeBox, NInputElement.EnabledProperty, NDateTimeBox.HighlightTodayProperty, NDateTimeBox.HasTodayButtonProperty, NDateTimeBox.ModeProperty, NDateTimeBox.FormatProperty, NDateTimeBox.SelectedDateProperty)

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and configure a date time box. Using the controls on the right you can
	modify various aspects of the date time box and its drop down calendar's appearance and behavior. NOV date time
	box is fully localizable, you can test how it looks for different cultures by selecting one from the cultures
	combo box on the right.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnDateTimeBoxSelectedColorChanged(args As NValueChangeEventArgs)
            Dim newDate As Date = args.NewValue
            m_EventsLog.LogEvent(newDate.ToString())
        End Sub
        Private Sub OnCultureComboSelectedIndexChanged(args As NValueChangeEventArgs)
            Dim combo As NComboBox = TryCast(args.TargetNode, NComboBox)

            Dim selectedItem = combo.SelectedItem
            If selectedItem Is Nothing Then Return

            m_DateTimeBox.CultureName = CStr(selectedItem.Tag)
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog
        Private m_DateTimeBox As NDateTimeBox

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDateTimeBoxExample.
        ''' </summary>
        Public Shared ReadOnly NDateTimeBoxExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly Cultures As NList(Of CultureInfo)

#End Region

#Region "Nested Types"

        Private Class NCultureNameComparer
            Implements IComparer(Of CultureInfo)
            Public Function Compare(culture1 As CultureInfo, culture2 As CultureInfo) As Integer Implements IComparer(Of CultureInfo).Compare
                Return culture1.EnglishName.CompareTo(culture2.EnglishName)
            End Function
        End Class

#End Region
    End Class
End Namespace
