Imports System

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NPrintDialogExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPrintDialogExampleSchema = NSchema.Create(GetType(NPrintDialogExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim printButton As NButton = New NButton("Print...")
            printButton.HorizontalPlacement = ENHorizontalPlacement.Left
            printButton.VerticalPlacement = ENVerticalPlacement.Top
            printButton.Click += New [Function](Of NEventArgs)(AddressOf OnPrintButtonClick)

            Return printButton
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' print range mode
            m_PrintRangeModeComboBox = New NComboBox()
            m_PrintRangeModeComboBox.FillFromEnum(Of ENPrintRangeMode)()
            m_PrintRangeModeComboBox.SelectedIndex = 0
            stack.Add(New NPairBox("Print Range Mode:", m_PrintRangeModeComboBox, True))

            ' enable current page
            m_EnableCurrentPageCheckBox = New NCheckBox()
            stack.Add(New NPairBox("Enable Current Page:", m_EnableCurrentPageCheckBox, True))

            ' enable selection
            m_EnableSelectionCheckBox = New NCheckBox()
            stack.Add(New NPairBox("Enable Selection:", m_EnableSelectionCheckBox, True))

            ' enable custom page range
            m_EnableCustomPageRangeCheckBox = New NCheckBox()
            stack.Add(New NPairBox("Enable Custom Page Range:", m_EnableCustomPageRangeCheckBox, True))

            ' collate
            m_CollateCheckBox = New NCheckBox()
            stack.Add(New NPairBox("Collate:", m_CollateCheckBox, True))

            ' number of copies
            m_NumberOfCopiesUpDown = New NNumericUpDown()
            m_NumberOfCopiesUpDown.DecimalPlaces = 0
            m_NumberOfCopiesUpDown.Step = 1
            m_NumberOfCopiesUpDown.Minimum = 1
            m_NumberOfCopiesUpDown.Maximum = 100
            stack.Add(New NPairBox("Number of Copies:", m_NumberOfCopiesUpDown, True))

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
				<p>
					This example demonstrates how to create and use the print dialog provided by NOV.
				</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnPrintButtonClick(args As NEventArgs)
            Dim printDocument As NPrintDocument = New NPrintDocument()
            printDocument.DocumentName = "Test Document 1"
            printDocument.BeginPrint += New [Function](Of NPrintDocument, NBeginPrintEventArgs)(AddressOf OnBeginPrint)
            printDocument.PrintPage += New [Function](Of NPrintDocument, NPrintPageEventArgs)(AddressOf OnPrintPage)
            printDocument.EndPrint += New [Function](Of NPrintDocument, NEndPrintEventArgs)(AddressOf OnEndPrint)

            Dim printDialog As NPrintDialog = New NPrintDialog()

            printDialog.PrintRangeMode = CType(m_PrintRangeModeComboBox.SelectedItem.Tag, ENPrintRangeMode)
            printDialog.EnableCustomPageRange = m_EnableCustomPageRangeCheckBox.Checked
            printDialog.EnableCurrentPage = m_EnableCurrentPageCheckBox.Checked
            printDialog.EnableSelection = m_EnableSelectionCheckBox.Checked

            printDialog.CustomPageRange = New NRangeI(1, 100)
            printDialog.NumberOfCopies = CInt(m_NumberOfCopiesUpDown.Value)
            printDialog.Collate = m_CollateCheckBox.Checked

            printDialog.PrintDocument = printDocument
            printDialog.Closed += New [Function](Of NPrintDialogResult)(AddressOf OnPrintDialogClosed)

            printDialog.RequestShow()
        End Sub
        Private Sub OnBeginPrint(sender As NPrintDocument, e As NBeginPrintEventArgs)
        End Sub
        Private Sub OnEndPrint(sender As NPrintDocument, e As NEndPrintEventArgs)
        End Sub
        Private Sub OnPrintPage(sender As NPrintDocument, e As NPrintPageEventArgs)
            Dim pageSizeDIP As NSize = New NSize(Me.Width, Me.Height)

            Try
                Dim pageMargins = NMargins.Zero

                Dim clip As NRegion = NRegion.FromRectangle(New NRectangle(0, 0, e.PrintableArea.Width, e.PrintableArea.Height))
                Dim transform As NMatrix = New NMatrix(e.PrintableArea.X, e.PrintableArea.Y)

                Dim visitor As NPaintVisitor = New NPaintVisitor(e.Graphics, 300, transform, clip)

                ' forward traverse the display tree
                m_PrintRangeModeComboBox.DisplayWindow.VisitDisplaySubtree(visitor)

                e.HasMorePages = False
            Catch x As Exception
                NMessageBox.Show(x.Message, "Exception", ENMessageBoxButtons.OK, ENMessageBoxIcon.Error)
            End Try

        End Sub
        Private Sub OnPrintDialogClosed(result As NPrintDialogResult)
            If result.Result Is ENCommonDialogResult.Error Then
                Call NMessageBox.Show("Error Message: " & result.ErrorException.Message.ToString(), "Print Dialog Error", ENMessageBoxButtons.OK, ENMessageBoxIcon.Error)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_PrintRangeModeComboBox As NComboBox
        Private m_EnableCustomPageRangeCheckBox As NCheckBox
        Private m_EnableCurrentPageCheckBox As NCheckBox
        Private m_EnableSelectionCheckBox As NCheckBox
        Private m_CollateCheckBox As NCheckBox
        Private m_NumberOfCopiesUpDown As NNumericUpDown

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPrintDialogExample.
        ''' </summary>
        Public Shared ReadOnly NPrintDialogExampleSchema As NSchema

#End Region
    End Class
End Namespace
