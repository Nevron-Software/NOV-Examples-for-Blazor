Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NMessageBoxExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMessageBoxExampleSchema = NSchema.Create(GetType(NMessageBoxExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.PreferredWidth = 300
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            ' Create a text box for the message box title
            m_TitleTextBox = New NTextBox("Message Box")
            stack.Add(CreatePairBox("Title:", m_TitleTextBox))

            ' Create a text box for the message box content
            m_ContentTextBox = New NTextBox("Here goes the content." & vbLf & "It can be multiline.")
            m_ContentTextBox.Multiline = True
            m_ContentTextBox.AcceptsEnter = True
            m_ContentTextBox.AcceptsTab = True
            m_ContentTextBox.PreferredHeight = 100
            m_ContentTextBox.HScrollMode = ENScrollMode.WhenNeeded
            m_ContentTextBox.VScrollMode = ENScrollMode.WhenNeeded
            m_ContentTextBox.WordWrap = False
            stack.Add(CreatePairBox("Content:", m_ContentTextBox))

            ' Create the message box buttons combo box
            m_ButtonsComboBox = New NComboBox()
            m_ButtonsComboBox.FillFromEnum(Of ENMessageBoxButtons)()
            stack.Add(CreatePairBox("Buttons:", m_ButtonsComboBox))

            ' Create the message box icon combo box
            m_IconComboBox = New NComboBox()
            m_IconComboBox.FillFromEnum(Of ENMessageBoxIcon)()
            m_IconComboBox.SelectedIndex = 1
            stack.Add(CreatePairBox("Icon:", m_IconComboBox))

            ' Create the show button
            Dim label As NLabel = New NLabel("Show")
            label.HorizontalPlacement = ENHorizontalPlacement.Center
            Dim showButton As NButton = New NButton(label)
            showButton.Click += New [Function](Of NEventArgs)(AddressOf OnShowButtonClick)
            stack.Add(showButton)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            Return m_EventsLog
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create message boxes in NOV. Use the controls at the top to set
	the title, the content and the buttons of the message box.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnShowButtonClick(args As NEventArgs)
            Dim button = CType(args.TargetNode, NButton)

            Dim settings As NMessageBoxSettings = New NMessageBoxSettings(m_ContentTextBox.Text, m_TitleTextBox.Text, m_ButtonsComboBox.SelectedIndex, m_IconComboBox.SelectedIndex, ENMessageBoxDefaultButton.Button1, DisplayWindow)                                  ' the message box content
            ' the message box title
            ' the button configuration of the message box
            ' the icon to use
            ' the default focused button
            ' the parent window of the message box

            Call NMessageBox.Show(settings).[Then](Sub(result As ENWindowResult) m_EventsLog.LogEvent("Message box result: '" & result.ToString() & "'"))     ' delegate that gets called when the message box is closed
        End Sub

#End Region

#Region "Fields"

        Private m_TitleTextBox As NTextBox
        Private m_ContentTextBox As NTextBox
        Private m_ButtonsComboBox As NComboBox
        Private m_IconComboBox As NComboBox
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMessageBoxExample.
        ''' </summary>
        Public Shared ReadOnly NMessageBoxExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreatePairBox(text As String, widget As NWidget) As NPairBox
            Dim label As NLabel = New NLabel(text)
            label.HorizontalPlacement = ENHorizontalPlacement.Right
            label.VerticalPlacement = ENVerticalPlacement.Center
            widget.VerticalPlacement = ENVerticalPlacement.Center

            Return New NPairBox(label, widget, True)
        End Function

#End Region
    End Class
End Namespace
