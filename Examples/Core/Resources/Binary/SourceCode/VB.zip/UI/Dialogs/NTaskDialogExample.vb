Imports System.Text

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NTaskDialogExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTaskDialogExampleSchema = NSchema.Create(GetType(NTaskDialogExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            Dim messageBoxLikeButton As NButton = New NButton("Message Box Like")
            messageBoxLikeButton.Click += AddressOf OnMessageBoxLikeButtonClick
            stack.Add(messageBoxLikeButton)

            Dim customButtonsButton As NButton = New NButton("Custom Buttons")
            customButtonsButton.Click += AddressOf OnCustomButtonsButtonClick
            stack.Add(customButtonsButton)

            Dim advancedCustomButtonsButton As NButton = New NButton("Advanced Custom Buttons")
            advancedCustomButtonsButton.Click += AddressOf OnAdvancedCustomButtonsButtonClick
            stack.Add(advancedCustomButtonsButton)

            Dim radioButtonsButton As NButton = New NButton("Radio Buttons")
            radioButtonsButton.Click += AddressOf OnRadioButtonsButtonClick
            stack.Add(radioButtonsButton)

            Dim verificationButton As NButton = New NButton("Verification Check Box")
            verificationButton.Click += AddressOf OnVerificationButtonClick
            stack.Add(verificationButton)

            Dim allFeaturesButton As NButton = New NButton("All Features")
            allFeaturesButton.Click += AddressOf OnAllFeaturesButtonClick
            stack.Add(allFeaturesButton)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            m_EventsLog = New NExampleEventsLog()
            Return m_EventsLog
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create task dialogs in NOV. Click any of the buttons above to show
	a preconfigured task dialog, which demonstrates different task dialog features.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnMessageBoxLikeButtonClick(arg As NEventArgs)
            Dim taskDialog = NTaskDialog.Create(DisplayWindow)
            taskDialog.Title = "Task Dialog"
            taskDialog.Header = New NTaskDialogHeader(ENMessageBoxIcon.Question, "Do you want to save the changes?")
            taskDialog.Buttons = ENTaskDialogButton.Yes Or ENTaskDialogButton.No Or ENTaskDialogButton.Cancel

            ' Change the texts of the Yes and No buttons
            Dim stack As NStackPanel = taskDialog.ButtonStrip.GetPredefinedButtonsStack()
            Dim label = CType(stack(0).GetFirstDescendant(NLabel.NLabelSchema), NLabel)
            label.Text = "Save"

            label = CType(stack(1).GetFirstDescendant(NLabel.NLabelSchema), NLabel)
            label.Text = "Don't Save"

            ' Subscribe to the Closed event and open the task dialog
            taskDialog.Closed += AddressOf OnTaskDialogClosed
            taskDialog.Open()
        End Sub
        Private Sub OnCustomButtonsButtonClick(arg As NEventArgs)
            Dim taskDialog = NTaskDialog.Create(DisplayWindow)
            taskDialog.Title = "Task Dialog"
            taskDialog.Header = New NTaskDialogHeader(ENMessageBoxIcon.Information, "This is a task dialog with custom buttons.")
            taskDialog.CustomButtons = New NTaskDialogCustomButtonCollection("Custom Button 1", "Custom Button 2", "Custom Button 3")

            ' Subscribe to the Closed event and open the task dialog
            taskDialog.Closed += AddressOf OnTaskDialogClosed
            taskDialog.Open()
        End Sub
        Private Sub OnAdvancedCustomButtonsButtonClick(arg As NEventArgs)
            Dim taskDialog = NTaskDialog.Create(DisplayWindow)
            taskDialog.Title = "Task Dialog"
            taskDialog.Header = New NTaskDialogHeader(ENMessageBoxIcon.Information, "This is a task dialog with custom buttons.")
            taskDialog.Content = New NLabel("These custom buttons contain a symbol/image, a title and a description.")

            ' Create some custom buttons
            taskDialog.CustomButtons = New NTaskDialogCustomButtonCollection()
            taskDialog.CustomButtons.Add(New NTaskDialogCustomButton("Title Only"))
            taskDialog.CustomButtons.Add(New NTaskDialogCustomButton("Title and Description", "This button has a title and a description."))
            taskDialog.CustomButtons.Add(New NTaskDialogCustomButton(NTaskDialogCustomButton.CreateDefaultSymbol(), "Symbol, Title, and Description", "This button has a symbol, a title and a description."))
            taskDialog.CustomButtons.Add(New NTaskDialogCustomButton(NResources.Image__16x16_Mail_png, "Image, Title and Description", "This button has an icon, a title and a description."))

            ' Subscribe to the Closed event and open the task dialog
            taskDialog.Closed += AddressOf OnTaskDialogClosed
            taskDialog.Open()
        End Sub
        Private Sub OnRadioButtonsButtonClick(arg As NEventArgs)
            Dim taskDialog = NTaskDialog.Create(DisplayWindow)
            taskDialog.Title = "Task Dialog"
            taskDialog.Header = New NTaskDialogHeader(ENMessageBoxIcon.Information, "This is a task dialog with radio buttons.")
            taskDialog.RadioButtonGroup = New NTaskDialogRadioButtonGroup("Radio Button 1", "Radio Button 2")
            taskDialog.Buttons = ENTaskDialogButton.OK

            ' Subscribe to the Closed event and open the task dialog
            taskDialog.Closed += AddressOf OnTaskDialogClosed
            taskDialog.Open()
        End Sub
        Private Sub OnVerificationButtonClick(arg As NEventArgs)
            Dim taskDialog = NTaskDialog.Create(DisplayWindow)
            taskDialog.Title = "Task Dialog"
            taskDialog.Header = New NTaskDialogHeader(ENMessageBoxIcon.Information, "This is the header.")
            taskDialog.Content = New NLabel("This is the content.")
            taskDialog.VerificationCheckBox = New NCheckBox("This is the verification check box.")
            taskDialog.Buttons = ENTaskDialogButton.OK Or ENTaskDialogButton.Cancel

            ' Subscribe to the Closed event and open the task dialog
            taskDialog.Closed += AddressOf OnTaskDialogClosed
            taskDialog.Open()
        End Sub
        Private Sub OnAllFeaturesButtonClick(arg As NEventArgs)
            Dim taskDialog = NTaskDialog.Create(DisplayWindow)
            taskDialog.Title = "Task Dialog"

            ' Add header and content
            taskDialog.Header = New NTaskDialogHeader(ENMessageBoxIcon.Information, "This is the header.")
            taskDialog.Content = New NLabel("This is the content.")

            ' Add some radio buttons and custom buttons
            taskDialog.RadioButtonGroup = New NTaskDialogRadioButtonGroup("Radio Button 1", "Radio Button 2", "Radio Button 3")
            taskDialog.CustomButtons = New NTaskDialogCustomButtonCollection("Custom Button 1", "Custom Button 2", "Custom Button 3")

            ' Set the common buttons
            taskDialog.Buttons = ENTaskDialogButton.OK Or ENTaskDialogButton.Cancel

            ' Add a verification check box and a footer
            taskDialog.VerificationCheckBox = New NCheckBox("This is the verification check box.")
            taskDialog.Footer = New NLabel("This is the footer.")

            ' Subscribe to the Closed event and open the task dialog
            taskDialog.Closed += AddressOf OnTaskDialogClosed
            taskDialog.Open()
        End Sub

        Private Sub OnTaskDialogClosed(arg As NEventArgs)
            Dim taskDialog = CType(arg.TargetNode, NTaskDialog)
            Dim radioButtonIndex = If(taskDialog.RadioButtonGroup IsNot Nothing, taskDialog.RadioButtonGroup.SelectedIndex, -1)
            Dim verificationChecked = If(taskDialog.VerificationCheckBox IsNot Nothing, taskDialog.VerificationCheckBox.Checked, False)

            Dim sb As StringBuilder = New StringBuilder()
            sb.AppendLine("Task result: " & taskDialog.TaskResult.ToString())
            sb.AppendLine("Radio button: " & radioButtonIndex.ToString())
            sb.AppendLine("Custom button: " & taskDialog.CustomButtonIndex.ToString())
            sb.AppendLine("Verification: " & verificationChecked.ToString())

            m_EventsLog.LogEvent(sb.ToString())
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTaskDialogExample.
        ''' </summary>
        Public Shared ReadOnly NTaskDialogExampleSchema As NSchema

#End Region
    End Class
End Namespace
