Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NBorderSplitButtonExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NBorderSplitButtonExampleSchema = NSchema.Create(GetType(NBorderSplitButtonExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_BorderSplitButton = New NBorderSplitButton()
            m_BorderSplitButton.HorizontalPlacement = ENHorizontalPlacement.Left
            m_BorderSplitButton.VerticalPlacement = ENVerticalPlacement.Top
            Me.m_BorderSplitButton.SelectedValueChanged += AddressOf OnBorderSplitButtonSelectedValueChanged
            Return m_BorderSplitButton
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_BorderSplitButton).CreatePropertyEditors(m_BorderSplitButton, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NDropDownEdit.DropDownButtonPositionProperty, NBorderSplitButton.HasAutomaticButtonProperty, NBorderSplitButton.HasNoneButtonProperty, NBorderSplitButton.HasMoreOptionsButtonProperty)

            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use border split buttons. Split buttons are drop down edits,
	whose item slot is filled with an action button, which generates a <b>Click</b> event on behalf of the
	split button. The border split button's drop down content provides the user with a convenient way to quickly
	select a border and its thickness.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnBorderSplitButtonSelectedValueChanged(arg As NValueChangeEventArgs)
            Dim selectedValue As NAutomaticValue(Of NBorder) = arg.NewValue
            Dim str As String
            If selectedValue.Automatic Then
                str = "Automatic"
            ElseIf selectedValue.Value Is Nothing Then
                str = "None"
            Else
                str = selectedValue.Value.ToString()
            End If

            m_EventsLog.LogEvent("Selected border: " & str)
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog
        Private m_BorderSplitButton As NBorderSplitButton

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBorderSplitButtonExample.
        ''' </summary>
        Public Shared ReadOnly NBorderSplitButtonExampleSchema As NSchema

#End Region
    End Class
End Namespace
