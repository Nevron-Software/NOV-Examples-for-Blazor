Imports System
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NTableFlowPanelExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTableFlowPanelExampleSchema = NSchema.Create(GetType(NTableFlowPanelExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_TablePanel = New NTableFlowPanel()
            m_TablePanel.SetBorder(1, NColor.Red)

            For i = 1 To 16
                m_TablePanel.Add(New NButton("Button " & i.ToString()))
            Next

            Return m_TablePanel
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim editors = NDesigner.GetDesigner(m_TablePanel).CreatePropertyEditors(m_TablePanel, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NTableFlowPanel.DirectionProperty, NTableFlowPanel.VerticalSpacingProperty, NTableFlowPanel.HorizontalSpacingProperty, NTableFlowPanel.MaxOrdinalProperty, NTableFlowPanel.RowFillModeProperty, NTableFlowPanel.RowFitModeProperty, NTableFlowPanel.ColFillModeProperty, NTableFlowPanel.ColFitModeProperty, NTableFlowPanel.InvertedProperty, NTableFlowPanel.UniformWidthsProperty, NTableFlowPanel.UniformHeightsProperty)

            Dim propertiesStack As NStackPanel = New NStackPanel()
            For i = 0 To editors.Count - 1
                propertiesStack.Add(editors(i))
            Next

            stack.Add(New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack)))

            ' items stack
            Dim itemsStack As NStackPanel = New NStackPanel()

            Dim addSmallItemButton As NButton = New NButton("Add Small Item")
            addSmallItemButton.Click += New [Function](Of NEventArgs)(AddressOf OnAddSmallItemButtonClick)
            itemsStack.Add(addSmallItemButton)

            Dim addLargeItemButton As NButton = New NButton("Add Large Item")
            addLargeItemButton.Click += New [Function](Of NEventArgs)(AddressOf OnAddLargeItemButtonClick)
            itemsStack.Add(addLargeItemButton)

            Dim addRandomItemButton As NButton = New NButton("Add Random Item")
            addRandomItemButton.Click += New [Function](Of NEventArgs)(AddressOf OnAddRandomItemButtonClick)
            itemsStack.Add(addRandomItemButton)

            Dim removeAllItemsButton As NButton = New NButton("Remove All Items")
            removeAllItemsButton.Click += New [Function](Of NEventArgs)(AddressOf OnRemoveAllItemsButtonClick)
            itemsStack.Add(removeAllItemsButton)

            stack.Add(New NGroupBox("Items", itemsStack))

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a table flow layout panel and add
	widgets to it. You can control the parameters of the layout algorithm
	using the controls to the right.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnAddSmallItemButtonClick(args As NEventArgs)
            Dim item As NButton = New NButton("Small." & m_TablePanel.Count.ToString())
            item.MinSize = New NSize(5, 5)
            item.PreferredSize = New NSize(25, 25)
            m_TablePanel.Add(item)
        End Sub
        Private Sub OnAddLargeItemButtonClick(args As NEventArgs)
            Dim item As NButton = New NButton("Large." & m_TablePanel.Count.ToString())
            item.MinSize = New NSize(20, 20)
            item.PreferredSize = New NSize(60, 60)
            m_TablePanel.Add(item)
        End Sub
        Private Sub OnAddRandomItemButtonClick(args As NEventArgs)
            Dim range = 30
            Dim rnd As Random = New Random()
            Dim item As NButton = New NButton("Random." & m_TablePanel.Count.ToString())
            item.MinSize = New NSize(rnd.Next(range), rnd.Next(range))
            item.PreferredSize = New NSize(rnd.Next(range) + range, rnd.Next(range) + range)
            m_TablePanel.Add(item)
        End Sub
        Private Sub OnRemoveAllItemsButtonClick(args As NEventArgs)
            m_TablePanel.Clear()
        End Sub

#End Region

#Region "Fields"

        Private m_TablePanel As NTableFlowPanel

#End Region

#Region "Schema"

        Public Shared ReadOnly NTableFlowPanelExampleSchema As NSchema

#End Region
    End Class
End Namespace
