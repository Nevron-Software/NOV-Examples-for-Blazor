
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically manipulate text documents, find content etc.
    ''' </summary>
    Public Class NSampleReport3Example
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NSampleReport3ExampleSchema = NSchema.Create(GetType(NSampleReport3Example), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' create the styles used in the report
            CreateHeaderStyles()

            ' Populate the rich text
            PopulateRichText()

            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()


            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to programmatically create reports as well as how to collect text elements of different type.</p>
"
        End Function

        Private Sub CreateHeaderStyles()
            m_ParStyleHeader1 = New NParagraphStyle("HeaderStyle1")
            m_ParStyleHeader2 = New NParagraphStyle("HeaderStyle2")
            m_ParStyleHeader3 = New NParagraphStyle("HeaderStyle3")

            m_ParStyleHeader1 = New NParagraphStyle("HeaderStyle1")
            m_ParStyleHeader1.InlineRule = New NInlineRule()
            m_ParStyleHeader1.InlineRule.FontSize = 18
            m_ParStyleHeader1.InlineRule.FontName = "Arial"
            m_ParStyleHeader1.InlineRule.FontStyle = ENFontStyle.Bold

            m_ParStyleHeader2 = New NParagraphStyle("HeaderStyle2")
            m_ParStyleHeader2.InlineRule = New NInlineRule()
            m_ParStyleHeader2.InlineRule.Fill = New NColorFill(NColor.Blue)
            m_ParStyleHeader2.InlineRule.FontSize = 14
            m_ParStyleHeader2.InlineRule.FontName = "Arial"
            m_ParStyleHeader2.InlineRule.FontStyle = ENFontStyle.Bold

            m_ParStyleHeader3 = New NParagraphStyle("HeaderStyle3")
            m_ParStyleHeader3.InlineRule = New NInlineRule()
            m_ParStyleHeader3.InlineRule.Fill = New NColorFill(NColor.White)
            m_ParStyleHeader3.InlineRule.FontSize = 10
            m_ParStyleHeader3.InlineRule.FontName = "Arial"
            m_ParStyleHeader3.ParagraphRule = New NParagraphRule()
            m_ParStyleHeader3.ParagraphRule.BackgroundFill = New NColorFill(NColor.Blue)
            m_ParStyleHeader3.InlineRule.FontStyle = ENFontStyle.Bold

            m_ContentStyle = New NParagraphStyle("ContentStyle")
            m_ContentStyle.InlineRule = New NInlineRule()
            m_ContentStyle.InlineRule.FontSize = 8
            m_ContentStyle.InlineRule.FontName = "Arial"
            m_ContentStyle.InlineRule.FontStyle = ENFontStyle.Regular
        End Sub

        Private Sub PopulateRichText()
            m_RichText.Content.Sections.Clear()
            m_RichText.Content.Selection.EnableTextIntegrityValidation = False

            Dim section As NSection = New NSection()
            section.PageMargins = New NMargins(10)
            m_RichText.Content.Sections.Add(section)

            ' Create the header
            Dim titlePar As NParagraph = New NParagraph("SmallCap Growth Fund")
            section.Blocks.Add(titlePar)
            m_ParStyleHeader1.Apply(titlePar)

            If True Then
                Dim headerTable As NTable = New NTable(1, 2)
                headerTable.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 100)
                section.Blocks.Add(headerTable)

                headerTable.Columns(0).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 20)
                headerTable.Columns(1).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 80)

                Dim title2 As NParagraph = New NParagraph("March 31, 2021")
                headerTable.Rows(0).Cells(0).Blocks.Clear()
                headerTable.Rows(0).Cells(0).Blocks.Add(title2)
                m_ParStyleHeader2.Apply(title2)

                Dim title3 As NParagraph = New NParagraph("Institutional Shares (BGRIX)")
                headerTable.Rows(0).Cells(1).Blocks.Clear()
                headerTable.Rows(0).Cells(1).Blocks.Add(title3)
                m_ParStyleHeader2.Apply(title3)

                headerTable.Border = NBorder.CreateFilledBorder(NColor.Gray)
            End If

            ' Create main table and start adding content to it
            Dim mainTable As NTable = New NTable(1, 3)
            section.Blocks.Add(mainTable)
            mainTable.Columns(0).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 20)
            mainTable.Columns(1).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 50)
            mainTable.Columns(2).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 30)

            ' Create content for first column
            If True Then
                mainTable.Rows(0).Cells(0).Blocks.Clear()
                CreateHeaderStory(mainTable.Rows(0).Cells(0), False, "Portfolio Managers", New String() {"Peter Hughes is SmallCap Capital’s founder, chairman, and CEO. He has 51 years of research and investment experience.", "Adrian Watkins joined SmallCap in 2009 as a research analyst and was named co-portfolio manager of SmallCap Growth Fund in 2018. He has 18 years of research experience.", "Please visit our website for details on their experience and education."})


                CreateHeaderStory(mainTable.Rows(0).Cells(0), True, "Investment Principles", New String() {"Long-term perspective allows us to think like an owner of a business", "Independent and exhaustive research is essential to understanding the long-term fundamental growth prospects of a business", "We seek open-ended growth opportunities, exceptional leadership, and sustainable competitive advantages.", "Purchase price and risk management are integral to our investment process"})
            End If

            ' Create content for second column
            If True Then
                Dim groupBlock As NGroupBlock = New NGroupBlock()

                groupBlock.Blocks.Add(New NParagraph("The Fund invests in small-sized U.S. companies with significant growth potential. Diversified."))

                Dim categoryTable As NTable = New NTable(4, 4)
                categoryTable.AllowSpacingBetweenCells = False

                ' fix the size of the table cells
                For i = 0 To 2
                    'categoryTable.Columns[i].PreferredWidth = new NMultiLength(ENMultiLengthUnit.Dip, 40);
                    'categoryTable.Rows[i + 1].PreferredHeight = new NMultiLength(ENMultiLengthUnit.Dip, 40);
                Next

                For i = 0 To 3
                    For j = 0 To 3
                        categoryTable.Rows(i).Cells(j).Border = NBorder.CreateFilledBorder(NColor.Black)
                        categoryTable.Rows(i).Cells(j).BorderThickness = New NMargins(1)
                    Next
                Next

                categoryTable.Rows(0).Cells(0).Blocks.Clear()
                categoryTable.Rows(0).Cells(0).Blocks.Add(New NParagraph("Value"))
                categoryTable.Rows(0).Cells(1).Blocks.Clear()
                categoryTable.Rows(0).Cells(1).Blocks.Add(New NParagraph("Blend"))
                categoryTable.Rows(0).Cells(2).Blocks.Clear()
                categoryTable.Rows(0).Cells(2).Blocks.Add(New NParagraph("Growth"))

                categoryTable.Rows(1).Cells(3).Blocks.Clear()
                categoryTable.Rows(1).Cells(3).Blocks.Add(New NParagraph("Large"))
                categoryTable.Rows(2).Cells(3).Blocks.Clear()
                categoryTable.Rows(2).Cells(3).Blocks.Add(New NParagraph("Medium"))
                categoryTable.Rows(3).Cells(3).Blocks.Clear()
                categoryTable.Rows(3).Cells(3).Blocks.Add(New NParagraph("Small"))

                categoryTable.Rows(3).Cells(2).BackgroundFill = New NColorFill(NColor.Blue)
                groupBlock.Blocks.Add(categoryTable)

                mainTable.Rows(0).Cells(1).Blocks.Clear()
                CreateHeaderStory(mainTable.Rows(0).Cells(1), "Investment Strategy", New NBlock() {groupBlock})
            End If

            If True Then
                Dim contents = New String() {"Inception Date", "December 31, 1994", "Net Assets", "$8.64 billion", "# of Equity Securities / % of Net Assets", "53 / 100.1%", "Turnover(3 Year Average)", "1.73 %", "Active Share", "97.3 %", "Median Market Cap²", "$5.96 billion", "Weighted Average Market Cap²", "$16.63 billion", "As of FYE 9 / 30 / 2020", "Institutional Shares", "CUSIP", "068278704", "Expense Ratio", "1.04 %"}

                Dim contentTable As NTable = New NTable(0, 2)
                contentTable.Columns(0).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 70)
                contentTable.Columns(1).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 30)

                For i = 0 To contents.Length - 1 Step 2
                    Dim tableRow As NTableRow = New NTableRow()

                    tableRow.Cells.Add(New NTableCell(contents(i)))
                    tableRow.Cells.Add(New NTableCell(contents(i + 1)))

                    contentTable.Rows.Add(tableRow)
                Next

                CreateHeaderStory(mainTable.Rows(0).Cells(1), "Portfolio Facts and Characteristics", New NBlock() {contentTable})
            End If

            If True Then
                Dim table As NTable = New NTable(1, 2)

                Dim contents = New String() {"", "% of Net Assets", "MSCI, Inc.", "8.4", "Penn National Gaming, Inc.", "7.6", "Vail Resorts, Inc.", "6.7", "CoStar Group, Inc.", "5.7", "ANSYS, Inc.", "5.0", "IDEXX Laboratories, Inc.", "4.6", "FactSet Research Systems, Inc.", "4.3", "Iridium Communications Inc.", "4.1", "Arch Capital Group Ltd.", "4.1", "Bio-Techne Corporation", "3.8", "Total", "54.3"}

                Dim contentTable As NTable = New NTable(0, 2)
                contentTable.Columns(0).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 70)
                contentTable.Columns(1).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 30)

                For i = 0 To contents.Length - 1 Step 2
                    Dim tableRow As NTableRow = New NTableRow()

                    tableRow.Cells.Add(New NTableCell(contents(i)))
                    tableRow.Cells.Add(New NTableCell(contents(i + 1)))

                    contentTable.Rows.Add(tableRow)
                Next

                CreateHeaderStory(mainTable.Rows(0).Cells(1), "Top 10 Holdings", New NBlock() {contentTable})
            End If

            ' Create pie chart
            If True Then
                Dim labels = New String() {"Financials", "Consumer Discretionary", "Information Technology", "Health Care", "Industrials", "Real Estate", "Communication Services", "Materials", "Unclassified"}

                Dim values = New Double() {27.6, 24.2, 14.5, 13.7, 9.2, 5.6, 4.9, 0.3, 0.0}

                mainTable.Rows(0).Cells(2).Blocks.Clear()
                CreatePieChartStory(mainTable.Rows(0).Cells(2), "GICS Sector Breakdown¹", labels, values)
            End If

            ' Create bar chart
            If True Then
                Dim labels = New String() {"Financial Exchanges & Data", "Application Software", "Casinos and Gaming", "Leisure Facilities", "Hotels, Resorts & Cruise Lines", "Property & Casual Insurance", "Research & Consulting Services", "Life Sciences Tools & Services", "Health Care Equipment", "Alternative Careers"}

                Dim values = New Double() {15.4, 10.2, 8.5, 6.7, 6.3, 6.0, 5.7, 5.2, 4.6, 4.1}

                CreateBarChartStory(mainTable.Rows(0).Cells(2), "Top GICS Sub-Industry Breakdown¹", labels, values)
            End If

            If True Then
                Dim par As NParagraph = New NParagraph()

                Dim text As NTextInline = New NTextInline("Risks: ")
                text.FontStyle = ENFontStyle.Bold
                par.Inlines.Add(text)

                par.Inlines.Add(New NTextInline("Specific risks associated with investing in smaller companies include that the securities may be thinly traded and more difficult to sell during market downturns.Even though the Fund is diversified, it may establish significant positions where the Adviser has the greatest conviction. This could increase volatility of the Fund’s returns. "))

                'mainTable.Rows[0].Cells[2].Blocks.Clear();
                CreateHeaderStory(mainTable.Rows(0).Cells(2), "Portfolio Facts and Characteristics", New NBlock() {par})
            End If
        End Sub

        Private Sub CreateHeaderStory(groupBlock As NGroupBlock, title As String, content As NBlock())
            ' groupBlock.Blocks.Clear();

            Dim header As NParagraph = New NParagraph(title)
            groupBlock.Blocks.Add(header)
            m_ParStyleHeader3.Apply(header)

            For i = 0 To content.Length - 1
                groupBlock.Blocks.Add(content(i))

                Dim paragraphs = content(i).GetDescendants(NParagraph.NParagraphSchema)

                For j = 0 To paragraphs.Count - 1
                    m_ContentStyle.Apply(CType(paragraphs(j), NParagraph))
                Next
            Next
        End Sub

        Private Sub CreateHeaderStory(groupBlock As NGroupBlock, hasBullets As Boolean, title As String, paragraphContent As String())
            Dim header As NParagraph = New NParagraph(title)
            groupBlock.Blocks.Add(header)
            m_ParStyleHeader3.Apply(header)

            Dim bulletList As NBulletList = Nothing
            If hasBullets Then
                bulletList = New NBulletList(ENBulletListTemplateType.Bullet)
                m_RichText.Content.BulletLists.Add(bulletList)
            End If

            For i = 0 To paragraphContent.Length - 1
                Dim content As NParagraph = New NParagraph(paragraphContent(i))
                groupBlock.Blocks.Add(content)

                If hasBullets Then
                    content.SetBulletList(bulletList, 0)
                End If

                m_ContentStyle.Apply(content)
            Next
        End Sub

        Private Sub CreatePieChartStory(groupBlock As NGroupBlock, title As String, labels As String(), values As Double())
            Dim header As NParagraph = New NParagraph(title)
            groupBlock.Blocks.Add(header)
            m_ParStyleHeader3.Apply(header)

            Dim widgetInline As NWidgetInline = New NWidgetInline()
            Dim dummyPar As NParagraph = New NParagraph()
            groupBlock.Blocks.Add(dummyPar)
            dummyPar.Inlines.Add(widgetInline)

            Dim chartView As NChartView = New NChartView()
            chartView.BorderThickness = New NMargins(0)
            chartView.PreferredWidth = 250
            chartView.PreferredHeight = 300
            widgetInline.Content = chartView

            Dim vStack As NStackPanel = New NStackPanel()
            vStack.FillMode = Layout.ENStackFillMode.Last
            vStack.Direction = Layout.ENHVDirection.BottomToTop
            chartView.Surface.Content = vStack

            Dim legend As NLegend = New NLegend()
            vStack.Add(legend)

            Dim pieChart As NPieChart = New NPieChart()
            vStack.Add(pieChart)

            pieChart.Legend = legend

            Dim pieSeries As NPieSeries = New NPieSeries()
            pieSeries.LegendView.Mode = ENSeriesLegendMode.DataPoints
            pieSeries.LegendView.TextStyle.Font.Size = 8
            pieChart.Series.Add(pieSeries)

            For i = 0 To labels.Length - 1
                pieSeries.DataPoints.Add(New NPieDataPoint(values(i), labels(i)))
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))
        End Sub

        Private Sub CreateBarChartStory(groupBlock As NGroupBlock, title As String, labels As String(), values As Double())
            Dim header As NParagraph = New NParagraph(title)
            groupBlock.Blocks.Add(header)
            m_ParStyleHeader3.Apply(header)

            Dim widgetInline As NWidgetInline = New NWidgetInline()
            Dim dummyPar As NParagraph = New NParagraph()
            groupBlock.Blocks.Add(dummyPar)
            dummyPar.Inlines.Add(widgetInline)

            Dim chartView As NChartView = New NChartView()
            chartView.BorderThickness = New NMargins(0)
            chartView.PreferredWidth = 250
            chartView.PreferredHeight = 300
            widgetInline.Content = chartView



            Dim cartesianChart As NCartesianChart = New NCartesianChart()
            cartesianChart.LabelLayout.EnableInitialPositioning = False
            cartesianChart.LabelLayout.EnableLabelAdjustment = False
            cartesianChart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)
            cartesianChart.Margins = New NMargins(0)
            cartesianChart.Orientation = ENCartesianChartOrientation.LeftToRight

            chartView.Surface.Content = cartesianChart

            Dim xScale As NOrdinalScale = cartesianChart.Axes(ENCartesianAxis.PrimaryX).Scale
            xScale.Labels.Style.TextStyle.Font = New NFont("Aria", 6)
            xScale.Labels.TextProvider = New NOrdinalScaleLabelTextProvider(labels)

            Dim barSeries As NBarSeries = New NBarSeries()
            cartesianChart.Series.Add(barSeries)


            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            barSeries.DataLabelStyle = dataLabelStyle
            barSeries.DataLabelStyle.TextStyle.Background.Visible = False
            barSeries.DataLabelStyle.TextStyle.Font = New NFont("Arial", 7, ENFontStyle.Regular)
            barSeries.DataLabelStyle.Format = "<value>"

            For i = 0 To labels.Length - 1
                barSeries.DataPoints.Add(New NBarDataPoint(values(i)))
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))
        End Sub

#End Region

#Region "Fields"

        Private m_ParStyleHeader1 As NParagraphStyle
        Private m_ParStyleHeader2 As NParagraphStyle
        Private m_ParStyleHeader3 As NParagraphStyle
        Private m_ContentStyle As NParagraphStyle

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NSampleReport3ExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetTotal(values As Double()) As Double
            Dim total = 0.0

            For i = 0 To values.Length - 1
                total += values(i)
            Next

            Return total
        End Function
        Private Shared Function CreateHeaderText(text As String) As NTextInline
            Dim inline As NTextInline = New NTextInline(text)

            inline.FontSize = 14
            inline.FontStyle = ENFontStyle.Bold

            Return inline
        End Function
        Private Shared Function CreateNormalText(text As String) As NTextInline
            Dim inline As NTextInline = New NTextInline(text)

            inline.FontSize = 9

            Return inline
        End Function

        ''' <summary>
        ''' Creates a sample bar chart given title, values and labels
        ''' </summary>
        ''' <paramname="area"></param>
        ''' <paramname="size"></param>
        ''' <paramname="title"></param>
        ''' <paramname="values"></param>
        ''' <paramname="labels"></param>
        ''' <returns></returns>
        Private Shared Function CreateBarChart(area As Boolean, size As NSize, title As String, values As Double(), labels As String()) As NParagraph
            Dim chartView As NChartView = New NChartView()

            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            chartView.PreferredSize = size

            ' configure title
            chartView.Surface.Titles(0).Text = title
            chartView.Surface.Titles(0).Margins = NMargins.Zero
            chartView.Surface.Legends(0).Visibility = ENVisibility.Hidden
            chartView.BorderThickness = NMargins.Zero

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.Padding = New NMargins(20)

            ' configure axes
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)
            chart.Margins = NMargins.Zero

            If area Then
                Dim areaSeries As NAreaSeries = New NAreaSeries()
                areaSeries.LegendView.Mode = ENSeriesLegendMode.None
                areaSeries.DataLabelStyle = New NDataLabelStyle(False)

                chart.Series.Add(areaSeries)

                For i = 0 To values.Length - 1
                    areaSeries.DataPoints.Add(New NAreaDataPoint(values(i)))
                Next
            Else
                Dim barSeries As NBarSeries = New NBarSeries()
                barSeries.LegendView.Mode = ENSeriesLegendMode.None
                barSeries.DataLabelStyle = New NDataLabelStyle(False)

                chart.Series.Add(barSeries)

                For i = 0 To values.Length - 1
                    barSeries.DataPoints.Add(New NBarDataPoint(values(i)))
                Next
            End If

            Dim scaleX As NOrdinalScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale
            scaleX.Labels.TextProvider = New NOrdinalScaleLabelTextProvider(labels)
            scaleX.MajorTickMode = ENMajorTickMode.CustomStep
            scaleX.CustomStep = 1

            Dim paragraph As NParagraph = New NParagraph()

            Dim chartInline As NWidgetInline = New NWidgetInline()
            chartInline.Content = chartView
            paragraph.Inlines.Add(chartInline)

            Return paragraph
        End Function

#End Region
    End Class
End Namespace
