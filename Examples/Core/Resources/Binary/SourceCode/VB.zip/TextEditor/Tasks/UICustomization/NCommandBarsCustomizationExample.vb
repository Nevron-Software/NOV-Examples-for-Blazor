Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.Commands
Imports Nevron.Nov.Text.UI
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NCommandBarsCustomizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCommandBarsCustomizationExampleSchema = NSchema.Create(GetType(NCommandBarsCustomizationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_RichText = New NRichTextView()
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            ' Add the custom command action to the rich text view's commander
            m_RichText.Commander.Add(New CustomCommandAction())

            ' Remove the "Edit" menu and insert a custom one
            m_CommandBarBuilder = New NRichTextCommandBarBuilder()
            m_CommandBarBuilder.MenuDropDownBuilders.Remove(NLoc.Get("Edit"))
            m_CommandBarBuilder.MenuDropDownBuilders.Insert(1, New CustomMenuBuilder())

            ' Remove the "Standard" toolbar and insert a custom one
            m_CommandBarBuilder.ToolBarBuilders.Remove(NLoc.Get("Standard"))
            m_CommandBarBuilder.ToolBarBuilders.Insert(0, New CustomToolBarBuilder())

            ' Create the command bars UI
            Return m_CommandBarBuilder.CreateUI(m_RichText)
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to customize the NOV rich text command bars (menus and toolbars).</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            section.Blocks.Add(GetDescriptionBlock("Ribbon Customization", "This example demonstrates how to customize the NOV rich text command bars (menus and toolbars).", 1))
        End Sub

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCommandBarsCustomizationExample.
        ''' </summary>
        Public Shared ReadOnly NCommandBarsCustomizationExampleSchema As NSchema

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView
        Private m_CommandBarBuilder As NRichTextCommandBarBuilder

#End Region

#Region "Constants"

        Public Shared ReadOnly CustomCommand As NCommand = NCommand.Create(GetType(NCommandBarsCustomizationExample), "CustomCommand", "Custom Command")

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(text As String) As NParagraph
            Return New NParagraph(text)
        End Function
        Private Shared Function GetTitleParagraphNoBorder(text As String, level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()

            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle

            Dim textInline As NTextInline = New NTextInline(text)

            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize

            paragraph.Inlines.Add(textInline)

            Return paragraph

        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Shared Function GetTitleParagraph(text As String, level As Integer) As NParagraph
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(text, level)
            paragraph.HorizontalAlignment = ENAlign.Left

            paragraph.Border = CreateLeftTagBorder(color)
            paragraph.BorderThickness = defaultBorderThickness

            Return paragraph
        End Function
        Private Shared Function GetNoteBlock(text As String, level As Integer) As NGroupBlock
            Dim color = NColor.Red
            Dim paragraph = GetTitleParagraphNoBorder("Note", level)

            Dim groupBlock As NGroupBlock = New NGroupBlock()

            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(text))

            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness

            Return groupBlock
        End Function
        Private Shared Function GetDescriptionBlock(title As String, description As String, level As Integer) As NGroupBlock
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(title, level)

            Dim groupBlock As NGroupBlock = New NGroupBlock()

            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))

            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness

            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(color As NColor) As NBorder
            Dim border As NBorder = New NBorder()

            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)

            Return border
        End Function
        Private Shared Function GetLoremIpsumParagraph() As NParagraph
            Return New NParagraph("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum placerat in tortor nec tincidunt. Sed sagittis in sem ac auctor. Donec scelerisque molestie eros, a dictum leo fringilla eu. Vivamus porta urna non ullamcorper commodo. Nulla posuere sodales pellentesque. Donec a erat et tortor viverra euismod non et erat. Donec dictum ante eu mauris porta, eget suscipit mi ultrices. Nunc convallis adipiscing ligula, non pharetra dolor egestas at. Etiam in condimentum sapien. Praesent sagittis pulvinar metus, a posuere mauris aliquam eget.")
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region

#Region "Nested Types"

        Public Class CustomMenuBuilder
            Inherits NMenuDropDownBuilder
            Public Sub New()
                MyBase.New("Custom Menu")
            End Sub

            Protected Overrides Sub AddItems(items As NMenuItemCollection)
                ' Add the "Copy" menu item
                items.Add(CreateMenuItem(Presentation.NResources.Image_Edit_Copy_png, NRichTextView.CopyCommand))

                ' Add the custom command menu item
                items.Add(CreateMenuItem(NResources.Image_Ribbon_16x16_smiley_png, CustomCommand))
            End Sub
        End Class

        Public Class CustomToolBarBuilder
            Inherits NToolBarBuilder
            Public Sub New()
                MyBase.New("Custom Toolbar")
            End Sub

            Protected Overrides Sub AddItems(items As NCommandBarItemCollection)
                ' Add the "Copy" button
                items.Add(MyBase.CreateButton(Presentation.NResources.Image_Edit_Copy_png, NRichTextView.CopyCommand))

                ' Add the custom command button
                items.Add(CreateButton(NResources.Image_Ribbon_16x16_smiley_png, CustomCommand))
            End Sub
        End Class

        Public Class CustomCommandAction
            Inherits NTextCommandAction
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomCommandActionSchema = NSchema.Create(GetType(CustomCommandAction), NTextCommandActionSchema)
            End Sub

#End Region

#Region "Public Overrides"

            ''' <summary>
            ''' Gets the command associated with this command action.
            ''' </summary>
            ''' <returns></returns>
            Public Overrides Function GetCommand() As NCommand
                Return CustomCommand
            End Function
            ''' <summary>
            ''' Executes the command action.
            ''' </summary>
            ''' <paramname="target"></param>
            ''' <paramname="parameter"></param>
            Public Overrides Sub Execute(target As NNode, parameter As Object)
                Dim richTextView = GetRichTextView(target)

                NMessageBox.Show("Rich Text Custom Command executed!", "Custom Command", ENMessageBoxButtons.OK, ENMessageBoxIcon.Information)
            End Sub

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomCommandAction.
            ''' </summary>
            Public Shared ReadOnly CustomCommandActionSchema As NSchema

#End Region
        End Class

#End Region
    End Class
End Namespace
