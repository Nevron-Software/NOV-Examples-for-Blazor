Imports Nevron.Nov.Dom
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to create a simple "Notepad" like editor.
    ''' </summary>
    Public Class NNotepadEditorExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NNotepadEditorExampleSchema = NSchema.Create(GetType(NNotepadEditorExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            m_RichText = New NRichTextView()
            m_RichText.AcceptsTab = True

            ' make sure line breaks behave like a normal text box
            m_RichText.ViewSettings.ExtendLineBreakWithSpaces = False
            m_RichText.Content.Sections.Clear()

            ' set the content to web and allow only text copy paste
            m_RichText.Content.Layout = ENTextLayout.Web
            ' m_RichText.Content.Selection.ClipboardTextFormats = new NClipboardTextFormat[] { NTextClipboardTextFormat.Instance };

            ' add some content
            Dim section As NSection = New NSection()

            For i = 0 To 9
                Dim text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumstring."
                section.Blocks.Add(New NParagraph(text))
            Next

            m_RichText.Content.Sections.Add(section)

            m_RichText.HRuler.Visibility = ENVisibility.Visible
            m_RichText.VRuler.Visibility = ENVisibility.Visible

            Return m_RichText
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_WordWrapCheckBox = New NCheckBox("Word Wrap")
            Me.m_WordWrapCheckBox.CheckedChanged += AddressOf OnWordWrapCheckBoxCheckedChanged
            stack.Add(m_WordWrapCheckBox)
            m_WordWrapCheckBox.Checked = False

            OnWordWrapCheckBoxCheckedChanged(Nothing)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to create a simple ""Notepad"" like editor.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnWordWrapCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_RichText.Content.WrapMinWidth = m_WordWrapCheckBox.Checked
            m_RichText.Content.WrapDesiredWidth = m_WordWrapCheckBox.Checked
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView
        Private m_WordWrapCheckBox As NCheckBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NNotepadEditorExampleSchema As NSchema

#End Region
    End Class
End Namespace
