Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to apply css like styles to the text document
    ''' </summary>
    Public Class NCssStylingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NCssStylingExampleSchema = NSchema.Create(GetType(NCssStylingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            m_RichTextWithRibbon = New NRichTextViewWithRibbon()
            m_RichTextWithRibbon.View.Content.Sections.Clear()

            ' set the content to web and allow only text copy paste
            m_RichTextWithRibbon.View.Content.Layout = ENTextLayout.Web

            ' add some content
            Dim section As NSection = New NSection()

            For i = 0 To 1
                Dim text = "Paragraph block contained in a section block. The paragraph will appear with a red background."
                section.Blocks.Add(New NParagraph(text))
            Next

            Dim groupBlock As NGroupBlock = New NGroupBlock()
            section.Blocks.Add(groupBlock)

            For i = 0 To 1
                Dim text = "Paragraph block contained in a group block. This paragraph will appear with a green background, italic font style, and altered font size and indentation."
                groupBlock.Blocks.Add(New NParagraph(text))
            Next

            Dim table As NTable = New NTable(2, 2)
            table.Border = NBorder.CreateFilledBorder(NColor.Black)
            table.BorderThickness = New NMargins(2, 2, 2, 2)
            table.AllowSpacingBetweenCells = False
            section.Blocks.Add(table)

            For rowIndex = 0 To table.Rows.Count - 1
                For colIndex = 0 To table.Columns.Count - 1
                    Dim text = "Paragraph block contained in a table cell. This paragraph with appear in blue."
                    table.Rows(rowIndex).Cells(colIndex).Blocks.Add(New NParagraph(text))
                Next
            Next

            m_RichTextWithRibbon.View.Content.Sections.Add(section)

            ' create a CSS style sheet that applies different background and font depending on the parent of the paragraph
            Dim sheet As NStyleSheet = New NStyleSheet()
            m_RichTextWithRibbon.View.Document.StyleSheets.Add(sheet)

            ' for all paragraphs that are directly contained in a section
            If True Then
                Dim rule1 As NRule = New NRule()
                rule1.Declarations.Add(New NValueDeclaration(Of NFill)("BackgroundFill", New NColorFill(NColor.LightCoral)))
                sheet.Add(rule1)

                Dim selector1 As NSelector = New NSelector()
                rule1.Selectors.Add(selector1)

                ' select all paragraph
                selector1.Conditions.Add(New NTypeCondition(NParagraph.NParagraphSchema))

                ' that are children of range collection
                Dim childOfBlockCollection As NChildCombinator = New NChildCombinator()
                selector1.Combinators.Add(childOfBlockCollection)

                ' that are direct descendants of section
                Dim childOfSection As NChildCombinator = New NChildCombinator()
                childOfSection.Conditions.Add(New NTypeCondition(NSection.NSectionSchema))
                selector1.Combinators.Add(childOfSection)
            End If

            ' then add a rule for blocks contained inside a group block
            If True Then
                If True Then
                    Dim rule2 As NRule = New NRule()
                    rule2.Declarations.Add(New NValueDeclaration(Of NFill)("BackgroundFill", New NColorFill(NColor.LightGreen)))
                    rule2.Declarations.Add(New NValueDeclaration(Of Double)("FontSize", 12.0R))
                    rule2.Declarations.Add(New NValueDeclaration(Of Double)("FirstLineIndent", 10.0R))
                    rule2.Declarations.Add(New NValueDeclaration(Of Boolean)("FontStyleItalic", True))
                    sheet.Add(rule2)

                    Dim builder As NSelectorBuilder = New NSelectorBuilder(rule2)

                    builder.Start()

                    builder.Type(NParagraph.NParagraphSchema)
                    builder.ChildOf()
                    builder.ChildOf()
                    builder.Type(NGroupBlock.NGroupBlockSchema)
                    builder.ChildOf()
                    builder.ChildOf()
                    builder.Type(NSection.NSectionSchema)

                    builder.End()
                End If


                If True Then
                    Dim rule3 As NRule = New NRule()
                    rule3.Declarations.Add(New NValueDeclaration(Of NFill)("BackgroundFill", New NColorFill(NColor.LightBlue)))
                    sheet.Add(rule3)


                    Dim builder As NSelectorBuilder = New NSelectorBuilder(rule3)

                    builder.Start()

                    builder.Type(NParagraph.NParagraphSchema)
                    builder.ChildOf()
                    builder.ChildOf()
                    builder.Type(NGroupBlock.NGroupBlockSchema)
                    builder.ChildOf()
                    builder.ChildOf()
                    builder.Type(NTableRow.NTableRowSchema)

                    builder.End()
                End If
            End If


            Return m_RichTextWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()


            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to apply css like styles to the text document.</p>"
        End Function

#End Region

#Region "Event Handlers"

#End Region

#Region "Fields"

        Private m_RichTextWithRibbon As NRichTextViewWithRibbon

#End Region

#Region "Schema"

        Public Shared ReadOnly NCssStylingExampleSchema As NSchema

#End Region
    End Class
End Namespace
