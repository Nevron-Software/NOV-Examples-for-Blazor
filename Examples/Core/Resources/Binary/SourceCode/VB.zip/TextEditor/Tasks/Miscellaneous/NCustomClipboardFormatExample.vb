Imports System.IO
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Serialization
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.Formats
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to create a custom clipboard format that allows the user to selectively copy/paste text, images or both.
    ''' </summary>
    Public Class NCustomClipboardFormatExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NCustomClipboardFormatExampleSchema = NSchema.Create(GetType(NCustomClipboardFormatExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            m_RichText = New NRichTextView()
            m_RichText.AcceptsTab = True

            m_RichText.Content.Sections.Clear()
            m_RichText.Selection.ClipboardTextFormats.Add(New NCustomClipboardFormat(Me))

            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            section.Blocks.Add(New NParagraph("The example demonstrates how to implement a custom clipboard format."))
            section.Blocks.Add(New NParagraph("This example demonstrates a scenario where the user can selectively copy/paste just text or images."))

            For i = 0 To 2
                Dim paragraph As NParagraph = New NParagraph("This paragraph contains text and")
                section.Blocks.Add(paragraph)

                paragraph.Inlines.Add(New NLineBreakInline())

                Dim imageInline As NImageInline = New NImageInline()
                imageInline.Image = NResources.Image_Artistic_FishBowl_jpg
                imageInline.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Dip, 250)
                imageInline.PreferredHeight = New NMultiLength(ENMultiLengthUnit.Dip, 200)
                paragraph.Inlines.Add(imageInline)

                paragraph.Inlines.Add(New NLineBreakInline())

                paragraph.Inlines.Add(New NTextInline("image inline content."))
            Next

            Return m_RichText
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_ContentTypeComboBox = New NComboBox()
            m_ContentTypeComboBox.Items.Add(New NComboBoxItem("Text"))
            m_ContentTypeComboBox.Items.Add(New NComboBoxItem("Image"))
            m_ContentTypeComboBox.Items.Add(New NComboBoxItem("Text and Image"))
            m_ContentTypeComboBox.SelectedIndex = 0

            stack.Add(NPairBox.Create("Custom Clipboard Content: ", m_ContentTypeComboBox))

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates a scenario where the user can selectively copy/paste text, images, or both. The purpose of the example is to demonstrate how to implement a custom clipboard format.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView
        Private m_ContentTypeComboBox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NCustomClipboardFormatExampleSchema As NSchema

#End Region

#Region "Nested Types"

        ''' <summary>
        ''' Represents a custom clipboard format.
        ''' </summary>
        Public Class NCustomClipboardFormat
            Inherits NClipboardTextFormat
#Region "Constructors"

            ''' <summary>
            ''' Initializer constructor
            ''' </summary>
            ''' <paramname="example"></param>
            Public Sub New(example As NCustomClipboardFormatExample)
                m_Example = example
            End Sub
            ''' <summary>
            ''' Static constructor
            ''' </summary>
            Shared Sub New()
                ' create the Data Format associated with MyFirstDataEchangeObject
                s_DataFormat = NDataFormat.Create("CustomClipboardFormat", New FunctionResult(Of Byte(), NDataFormat, Object)(AddressOf SerializeDataObject), New FunctionResult(Of Object, NDataFormat, Byte())(AddressOf DeserializeDataObject))
            End Sub

#End Region

#Region "Public Overrides"

            ''' <summary>
            ''' Imports a document from a data object
            ''' </summary>
            ''' <paramname="obj"></param>
            ''' <returns></returns>
            Public Overrides Function FromDataObject(obj As Object) As NRichTextDocument
                Return obj
            End Function
            ''' <summary>
            ''' Exports the specified document to the specified data object
            ''' </summary>
            ''' <paramname="document"></param>
            ''' <paramname="dataObject"></param>
            ''' <returns></returns>
            Public Overrides Sub ToDataObject(document As NRichTextDocument, dataObject As NDataObject)
                ' create a clone of the document so that we can modify it
                document = CType(document.DeepClone(), NRichTextDocument)

                ' TODO Implement your own document filtering
                Select Case m_Example.m_ContentTypeComboBox.SelectedIndex
                    Case 0 ' text
                        ' remove all images from the document
                        Dim inlines = document.GetDescendants(NImageInline.NImageInlineSchema)

                        For i = 0 To inlines.Count - 1
                            Dim imageInline = CType(inlines(i), NImageInline)

                            Dim par = CType(imageInline.ParentBlock, NParagraph)

                            par.Inlines.Remove(imageInline)
                        Next
                    Case 1 ' image
                        ' remove all text inlines from the document
                        Dim inlines = document.GetDescendants(NTextInline.NTextInlineSchema)

                        For i = 0 To inlines.Count - 1
                            Dim textInline = CType(inlines(i), NTextInline)

                            Dim par = CType(textInline.ParentBlock, NParagraph)

                            par.Inlines.Remove(textInline)
                        Next
                                            ' do nothing
                    Case 2 ' image and text
                End Select

                dataObject.SetData(s_DataFormat, document)
            End Sub
            ''' <summary>
            ''' The underling text format
            ''' </summary>
            Public Overrides ReadOnly Property TextFormat As NTextFormat
                Get
                    Return Nothing
                End Get
            End Property
            ''' <summary>
            ''' The underling text format
            ''' </summary>
            Public Overrides ReadOnly Property DataFormat As NDataFormat
                Get
                    Return s_DataFormat
                End Get
            End Property

#End Region

#Region "DataFormat Implementation"

            ''' <summary>
            ''' Serialization function for the data format
            ''' </summary>
            ''' <paramname="format"></param>
            ''' <paramname="obj"></param>
            ''' <returns></returns>
            Private Shared Function SerializeDataObject(format As NDataFormat, obj As Object) As Byte()
                Dim document As NRichTextDocument = obj
                Dim stream As MemoryStream = New MemoryStream(10240)

                Dim serializer As NDomNodeSerializer = New NDomNodeSerializer()

                serializer.SaveToStream(New NNode() {document}, stream, ENPersistencyFormat.Xml)

                Return stream.ToArray()
            End Function
            ''' <summary>
            ''' Deserialization function for the custom data format
            ''' </summary>
            ''' <paramname="format"></param>
            ''' <paramname="bytes"></param>
            ''' <returns></returns>
            Private Shared Function DeserializeDataObject(format As NDataFormat, bytes As Byte()) As Object
                Dim stream As MemoryStream = New MemoryStream(bytes)

                Dim serializer As NDomNodeDeserializer = New NDomNodeDeserializer()
                Dim myObject = CType(serializer.LoadFromStream(stream, ENPersistencyFormat.Xml)(0), NRichTextDocument)
                Return myObject
            End Function

#End Region

#Region "Fields"

            Private m_Example As NCustomClipboardFormatExample

#End Region

#Region "Static Fields"

            Friend Shared s_DataFormat As NDataFormat

#End Region
        End Class

#End Region
    End Class
End Namespace
