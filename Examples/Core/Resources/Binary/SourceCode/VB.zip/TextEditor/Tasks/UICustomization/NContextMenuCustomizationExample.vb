Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.Commands
Imports Nevron.Nov.Text.UI
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NContextMenuCustomizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NContextMenuCustomizationExampleSchema = NSchema.Create(GetType(NContextMenuCustomizationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            ' Add the custom command action to the rich text view's commander
            m_RichText.Commander.Add(New CustomCommandAction())

            ' Get the context menu builder
            Dim builder = m_RichText.ContextMenuBuilder

            ' Remove the common menu group, which contains commands such as Cut, Copy, Paste, etc.
            builder.Groups.RemoveByName(NRichTextMenuGroup.Common)

            ' Add the custom context menu group
            builder.Groups.Add(New CustomMenuGroup())

            Return richTextWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to customize the NOV rich text context menu. The common menu group,
which contains command such as Cut, Copy, Paste, etc. is removed and a custom menu group which contains
only the Copy command and a custom command is added to the context menu builder of the rich text view's
selection.</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            section.Blocks.Add(GetDescriptionBlock("Context Menu Customization", "The example demonstrates how to customize the NOV rich text context menu.", 1))
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NContextMenuCustomizationExample.
        ''' </summary>
        Public Shared ReadOnly NContextMenuCustomizationExampleSchema As NSchema

#End Region

#Region "Constants"

        Public Shared ReadOnly CustomCommand As NCommand = NCommand.Create(GetType(NContextMenuCustomizationExample), "CustomCommand", "Custom Command")

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(text As String) As NParagraph
            Return New NParagraph(text)
        End Function
        Private Shared Function GetTitleParagraphNoBorder(text As String, level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()

            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle

            Dim textInline As NTextInline = New NTextInline(text)

            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize

            paragraph.Inlines.Add(textInline)

            Return paragraph

        End Function
        Private Shared Function GetDescriptionBlock(title As String, description As String, level As Integer) As NGroupBlock
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(title, level)

            Dim groupBlock As NGroupBlock = New NGroupBlock()

            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))

            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness

            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(color As NColor) As NBorder
            Dim border As NBorder = New NBorder()

            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)

            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region

#Region "Nested Types"

        ''' <summary>
        ''' A custom menu group, which applies to every text element and adds only a Copy menu item
        ''' and a custom command menu item.
        ''' </summary>
        Public Class CustomMenuGroup
            Inherits NRichTextMenuGroup
            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
                MyBase.New("Custom")
            End Sub

            ''' <summary>
            ''' Gets whether this context menu group should be shown for the given
            ''' text element. Overriden to return true for every text element.
            ''' </summary>
            ''' <paramname="textElement"></param>
            ''' <returns></returns>
            Public Overrides Function AppliesTo(textElement As NTextElement) As Boolean
                Return True
            End Function
            ''' <summary>
            ''' Appends the context menu action items from this group to the given menu.
            ''' </summary>
            ''' <paramname="menu">The menu to append to.</param>
            ''' <paramname="textElement">The text element this menu is built for.</param>
            Public Overrides Sub AppendActionsTo(menu As NMenu, textElement As NTextElement)
                ' Add the "Copy" command
                menu.Items.Add(CreateMenuItem(Presentation.NResources.Image_Edit_Copy_png, NRichTextView.CopyCommand))

                ' Add the custom command
                menu.Items.Add(CreateMenuItem(NResources.Image_Ribbon_16x16_smiley_png, CustomCommand))
            End Sub
        End Class

        Public Class CustomCommandAction
            Inherits NTextCommandAction
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomCommandActionSchema = NSchema.Create(GetType(CustomCommandAction), NTextCommandActionSchema)
            End Sub

#End Region

#Region "Public Overrides"

            ''' <summary>
            ''' Gets the command associated with this command action.
            ''' </summary>
            ''' <returns></returns>
            Public Overrides Function GetCommand() As NCommand
                Return CustomCommand
            End Function
            ''' <summary>
            ''' Executes the command action.
            ''' </summary>
            ''' <paramname="target"></param>
            ''' <paramname="parameter"></param>
            Public Overrides Sub Execute(target As NNode, parameter As Object)
                Dim richTextView = GetRichTextView(target)

                NMessageBox.Show("Rich Text Custom Command executed!", "Custom Command", ENMessageBoxButtons.OK, ENMessageBoxIcon.Information)
            End Sub

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomCommandAction.
            ''' </summary>
            Public Shared ReadOnly CustomCommandActionSchema As NSchema

#End Region
        End Class

#End Region
    End Class
End Namespace
