Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt inline formatting
    ''' </summary>
    Public Class NSelectionExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NSelectionExampleSchema = NSchema.Create(GetType(NSelectionExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            Return richTextWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim groupsStack As NStackPanel = New NStackPanel()

            ' caret navigation
            If True Then
                Dim groupBox As NGroupBox = New NGroupBox("Caret Navigation")
                groupsStack.Add(groupBox)

                Dim stack As NStackPanel = New NStackPanel()
                groupBox.Content = stack

                Dim moveToNextWordButton As NButton = New NButton("Move Caret to Next Word")
                moveToNextWordButton.Click += New [Function](Of NEventArgs)(AddressOf OnMoveToNextWordButtonClick)
                stack.Add(moveToNextWordButton)

                Dim moveToPrevWordButton As NButton = New NButton("Move Caret to Prev Word")
                moveToPrevWordButton.Click += New [Function](Of NEventArgs)(AddressOf OnMoveToPrevWordButtonClick)
                stack.Add(moveToPrevWordButton)
            End If

            If True Then
                Dim groupBox As NGroupBox = New NGroupBox("Range Selection")
                groupsStack.Add(groupBox)

                Dim stack As NStackPanel = New NStackPanel()
                groupBox.Content = stack

                Dim selectCurrentParagraphButton As NButton = New NButton("Select Current Paragraph")
                selectCurrentParagraphButton.Click += New [Function](Of NEventArgs)(AddressOf OnSelectCurrentParagraphButtonClick)
                stack.Add(selectCurrentParagraphButton)

                Dim deleteSelectedTextButton As NButton = New NButton("Delete Selected Text")
                deleteSelectedTextButton.Click += New [Function](Of NEventArgs)(AddressOf OnDeleteSelectedTextButtonClick)
                stack.Add(deleteSelectedTextButton)
            End If

            If True Then
                Dim groupBox As NGroupBox = New NGroupBox("Copy / Paste")
                groupsStack.Add(groupBox)

                Dim pasteOptionsStack As NStackPanel = New NStackPanel()
                groupBox.Content = pasteOptionsStack

                If True Then
                    Dim copyButton As NButton = New NButton("Copy")
                    copyButton.Click += New [Function](Of NEventArgs)(AddressOf OnCopyButtonClick)
                    pasteOptionsStack.Add(copyButton)

                    Dim pasteButton As NButton = New NButton("Paste")
                    pasteButton.Click += New [Function](Of NEventArgs)(AddressOf OnPasteButtonClick)
                    pasteOptionsStack.Add(pasteButton)

                    Dim allowImagesCheckBox As NCheckBox = New NCheckBox("Allow Images")
                    allowImagesCheckBox.CheckedChanged += AddressOf OnAllowImagesCheckBoxCheckedChanged
                    allowImagesCheckBox.Checked = True
                    pasteOptionsStack.Add(allowImagesCheckBox)

                    Dim allowTablesCheckBox As NCheckBox = New NCheckBox("Allow Tables")
                    allowTablesCheckBox.CheckedChanged += AddressOf OnAllowTablesCheckBoxCheckedChanged
                    allowTablesCheckBox.Checked = True
                    pasteOptionsStack.Add(allowTablesCheckBox)

                    Dim allowSectionsCheckBox As NCheckBox = New NCheckBox("Allow Sections")
                    allowSectionsCheckBox.CheckedChanged += AddressOf OnAllowSectionsCheckBoxCheckedChanged
                    allowSectionsCheckBox.Checked = True
                    pasteOptionsStack.Add(allowSectionsCheckBox)
                End If
            End If

            If True Then
                Dim groupBox As NGroupBox = New NGroupBox("Inline Formatting")
                groupsStack.Add(groupBox)

                Dim stack As NStackPanel = New NStackPanel()
                groupBox.Content = stack

                Dim setBoldStyleButton As NButton = New NButton("Set Bold Style")
                setBoldStyleButton.Click += New [Function](Of NEventArgs)(AddressOf OnSetBoldStyleButtonClick)
                stack.Add(setBoldStyleButton)

                Dim setItalicStyleButton As NButton = New NButton("Set Italic Style")
                setItalicStyleButton.Click += New [Function](Of NEventArgs)(AddressOf OnSetItalicStyleButtonClick)
                stack.Add(setItalicStyleButton)

                Dim clearStyleButton As NButton = New NButton("Clear Style")
                clearStyleButton.Click += New [Function](Of NEventArgs)(AddressOf OnClearStyleButtonClick)
                stack.Add(clearStyleButton)
            End If

            Return groupsStack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to use the selection object in order to select text as well as how to modify selected text appearance</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            section.Blocks.Add(GetDescriptionBlock("Working With the Selection Object", "The example demonstrates how to work with the selection object.", 1))

            For i = 0 To 9
                section.Blocks.Add(New NParagraph("Now it so happened that on one occasion the princess's golden ball did not fall into the little hand which she was holding up for it, but on to the ground beyond, and rolled straight into the water.  The king's daughter followed it with her eyes, but it vanished, and the well was deep, so deep that the bottom could not be seen.  At this she began to cry, and cried louder and louder, and could not be comforted.  And as she thus lamented someone said to her, ""What ails you, king's daughter?  You weep so that even a stone would show pity."""))
            Next
        End Sub

#End Region

#Region "Event Handlers"


        Private Sub OnClearStyleButtonClick(arg As NEventArgs)
            m_RichText.Selection.ClearFontStyleFromSelectedInlines(ENFontStyle.Bold Or ENFontStyle.Italic Or ENFontStyle.Strikethrough Or ENFontStyle.Underline)
            m_RichText.Focus()
        End Sub

        Private Sub OnSetItalicStyleButtonClick(arg As NEventArgs)
            m_RichText.Selection.AddFontStyleToSelectedInlines(ENFontStyle.Italic)
            m_RichText.Focus()
        End Sub

        Private Sub OnSetBoldStyleButtonClick(arg As NEventArgs)
            m_RichText.Selection.AddFontStyleToSelectedInlines(ENFontStyle.Bold)
            m_RichText.Focus()
        End Sub

        Private Sub OnPasteButtonClick(arg As NEventArgs)
            m_RichText.Selection.Paste()
            m_RichText.Focus()
        End Sub

        Private Sub OnCopyButtonClick(arg As NEventArgs)
            m_RichText.Selection.SelectAll()
            m_RichText.Selection.Copy()
            m_RichText.Focus()
        End Sub

        Private Sub OnDeleteSelectedTextButtonClick(arg As NEventArgs)
            m_RichText.Selection.Delete()
            m_RichText.Focus()
        End Sub

        Private Sub OnAllowTablesCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_RichText.Selection.PasteOptions.AllowTables = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnAllowSectionsCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_RichText.Selection.PasteOptions.AllowSections = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnAllowImagesCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_RichText.Selection.PasteOptions.AllowImages = CType(arg.TargetNode, NCheckBox).Checked
        End Sub


        Private Sub OnSelectCurrentParagraphButtonClick(arg As NEventArgs)
            Dim inline = m_RichText.Selection.CaretInline

            If inline Is Nothing Then Return

            Dim currentParagraph As NParagraph = TryCast(inline.ParentBlock, NParagraph)

            If currentParagraph IsNot Nothing Then
                m_RichText.Selection.SelectRange(currentParagraph.Range)
            End If
        End Sub

        Private Sub OnMoveToNextWordButtonClick(arg As NEventArgs)
            m_RichText.Selection.MoveCaret(ENCaretMoveDirection.NextWord, False)
            m_RichText.Focus()
        End Sub

        Private Sub OnMoveToPrevWordButtonClick(arg As NEventArgs)
            m_RichText.Selection.MoveCaret(ENCaretMoveDirection.PrevWord, False)
            m_RichText.Focus()
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NSelectionExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(text As String) As NParagraph
            Return New NParagraph(text)
        End Function
        Private Shared Function GetTitleParagraphNoBorder(text As String, level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()

            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle

            Dim textInline As NTextInline = New NTextInline(text)

            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize

            paragraph.Inlines.Add(textInline)

            Return paragraph

        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Shared Function GetTitleParagraph(text As String, level As Integer) As NParagraph
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(text, level)
            paragraph.HorizontalAlignment = ENAlign.Left

            paragraph.Border = CreateLeftTagBorder(color)
            paragraph.BorderThickness = defaultBorderThickness

            Return paragraph
        End Function
        Private Shared Function GetNoteBlock(text As String, level As Integer) As NGroupBlock
            Dim color = NColor.Red
            Dim paragraph = GetTitleParagraphNoBorder("Note", level)

            Dim groupBlock As NGroupBlock = New NGroupBlock()

            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(text))

            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness

            Return groupBlock
        End Function
        Private Shared Function GetDescriptionBlock(title As String, description As String, level As Integer) As NGroupBlock
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(title, level)

            Dim groupBlock As NGroupBlock = New NGroupBlock()

            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))

            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness

            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(color As NColor) As NBorder
            Dim border As NBorder = New NBorder()

            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)

            Return border
        End Function
        Private Shared Function GetLoremIpsumParagraph() As NParagraph
            Return New NParagraph("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum placerat in tortor nec tincidunt. Sed sagittis in sem ac auctor. Donec scelerisque molestie eros, a dictum leo fringilla eu. Vivamus porta urna non ullamcorper commodo. Nulla posuere sodales pellentesque. Donec a erat et tortor viverra euismod non et erat. Donec dictum ante eu mauris porta, eget suscipit mi ultrices. Nunc convallis adipiscing ligula, non pharetra dolor egestas at. Etiam in condimentum sapien. Praesent sagittis pulvinar metus, a posuere mauris aliquam eget.")
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region

    End Class
End Namespace
