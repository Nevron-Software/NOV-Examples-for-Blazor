Imports System.IO

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.IO
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.Formats
Imports Nevron.Nov.Text.Formats.Html
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NHtmlExportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NHtmlExportExampleSchema = NSchema.Create(GetType(NHtmlExportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim splitter As NSplitter = New NSplitter()
            splitter.SplitMode = ENSplitterSplitMode.Proportional
            splitter.SplitFactor = 0.5

            ' Create the rich text view
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Stack the rich text with ribbon and an export button
            Dim exportButton As NButton = New NButton("Export")
            exportButton.Content.HorizontalPlacement = ENHorizontalPlacement.Center
            exportButton.Click += AddressOf OnExportButtonClick

            splitter.Pane1.Content = CreatePairBox(richTextWithRibbon, exportButton)

            ' Create the HTML rich text box
            m_HtmlTextBox = New NTextBox()
            m_HtmlTextBox.AcceptsEnter = True
            m_HtmlTextBox.AcceptsTab = True
            m_HtmlTextBox.Multiline = True
            m_HtmlTextBox.WordWrap = False
            m_HtmlTextBox.VScrollMode = ENScrollMode.WhenNeeded
            m_HtmlTextBox.HScrollMode = ENScrollMode.WhenNeeded
            m_HtmlTextBox.ReadOnly = True
            splitter.Pane2.Content = New NGroupBox("Exported HTML", m_HtmlTextBox)

            Return splitter
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.VerticalSpacing = 10

            ' Create the export settings check boxes
            m_InlineStylesCheckBox = New NCheckBox("Inline styles", False)
            Me.m_InlineStylesCheckBox.CheckedChanged += AddressOf OnSettingsCheckBoxCheckedChanged
            stack.Add(m_InlineStylesCheckBox)

            m_MinifyHtmlCheckBox = New NCheckBox("Minify HTML", False)
            Me.m_MinifyHtmlCheckBox.CheckedChanged += AddressOf OnSettingsCheckBoxCheckedChanged
            stack.Add(m_MinifyHtmlCheckBox)

            ' Create the predefined tests list box
            Dim testListBox As NListBox = New NListBox()
            testListBox.Items.Add(CreateTestListBoxItem(New NRichTextBorders()))
            testListBox.Items.Add(CreateTestListBoxItem(New NRichTextLists()))
            testListBox.Items.Add(CreateTestListBoxItem(New NRichTextTables()))
            testListBox.Items.Add(CreateTestListBoxItem(New NRichTextTextStyles()))
            testListBox.Items.Add(CreateTestListBoxItem(New NRichTextElementPositioning()))
            testListBox.Selection.Selected += AddressOf OnTestListBoxItemSelected

            ' Add the list box in a group box
            stack.Add(New NGroupBox("Predefined text documents", testListBox))

            ' Create the Load from file group box
            Dim dockPanel As NDockPanel = New NDockPanel()
            dockPanel.HorizontalSpacing = 3
            dockPanel.VerticalSpacing = 3

            Dim loadButton As NButton = New NButton("Load")
            loadButton.Click += AddressOf OnLoadButtonClick
            NDockLayout.SetDockArea(loadButton, ENDockArea.Bottom)
            dockPanel.Add(loadButton)

            m_FileNameTextBox = New NTextBox()
            m_FileNameTextBox.VerticalPlacement = ENVerticalPlacement.Center
            NDockLayout.SetDockArea(m_FileNameTextBox, ENDockArea.Center)
            dockPanel.Add(m_FileNameTextBox)

            Dim browseButton As NButton = New NButton("...")
            browseButton.Click += AddressOf OnBrowseButtonClick
            NDockLayout.SetDockArea(browseButton, ENDockArea.Right)
            dockPanel.Add(browseButton)

            stack.Add(New NGroupBox("Load from file", dockPanel))

            m_ElapsedTimeLabel = New NLabel()
            stack.Add(m_ElapsedTimeLabel)

            ' Select the initial test
            testListBox.Selection.SingleSelect(testListBox.Items(0))

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the HTML export capabilities of the Nevron Rich Text widget. Simply select one of the preloaded examples
    from the combo box to the right and see it exported. You can also edit the text document and press the <b>Export</b> button when ready.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Sub ExportToHtml()
            m_ElapsedTimeLabel.Text = Nothing

            Dim stopwatch As NStopwatch = NStopwatch.StartNew()
            Using stream As MemoryStream = New MemoryStream()
                ' Create and configure HTML save settings
                Dim saveSettings As NHtmlSaveSettings = New NHtmlSaveSettings()
                saveSettings.InlineStyles = m_InlineStylesCheckBox.Checked
                saveSettings.MinifyHtml = m_MinifyHtmlCheckBox.Checked

                ' Save to HTML
                m_RichText.SaveToStreamAsync(stream, NTextFormat.Html, saveSettings)
                stopwatch.Stop()

                LoadHtmlSource(stream)
            End Using

            m_ElapsedTimeLabel.Text = "Export done in: " & stopwatch.ElapsedMilliseconds.ToString() & " ms."
        End Sub
        Private Sub LoadHtmlSource(stream As Stream)
            stream.Position = 0
            Dim bytes = NStreamHelpers.ReadToEnd(stream)
            m_HtmlTextBox.Text = NEncoding.UTF8.GetString(bytes)
        End Sub
        Private Function LoadRtfFromFile(fileName As String) As Boolean
            Try
                m_RichText.LoadFromFileAsync(fileName)
            Catch
                m_ElapsedTimeLabel.Text = "RTF loading failed."
                Return False
            End Try

            Return True
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnExportButtonClick(arg1 As NEventArgs)
            ExportToHtml()
        End Sub
        Private Sub OnSettingsCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            ExportToHtml()
        End Sub
        Private Sub OnTestListBoxItemSelected(arg1 As NSelectEventArgs(Of NListBoxItem))
            Dim selectedItem = arg1.Item
            If selectedItem Is Nothing Then Return

            Dim example As NRichTextToHtmlExample = TryCast(selectedItem.Tag, NRichTextToHtmlExample)
            If example Is Nothing Then Return

            ' Recreate the content of the Nevron rich text widget
            Dim documentRoot As NDocumentBlock = example.CreateDocument()

            Dim document As NRichTextDocument = New NRichTextDocument()
            document.Content = documentRoot
            document.Evaluate()

            m_RichText.Document = document
            ExportToHtml()
        End Sub
        Private Sub OnBrowseButtonClick(arg1 As NEventArgs)
            Dim openFileDialog As NOpenFileDialog = New NOpenFileDialog()
            openFileDialog.FileTypes = New NFileDialogFileType() {New NFileDialogFileType("Word Documents and Rich Text Files", New String() {"docx", "rtf"})}
            openFileDialog.SelectedFilterIndex = 0
            openFileDialog.MultiSelect = False
            openFileDialog.InitialDirectory = String.Empty

            openFileDialog.Closed += New [Function](Of NOpenFileDialogResult)(Sub(result As NOpenFileDialogResult)
                                                                                  If result.Result IsNot ENCommonDialogResult.OK Then Return

                                                                                  Dim fileName = result.Files(0).Path
                                                                                  m_FileNameTextBox.Text = fileName

                                                                                  If LoadRtfFromFile(fileName) Then
                                                                                      ExportToHtml()
                                                                                  End If
                                                                              End Sub)

            openFileDialog.RequestShow()
        End Sub
        Private Sub OnLoadButtonClick(arg1 As NEventArgs)
            Dim fileName = m_FileNameTextBox.Text
            Dim file = NFileSystem.Current.GetFile(fileName)

            If file Is Nothing Then Return

            file.Exists().[Then](Sub(exists As Boolean)
                                     If exists AndAlso LoadRtfFromFile(fileName) Then ExportToHtml()
                                 End Sub)
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView
        Private m_HtmlTextBox As NTextBox
        Private m_InlineStylesCheckBox As NCheckBox
        Private m_MinifyHtmlCheckBox As NCheckBox
        Private m_FileNameTextBox As NTextBox
        Private m_ElapsedTimeLabel As NLabel

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NHtmlExportExample.
        ''' </summary>
        Public Shared ReadOnly NHtmlExportExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateTestListBoxItem(example As NRichTextToHtmlExample) As NListBoxItem
            Dim item As NListBoxItem = New NListBoxItem(example.Title)
            item.Tag = example
            Return item
        End Function
        Private Shared Function CreatePairBox(widget1 As NWidget, widget2 As NWidget) As NPairBox
            Dim pairBox As NPairBox = New NPairBox(widget1, widget2, ENPairBoxRelation.Box1AboveBox2)
            pairBox.FitMode = ENStackFitMode.First
            pairBox.FillMode = ENStackFillMode.First
            pairBox.Spacing = NDesign.VerticalSpacing

            Return pairBox
        End Function

#End Region

#Region "Nested Types"

        Private MustInherit Class NRichTextToHtmlExample
            Public Sub New(title As String)
                m_Title = title
            End Sub

            Public ReadOnly Property Title As String
                Get
                    Return m_Title
                End Get
            End Property

            Public Overridable Function CreateDocument() As NDocumentBlock
                Dim document As NDocumentBlock = New NDocumentBlock()
                document.Information.Title = m_Title

                Dim section As NSection = New NSection()
                document.Sections.Add(section)

                Dim heading As NParagraph = New NParagraph(m_Title)
                section.Blocks.Add(heading)
                heading.HorizontalAlignment = ENAlign.Center
                heading.FontSize = 24

                Return document
            End Function

            Private m_Title As String
        End Class

        Private Class NRichTextBorders
            Inherits NRichTextToHtmlExample
            Public Sub New()
                MyBase.New("Borders")
            End Sub

            Public Overrides Function CreateDocument() As NDocumentBlock
                Dim document As NDocumentBlock = MyBase.CreateDocument()

                Dim section = document.Sections(0)
                Dim p As NParagraph = New NParagraph("Black solid border")
                section.Blocks.Add(p)
                p.Border = NBorder.CreateFilledBorder(NColor.Black)
                p.BorderThickness = New NMargins(1)

                p = New NParagraph("Black dashed border")
                section.Blocks.Add(p)
                p.Border = New NBorder()
                p.Border.MiddleStroke = New NStroke(5, NColor.Black, ENDashStyle.Dash)
                p.BorderThickness = New NMargins(5)

                p = New NParagraph("Green/DarkGreen two-color border")
                section.Blocks.Add(p)
                p.Border = NBorder.CreateTwoColorBorder(NColor.Green, NColor.DarkGreen)
                p.BorderThickness = New NMargins(10)

                p = New NParagraph("A border with left, right and bottom sides and wide but not set top side")
                section.Blocks.Add(p)
                p.Border = New NBorder()
                p.Border.LeftSide = New NThreeColorsBorderSide(NColor.Black, NColor.Gray, NColor.LightGray)
                p.Border.RightSide = New NBorderSide()
                p.Border.RightSide.OuterStroke = New NStroke(10, NColor.Blue, ENDashStyle.Dot)
                p.Border.BottomSide = New NBorderSide(NColor.Red)
                p.BorderThickness = New NMargins(9, 50, 5, 5)

                Return document
            End Function
        End Class
        Private Class NRichTextTextStyles
            Inherits NRichTextToHtmlExample
            Public Sub New()
                MyBase.New("Text Styles")
            End Sub

            Public Overrides Function CreateDocument() As NDocumentBlock
                Dim document As NDocumentBlock = MyBase.CreateDocument()

                Dim section = document.Sections(0)
                section.Blocks.Add(New NParagraph("This is the first paragraph."))
                section.Blocks.Add(New NParagraph("This is the second paragraph." & vbLf & "This is part of the second paragraph, too."))

                Dim div As NGroupBlock = New NGroupBlock()
                section.Blocks.Add(div)
                div.Fill = New NColorFill(NColor.Red)
                Dim p As NParagraph = New NParagraph("This is a paragraph in a div. It should have red underlined text.")
                div.Blocks.Add(p)
                p.FontStyle = ENFontStyle.Underline

                p = New NParagraph("This is another paragraph in the div. It contains a ")
                div.Blocks.Add(p)
                Dim inline As NTextInline = New NTextInline("bold italic blue inline")
                p.Inlines.Add(inline)
                inline.Fill = New NColorFill(NColor.Blue)
                inline.FontStyle = ENFontStyle.Bold Or ENFontStyle.Italic

                p.Inlines.Add(New NTextInline("."))

                Return document
            End Function
        End Class
        Private Class NRichTextTables
            Inherits NRichTextToHtmlExample
            Public Sub New()
                MyBase.New("Tables")
            End Sub

            Public Overrides Function CreateDocument() As NDocumentBlock
                Dim document As NDocumentBlock = MyBase.CreateDocument()

                ' Create a simple 2x2 table
                Dim section = document.Sections(0)
                Dim table As NTable = New NTable(2, 2)
                section.Blocks.Add(table)

                Dim row = 0, i = 1

                While row < table.Rows.Count
                    Dim col = 0

                    While col < table.Columns.Count
                        Call InitCell(table.Rows(row).Cells(col), "Cell " & i.ToString())
                        col += 1
                        i += 1
                    End While

                    row += 1
                End While

                ' Create a 3x3 table with rowspans and colspans
                table = New NTable(4, 3)
                section.Blocks.Add(table)
                InitCell(table.Rows(0).Cells(0), 2, 1, "Cell 1 (2 rows)")
                InitCell(table.Rows(0).Cells(1), "Cell 2")
                InitCell(table.Rows(0).Cells(2), "Cell 3")
                InitCell(table.Rows(1).Cells(1), 1, 2, "Cell 4 (2 cols)")
                InitCell(table.Rows(2).Cells(0), "Cell 5")
                InitCell(table.Rows(2).Cells(1), 2, 2, "Cell 6 (2 rows x 2 cols)")
                InitCell(table.Rows(3).Cells(0), "Cell 7")

                Return document
            End Function

            Private Shared Sub InitCell(cell As NTableCell, text As String)
                InitCell(cell, 1, 1, text)
            End Sub
            Private Shared Sub InitCell(cell As NTableCell, rowSpan As Integer, colSpan As Integer, text As String)
                If rowSpan <> 1 Then
                    cell.RowSpan = rowSpan
                End If

                If colSpan <> 1 Then
                    cell.ColSpan = colSpan
                End If

                ' By default cells contain a single paragraph
                cell.Blocks.Clear()
                cell.Blocks.Add(New NParagraph(text))

                ' Create a border
                cell.Border = NBorder.CreateFilledBorder(NColor.Black)
                cell.BorderThickness = New NMargins(1)
            End Sub
        End Class
        Private Class NRichTextLists
            Inherits NRichTextToHtmlExample
            Public Sub New()
                MyBase.New("Lists")
            End Sub

            Public Overrides Function CreateDocument() As NDocumentBlock
                Dim document As NDocumentBlock = MyBase.CreateDocument()
                Dim section = document.Sections(0)

                ' Add bullet lists of all unordered types
                Dim bulletTypes = New ENBulletListTemplateType() {ENBulletListTemplateType.Bullet}

                For i = 0 To bulletTypes.Length - 1
                    Dim bulletList As NBulletList = New NBulletList(ENBulletListTemplateType.Bullet)
                    document.BulletLists.Add(bulletList)

                    For j = 1 To 3
                        Dim paragraph As NParagraph = New NParagraph("This is parargaph number " & j.ToString() & ". This paragraph is contained in a bullet list of type " & bulletTypes(i).ToString())
                        paragraph.SetBulletList(bulletList, 0)
                        section.Blocks.Add(paragraph)
                    Next
                Next

                ' Add bullet lists of all ordered types
                bulletTypes = New ENBulletListTemplateType() {ENBulletListTemplateType.Decimal, ENBulletListTemplateType.LowerAlpha, ENBulletListTemplateType.LowerRoman, ENBulletListTemplateType.UpperAlpha, ENBulletListTemplateType.UpperRoman}

                For i = 0 To bulletTypes.Length - 1
                    section.Blocks.Add(New NParagraph())

                    Dim bulletList As NBulletList = New NBulletList(bulletTypes(i))

                    For j = 1 To 3
                        Dim paragraph As NParagraph = New NParagraph("Bullet List Item " & j.ToString(), bulletList, 0)
                        section.Blocks.Add(paragraph)

                        For z = 1 To 3
                            Dim par2 As NParagraph = New NParagraph("Bullet List Sub Item " & z.ToString(), bulletList, 1)
                            section.Blocks.Add(par2)
                        Next
                    Next
                Next

                Return document
            End Function
        End Class
        Private Class NRichTextElementPositioning
            Inherits NRichTextToHtmlExample
            Public Sub New()
                MyBase.New("Element Positioning")
            End Sub

            Public Overrides Function CreateDocument() As NDocumentBlock
                Dim document As NDocumentBlock = MyBase.CreateDocument()

                Dim section = document.Sections(0)
                Dim p As NParagraph = New NParagraph("This is a red paragraph on the left.")
                p.HorizontalAnchor = ENHorizontalAnchor.Ancestor
                p.HorizontalBlockAlignment = ENHorizontalBlockAlignment.Left
                p.VerticalAnchor = ENVerticalAnchor.Ancestor
                p.XOffset = 20
                p.YOffset = 200
                p.PreferredWidth = NMultiLength.NewPercentage(25)
                p.BackgroundFill = New NColorFill(NColor.Red)
                section.Blocks.Add(p)

                p = New NParagraph("This is a green paragraph on the top.")
                p.HorizontalAnchor = ENHorizontalAnchor.Ancestor
                p.VerticalAnchor = ENVerticalAnchor.Ancestor
                p.VerticalBlockAlignment = ENVerticalBlockAlignment.Top
                p.XOffset = 120
                p.YOffset = 100
                p.PreferredWidth = NMultiLength.NewPercentage(50)
                p.BackgroundFill = New NColorFill(NColor.Green)
                section.Blocks.Add(p)

                p = New NParagraph("This is a blue paragraph on the right.")
                p.HorizontalAnchor = ENHorizontalAnchor.Ancestor
                p.HorizontalBlockAlignment = ENHorizontalBlockAlignment.Right
                p.VerticalAnchor = ENVerticalAnchor.Ancestor
                p.XOffset = 20
                p.YOffset = 200
                p.PreferredWidth = NMultiLength.NewPercentage(25)
                p.BackgroundFill = New NColorFill(NColor.Blue)
                p.Fill = New NColorFill(NColor.White)
                section.Blocks.Add(p)

                Return document
            End Function
        End Class

#End Region
    End Class
End Namespace
