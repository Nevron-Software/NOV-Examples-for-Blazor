Imports System
Imports System.IO

Imports Nevron.Nov.Dom
Imports Nevron.Nov.IO
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.Formats
Imports Nevron.Nov.UI
Imports System.Runtime.InteropServices

Namespace Nevron.Nov.Examples.Text
    Public Class NHtmlImportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NHtmlImportExampleSchema = NSchema.Create(GetType(NHtmlImportExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim splitter As NSplitter = New NSplitter()
            splitter.SplitMode = ENSplitterSplitMode.Proportional
            splitter.SplitFactor = 0.5

            ' Create the "HTML Code" group box
            m_HtmlTextBox = New NTextBox()
            m_HtmlTextBox.AcceptsEnter = True
            m_HtmlTextBox.AcceptsTab = True
            m_HtmlTextBox.Multiline = True
            m_HtmlTextBox.WordWrap = False
            m_HtmlTextBox.VScrollMode = ENScrollMode.WhenNeeded
            m_HtmlTextBox.HScrollMode = ENScrollMode.WhenNeeded

            Dim importButton As NButton = New NButton("Import")
            importButton.Content.HorizontalPlacement = ENHorizontalPlacement.Center
            importButton.Click += New [Function](Of NEventArgs)(AddressOf OnImportButtonClick)

            Dim pairBox = CreatePairBox(m_HtmlTextBox, importButton)
            splitter.Pane1.Content = New NGroupBox("HTML Code", pairBox)

            ' Create the "Preview" group box
            m_PreviewRichText = New NRichTextView()
            m_PreviewRichText.ReadOnly = True
            Me.m_PreviewRichText.DocumentLoaded += AddressOf OnRichTextDocumentLoaded
            splitter.Pane2.Content = New NGroupBox("Preview", m_PreviewRichText)

            Return splitter
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.VerticalSpacing = 10

            m_ElapsedTimeLabel = New NLabel()
            stack.Add(CreatePredefinedPageGroupBox())
#If Not SILVERLIGHT
            stack.Add(CreateNavigationGroupBox())
#End If
            stack.Add(m_ElapsedTimeLabel)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the HTML import capabilities of the Nevron Rich Text widget. Simply select one of the preloaded examples
	from the combo box to the right and see it imported. You can also edit the source of the HTML code and press the <b>Import</b>
	button when ready.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreatePredefinedPageGroupBox() As NGroupBox
            Const HtmlSuitePrefix = "RSTR_HtmlSuite_"

            Dim testListBox As NListBox = New NListBox()
            Dim resourceName As String() = NResources.Instance.GetResourceNames()
            Dim i = 0, count = resourceName.Length

            While i < count
                Dim resName = resourceName(i)
                If resName.StartsWith(HtmlSuitePrefix, StringComparison.Ordinal) Then
                    ' The current resource is an HTML page, so add it to the list box
                    Dim testName = resName.Substring(HtmlSuitePrefix.Length, resName.Length - HtmlSuitePrefix.Length - 5)
                    Dim item As NListBoxItem = New NListBoxItem(NStringHelpers.InsertSpacesBeforeUppersAndDigits(testName))
                    item.Tag = resName
                    testListBox.Items.Add(item)
                End If

                i += 1
            End While

            testListBox.Selection.Selected += AddressOf OnListBoxItemSelected
            testListBox.Selection.SingleSelect(testListBox.Items(0))
            Return New NGroupBox("Predefined HTML pages", testListBox)
        End Function
        Private Function CreateNavigationGroupBox() As NGroupBox
            ' Create the navigation pair box
            m_NavigationTextBox = New NTextBox()
            m_NavigationTextBox.Text = DefaultAddress
            m_NavigationTextBox.VerticalPlacement = ENVerticalPlacement.Center

            Dim goButton As NButton = New NButton("Go")
            goButton.VerticalPlacement = ENVerticalPlacement.Center
            goButton.Click += New [Function](Of NEventArgs)(AddressOf OnGoButtonClick)

            Dim pairBox As NPairBox = New NPairBox(m_NavigationTextBox, goButton)
            pairBox.FitMode = ENStackFitMode.First
            pairBox.FillMode = ENStackFillMode.First
            pairBox.Spacing = 3

            Return New NGroupBox("Import from URL", pairBox)
        End Function

        Private Function TryParseUrl(url As String, <Out> ByRef uri As NUriBase) As Boolean
            uri = Nothing

            url = NStringHelpers.SafeTrim(url)
            If String.IsNullOrEmpty(url) Then Return False

            If Not url.Contains("://") AndAlso url.IndexOf(":\") <> 1 AndAlso url(0) <> "/"c Then ' URI scheme check
                ' Windows file path check
                ' Unix file path check
                ' This URL doesn't have a scheme and is not a file path, so add an HTTP URI scheme
                url = "http://" & url
            End If

            Return NUri.TryCreate(url, ENUriKind.Absolute, uri)
        End Function
        Private Sub LoadSource(stream As Stream)
            Dim bytes = NStreamHelpers.ReadToEnd(stream)
            m_HtmlTextBox.Text = NEncoding.UTF8.GetString(bytes)
        End Sub
        Private Function LoadHtml(stream As Stream, baseUri As String) As NPromise(Of Boolean)
            m_ElapsedTimeLabel.Text = String.Empty

            stream.Position = 0
            m_Stopwatch = NStopwatch.StartNew()

            Dim settings As NTextLoadSettings = Nothing
            If Not Equals(baseUri, Nothing) Then
                settings = New NTextLoadSettings()
                settings.BaseUri = New NUri(baseUri)
            End If

            Return m_PreviewRichText.LoadFromStreamAsync(stream, NTextFormat.Html, settings)
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnImportButtonClick(arg1 As NEventArgs)
            Dim bytes = NEncoding.UTF8.GetBytes(m_HtmlTextBox.Text)
            Using stream As MemoryStream = New MemoryStream(bytes)
                LoadHtml(stream, Nothing)
            End Using
        End Sub
        Private Sub OnListBoxItemSelected(arg1 As NSelectEventArgs(Of NListBoxItem))
            If arg1.TargetNode Is Nothing Then Return

            ' Determine the full name of the selected resource
            Dim resName = CStr(arg1.Item.Tag)

            ' Read the stream and set it as text of the HTML code text box
            Dim stream As Stream = NResources.Instance.GetResourceStream(resName)
            LoadSource(stream)
            LoadHtml(stream, Nothing).[Finally](Sub() stream.Close())
        End Sub
        Private Sub OnGoButtonClick(arg1 As NEventArgs)
            Dim url = m_NavigationTextBox.Text
            If String.IsNullOrEmpty(url) Then Return

            ' Normalize the URL
            Dim uri As NUriBase
            If Not TryParseUrl(url, uri) Then
                NMessageBox.ShowError("Invalid URL or file path", "Error")
                Return
            End If

            If uri.IsFile Then
                ' Load from file
                Dim file = NFileSystem.Current.GetFile(url)

                file.OpenReadAsync().[Then](Sub(stream As Stream)
                                                Using stream
                                                    LoadSource(stream)
                                                    LoadHtml(stream, url)
                                                End Using
                                            End Sub)
            ElseIf uri.IsHTTP Then
                ' Load from URI
                Try
                    m_Stopwatch = NStopwatch.StartNew()
                    m_PreviewRichText.LoadFromUriAsync(CType(uri, NUri))
                Catch ex As Exception
                    m_Stopwatch.Stop()
                    NMessageBox.ShowError(ex.Message, "Error")
                End Try
            End If
        End Sub
        Private Sub OnRichTextDocumentLoaded(args As NEventArgs)
            ' Show the elapsed time
            If m_Stopwatch IsNot Nothing Then
                m_Stopwatch.Stop()
                m_ElapsedTimeLabel.Text = "Elapsed time: " & m_Stopwatch.ElapsedMilliseconds.ToString() & " ms"
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_HtmlTextBox As NTextBox
        Private m_PreviewRichText As NRichTextView
        Private m_NavigationTextBox As NTextBox
        Private m_ElapsedTimeLabel As NLabel

        Private m_Stopwatch As NStopwatch

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NHtmlImportExample.
        ''' </summary>
        Public Shared ReadOnly NHtmlImportExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreatePairBox(widget1 As NWidget, widget2 As NWidget) As NPairBox
            Dim pairBox As NPairBox = New NPairBox(widget1, widget2, ENPairBoxRelation.Box1AboveBox2)
            pairBox.FitMode = ENStackFitMode.First
            pairBox.FillMode = ENStackFillMode.First
            pairBox.Spacing = NDesign.VerticalSpacing

            Return pairBox
        End Function

#End Region

#Region "Constants"

        Private Const DefaultAddress As String = "http://en.wikipedia.org/wiki/Web_browser"

#End Region
    End Class
End Namespace
