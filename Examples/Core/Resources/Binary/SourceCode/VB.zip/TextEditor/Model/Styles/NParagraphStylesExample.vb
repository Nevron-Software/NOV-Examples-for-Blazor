Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NParagraphStylesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NParagraphStylesExampleSchema = NSchema.Create(GetType(NParagraphStylesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            Return richTextWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create and apply paragraph styles.</p>"
        End Function

        Private Sub PopulateRichText()
            Dim documentBlock = m_RichText.Content
            Dim section As NSection = New NSection()
            documentBlock.Sections.Add(section)

            ' Create the first paragraph
            Dim paragraph1 As NParagraph = New NParagraph("This paragraph is styled with a predefined paragraph style.")
            section.Blocks.Add(paragraph1)

            ' Apply a predefined paragraph style
            Dim predefinedStyle = documentBlock.Styles.FindStyleByTypeAndId(ENRichTextStyleType.Paragraph, "Heading2")
            predefinedStyle.Apply(paragraph1)

            ' Create the second paragraph
            Dim paragraph2 As NParagraph = New NParagraph("This paragraph is styled with a custom paragraph style.")
            section.Blocks.Add(paragraph2)

            ' Create a custom paragraph style and apply it
            Dim customStyle As NParagraphStyle = New NParagraphStyle("CustomStyle")
            customStyle.ParagraphRule = New NParagraphRule()
            customStyle.ParagraphRule.BorderRule = New NBorderRule(ENPredefinedBorderStyle.Dash, NColor.Red, New NMargins(1))
            customStyle.ParagraphRule.HorizontalAlignment = ENAlign.Center
            customStyle.ParagraphRule.Padding = New NMargins(20)

            customStyle.InlineRule = New NInlineRule()
            customStyle.InlineRule.Fill = New NColorFill(NColor.Blue)

            customStyle.Apply(paragraph2)
            paragraph2.MarginTop = 30
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NParagraphStylesExample.
        ''' </summary>
        Public Shared ReadOnly NParagraphStylesExampleSchema As NSchema

#End Region
    End Class
End Namespace
