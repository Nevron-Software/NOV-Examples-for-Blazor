Imports Nevron.Nov.Dom
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI
Imports Nevron.Nov.Graphics
Imports System.Text

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt inline formatting
    ''' </summary>
    Public Class NBlockPagingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NBlockPagingExampleSchema = NSchema.Create(GetType(NBlockPagingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            Return richTextWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to control text paging using the PageBreakBefore and PageBreakAfter properties of text block elements.
</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            m_RichText.Content.Layout = ENTextLayout.Print

            section.Blocks.Add(GetDescriptionBlock("Block Paging Control", "For each block in the control, you can specify whether it starts on a new page or whether it has to avoid page breaks", 1))

            section.Blocks.Add(GetDescriptionBlock("PageBreakBefore and PageBreakAfter", "The following paragraphs have PageBreakBefore and PageBreakAfter set to true", 2))

            Dim paragraph1 = CreateSampleParagraph1("Page break must appear before this paragraph.")
            paragraph1.PageBreakBefore = True
            section.Blocks.Add(paragraph1)

            Dim paragraph2 = CreateSampleParagraph1("Page break must appear after this paragraph.")
            paragraph2.PageBreakAfter = True
            section.Blocks.Add(paragraph2)

        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NBlockPagingExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateSampleParagraph1(text As String) As NParagraph
            Dim paragraph As NParagraph = New NParagraph(GetRepeatingText(text, 10))

            paragraph.Margins = New NMargins(10)
            paragraph.BorderThickness = New NMargins(10)
            paragraph.Padding = New NMargins(10)
            paragraph.Border = NBorder.CreateFilledBorder(NColor.Red)
            paragraph.BackgroundFill = New NStockGradientFill(NColor.White, NColor.LightYellow)

            Return paragraph
        End Function
        Private Shared Function GetDescriptionParagraph(text As String) As NParagraph
            Return New NParagraph(text)
        End Function
        Private Shared Function GetTitleParagraphNoBorder(text As String, level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()

            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle

            Dim textInline As NTextInline = New NTextInline(text)

            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize

            paragraph.Inlines.Add(textInline)

            Return paragraph

        End Function
        Private Shared Function GetDescriptionBlock(title As String, description As String, level As Integer) As NGroupBlock
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(title, level)

            Dim groupBlock As NGroupBlock = New NGroupBlock()

            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))

            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness

            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(color As NColor) As NBorder
            Dim border As NBorder = New NBorder()

            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)

            Return border
        End Function
        ''' <summary>
        ''' Gets the specified text repeated
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <paramname="count"></param>
        ''' <returns></returns>
        Private Shared Function GetRepeatingText(text As String, count As Integer) As String
            Dim builder As StringBuilder = New StringBuilder()

            For i = 0 To count - 1
                If builder.Length > 0 Then
                    builder.Append(" ")
                End If

                builder.Append(text)
            Next

            Return builder.ToString()
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace
