Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NTableStylesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTableStylesExampleSchema = NSchema.Create(GetType(NTableStylesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            Return richTextWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create and apply table styles.</p>"
        End Function

        Private Sub PopulateRichText()
            Dim documentBlock = m_RichText.Content
            Dim section As NSection = New NSection()
            documentBlock.Sections.Add(section)

            ' Create the first table
            section.Blocks.Add(New NParagraph("Table with predefined table style:"))
            Dim table1 As NTable = CreateTable()
            section.Blocks.Add(table1)

            ' Apply a predefined table style
            Dim predefinedStyle = documentBlock.Styles.FindStyleByTypeAndId(ENRichTextStyleType.Table, "GridTable2Blue")
            predefinedStyle.Apply(table1)

            ' Create the second table
            Dim paragraph As NParagraph = New NParagraph("Table with custom table style:")
            paragraph.MarginTop = 30
            section.Blocks.Add(paragraph)
            Dim table2 As NTable = CreateTable()
            section.Blocks.Add(table2)

            ' Create a custom table style and apply it
            Dim customStyle As NTableStyle = New NTableStyle("CustomTableStyle")
            customStyle.WholeTable = New NTablePartStyle()
            customStyle.WholeTable.BorderRule = New NBorderRule(ENPredefinedBorderStyle.Solid, NColor.DarkRed, New NMargins(1))
            customStyle.WholeTable.BorderRule.InsideHSides = New NBorderSideRule(ENPredefinedBorderStyle.Solid, NColor.DarkRed, 1)
            customStyle.WholeTable.BorderRule.InsideVSides = New NBorderSideRule(ENPredefinedBorderStyle.Solid, NColor.DarkRed, 1)

            customStyle.FirstRow = New NTablePartStyle()
            customStyle.FirstRow.BackgroundFill = New NColorFill(NColor.DarkRed)
            customStyle.FirstRow.InlineRule = New NInlineRule(NColor.White)
            customStyle.FirstRow.InlineRule.FontStyle = ENFontStyle.Bold

            customStyle.Apply(table2)
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateTable() As NTable
            Dim table As NTable = New NTable()
            table.AllowSpacingBetweenCells = False

            Dim rowCount = 3
            Dim colCount = 3

            ' first create the columns
            For i = 0 To colCount - 1
                table.Columns.Add(New NTableColumn())
            Next

            ' then add rows with cells count matching the number of columns
            For row = 0 To rowCount - 1
                Dim tableRow As NTableRow = New NTableRow()
                table.Rows.Add(tableRow)

                For col = 0 To colCount - 1
                    Dim tableCell As NTableCell = New NTableCell()
                    tableRow.Cells.Add(tableCell)
                    tableCell.Margins = New NMargins(4)

                    tableCell.Border = NBorder.CreateFilledBorder(NColor.Black)
                    tableCell.BorderThickness = New NMargins(1)

                    Dim paragraph As NParagraph = New NParagraph("This is a table cell [" & row.ToString() & ", " & col.ToString() & "]")
                    tableCell.Blocks.Add(paragraph)
                Next
            Next

            Return table
        End Function

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTableStylesExample.
        ''' </summary>
        Public Shared ReadOnly NTableStylesExampleSchema As NSchema

#End Region
    End Class
End Namespace
