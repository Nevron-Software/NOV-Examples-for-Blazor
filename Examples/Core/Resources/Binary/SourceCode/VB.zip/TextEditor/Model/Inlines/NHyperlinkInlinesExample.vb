Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create inline elements with different formatting
    ''' </summary>
    Public Class NHyperlinkInlinesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NHyperlinkInlinesExampleSchema = NSchema.Create(GetType(NHyperlinkInlinesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Examples"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()

            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            Return richTextWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim jumpToBookmarkButton As NButton = New NButton("Jump to Bookmark")
            jumpToBookmarkButton.Click += AddressOf OnJumpToBookmarkButtonClick

            stack.Add(jumpToBookmarkButton)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to add hyperlinks and bookmarks and how to create image hyperlinks.</p>
<p>Press the ""Jump to Bookmark"" button to position the caret to ""MyBookmark"" bookmark.</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            section.Blocks.Add(GetDescriptionBlock("Hyperlink Inlines", "The example shows how to use hyperlinks inlines.", 1))

            ' Field inline with a hyperlink to a bookmark
            If True Then
                Dim bookmarkHyperlinkInline As NFieldInline = New NFieldInline("Jump to MyBookmark", New NBookmarkHyperlink("MyBookmark"))

                Dim paragraph As NParagraph = New NParagraph()
                paragraph.Inlines.Add(bookmarkHyperlinkInline)
                section.Blocks.Add(paragraph)
            End If

            ' Field inline with a hyperlink to an URL
            If True Then
                Dim urlHyperlinkInline As NFieldInline = New NFieldInline("Jump to www.nevron.com", New NUrlHyperlink("http://www.nevron.com", ENUrlHyperlinkTarget.SameWindowSameFrame))

                Dim paragraph As NParagraph = New NParagraph()
                paragraph.Inlines.Add(urlHyperlinkInline)
                section.Blocks.Add(paragraph)
            End If

            ' Image inline with a hyperlink to an URL
            If True Then
                Dim imageInline As NImageInline = New NImageInline()
                imageInline.Image = Diagram.NResources.Image_MyDraw_Logos_MyDrawLogo_png
                imageInline.Hyperlink = New NUrlHyperlink("http://www.mydraw.com", ENUrlHyperlinkTarget.SameWindowSameFrame)

                Dim paragraph As NParagraph = New NParagraph()
                paragraph.Inlines.Add(imageInline)
                section.Blocks.Add(paragraph)
            End If

            For i = 0 To 9
                section.Blocks.Add(New NParagraph("Some paragraph"))
            Next

            ' Bookmark
            If True Then
                Dim paragraph As NParagraph = New NParagraph()

                Dim textInline As NTextInline = New NTextInline("This is a bookmark")
                textInline.Fill = New NColorFill(NColor.Red)
                paragraph.Inlines.Add(textInline)

                section.Blocks.Add(paragraph)

                m_RichText.Content.Bookmarks.Create("MyBookmark", textInline)
            End If
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnJumpToBookmarkButtonClick(arg As NEventArgs)
            m_RichText.Content.Goto(ENTextDocumentPart.Bookmark, "MyBookmark", True)
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NHyperlinkInlinesExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(text As String) As NParagraph
            Return New NParagraph(text)
        End Function
        Private Shared Function GetTitleParagraphNoBorder(text As String, level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()

            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle

            Dim textInline As NTextInline = New NTextInline(text)

            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize

            paragraph.Inlines.Add(textInline)

            Return paragraph

        End Function
        Private Shared Function GetDescriptionBlock(title As String, description As String, level As Integer) As NGroupBlock
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(title, level)

            Dim groupBlock As NGroupBlock = New NGroupBlock()

            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))

            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness

            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(color As NColor) As NBorder
            Dim border As NBorder = New NBorder()

            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)

            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace
