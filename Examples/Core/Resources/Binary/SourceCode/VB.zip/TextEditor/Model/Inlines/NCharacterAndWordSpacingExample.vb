Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create inline elements with different formatting
    ''' </summary>
    Public Class NCharacterAndWordSpacingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NCharacterAndWordSpacingExampleSchema = NSchema.Create(GetType(NCharacterAndWordSpacingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            Return richTextWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_CharacterSpacing = New NNumericUpDown()
            m_CharacterSpacing.Value = 0
            Me.m_CharacterSpacing.ValueChanged += AddressOf OnCharacterSpacingFactorValueChanged

            m_WordSpacing = New NNumericUpDown()
            m_WordSpacing.Value = 0
            Me.m_WordSpacing.ValueChanged += AddressOf OnWordSpacingFactorValueChanged

            stack.Add(New NPairBox(New NLabel("Character Spacing:"), m_CharacterSpacing, ENPairBoxRelation.Box1BeforeBox2))
            stack.Add(New NPairBox(New NLabel("Word Spacing:"), m_WordSpacing, ENPairBoxRelation.Box1BeforeBox2))

            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to apply character and word spacing.
</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            For i = 0 To 2
                Dim paragraph As NParagraph = New NParagraph()
                section.Blocks.Add(paragraph)

                paragraph.Inlines.Add(New NTextInline("This example demonstrates the ability to apply ", ENFontStyle.Underline))

                If i = 1 Then
                    paragraph.Inlines.Add(New NTextInline("Character and Word (This is inline with modified character and word spacing) ", ENFontStyle.BoldItalic))
                End If

                paragraph.Inlines.Add(New NTextInline("spacing to inlines and individual blocks."))

                If i = 0 Then
                    paragraph.Inlines.Add(New NTextInline("This paragraph has modified character and word spacing. Use the controls on the right to set different word and character spacing"))
                End If
            Next
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnWordSpacingFactorValueChanged(arg As NValueChangeEventArgs)
            Dim textElements As NList(Of NTextElement) = CollectTextElements()

            For i = 0 To textElements.Count - 1
                textElements(i).FontWordSpacing = m_WordSpacing.Value
            Next
        End Sub

        Private Sub OnCharacterSpacingFactorValueChanged(arg As NValueChangeEventArgs)
            Dim textElements As NList(Of NTextElement) = CollectTextElements()

            For i = 0 To textElements.Count - 1
                textElements(i).FontCharacterSpacing = m_CharacterSpacing.Value
            Next
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Collects some text elements to apply character and word spacing to. You can apply 
        ''' </summary>
        ''' <returns></returns>
        Private Function CollectTextElements() As NList(Of NTextElement)
            Dim targetElements As NList(Of NTextElement) = New NList(Of NTextElement)()
            Dim paragraphs = m_RichText.Content.GetDescendants(NParagraph.NParagraphSchema)

            If paragraphs.Count > 0 Then
                targetElements.Add(CType(paragraphs(0), NTextElement))
            End If

            If paragraphs.Count > 1 Then
                If CType(paragraphs(1), NParagraph).Inlines.Count > 1 Then
                    targetElements.Add(CType(paragraphs(1), NParagraph).Inlines(1))
                End If
            End If

            Return targetElements
        End Function

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

        Private m_CharacterSpacing As NNumericUpDown
        Private m_WordSpacing As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NCharacterAndWordSpacingExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(text As String) As NParagraph
            Return New NParagraph(text)
        End Function
        Private Shared Function GetTitleParagraphNoBorder(text As String, level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()

            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle

            Dim textInline As NTextInline = New NTextInline(text)

            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize

            paragraph.Inlines.Add(textInline)

            Return paragraph

        End Function
        Private Shared Function GetDescriptionBlock(title As String, description As String, level As Integer) As NGroupBlock
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(title, level)

            Dim groupBlock As NGroupBlock = New NGroupBlock()

            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))

            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness

            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(color As NColor) As NBorder
            Dim border As NBorder = New NBorder()

            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)

            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace
