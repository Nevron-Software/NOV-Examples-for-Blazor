Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create inline elements with different formatting
    ''' </summary>
    Public Class NFieldInlinesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NFieldInlinesExampleSchema = NSchema.Create(GetType(NFieldInlinesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            Return richTextWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim updateAllFieldsButton As NButton = New NButton("Update All Fields")
            updateAllFieldsButton.Click += New [Function](Of NEventArgs)(AddressOf OnUpdateAllFieldsButtonClick)

            stack.Add(updateAllFieldsButton)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to add different field inlines as well as how to use a range visitor delegate to update all fields in a block tree.</p>
<p>Press the ""Update All Fields"" button to update all fields.</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            section.Blocks.Add(GetDescriptionBlock("Field Inlines", "The example shows how to use field inlines.", 1))

            section.Blocks.Add(GetNoteBlock("Not all field values are always available. Please check the documentation for more information.", 1))

            ' add numeric fields
            section.Blocks.Add(GetTitleParagraph("Numeric Fields", 2))

            Dim numericFields As ENNumericFieldName() = NEnum.GetValues(Of ENNumericFieldName)()
            Dim numericFieldNames As String() = NEnum.GetNames(Of ENNumericFieldName)()

            For i = 0 To numericFieldNames.Length - 1
                Dim paragraph As NParagraph = New NParagraph()

                paragraph.Inlines.Add(New NTextInline(numericFieldNames(i) & " ["))

                Dim fieldInline As NFieldInline = New NFieldInline()
                fieldInline.Value = New NNumericFieldValue(numericFields(i))
                fieldInline.Text = "Not Updated"
                paragraph.Inlines.Add(fieldInline)

                paragraph.Inlines.Add(New NTextInline("]"))

                section.Blocks.Add(paragraph)
            Next

            ' add date time fields
            section.Blocks.Add(GetTitleParagraph("Date/Time Fields", 2))

            Dim dateTimeFields As ENDateTimeFieldName() = NEnum.GetValues(Of ENDateTimeFieldName)()
            Dim dateTimecFieldNames As String() = NEnum.GetNames(Of ENDateTimeFieldName)()

            For i = 0 To dateTimecFieldNames.Length - 1
                Dim paragraph As NParagraph = New NParagraph()

                paragraph.Inlines.Add(New NTextInline(dateTimecFieldNames(i) & " ["))

                Dim fieldInline As NFieldInline = New NFieldInline()
                fieldInline.Value = New NDateTimeFieldValue(dateTimeFields(i))
                fieldInline.Text = "Not Updated"
                paragraph.Inlines.Add(fieldInline)

                paragraph.Inlines.Add(New NTextInline("]"))

                section.Blocks.Add(paragraph)
            Next

            ' add string fields
            section.Blocks.Add(GetTitleParagraph("String Fields", 2))

            Dim stringFields As ENStringFieldName() = NEnum.GetValues(Of ENStringFieldName)()
            Dim stringcFieldNames As String() = NEnum.GetNames(Of ENStringFieldName)()

            For i = 0 To stringcFieldNames.Length - 1
                Dim paragraph As NParagraph = New NParagraph()

                paragraph.Inlines.Add(New NTextInline(stringcFieldNames(i) & " ["))

                Dim fieldInline As NFieldInline = New NFieldInline()
                fieldInline.Value = New NStringFieldValue(stringFields(i))
                fieldInline.Text = "Not Updated"
                paragraph.Inlines.Add(fieldInline)

                paragraph.Inlines.Add(New NTextInline("]"))

                section.Blocks.Add(paragraph)
            Next
        End Sub

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnUpdateAllFieldsButtonClick(arg As NEventArgs)
            m_RichText.Content.VisitRanges(Sub(range As NRangeTextElement)
                                               Dim field As NFieldInline = TryCast(range, NFieldInline)

                                               If field IsNot Nothing Then
                                                   field.Update()
                                               End If
                                           End Sub)
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NFieldInlinesExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(text As String) As NParagraph
            Return New NParagraph(text)
        End Function
        Private Shared Function GetTitleParagraphNoBorder(text As String, level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()

            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle

            Dim textInline As NTextInline = New NTextInline(text)

            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize

            paragraph.Inlines.Add(textInline)

            Return paragraph

        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Shared Function GetTitleParagraph(text As String, level As Integer) As NParagraph
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(text, level)
            paragraph.HorizontalAlignment = ENAlign.Left

            paragraph.Border = CreateLeftTagBorder(color)
            paragraph.BorderThickness = defaultBorderThickness

            Return paragraph
        End Function
        Private Shared Function GetNoteBlock(text As String, level As Integer) As NGroupBlock
            Dim color = NColor.Red
            Dim paragraph = GetTitleParagraphNoBorder("Note", level)

            Dim groupBlock As NGroupBlock = New NGroupBlock()

            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(text))

            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness

            Return groupBlock
        End Function
        Private Shared Function GetDescriptionBlock(title As String, description As String, level As Integer) As NGroupBlock
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(title, level)

            Dim groupBlock As NGroupBlock = New NGroupBlock()

            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))

            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness

            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(color As NColor) As NBorder
            Dim border As NBorder = New NBorder()

            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)

            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace
