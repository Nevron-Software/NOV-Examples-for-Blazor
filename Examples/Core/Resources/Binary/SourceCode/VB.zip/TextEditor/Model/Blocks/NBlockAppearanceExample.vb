
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt inline formatting
    ''' </summary>
    Public Class NBlockAppearanceExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NBlockAppearanceExampleSchema = NSchema.Create(GetType(NBlockAppearanceExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()



            ' Populate the rich text
            PopulateRichText()

            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to control the appearance of text blocks.
</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            section.Blocks.Add(GetDescriptionBlock("Block Appearance", "Every block in the document follows the HTML block formatting model which allows you to specify filling and border. The following paragraph has gradient background filling and solid border.", 1))

            Dim paragraph As NParagraph = New NParagraph()

            Dim textInline As NTextInline = New NTextInline("Paragraph with a solid border and gradient filling applied on the background.")
            textInline.Fill = New NColorFill(NColor.Aquamarine)
            textInline.FontSize = 24
            paragraph.Inlines.Add(textInline)

            paragraph.BackgroundFill = New NStockGradientFill(ENGradientStyle.FromCorner, ENGradientVariant.Variant1, NColor.Gainsboro, NColor.SlateGray)
            paragraph.Border = NBorder.CreateFilledBorder(NColor.DarkBlue)
            paragraph.BorderThickness = New NMargins(3)

            paragraph.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Dip, 500)

            section.Blocks.Add(paragraph)
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NBlockAppearanceExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(text As String) As NParagraph
            Return New NParagraph(text)
        End Function
        Private Shared Function GetTitleParagraphNoBorder(text As String, level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()

            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle

            Dim textInline As NTextInline = New NTextInline(text)

            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize

            paragraph.Inlines.Add(textInline)

            Return paragraph

        End Function
        Private Shared Function GetDescriptionBlock(title As String, description As String, level As Integer) As NGroupBlock
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(title, level)

            Dim groupBlock As NGroupBlock = New NGroupBlock()

            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))

            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness

            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(color As NColor) As NBorder
            Dim border As NBorder = New NBorder()

            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)

            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace
