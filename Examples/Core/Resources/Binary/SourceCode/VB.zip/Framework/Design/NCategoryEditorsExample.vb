Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NCategoryEditorsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
            m_Node = New NStyleNode()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCategoryEditorsExampleSchema = NSchema.Create(GetType(NCategoryEditorsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.VerticalPlacement = ENVerticalPlacement.Top

            Dim designers As NDesigner() = NStyleNode.Designers
            Dim i = 0, count = designers.Length

            While i < count
                Dim designer = designers(i)
                Dim button As NButton = New NButton(designer.ToString())

                stack.Add(button)
                button.Tag = designer
                button.Click += New [Function](Of NEventArgs)(AddressOf OnButtonClick)
                i += 1
            End While

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to use category editor templates in node designers to achieve different designer layouts.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnButtonClick(args As NEventArgs)
            Dim button As NButton = TryCast(args.TargetNode, NButton)
            If button Is Nothing Then Return

            Dim designer As NDesigner = button.Tag
            Dim editor As NEditor = designer.CreateInstanceEditor(m_Node)
            Dim window As NEditorWindow = NApplication.CreateTopLevelWindow(Of NEditorWindow)()

            window.Editor = editor
            window.Modal = False
            window.Open()
        End Sub

#End Region

#Region "Fields"

        Private m_Node As NStyleNode

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCategoryEditorsExample.
        ''' </summary>
        Public Shared ReadOnly NCategoryEditorsExampleSchema As NSchema

#End Region
    End Class
End Namespace
