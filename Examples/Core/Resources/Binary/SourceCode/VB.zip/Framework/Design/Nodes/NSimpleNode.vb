Imports System

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics

Namespace Nevron.Nov.Examples.Framework
    Public Class NSimpleNode
        Inherits NNode
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NSimpleNodeSchema = NSchema.Create(GetType(NSimpleNode), NNodeSchema)

            ' Properties
            BooleanValueProperty = NSimpleNodeSchema.AddSlot("BooleanValue", NDomType.Boolean, defaultBoolean)
            IntegerValueProperty = NSimpleNodeSchema.AddSlot("IntegerValue", NDomType.Int32, defaultInteger)
            LongValueProperty = NSimpleNodeSchema.AddSlot("LongValue", NDomType.Int64, defaultLong)
            UnsignedIntegerValueProperty = NSimpleNodeSchema.AddSlot("UnsignedIntegerValue", NDomType.UInt32, defaultUnsignedInteger)
            SingleValueProperty = NSimpleNodeSchema.AddSlot("SingleValue", NDomType.Single, defaultSingle)
            DoubleValueProperty = NSimpleNodeSchema.AddSlot("DoubleValue", NDomType.Double, defaultDouble)
            SpecifiedDoubleValueProperty = NSimpleNodeSchema.AddSlot("SpecifiedDoubleValue", NDomType.Double, defaultSpecifiedDouble)
            ComboBoxEnumValueProperty = NSimpleNodeSchema.AddSlot("ComboBoxEnum", GetType(ENSampleEnum), defaultComboBoxEnum)
            ComboBoxMaskedEnumProperty = NSimpleNodeSchema.AddSlot("ComboBoxMaskedEnum", GetType(ENSampleEnum), DefaultComboBoxMaskedEnum)
            HRadioGroupEnumProperty = NSimpleNodeSchema.AddSlot("HRadioGroupEnum", GetType(ENSampleEnum), defaultHRadioGroupEnum)
            VRadioGroupEnumProperty = NSimpleNodeSchema.AddSlot("VRadioGroupEnum", GetType(ENSampleEnum), defaultVRadioGroupEnum)

            AngleProperty = NSimpleNodeSchema.AddSlot("Angle", NDomType.NAngle, defaultAngle)
            ColorProperty = NSimpleNodeSchema.AddSlot("Color", NDomType.NColor, defaultColor)
            AdvancedColorProperty = NSimpleNodeSchema.AddSlot("AdvancedColor", NDomType.NColor, defaultAdvancedColor)
            LengthProperty = NSimpleNodeSchema.AddSlot("Length", NDomType.NLength, defaultLength)
            MarginsProperty = NSimpleNodeSchema.AddSlot("Margins", NDomType.NMargins, defaultMargins)
            PointProperty = NSimpleNodeSchema.AddSlot("Point", NDomType.NPoint, defaultPoint)
            RectangleProperty = NSimpleNodeSchema.AddSlot("Rectangle", NDomType.NRectangle, defaultRectangle)
            SizeProperty = NSimpleNodeSchema.AddSlot("Size", NDomType.NSize, defaultSize)
            MultiLengthProperty = NSimpleNodeSchema.AddSlot("MultiLength", GetType(NMultiLength), defaultMultiLength)

            ' Designer
            Call NSimpleNodeSchema.SetMetaUnit(New NDesignerMetaUnit(GetType(NSimpleNodeDesigner)))
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the value of the Boolean property.
        ''' </summary>
        Public Property BooleanValue As Boolean
            Get
                Return MyBase.GetValue(BooleanValueProperty)
            End Get
            Set(value As Boolean)
                MyBase.SetValue(BooleanValueProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the Integer property.
        ''' </summary>
        Public Property IntegerValue As Integer
            Get
                Return MyBase.GetValue(IntegerValueProperty)
            End Get
            Set(value As Integer)
                MyBase.SetValue(IntegerValueProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the Long property.
        ''' </summary>
        Public Property LongValue As Long
            Get
                Return MyBase.GetValue(LongValueProperty)
            End Get
            Set(value As Long)
                MyBase.SetValue(LongValueProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the Single property.
        ''' </summary>
        Public Property SingleValue As Single
            Get
                Return MyBase.GetValue(SingleValueProperty)
            End Get
            Set(value As Single)
                MyBase.SetValue(SingleValueProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the UnsignedInteger property.
        ''' </summary>
        Public Property UnsignedIntegerValue As UInteger
            Get
                Return MyBase.GetValue(UnsignedIntegerValueProperty)
            End Get
            Set(value As UInteger)
                MyBase.SetValue(UnsignedIntegerValueProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the double property.
        ''' </summary>
        Public Property DoubleValue As Double
            Get
                Return MyBase.GetValue(DoubleValueProperty)
            End Get
            Set(value As Double)
                MyBase.SetValue(DoubleValueProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the SpecifiedDouble property.
        ''' </summary>
        Public Property SpecifiedDoubleValue As Double
            Get
                Return MyBase.GetValue(SpecifiedDoubleValueProperty)
            End Get
            Set(value As Double)
                MyBase.SetValue(SpecifiedDoubleValueProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the ComboBoxEnum property.
        ''' </summary>
        Public Property ComboBoxEnum As ENSampleEnum
            Get
                Return MyBase.GetValue(ComboBoxEnumValueProperty)
            End Get
            Set(value As ENSampleEnum)
                MyBase.SetValue(ComboBoxEnumValueProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the ComboBoxMaskedEnumValue property.
        ''' </summary>
        Public Property ComboBoxMaskedEnum As ENSampleEnum
            Get
                Return MyBase.GetValue(ComboBoxMaskedEnumProperty)
            End Get
            Set(value As ENSampleEnum)
                MyBase.SetValue(ComboBoxMaskedEnumProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the HRadioGroupEnum property.
        ''' </summary>
        Public Property HRadioGroupEnum As ENSampleEnum
            Get
                Return MyBase.GetValue(HRadioGroupEnumProperty)
            End Get
            Set(value As ENSampleEnum)
                MyBase.SetValue(HRadioGroupEnumProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the VRadioGroupEnum property.
        ''' </summary>
        Public Property VRadioGroupEnum As ENSampleEnum
            Get
                Return MyBase.GetValue(VRadioGroupEnumProperty)
            End Get
            Set(value As ENSampleEnum)
                MyBase.SetValue(VRadioGroupEnumProperty, value)
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the value of the Angle property.
        ''' </summary>
        Public Property Angle As NAngle
            Get
                Return MyBase.GetValue(AngleProperty)
            End Get
            Set(value As NAngle)
                MyBase.SetValue(AngleProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the color property.
        ''' </summary>
        Public Property Color As NColor
            Get
                Return MyBase.GetValue(ColorProperty)
            End Get
            Set(value As NColor)
                MyBase.SetValue(ColorProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the AdvancedColor property.
        ''' </summary>
        Public Property AdvancedColor As NColor
            Get
                Return MyBase.GetValue(AdvancedColorProperty)
            End Get
            Set(value As NColor)
                MyBase.SetValue(AdvancedColorProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the Length property.
        ''' </summary>
        Public Property Length As NLength
            Get
                Return MyBase.GetValue(LengthProperty)
            End Get
            Set(value As NLength)
                MyBase.SetValue(LengthProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the Point property.
        ''' </summary>
        Public Property Point As NPoint
            Get
                Return MyBase.GetValue(PointProperty)
            End Get
            Set(value As NPoint)
                MyBase.SetValue(PointProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the size property.
        ''' </summary>
        Public Property Size As NSize
            Get
                Return MyBase.GetValue(SizeProperty)
            End Get
            Set(value As NSize)
                MyBase.SetValue(SizeProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the rectangle property.
        ''' </summary>
        Public Property Rectangle As NRectangle
            Get
                Return MyBase.GetValue(RectangleProperty)
            End Get
            Set(value As NRectangle)
                MyBase.SetValue(RectangleProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the Margins property.
        ''' </summary>
        Public Property Margins As NMargins
            Get
                Return MyBase.GetValue(MarginsProperty)
            End Get
            Set(value As NMargins)
                MyBase.SetValue(MarginsProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the MultiLength property.
        ''' </summary>
        Public Property MultiLength As NMultiLength
            Get
                Return MyBase.GetValue(MultiLengthProperty)
            End Get
            Set(value As NMultiLength)
                MyBase.SetValue(MultiLengthProperty, value)
            End Set
        End Property

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NSimpleNode.
        ''' </summary>
        Public Shared ReadOnly NSimpleNodeSchema As NSchema
        ''' <summary>
        ''' Reference to the Angle property.
        ''' </summary>
        Public Shared ReadOnly AngleProperty As NProperty
        ''' <summary>
        ''' Reference to the Boolean property.
        ''' </summary>
        Public Shared ReadOnly BooleanValueProperty As NProperty
        ''' <summary>
        ''' Reference to the Integer property.
        ''' </summary>
        Public Shared ReadOnly IntegerValueProperty As NProperty
        ''' <summary>
        ''' Reference to the Long property.
        ''' </summary>
        Public Shared ReadOnly LongValueProperty As NProperty
        ''' <summary>
        ''' Reference to the UnsignedInteger property.
        ''' </summary>
        Public Shared ReadOnly UnsignedIntegerValueProperty As NProperty
        ''' <summary>
        ''' Reference to the Single property.
        ''' </summary>
        Public Shared ReadOnly SingleValueProperty As NProperty
        ''' <summary>
        ''' Reference to the Double property.
        ''' </summary>
        Public Shared ReadOnly DoubleValueProperty As NProperty
        ''' <summary>
        ''' Reference to the SpecifiedDouble property.
        ''' </summary>
        Public Shared ReadOnly SpecifiedDoubleValueProperty As NProperty
        ''' <summary>
        ''' Reference to the Color property.
        ''' </summary>
        Public Shared ReadOnly ColorProperty As NProperty
        ''' <summary>
        ''' Reference to the AdvancedColor property.
        ''' </summary>
        Public Shared ReadOnly AdvancedColorProperty As NProperty
        ''' <summary>
        ''' Reference to the Point property.
        ''' </summary>
        Public Shared ReadOnly PointProperty As NProperty
        ''' <summary>
        ''' Reference to the ComboBoxEnum property.
        ''' </summary>
        Public Shared ReadOnly ComboBoxEnumValueProperty As NProperty
        ''' <summary>
        ''' Reference to the ComboBoxMaskedEnum property.
        ''' </summary>
        Public Shared ReadOnly ComboBoxMaskedEnumProperty As NProperty
        ''' <summary>
        ''' Reference to the HRadioGroupEnum property.
        ''' </summary>
        Public Shared ReadOnly HRadioGroupEnumProperty As NProperty
        ''' <summary>
        ''' Reference to the VRadioGroupEnum property.
        ''' </summary>
        Public Shared ReadOnly VRadioGroupEnumProperty As NProperty
        ''' <summary>
        ''' Reference to the Length property.
        ''' </summary>
        Public Shared ReadOnly LengthProperty As NProperty
        ''' <summary>
        ''' Reference to the Size property.
        ''' </summary>
        Public Shared ReadOnly SizeProperty As NProperty
        ''' <summary>
        ''' Reference to the Margins property.
        ''' </summary>
        Public Shared ReadOnly MarginsProperty As NProperty
        ''' <summary>
        ''' Reference to the Rectangle property.
        ''' </summary>
        Public Shared ReadOnly RectangleProperty As NProperty
        ''' <summary>
        ''' Reference to the MultiLength property.
        ''' </summary>
        Public Shared ReadOnly MultiLengthProperty As NProperty

#End Region

#Region "Default Values"

        Private Const defaultBoolean As Boolean = True
        Private Const defaultInteger As Integer = 0
        Private Const defaultLong As Long = 0
        Private Const defaultUnsignedInteger As UInteger = 0
        Private Const defaultSingle As Single = 0
        Private Const defaultDouble As Double = 0
        Private Const defaultSpecifiedDouble As Double = Double.NaN
        Private Const defaultComboBoxEnum As ENSampleEnum = ENSampleEnum.Option1
        Private Const DefaultComboBoxMaskedEnum As ENSampleEnum = ENSampleEnum.Option1 Or ENSampleEnum.Option2
        Private Const defaultHRadioGroupEnum As ENSampleEnum = ENSampleEnum.Option1
        Private Const defaultVRadioGroupEnum As ENSampleEnum = ENSampleEnum.Option1

        Private Shared ReadOnly defaultAngle As NAngle = NAngle.Zero
        Private Shared ReadOnly defaultColor As NColor = NColor.White
        Private Shared ReadOnly defaultAdvancedColor As NColor = NColor.Black
        Private Shared ReadOnly defaultLength As NLength = NLength.Zero
        Private Shared ReadOnly defaultMargins As NMargins = NMargins.Zero
        Private Shared ReadOnly defaultPoint As NPoint = NPoint.Zero
        Private Shared ReadOnly defaultRectangle As NRectangle = NRectangle.Zero
        Private Shared ReadOnly defaultSize As NSize = NSize.Zero
        Private Shared ReadOnly defaultMultiLength As NMultiLength = NMultiLength.NewFixed(0)

#End Region

#Region "Nested Types"

        <Flags>
        Public Enum ENSampleEnum
            None = 0
            Option1 = 1
            Option2 = 2
            Option3 = 4
            Option4 = 8
        End Enum

#End Region

#Region "Designer"

        ''' <summary>
        ''' Designer for NSimpleNode.
        ''' </summary>
        Public Class NSimpleNodeDesigner
            Inherits NDesigner
            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
                ' Categories
                SetPropertyCategory(AdvancedColorProperty, ColorsCategory)
                SetPropertyCategory(ColorProperty, ColorsCategory)

                SetPropertyCategory(ComboBoxEnumValueProperty, EnumsCategory)
                SetPropertyCategory(ComboBoxMaskedEnumProperty, EnumsCategory)
                SetPropertyCategory(HRadioGroupEnumProperty, EnumsCategory)
                SetPropertyCategory(VRadioGroupEnumProperty, EnumsCategory)

                ' Category Editors
                SetCategoryEditor(NLocalizedString.Empty, NTabCategoryEditor.HeadersTopTemplate)

                ' Property Editors
                MyBase.SetPropertyEditor(ComboBoxMaskedEnumProperty, NMaskedEnumPropertyEditor.DropDownTemplate)
                MyBase.SetPropertyEditor(SpecifiedDoubleValueProperty, NSpecifiedDoublePropertyEditor.ZeroTemplate)
                MyBase.SetPropertyEditor(AdvancedColorProperty, NColorPropertyEditor.AdvancedTemplate)
                MyBase.SetPropertyEditor(HRadioGroupEnumProperty, NEnumPropertyEditor.HorizontalRadioGroupTemplate)
                MyBase.SetPropertyEditor(VRadioGroupEnumProperty, NEnumPropertyEditor.VerticalRadioGroupTemplate)
            End Sub

            Private Shared ReadOnly ColorsCategory As NLocalizedString = New NLocalizedString("Colors")
            Private Shared ReadOnly EnumsCategory As NLocalizedString = New NLocalizedString("Enums")
        End Class

#End Region
    End Class
End Namespace
