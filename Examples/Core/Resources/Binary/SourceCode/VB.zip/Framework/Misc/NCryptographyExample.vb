Imports Nevron.Nov.Cryptography
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NCryptographyExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCryptographyExampleSchema = NSchema.Create(GetType(NCryptographyExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_DecryptedTextBox = New NTextBox("This is some text to encrypt.")
            m_DecryptedTextBox.PreferredWidth = 200
            m_DecryptedTextBox.Multiline = True
            Dim groupBox1 As NGroupBox = New NGroupBox("Decrypted Text", m_DecryptedTextBox)
            groupBox1.Padding = New NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing)

            m_EncryptedTextBox = New NTextBox()
            m_EncryptedTextBox.PreferredWidth = 200
            m_EncryptedTextBox.Multiline = True
            Dim groupBox2 As NGroupBox = New NGroupBox("Encrypted Text", m_EncryptedTextBox)
            groupBox2.Padding = New NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing)

            Dim pairBox As NPairBox = New NPairBox(groupBox1, groupBox2, ENPairBoxRelation.Box1BeforeBox2)
            pairBox.FitMode = ENStackFitMode.Equal
            pairBox.FillMode = ENStackFillMode.Equal
            pairBox.Spacing = NDesign.HorizontalSpacing
            pairBox.PreferredHeight = 300
            pairBox.VerticalPlacement = ENVerticalPlacement.Top

            Return pairBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_PasswordTextBox = New NTextBox("password")
            stack.Add(NPairBox.Create("Password", m_PasswordTextBox))

            Dim encryptButton As NButton = New NButton("Encrypt")
            encryptButton.Click += AddressOf OnEncryptButtonClick
            stack.Add(encryptButton)

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates how to encrypt and decrypt messages using the PK ZIP Classic encryption algorithm. Enter some text in the <b>Decrypted Text</b> text box and
    click the <b>Encrypt</b> button on the right to enrypt it. Then click the <b>Decrypt Button</b> to decrypt it.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEncryptButtonClick(arg As NEventArgs)
            Dim button = CType(arg.CurrentTargetNode, NButton)
            Dim label = CType(button.Content, NLabel)

            If Equals(label.Text, "Encrypt") Then
                m_EncryptedTextBox.Text = NCryptography.EncryptPkzipClassic(m_DecryptedTextBox.Text, m_PasswordTextBox.Text)
                m_DecryptedTextBox.Text = Nothing
                label.Text = "Decrypt"
            Else
                m_DecryptedTextBox.Text = NCryptography.DecryptPkzipClassic(m_EncryptedTextBox.Text, m_PasswordTextBox.Text)
                m_EncryptedTextBox.Text = Nothing
                label.Text = "Encrypt"
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_DecryptedTextBox As NTextBox
        Private m_PasswordTextBox As NTextBox
        Private m_EncryptedTextBox As NTextBox

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCryptographyExample.
        ''' </summary>
        Public Shared ReadOnly NCryptographyExampleSchema As NSchema

#End Region
    End Class
End Namespace
