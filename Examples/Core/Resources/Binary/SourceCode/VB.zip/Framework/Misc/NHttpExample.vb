Imports System

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.IO
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Networking
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NHttpExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NHttpExampleSchema = NSchema.Create(GetType(NHttpExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FitMode = ENStackFitMode.Last
            stack.FillMode = ENStackFillMode.Last

            stack.Add(CreatePredefinedRequestsWidget())
            stack.Add(CreateCustomRequestWidget())

            m_ResponseContentHolder = New NContentHolder()
            stack.Add(m_ResponseContentHolder)
            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' clear button
            Dim button As NButton = New NButton("Clear Requests")
            button.Content.HorizontalPlacement = ENHorizontalPlacement.Center
            button.Click += New [Function](Of NEventArgs)(AddressOf OnClearRequestsListBoxButtonClick)
            stack.Add(button)

            ' create the requests list box in which we add the submitted requests.
            m_RequestsListBox = New NListBox()
            stack.Add(m_RequestsListBox)

            Return New NGroupBox("Requests", stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
Demonstrates the HTTP protocol wrapper that comes along with. It allows you to make HTTP requests from a single code base.
</p>
"
        End Function

#End Region

#Region "Implementation"

#Region "Implementation - User Interface"

        Private Function CreatePredefinedRequestsWidget() As NWidget
            Dim groupBox As NGroupBox = New NGroupBox("Predefined Requests")

            Dim stack As NStackPanel = New NStackPanel()
            groupBox.Content = stack
            stack.Direction = ENHVDirection.LeftToRight

            ' get Google logo
            Dim getGoogleLogoButton As NButton = New NButton("Get Google LOGO")
            getGoogleLogoButton.Click += New [Function](Of NEventArgs)(AddressOf GetGoogleLogoClick)
            stack.Add(getGoogleLogoButton)

            ' get Google thml
            Dim getGoogleHtmlButton As NButton = New NButton("Get Google HTML")
            getGoogleHtmlButton.Click += New [Function](Of NEventArgs)(AddressOf GetGoogleHtmlClick)
            stack.Add(getGoogleHtmlButton)

            ' get wikipedia logo
            Dim getWikipediaLogoButton As NButton = New NButton("Get Wikipedia LOGO")
            getWikipediaLogoButton.Click += New [Function](Of NEventArgs)(AddressOf OnGetWikipediaLogoClick)
            stack.Add(getWikipediaLogoButton)

            ' get wikipedia home page HTML
            Dim getWikipediaHtmlButton As NButton = New NButton("Get Wikipedia HTML")
            getWikipediaHtmlButton.Click += New [Function](Of NEventArgs)(AddressOf OnGetWikipediaHtmlClick)
            stack.Add(getWikipediaHtmlButton)

            ' get wikipedia home page HTML
            Dim getNevronPieChartImage As NButton = New NButton("Get Nevron Pie Chart Image")
            getNevronPieChartImage.Click += AddressOf OnGetNevronPieChartImageClick
            stack.Add(getNevronPieChartImage)

            Return groupBox
        End Function

        Private Function CreateCustomRequestWidget() As NWidget
            Dim groupBox As NGroupBox = New NGroupBox("Request URI")

            Dim dock As NDockPanel = New NDockPanel()
            groupBox.Content = dock

            Dim label As NLabel = New NLabel("URI:")
            label.VerticalPlacement = ENVerticalPlacement.Center
            NDockLayout.SetDockArea(label, ENDockArea.Left)
            dock.Add(label)

            m_URLTextBox = New NTextBox()
            m_URLTextBox.Padding = New NMargins(0, 3, 0, 3)
            NDockLayout.SetDockArea(m_URLTextBox, ENDockArea.Center)
            dock.Add(m_URLTextBox)

            Dim submitButton As NButton = New NButton("Submit")
            NDockLayout.SetDockArea(submitButton, ENDockArea.Right)
            submitButton.Click += New [Function](Of NEventArgs)(AddressOf OnSumbitCustomRequestClick)
            dock.Add(submitButton)

            Return groupBox
        End Function

#End Region

#Region "Implementation - Event Handlers"

        Private Sub GetGoogleLogoClick(args As NEventArgs)
            ' create a HTTP request for the Google logo and subscribe for Completed event
            Dim googleLogoURI = "https://www.google.com//images//srpr//logo3w.png"
            Dim request As NHttpWebRequest = New NHttpWebRequest(googleLogoURI)
            request.Headers(NHttpHeaderFieldName.Accept) = "image/png"

            m_URLTextBox.Text = googleLogoURI

            ' create a list box item for the request, prior to submittion and submit the request
            CreateRequestUIItem(request)
            request.Submit()
        End Sub
        Private Sub GetGoogleHtmlClick(args As NEventArgs)
            ' create a HTTP request for the Google home page
            Dim googleHtmlURI = "https://www.google.com"
            Dim request As NHttpWebRequest = New NHttpWebRequest(googleHtmlURI)

            m_URLTextBox.Text = googleHtmlURI

            ' create a list box item for the request, prior to submition and submit the request
            CreateRequestUIItem(request)
            request.Submit()
        End Sub
        Private Sub OnGetWikipediaLogoClick(args As NEventArgs)
            ' create a HTTP request for the Wikipedia logo and subscribe for Completed event
            Dim wikipediaLogoURI = "https://upload.wikimedia.org//wikipedia//commons//6//63//Wikipedia-logo.png"
            Dim request As NHttpWebRequest = New NHttpWebRequest(wikipediaLogoURI)

            m_URLTextBox.Text = wikipediaLogoURI

            ' create a list box item for the request, prior to submittion and submit the request
            CreateRequestUIItem(request)
            request.Submit()
        End Sub
        Private Sub OnGetWikipediaHtmlClick(args As NEventArgs)
            ' create a HTTP request for the Wikipedia home page and subscribe for Completed event
            Dim wikipediaHtmlURI = "https://en.wikipedia.org/wiki/Main_Page"
            Dim request As NHttpWebRequest = New NHttpWebRequest(wikipediaHtmlURI)

            m_URLTextBox.Text = wikipediaHtmlURI

            ' create a list box item for the request, prior to submittion and submit the request
            CreateRequestUIItem(request)
            request.Submit()
        End Sub
        Private Sub OnGetNevronPieChartImageClick(arg As NEventArgs)
            ' create a HTTP request for the Wikipedia home page and subscribe for Completed event
            Dim nevronPieChartImage = "https://www.nevron.com//NIMG.axd?i=Chart//ChartTypes//Pie//3D_pie_cut_edge_ring.png"
            Dim request As NHttpWebRequest = New NHttpWebRequest(nevronPieChartImage)

            m_URLTextBox.Text = nevronPieChartImage

            ' create a list box item for the request, prior to submittion and submit the request
            CreateRequestUIItem(request)
            request.Submit()
        End Sub
        Private Sub OnSumbitCustomRequestClick(args As NEventArgs)
            Try
                ' create a HTTP request for the custom URI and subscribe for Completed event
                Dim uri = m_URLTextBox.Text
                Dim request As NWebRequest
                If Not NWebRequest.TryCreate(New NUri(uri), request) Then
                    NMessageBox.Show("The specified URI string is not valid for a URI request. Expected was an HTTP or File uri.", "Invalid URI", ENMessageBoxButtons.OK, ENMessageBoxIcon.Error)
                    Return
                End If

                ' create a list box item for the request, prior to submittion and submit the request
                CreateRequestUIItem(request)
                request.Submit()
            Catch ex As Exception
                NMessageBox.Show("Failed to submit custom request." & vbLf & vbLf & "Exception was: " & ex.Message, "Failed to submit custom request", ENMessageBoxButtons.OK, ENMessageBoxIcon.Error)
            End Try
        End Sub
        Private Sub OnClearRequestsListBoxButtonClick(args As NEventArgs)
            m_RequestsListBox.Items.Clear()
            m_Request2UIItem.Clear()
        End Sub

#End Region

#Region "Implementation - Requests List"

        ''' <summary>
        ''' Called when a request is about to be submitted. Adds a new entry in the requests list box.
        ''' </summary>
        ''' <paramname="request"></param>
        Private Sub CreateRequestUIItem(request As NWebRequest)
            Dim item As NUriRequestItem = New NUriRequestItem(request, m_ResponseContentHolder)
            m_RequestsListBox.Items.Add(item.ListBoxItem)
            m_Request2UIItem.Add(request, item)
        End Sub


#End Region

#End Region

#Region "Fields"

        ''' <summary>
        ''' A content holder for the content of the last completed request.
        ''' </summary>
        Private m_ResponseContentHolder As NContentHolder
        ''' <summary>
        ''' A text box in which the user enters the URI for a custom request.
        ''' </summary>
        Private m_URLTextBox As NTextBox
        ''' <summary>
        ''' The list in which we add information about the sumbitted requests.
        ''' </summary>
        Private m_RequestsListBox As NListBox
        ''' <summary>
        ''' A map for the requests 2 list box items.
        ''' </summary>
        Private m_Request2UIItem As NMap(Of NWebRequest, NUriRequestItem) = New NMap(Of NWebRequest, NUriRequestItem)()

#End Region

#Region "Schema"

        Public Shared ReadOnly NHttpExampleSchema As NSchema

#End Region

#Region "Nested Types"

        Public Class NUriRequestItem
#Region "Constructors"

            Public Sub New(request As NWebRequest, responseContentHolder As NContentHolder)
                Me.Request = request
                Me.ResponseContentHolder = responseContentHolder

                Dim groupBox As NGroupBox = New NGroupBox(New NLabel("URI: " & request.Uri.ToString()))
                groupBox.Header.MaxWidth = 350
                groupBox.HorizontalPlacement = ENHorizontalPlacement.Fit

                Dim stack As NStackPanel = New NStackPanel()
                stack.HorizontalPlacement = ENHorizontalPlacement.Fit
                groupBox.Content = stack

                Dim hstack As NStackPanel = New NStackPanel()
                hstack.Direction = ENHVDirection.LeftToRight
                hstack.HorizontalPlacement = ENHorizontalPlacement.Fit
                hstack.FillMode = ENStackFillMode.None
                hstack.FitMode = ENStackFitMode.Equal
                stack.Add(hstack)

                ' create progress bar
                ProgressBar = New NProgressBar()

                ProgressBar.PreferredHeight = 20
                ProgressBar.Minimum = 0
                ProgressBar.Maximum = 100
                stack.Add(ProgressBar)

                ' create status lable
                StatusLabel = New NLabel()
                StatusLabel.Text = " Status: Submitted"
                stack.Add(StatusLabel)

                ' create the abort button.
                AbortButton = New NButton("Abort")
                AbortButton.Click += New [Function](Of NEventArgs)(AddressOf OnAbortRequestButtonClick)
                hstack.Add(AbortButton)

                ' create view response headers button
                If TypeOf Me.Request Is NHttpWebRequest Then
                    ViewHeadersButton = New NButton("View Response Headers")
                    ViewHeadersButton.Click += New [Function](Of NEventArgs)(AddressOf OnViewResponseHeadersButtonClick)
                    hstack.Add(ViewHeadersButton)
                End If

                ' add item
                Dim item As NListBoxItem = New NListBoxItem(groupBox)
                item.BorderThickness = New NMargins(2)
                item.Border = Nothing
                ListBoxItem = item

                ' hook request events
                request.Completed += New [Function](Of NWebRequestCompletedEventArgs)(AddressOf OnRequestCompleted)
                request.StartDownload += AddressOf OnRequestStartDownload
                request.DownloadProgress += AddressOf OnRequestDownloadProgress
                request.EndDownload += AddressOf OnRequestEndDownload
            End Sub

#End Region

#Region "Event Handlers - Request"

            Private Sub OnRequestEndDownload(arg As NWebRequestDataEventArgs)
                ProgressBar.Value = 100
            End Sub

            Private Sub OnRequestDownloadProgress(arg As NWebRequestDataProgressEventArgs)
                Dim factor = arg.ProgressLength / arg.DataLength
                ProgressBar.Value = factor * 100.0R
            End Sub

            Private Sub OnRequestStartDownload(arg As NWebRequestDataEventArgs)
                ProgressBar.Value = 0
                StatusLabel.Text = " Status: Downloading Data"
            End Sub

#End Region

#Region "Event Handlers - Buttons"

            ''' <summary>
            ''' 
            ''' </summary>
            ''' <paramname="args"></param>
            Private Sub OnAbortRequestButtonClick(args As NEventArgs)
                Request.Abort()
            End Sub
            ''' <summary>
            ''' 
            ''' </summary>
            ''' <paramname="args"></param>
            Private Sub OnViewResponseHeadersButtonClick(args As NEventArgs)
                Dim httpResponse As NHttpWebResponse = TryCast(Response, NHttpWebResponse)
                If httpResponse Is Nothing Then Return

                ' create a top level window, setup as a dialog
                Dim window As NTopLevelWindow = NApplication.CreateTopLevelWindow()
                window.SetupDialogWindow(Request.Uri.ToString(), True)

                ' create a list box for the headers
                Dim listBox As NListBox = New NListBox()
                window.Content = listBox

                ' fill with header fields
                Dim it As INIterator(Of NHttpHeaderField) = httpResponse.HeaderFields.GetIterator()
                While it.MoveNext()
                    listBox.Items.Add(New NListBoxItem(it.Current.ToString()))
                End While

                ' open the window
                window.Open()
            End Sub
            ''' <summary>
            ''' Called by a NHttpRequest when it has been completed.
            ''' </summary>
            ''' <paramname="args"></param>
            Private Sub OnRequestCompleted(args As NWebRequestCompletedEventArgs)
                Response = CType(args.Response, NHttpWebResponse)

                ' highlight the completed item in red
                ListBoxItem.Border = NBorder.CreateFilledBorder(NColor.LightCoral)

                ' update the status
                StatusLabel.Text += " Status: " & Response.Status.ToString().ToString() & ", Received In: " + (Response.ReceivedAt - Request.SentAt).TotalSeconds.ToString().ToString() & " seconds"

                ' Disable the Abort button
                AbortButton.Enabled = False

                ' Enable the Headers Button
                ViewHeadersButton.Enabled = True

                ' update the response content holder
                Select Case args.Response.Status
                                            ' request has been aborted by the user -> do nothing.
                    Case ENAsyncResponseStatus.Aborted

                    Case ENAsyncResponseStatus.Failed
                        ' request has failed -> fill content with an error message
                        ResponseContentHolder.Content = New NLabel("Request for URI: " & args.Request.Uri.ToString() & " failed. Error was: " & args.Response.ErrorException.ToString().ToString())

                    Case ENAsyncResponseStatus.Succeeded
                        ' request succeded -> fill content with the response content
                        Dim httpResponse As NHttpWebResponse = TryCast(Response, NHttpWebResponse)
                        If httpResponse IsNot Nothing Then
                            HandleHttpResponse(httpResponse)
                        Else
                            Dim fileResponse As NFileWebResponse = TryCast(Response, NFileWebResponse)
                            If fileResponse IsNot Nothing Then
                                HandleFileResponse(fileResponse)
                            End If
                        End If
                End Select
            End Sub

#End Region

#Region "Implementation - Responses"

            ''' <summary>
            ''' Handles an HTTP response
            ''' </summary>
            ''' <paramname="response"></param>
            Private Sub HandleHttpResponse(httpResponse As NHttpWebResponse)
                Try
                    ' get the Content-Type Http Header field, and split it to portions
                    ' NOTE: the Content-Type is a multi value field. Values are seperated with the ';' char
                    Dim contentType = httpResponse.HeaderFields(NHttpHeaderFieldName.ContentType)
                    Dim contentTypes = contentType.Split(New Char() {";"c})

                    ' normalize content type values (trim and make lower case)
                    For i = 0 To contentTypes.Length - 1
                        contentTypes(i) = contentTypes(i).Trim()
                        contentTypes(i) = contentTypes(i).ToLower()
                    Next

                    ' the first part of the content type is the mime type of the content
                    Select Case contentTypes(0)
                        Case "image/png", "image/jpeg", "image/bmp"
                            Dim image As NImage = New NImage(New NBytesImageSource(httpResponse.DataArray))
                            Dim imageBox As NImageBox = New NImageBox(image)
                            ResponseContentHolder.Content = New NScrollContent(imageBox)

                        Case "text/html", "application/json"
                            Dim charSet = If(contentTypes.Length >= 1, contentTypes(1), "charset=utf-8")
                            Dim html = ""
                            Select Case charSet
                                Case "charset=utf-8"
                                    html = Text.NEncoding.UTF8.GetString(httpResponse.DataArray)
                                Case Else
                                    html = Text.NEncoding.UTF8.GetString(httpResponse.DataArray)
                            End Select

                            Dim textBox As NTextBox = New NTextBox()
                            textBox.Text = html
                            ResponseContentHolder.Content = textBox
                        Case Else
                    End Select
                Catch ex As Exception
                    ResponseContentHolder.Content = New NLabel("Request for URI: " & Request.Uri.ToString() & " decoding failed. Error was: " & ex.Message.ToString())
                End Try
            End Sub
            ''' <summary>
            ''' Handles a File response
            ''' </summary>
            ''' <paramname="fileResponse"></param>
            Private Sub HandleFileResponse(fileResponse As NFileWebResponse)
                Dim extension As String = NPath.Current.GetExtension(Request.Uri.GetLocalPath())

                Select Case extension
                    Case "png", "jpeg", "bmp"
                        Dim image As NImage = New NImage(New NBytesImageSource(fileResponse.DataArray))
                        Dim imageBox As NImageBox = New NImageBox(image)
                        ResponseContentHolder.Content = New NScrollContent(imageBox)

                    Case "html", "json", "txt"
                        Dim html = Text.NEncoding.UTF8.GetString(fileResponse.DataArray)
                        Dim textBox As NTextBox = New NTextBox()
                        textBox.Text = html
                        ResponseContentHolder.Content = textBox
                    Case Else
                End Select
            End Sub

#End Region

#Region "Fields"

            Public ReadOnly ResponseContentHolder As NContentHolder
            Public ReadOnly Request As NWebRequest
            Public ReadOnly ListBoxItem As NListBoxItem
            Public ReadOnly ProgressBar As NProgressBar
            Public ReadOnly StatusLabel As NLabel
            Public ReadOnly AbortButton As NButton
            Public ReadOnly ViewHeadersButton As NButton

            Public Response As NWebResponse

#End Region
        End Class

#End Region
    End Class
End Namespace
