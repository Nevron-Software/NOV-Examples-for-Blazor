Imports System
Imports System.IO

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Serialization
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    ''' <summary>
    ''' The example demonstrates how to serialize / deserialize .NET (CLR) objects
    ''' </summary>
    Public Class NCLRSerializationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NCLRSerializationExampleSchema = NSchema.Create(GetType(NCLRSerializationExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Overrides"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.VerticalPlacement = ENVerticalPlacement.Top
            stack.MinWidth = 400

            m_NameTextBox = New NTextBox()
            m_AddressTextBox = New NTextBox()
            m_MarriedCheckBox = New NCheckBox()
            m_GenderComboBox = New NComboBox()
            m_GenderComboBox.Items.Add(New NComboBoxItem("Male"))
            m_GenderComboBox.Items.Add(New NComboBoxItem("Female"))
            m_GenderComboBox.SelectedIndex = 0

            m_ProfessionComboBox = New NComboBox()
            m_ProfessionComboBox.FillFromEnum(Of Profession)()
            m_ProfessionComboBox.SelectedIndex = 0

            m_OtherTextBox = New NTextBox()

            stack.Add(New NPairBox(New NLabel("Name (string):"), m_NameTextBox, True))
            stack.Add(New NPairBox(New NLabel("Address (string):"), m_AddressTextBox, True))
            stack.Add(New NPairBox(New NLabel("Married (boolean):"), m_MarriedCheckBox, True))
            stack.Add(New NPairBox(New NLabel("Gender (singleton):"), m_GenderComboBox, True))
            stack.Add(New NPairBox(New NLabel("Profession (enum):"), m_ProfessionComboBox, True))
            stack.Add(New NPairBox(New NLabel("Other (string, non serialized):"), m_OtherTextBox, True))

            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim saveStateButton As NButton = New NButton("Save")
            saveStateButton.Click += New [Function](Of NEventArgs)(AddressOf OnSaveStateButtonClick)
            stack.Add(saveStateButton)

            Dim loadStateButton As NButton = New NButton("Load")
            loadStateButton.Click += New [Function](Of NEventArgs)(AddressOf OnLoadStateButtonClick)
            stack.Add(loadStateButton)

            Return stack
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to use CLR serialization in order to serialize .NET objects.</p>
<p>Press the ""Save"" button to save the current state of the form.</p>
<p>Press the ""Load"" button to load a previously loaded form state.</p>
<p><b>Note:</b> The value of ""Other"" is not persisted, because this field is marked as non serialized.</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSaveStateButtonClick(arg1 As NEventArgs)
            Try
                m_MemoryStream = New MemoryStream()

                Dim serializer As NSerializer = New NSerializer()

                Dim serializationObject As PersonInfo = New PersonInfo(m_NameTextBox.Text, m_AddressTextBox.Text, m_MarriedCheckBox.Checked, If(m_GenderComboBox.SelectedIndex = 0, GenderSingleton.Male, GenderSingleton.Female), CType((GetType(Profession).GetEnumValues().GetValue(m_ProfessionComboBox.SelectedIndex)), Profession), m_OtherTextBox.Text)

                serializer.SaveToStream(serializationObject, m_MemoryStream, ENPersistencyFormat.Binary)
            Catch ex As Exception
                NDebug.WriteLine(ex.Message)
            End Try
        End Sub

        Private Sub OnLoadStateButtonClick(arg1 As NEventArgs)
            If m_MemoryStream Is Nothing Then Return

            m_MemoryStream.Seek(0, SeekOrigin.Begin)

            Dim deserializer As NDeserializer = New NDeserializer()
            Dim serializationObject = CType(deserializer.LoadFromStream(m_MemoryStream, ENPersistencyFormat.Binary), PersonInfo)

            m_NameTextBox.Text = serializationObject.Name
            m_AddressTextBox.Text = serializationObject.Address
            m_MarriedCheckBox.Checked = serializationObject.Married
            m_GenderComboBox.SelectedIndex = If(serializationObject.Gender Is GenderSingleton.Male, 0, 1)

            ' intentionally done this way to test serialization of UInt64 based enums
            Dim index = 0
            For Each profession As Profession In GetType(Profession).GetEnumValues()
                If profession = serializationObject.Profession Then
                    m_ProfessionComboBox.SelectedIndex = index
                    Exit For
                End If
                index += 1
            Next

            m_OtherTextBox.Text = serializationObject.Other
        End Sub

#End Region

#Region "Nested Types"

        ''' <summary>
        ''' Represents a singleton object
        ''' </summary>
        Public Class GenderSingleton
#Region "Constructors"

            ''' <summary>
            ''' Initializer constructor
            ''' </summary>
            ''' <paramname="genderName"></param>
            Private Sub New(genderName As String)
                m_GenderName = genderName
            End Sub

#End Region

#Region "Static Methods"

            Public Shared Function GetSurrogateSerializer(singleton As GenderSingleton) As Object
                Return New GenderSurrogate(singleton)
            End Function

#End Region

#Region "Fields"

            Private m_GenderName As String

#End Region

#Region "Static Fields"

            Public Shared Male As GenderSingleton = New GenderSingleton("Male")
            Public Shared Female As GenderSingleton = New GenderSingleton("Female")

#End Region
        End Class
        ''' <summary>
        ''' Represents a class used to perform the actual serialization of the NGenderSingleton class
        ''' </summary>
        Public Class GenderSurrogate
            Implements INSurrogateSerializer
#Region "Constructors"

            ''' <summary>
            ''' Default constructor
            ''' </summary>
            Public Sub New()

            End Sub
            ''' <summary>
            ''' Initializer constructor
            ''' </summary>
            ''' <paramname="instance"></param>
            Public Sub New(instance As GenderSingleton)
                IsMale = instance Is GenderSingleton.Male
            End Sub

#End Region

#Region "INSurrogateSerializer"

            Public Function GetRealObject() As Object Implements INSurrogateSerializer.GetRealObject
                If IsMale Then
                    Return GenderSingleton.Male
                Else
                    Return GenderSingleton.Female
                End If
            End Function

            Public Sub ApplyToRealObject(obj As Object) Implements INSurrogateSerializer.ApplyToRealObject
                ' not implemented
            End Sub

#End Region

#Region "Fields"

            Public IsMale As Boolean

#End Region
        End Class

        Public Enum Profession As ULong
            Architect
            Businessman
            Dentist
            Developer = UInteger.MaxValue
        End Enum

        ''' <summary>
        ''' Represents a class showing some 
        ''' </summary>
        Public Class PersonInfo
#Region "Constructors"

            ''' <summary>
            ''' Default constructor
            ''' </summary>
            Public Sub New()

            End Sub
            ''' <summary>
            ''' Initializer constructor
            ''' </summary>
            ''' <paramname="name"></param>
            ''' <paramname="address"></param>
            ''' <paramname="married"></param>
            ''' <paramname="gender"></param>
            ''' <paramname="profession"></param>
            ''' <paramname="other"></param>
            Public Sub New(name As String, address As String, married As Boolean, gender As GenderSingleton, profession As Profession, other As String)
                Me.Name = name
                Me.Address = address
                Me.Married = married
                Me.Gender = gender
                Me.Profession = profession
                Me.Other = other
            End Sub

#End Region

#Region "Fields"

            Public Name As String
            Public Address As String
            Public Married As Boolean
            Public Gender As GenderSingleton
            Public Profession As Profession

            <NNonSerialized>
            Public Other As String

#End Region
        End Class

#End Region

#Region "Fields"

        Private m_NameTextBox As NTextBox
        Private m_AddressTextBox As NTextBox
        Private m_MarriedCheckBox As NCheckBox
        Private m_GenderComboBox As NComboBox
        Private m_ProfessionComboBox As NComboBox
        Private m_OtherTextBox As NTextBox

        Private m_MemoryStream As MemoryStream

#End Region

#Region "Static"

        Public Shared ReadOnly NCLRSerializationExampleSchema As NSchema

#End Region
    End Class
End Namespace
