Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NStrokeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default Constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static Constructor.
        ''' </summary>
        Shared Sub New()
            NStrokeExampleSchema = NSchema.Create(GetType(NStrokeExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim width As Double = 1
            Dim color = NColor.Black

            m_arrStrokes = New NStroke() {New NStroke(width, color, ENDashStyle.Solid), New NStroke(width, color, ENDashStyle.Dot), New NStroke(width, color, ENDashStyle.Dash), New NStroke(width, color, ENDashStyle.DashDot), New NStroke(width, color, ENDashStyle.DashDotDot), New NStroke(width, color, New NDashPattern(2, 2, 2, 2, 0, 2))}

            m_EditStroke = New NStroke()
            m_EditStroke.Width = width
            m_EditStroke.Color = color
            m_EditStroke.DashCap = ENLineCap.Square
            m_EditStroke.StartCap = ENLineCap.Square
            m_EditStroke.EndCap = ENLineCap.Square

            For i = 0 To m_arrStrokes.Length - 1
                Dim stroke = m_arrStrokes(i)
                stroke.DashCap = m_EditStroke.DashCap
                stroke.StartCap = m_EditStroke.StartCap
                stroke.EndCap = m_EditStroke.EndCap
            Next

            m_LabelFont = New NFont(NFontDescriptor.DefaultSansFamilyName, 12, ENFontStyle.Bold)
            m_LabelFill = New NColorFill(ENNamedColor.Black)

            m_CanvasStack = New NStackPanel()
            m_CanvasStack.FillMode = ENStackFillMode.None
            m_CanvasStack.FitMode = ENStackFitMode.None

            Dim preferredSize = GetCanvasPreferredSize(m_EditStroke.Width)

            For i = 0 To m_arrStrokes.Length - 1
                Dim canvas As NCanvas = New NCanvas()
                canvas.PrePaint += New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
                canvas.PreferredSize = preferredSize
                canvas.Tag = m_arrStrokes(i)
                canvas.BackgroundFill = New NColorFill(NColor.White)
                m_CanvasStack.Add(canvas)
            Next

            ' The stack must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_CanvasStack
            Return scroll
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None

            ' get editors for stroke properties
            Dim editors = NDesigner.GetDesigner(m_EditStroke).CreatePropertyEditors(m_EditStroke, NStroke.WidthProperty, NStroke.ColorProperty, NStroke.DashCapProperty, NStroke.StartCapProperty, NStroke.EndCapProperty, NStroke.LineJoinProperty)

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            m_EditStroke.Changed += New [Function](Of NEventArgs)(AddressOf OnEditStrokeChanged)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to use strokes. You can specify the width and the color of a stroke,
	as well as its dash properties. NOV supports the following dash styles:
	<ul>
		<li>Solid - specifies a solid line.</li>
		<li>Dash - specifies a line consisting of dashes.</li>
		<li>Dot - specifies a line consisting of dots.</li>
		<li>DashDot - specifies a line consisting of a repeating pattern of dash-dot.</li>
		<li>DashDotDot - specifies a line consisting of a repeating pattern of dash-dot-dot.</li>
		<li>Custom - specifies a user-defined custom dash style.</li>
	</ul>

	Use the controls to the right to modify various properties of the stroke.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return

            Dim stroke As NStroke = canvas.Tag

            Dim visitor = args.PaintVisitor
            visitor.SetStroke(stroke)
            visitor.SetFill(Nothing)

            Dim strokeWidth = stroke.Width
            Dim rectWidth As Double = 300
            Dim ellipseWidth As Double = 150
            Dim polylineWidth As Double = 180
            Dim dist As Double = 20

            Dim x1 = 10 + strokeWidth / 2
            Dim x2 = x1 + rectWidth + dist + strokeWidth
            Dim x3 = x2 + ellipseWidth
            Dim x4 = x3 + dist + strokeWidth
            Dim x5 = x4 + polylineWidth + dist + strokeWidth / 2
            Dim y1 = 10 + strokeWidth / 2
            Dim y2 = y1 + strokeWidth + 10
            Dim y3 = y1 + 50

            ' draw a horizontal line
            visitor.PaintLine(x1, y1, x3, y1)

            ' draw a rectangle
            visitor.PaintRectangle(x1, y2, rectWidth, 100)

            ' draw an ellipse
            visitor.PaintEllipse(x2, y2, ellipseWidth, 100)

            ' draw a polyline
            Dim polyLine As NPolyline = New NPolyline(4)
            polyLine.Add(New NPoint(x4, y2 + 90))
            polyLine.Add(New NPoint(x4 + 60, y2))
            polyLine.Add(New NPoint(x4 + 120, y2 + 90))
            polyLine.Add(New NPoint(x4 + 180, y2))
            visitor.PaintPolyline(polyLine)

            ' draw text
            Dim dashStyleName As String = stroke.DashStyle.ToString()

            visitor.ClearStroke()
            visitor.SetFont(m_LabelFont)
            visitor.SetFill(m_LabelFill)

            Dim settings As NPaintTextRectSettings = New NPaintTextRectSettings()
            visitor.PaintString(New NRectangle(x5, y3, 200, 50), dashStyleName, settings)
        End Sub
        Private Sub OnEditStrokeChanged(args As NEventArgs)
            Dim localValueChangeArgs As NValueChangeEventArgs = TryCast(args, NValueChangeEventArgs)

            If localValueChangeArgs IsNot Nothing Then
                For i = 0 To m_arrStrokes.Length - 1
                    Dim stroke = m_arrStrokes(i)
                    stroke.SetValue(localValueChangeArgs.Property, localValueChangeArgs.NewValue)

                    Dim canvas As NCanvas = TryCast(m_CanvasStack(i), NCanvas)
                    Dim strokeWidth = stroke.Width

                    If strokeWidth < 0 Then strokeWidth = 0

                    canvas.PreferredSize = GetCanvasPreferredSize(strokeWidth)

                    If canvas IsNot Nothing Then
                        canvas.InvalidateDisplay()
                    End If
                Next
            End If
        End Sub

#End Region

#Region "Implementation"

        Private Function GetCanvasPreferredSize(strokeWidth As Double) As NSize
            Return New NSize(850 + 3 * strokeWidth, 150 + 2 * strokeWidth)
        End Function

#End Region

#Region "Fields"

        Private m_LabelFont As NFont
        Private m_LabelFill As NFill
        Private m_EditStroke As NStroke
        Private m_arrStrokes As NStroke()
        Private m_CanvasStack As NStackPanel

#End Region

#Region "Schema"

        Public Shared ReadOnly NStrokeExampleSchema As NSchema

#End Region
    End Class
End Namespace
