Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NTransformationsAndClippingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTransformationsAndClippingExampleSchema = NSchema.Create(GetType(NTransformationsAndClippingExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_PositionX = 100
            m_PositionY = 220
            m_Angle1 = -50
            m_Angle2 = 40
            m_Angle3 = 90
            m_ClipRect = New NRectangle(20, 20, 500, 360)

            m_Canvas = New NCanvas()
            m_Canvas.PreferredSize = New NSize(600, 400)
            m_Canvas.BackgroundFill = New NColorFill(New NColor(220, 220, 200))
            m_Canvas.HorizontalPlacement = ENHorizontalPlacement.Center
            m_Canvas.VerticalPlacement = ENVerticalPlacement.Center
            m_Canvas.PrePaint += New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)

            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Canvas
            scroll.NoScrollHAlign = ENNoScrollHAlign.Center
            scroll.NoScrollVAlign = ENNoScrollVAlign.Center
            Return scroll
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            m_PositionXUpDown = CreateNumericUpDown(40, 400, m_PositionX)
            m_PositionYUpDown = CreateNumericUpDown(100, 300, m_PositionY)
            m_Angle1UpDown = CreateNumericUpDown(-90, -10, m_Angle1)
            m_Angle2UpDown = CreateNumericUpDown(-100, 100, m_Angle2)
            m_Angle3UpDown = CreateNumericUpDown(-100, 100, m_Angle3)

            Dim roboArmControlsStack As NStackPanel = New NStackPanel()
            roboArmControlsStack.Add(NPairBox.Create("X:", m_PositionXUpDown))
            roboArmControlsStack.Add(NPairBox.Create("Y:", m_PositionYUpDown))
            roboArmControlsStack.Add(NPairBox.Create("Angle 1:", m_Angle1UpDown))
            roboArmControlsStack.Add(NPairBox.Create("Angle 2:", m_Angle2UpDown))
            roboArmControlsStack.Add(NPairBox.Create("Angle 3:", m_Angle3UpDown))

            Dim roboArmGroupBox As NGroupBox = New NGroupBox("Robo Arm")
            roboArmGroupBox.Content = roboArmControlsStack

            m_ClipRectXUpDown = CreateNumericUpDown(0, 600, m_ClipRect.X)
            m_ClipRectYUpDown = CreateNumericUpDown(0, 400, m_ClipRect.Y)
            m_ClipRectWUpDown = CreateNumericUpDown(0, 600, m_ClipRect.Width)
            m_ClipRectHUpDown = CreateNumericUpDown(0, 400, m_ClipRect.Height)

            Dim clipRectControlsStack As NStackPanel = New NStackPanel()
            clipRectControlsStack.Add(NPairBox.Create("X:", m_ClipRectXUpDown))
            clipRectControlsStack.Add(NPairBox.Create("Y:", m_ClipRectYUpDown))
            clipRectControlsStack.Add(NPairBox.Create("Width:", m_ClipRectWUpDown))
            clipRectControlsStack.Add(NPairBox.Create("Height:", m_ClipRectHUpDown))

            Dim clipRectGroupBox As NGroupBox = New NGroupBox("Clip Rect")
            clipRectGroupBox.Content = clipRectControlsStack

            ' create a stack and put the controls in it
            Dim stack As NStackPanel = New NStackPanel()
            stack.Add(roboArmGroupBox)
            stack.Add(clipRectGroupBox)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates geometric transforms and clipping with the NOV graphics.
</p>
"
        End Function


#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return

            canvas.HorizontalPlacement = ENHorizontalPlacement.Center
            canvas.VerticalPlacement = ENVerticalPlacement.Center

            Dim pv = args.PaintVisitor
            pv.ClearStyles()
            pv.SetStroke(NColor.MidnightBlue, 1)
            pv.SetFill(NColor.LightSteelBlue)

            Dim m1 = NMatrix.Identity
            m1.Rotate(NAngle.Degree2Rad * m_Angle1)

            Dim m2 = NMatrix.Identity
            m2.Rotate(NAngle.Degree2Rad * m_Angle2)
            m2.Translate(100, 0)

            Dim m3 = NMatrix.Identity
            m3.Rotate(NAngle.Degree2Rad * m_Angle3)
            m3.Translate(100, 0)

            Dim clipRegion = NRegion.FromRectangle(m_ClipRect)

            pv.PushClip(clipRegion)

            pv.PushTransform(New NMatrix(m_PositionX, 0))
            PaintVerticalBar(pv)

            pv.PushTransform(New NMatrix(0, m_PositionY))
            PaintBase(pv)

            pv.PushTransform(m1)
            PaintLink(pv, 20)
            PaintJoint(pv, 20)

            pv.PushSnapToPixels(False)
            pv.PushTransform(m2)
            PaintLink(pv, 16)
            PaintJoint(pv, 16)

            pv.PushTransform(m3)
            PaintGripper(pv)
            PaintJoint(pv, 12)

            pv.PopTransform() ' m3
            pv.PopTransform() ' m2
            pv.PopTransform() ' m1
            pv.PopTransform() ' mTY
            pv.PopTransform() ' mTX
            pv.PopSnapToPixels()
            pv.PopClip()

            ' paint a border around the clip rectangle
            pv.ClearFill()
            pv.SetStroke(NColor.Red, 1)
            pv.PaintRectangle(m_ClipRect)

            ' paint a border around the canvas
            pv.SetStroke(NColor.Black, 1)
            pv.PaintRectangle(0, 0, canvas.Width, canvas.Height)
        End Sub
        Private Sub OnNumericUpDownValueChanged(args As NValueChangeEventArgs)
            If m_Canvas Is Nothing Then Return

            m_PositionX = m_PositionXUpDown.Value
            m_PositionY = m_PositionYUpDown.Value
            m_Angle1 = m_Angle1UpDown.Value
            m_Angle2 = m_Angle2UpDown.Value
            m_Angle3 = m_Angle3UpDown.Value

            m_ClipRect.X = m_ClipRectXUpDown.Value
            m_ClipRect.Y = m_ClipRectYUpDown.Value
            m_ClipRect.Width = m_ClipRectWUpDown.Value
            m_ClipRect.Height = m_ClipRectHUpDown.Value

            m_Canvas.InvalidateDisplay()
        End Sub

#End Region

#Region "Implementation"

        Private Sub PaintJoint(pv As NPaintVisitor, radius As Double)
            Dim innerR = radius - 3

            pv.PaintEllipse(-radius, -radius, 2 * radius, 2 * radius)
            pv.PaintEllipse(-innerR, -innerR, 2 * innerR, 2 * innerR)
        End Sub
        Private Sub PaintLink(pv As NPaintVisitor, radius As Double)
            Dim r = radius - 8
            pv.PaintRectangle(0, -r, 100, 2 * r)
        End Sub
        Private Sub PaintGripper(pv As NPaintVisitor)
            If m_ArmGripperPath Is Nothing Then
                m_ArmGripperPath = New NGraphicsPath()
                m_ArmGripperPath.StartFigure(0, -6)
                m_ArmGripperPath.LineTo(20, -6)
                m_ArmGripperPath.LineTo(20, -14)
                m_ArmGripperPath.LineTo(30, -14)
                m_ArmGripperPath.LineTo(30, 14)
                m_ArmGripperPath.LineTo(20, 14)
                m_ArmGripperPath.LineTo(20, 6)
                m_ArmGripperPath.LineTo(0, 6)
                m_ArmGripperPath.CloseFigure()

                m_ArmGripperPath.StartFigure(30, -14)
                m_ArmGripperPath.LineTo(40, -14)
                m_ArmGripperPath.LineTo(50, -10)
                m_ArmGripperPath.LineTo(50, -7)
                m_ArmGripperPath.LineTo(30, -7)
                m_ArmGripperPath.CloseFigure()

                m_ArmGripperPath.StartFigure(30, 14)
                m_ArmGripperPath.LineTo(40, 14)
                m_ArmGripperPath.LineTo(50, 10)
                m_ArmGripperPath.LineTo(50, 7)
                m_ArmGripperPath.LineTo(30, 7)
                m_ArmGripperPath.CloseFigure()
            End If

            pv.PaintPath(m_ArmGripperPath)
        End Sub
        Private Sub PaintBase(pv As NPaintVisitor)
            If m_ArmBasePath Is Nothing Then
                m_ArmBasePath = New NGraphicsPath()
                m_ArmBasePath.StartFigure(0, 0)
                m_ArmBasePath.LineTo(-40, 0)
                m_ArmBasePath.LineTo(-40, 50)
                m_ArmBasePath.LineTo(25, 50)
                m_ArmBasePath.LineTo(25, 20)
                m_ArmBasePath.CloseFigure()
            End If

            pv.PaintPath(m_ArmBasePath)
        End Sub
        Private Sub PaintVerticalBar(pv As NPaintVisitor)
            pv.PaintRectangle(-35, 0, 8, 400)
        End Sub

        Private Function CreateNumericUpDown(min As Double, max As Double, value As Double) As NNumericUpDown
            Dim control As NNumericUpDown = New NNumericUpDown()
            control.Minimum = min
            control.Maximum = max
            control.Value = value
            control.Step = 1
            control.DecimalPlaces = 0
            control.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)
            Return control
        End Function

#End Region

#Region "Fields"

        Private m_Canvas As NCanvas
        Private m_PositionXUpDown As NNumericUpDown
        Private m_PositionYUpDown As NNumericUpDown
        Private m_Angle1UpDown As NNumericUpDown
        Private m_Angle2UpDown As NNumericUpDown
        Private m_Angle3UpDown As NNumericUpDown
        Private m_ClipRectXUpDown As NNumericUpDown
        Private m_ClipRectYUpDown As NNumericUpDown
        Private m_ClipRectWUpDown As NNumericUpDown
        Private m_ClipRectHUpDown As NNumericUpDown

        Private m_ArmBasePath As NGraphicsPath
        Private m_ArmGripperPath As NGraphicsPath

        Private m_PositionX As Double
        Private m_PositionY As Double
        Private m_Angle1 As Double
        Private m_Angle2 As Double
        Private m_Angle3 As Double
        Private m_ClipRect As NRectangle

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTransformationsAndClippingExample.
        ''' </summary>
        Public Shared ReadOnly NTransformationsAndClippingExampleSchema As NSchema

#End Region
    End Class
End Namespace
