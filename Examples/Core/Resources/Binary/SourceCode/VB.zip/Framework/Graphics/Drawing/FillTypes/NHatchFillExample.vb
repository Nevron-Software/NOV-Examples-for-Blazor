Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NHatchFillExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NHatchFillExampleSchema = NSchema.Create(GetType(NHatchFillExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Get the fill styles
            Dim hatches As ENHatchStyle() = NEnum.GetValues(Of ENHatchStyle)()
            Dim count = hatches.Length

            ' Create a table layout panel
            m_Table = New NTableFlowPanel()
            m_Table.HorizontalPlacement = ENHorizontalPlacement.Left
            m_Table.VerticalPlacement = ENVerticalPlacement.Top
            m_Table.Padding = New NMargins(30)
            m_Table.HorizontalSpacing = 30
            m_Table.VerticalSpacing = 30
            m_Table.MaxOrdinal = 6

            ' Add widgets with the proper filling and names to the panel

            For i = 0 To count - 1
                Dim stack As NStackPanel = New NStackPanel()
                m_Table.Add(stack)
                stack.Direction = ENHVDirection.TopToBottom
                stack.FillMode = ENStackFillMode.First
                stack.FitMode = ENStackFitMode.First

                ' Create a widget with the proper filling
                Dim canvas As NCanvas = New NCanvas()
                canvas.PreferredSize = New NSize(defaultCanvasWidth, defaultCanvasHeight)
                canvas.Tag = New NHatchFill(hatches(i), defaultForegroundColor, defaultBackgroundColor)
                stack.Add(canvas)
                canvas.PrePaint += New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)

                ' Create a label with the corresponding name
                Dim label As NLabel = New NLabel(hatches(i).ToString())
                stack.Add(label)
                label.HorizontalPlacement = ENHorizontalPlacement.Center
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Table
            Return scroll
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            ' Create background color editor
            Dim colorBox1 As NColorBox = New NColorBox()
            colorBox1.SelectedColor = defaultBackgroundColor
            colorBox1.Tag = NHatchFill.BackgroundColorProperty
            colorBox1.SelectedColorChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnColorBoxSelectedColorChanged)

            ' Create foreground color editor
            Dim colorBox2 As NColorBox = New NColorBox()
            colorBox2.SelectedColor = defaultForegroundColor
            colorBox2.Tag = NHatchFill.ForegroundColorProperty
            colorBox2.SelectedColorChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnColorBoxSelectedColorChanged)

            ' Canvas width editor
            m_CanvasWidthUpDown = New NNumericUpDown()
            m_CanvasWidthUpDown.Minimum = 100
            m_CanvasWidthUpDown.Maximum = 300
            m_CanvasWidthUpDown.Value = defaultCanvasWidth
            m_CanvasWidthUpDown.Step = 1
            m_CanvasWidthUpDown.DecimalPlaces = 0
            m_CanvasWidthUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' Canvas height editor
            m_CanvasHeightUpDown = New NNumericUpDown()
            m_CanvasHeightUpDown.Minimum = 100
            m_CanvasHeightUpDown.Maximum = 300
            m_CanvasHeightUpDown.Value = defaultCanvasHeight
            m_CanvasHeightUpDown.Step = 1
            m_CanvasHeightUpDown.DecimalPlaces = 0
            m_CanvasHeightUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' create a stack and put the controls in it
            Dim stack As NStackPanel = New NStackPanel()
            stack.Add(NPairBox.Create("Background Color:", colorBox1))
            stack.Add(NPairBox.Create("ForegroundColor:", colorBox2))
            stack.Add(NPairBox.Create("Canvas Width:", m_CanvasWidthUpDown))
            stack.Add(NPairBox.Create("Canvas Height:", m_CanvasHeightUpDown))

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example shows the hatch fillings supported by NOV. Use the controls in the right-side panel to specify the background
	and the foreground colors of the hatches.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return

            Dim fill As NFill = canvas.Tag

            args.PaintVisitor.ClearStyles()
            args.PaintVisitor.SetFill(fill)
            args.PaintVisitor.PaintRectangle(0, 0, canvas.Width, canvas.Height)
        End Sub
        Private Sub OnColorBoxSelectedColorChanged(args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return

            Dim color As NColor = args.NewValue
            Dim colorBox = CType(args.TargetNode, NColorBox)
            Dim [property] As NProperty = colorBox.Tag

            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                CType(canvas.Tag, NHatchFill).SetValue([property], color)
                canvas.InvalidateDisplay()
            End While
        End Sub
        Private Sub OnNumericUpDownValueChanged(args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return

            Dim width = m_CanvasWidthUpDown.Value
            Dim height = m_CanvasHeightUpDown.Value

            ' Resize the canvases
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                CType(canvas.ParentNode, NWidget).PreferredWidth = width
                canvas.PreferredHeight = height
            End While
        End Sub

#End Region

#Region "Fields"

        Private m_Table As NTableFlowPanel
        Private m_CanvasWidthUpDown As NNumericUpDown
        Private m_CanvasHeightUpDown As NNumericUpDown

#End Region

#Region "Constants"

        Const defaultCanvasWidth As Integer = 140
        Const defaultCanvasHeight As Integer = 140

        Private Shared ReadOnly defaultForegroundColor As NColor = New NColor(10, 30, 54)
        Private Shared ReadOnly defaultBackgroundColor As NColor = New NColor(208, 217, 234)

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NHatchFillExample.
        ''' </summary>
        Public Shared ReadOnly NHatchFillExampleSchema As NSchema

#End Region
    End Class
End Namespace
