Imports System
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NAreaOperationsExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NAreaOperationsExampleSchema = NSchema.Create(GetType(NAreaOperationsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_InputPaths = New NList(Of NGraphicsPath)()
            m_OutputPath = New NGraphicsPath()

            m_Canvas = New NCanvas()
            m_Canvas.HorizontalPlacement = ENHorizontalPlacement.Fit
            m_Canvas.VerticalPlacement = ENVerticalPlacement.Fit
            m_Canvas.PrePaint += New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
            m_Canvas.BackgroundFill = New NColorFill(NColor.White)

            Dim scrollContent As NScrollContent = New NScrollContent()
            scrollContent.Content = m_Canvas

            ' Add 3 circles
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddCircle(100, 100, 100)
            m_InputPaths.Add(path)

            path = New NGraphicsPath()
            path.AddCircle(250, 100, 100)
            m_InputPaths.Add(path)

            Return scrollContent
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None

            m_OperatorCombo = New NComboBox()
            m_OperatorCombo.Items.Add(New NComboBoxItem("Union"))
            m_OperatorCombo.Items.Add(New NComboBoxItem("Intersect"))
            m_OperatorCombo.Items.Add(New NComboBoxItem("Subtract"))
            m_OperatorCombo.Items.Add(New NComboBoxItem("Exclusive OR"))
            m_OperatorCombo.SelectedIndex = 0
            m_OperatorCombo.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnAreaOperatorComboSelectedIndexChanged)
            stack.Add(m_OperatorCombo)

            ' random path creation
            Dim randomRectButton As NButton = New NButton("Random Rectangle")
            randomRectButton.Click += New [Function](Of NEventArgs)(AddressOf OnRandomRectButtonClick)
            stack.Add(randomRectButton)

            Dim randomEllipseButton As NButton = New NButton("Random Ellipse")
            randomEllipseButton.Click += New [Function](Of NEventArgs)(AddressOf OnRandomEllipseButtonClick)
            stack.Add(randomEllipseButton)

            Dim randomTriangleButton As NButton = New NButton("Random Triangle")
            randomTriangleButton.Click += New [Function](Of NEventArgs)(AddressOf OnRandomTriangleButtonClick)
            stack.Add(randomTriangleButton)

            Dim clearButton As NButton = New NButton("Clear")
            clearButton.Click += New [Function](Of NEventArgs)(AddressOf OnClearButtonClick)
            stack.Add(clearButton)

            m_ShowInputPathInteriors = New NCheckBox("Show Input Path Interiors")
            m_ShowInputPathInteriors.Checked = True
            m_ShowInputPathInteriors.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowInputPathInteriorsCheckedChanged)
            stack.Add(m_ShowInputPathInteriors)

            m_ShowInputPathOutlines = New NCheckBox("Show Input Path Outlines")
            m_ShowInputPathOutlines.Checked = True
            m_ShowInputPathOutlines.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowInputPathOutlinesCheckedChanged)
            stack.Add(m_ShowInputPathOutlines)

            m_ShowOutputPathOutline = New NCheckBox("Show Output Path Outline")
            m_ShowOutputPathOutline.Checked = True
            m_ShowOutputPathOutline.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowInputPathInteriorsCheckedChanged)
            stack.Add(m_ShowOutputPathOutline)

            m_ShowOutputPathInterior = New NCheckBox("Show Output Path Interior")
            m_ShowOutputPathInterior.Checked = True
            m_ShowOutputPathInterior.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowInputPathInteriorsCheckedChanged)
            stack.Add(m_ShowOutputPathInterior)

            UpdateOuputPath()

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
Demonstrates the Area Set Operations implemented by the NRegion class. Area Set Operations are performed on the closed areas represented by regions. 
Via these operations you can construct very complex solid geometries by combining primitive ones.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Sub UpdateOuputPath()
            Dim bounds As NRectangle = New NRectangle()
            Dim count = m_InputPaths.Count

            ' compute the ouput path and the bounds
            If count <> 0 Then
                Dim result = NRegion.FromPath(m_InputPaths(0), ENFillRule.EvenOdd)
                bounds = result.Bounds

                For i = 1 To count - 1
                    Dim operand = NRegion.FromPath(m_InputPaths(i), ENFillRule.EvenOdd)
                    bounds = NRectangle.Union(bounds, operand.Bounds)

                    Select Case m_OperatorCombo.SelectedIndex
                        Case 0 ' union
                            result = result.Union(operand)
                        Case 1 ' intersection
                            result = result.Intersect(operand)
                        Case 2
                            result = result.Subtract(operand)
                        Case 3
                            result = result.ExclusiveOr(operand)
                    End Select
                Next

                m_OutputPath = New NGraphicsPath(result.GetPath())
            Else
                m_OutputPath = New NGraphicsPath()
            End If

            ' normalize the coordinates
            For i = 0 To count - 1
                Dim path = m_InputPaths(i)
                'NRectangle pathBounds = path.GetBounds();
                path.Translate(-bounds.X, -bounds.Y)
            Next
            m_OutputPath.Translate(-bounds.X, -bounds.Y)

            m_Canvas.PreferredSize = New NSize(bounds.Width + 20, bounds.Height + 20)
            m_Canvas.InvalidateDisplay()
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(args As NCanvasPaintEventArgs)
            args.PaintVisitor.PushTransform(NMatrix.CreateTranslationMatrix(10, 10))

            ' input path interiors
            If m_ShowInputPathInteriors.Checked Then
                args.PaintVisitor.ClearStyles()
                args.PaintVisitor.SetFill(NColor.LightBlue)

                For i = 0 To m_InputPaths.Count - 1
                    args.PaintVisitor.PaintPath(m_InputPaths(i))
                Next
            End If

            ' input path outlines
            If m_ShowInputPathOutlines.Checked Then
                args.PaintVisitor.ClearStyles()
                args.PaintVisitor.SetStroke(NColor.Black, 1)

                For i = 0 To m_InputPaths.Count - 1
                    args.PaintVisitor.PaintPath(m_InputPaths(i))
                Next
            End If

            ' output path interior
            If m_ShowOutputPathInterior.Checked Then
                args.PaintVisitor.ClearStyles()
                args.PaintVisitor.SetFill(New NColor(NColor.LightCoral, 128))
                args.PaintVisitor.PaintPath(m_OutputPath)
            End If

            ' output path outline
            If m_ShowOutputPathOutline.Checked Then
                args.PaintVisitor.ClearStyles()
                args.PaintVisitor.SetStroke(NColor.Black, 2)
                args.PaintVisitor.PaintPath(m_OutputPath)
            End If

            args.PaintVisitor.PopTransform()
        End Sub
        Private Sub OnClearButtonClick(args As NEventArgs)
            m_InputPaths.Clear()
            UpdateOuputPath()
        End Sub
        Private Sub OnRandomEllipseButtonClick(args As NEventArgs)
            Dim rect As NRectangle = New NRectangle(m_Random.Next(500), m_Random.Next(500), m_Random.Next(500), m_Random.Next(500))
            rect.Normalize()

            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddEllipse(rect)

            m_InputPaths.Add(path)

            UpdateOuputPath()
        End Sub
        Private Sub OnRandomRectButtonClick(args As NEventArgs)
            Dim rect As NRectangle = New NRectangle(m_Random.Next(500), m_Random.Next(500), m_Random.Next(500), m_Random.Next(500))
            rect.Normalize()

            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddRectangle(rect)

            m_InputPaths.Add(path)
            UpdateOuputPath()
        End Sub
        Private Sub OnRandomTriangleButtonClick(args As NEventArgs)
            Dim p1 As NPoint = New NPoint(m_Random.Next(500), m_Random.Next(500))
            Dim p2 As NPoint = New NPoint(m_Random.Next(500), m_Random.Next(500))
            Dim p3 As NPoint = New NPoint(m_Random.Next(500), m_Random.Next(500))

            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddTriangle(New NTriangle(p1, p2, p3))
            m_InputPaths.Add(path)
            UpdateOuputPath()
        End Sub

        Private Sub OnShowInputPathInteriorsCheckedChanged(args As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub
        Private Sub OnShowInputPathOutlinesCheckedChanged(args As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub
        Private Sub OnAreaOperatorComboSelectedIndexChanged(args As NValueChangeEventArgs)
            UpdateOuputPath()
        End Sub

#End Region

#Region "Fields"

        Private m_Canvas As NCanvas
        Private m_OutputPath As NGraphicsPath

        Private m_InputPaths As NList(Of NGraphicsPath)
        Private m_Random As Random = New Random(300)

        Private m_OperatorCombo As NComboBox
        Private m_ShowInputPathInteriors As NCheckBox
        Private m_ShowInputPathOutlines As NCheckBox
        Private m_ShowOutputPathOutline As NCheckBox
        Private m_ShowOutputPathInterior As NCheckBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NAreaOperationsExampleSchema As NSchema

#End Region
    End Class
End Namespace
