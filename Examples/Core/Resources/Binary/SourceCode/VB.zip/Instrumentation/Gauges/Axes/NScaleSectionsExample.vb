Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' 
    ''' </summary>
    Public Class NScaleSectionsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NScaleSectionsExampleSchema = NSchema.Create(GetType(NScaleSectionsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            controlStack.Direction = ENHVDirection.LeftToRight
            stack.Add(controlStack)

            m_LinearGauge = New NLinearGauge()
            m_LinearGauge.Orientation = ENLinearGaugeOrientation.Vertical
            m_LinearGauge.PreferredSize = defaultLinearVerticalGaugeSize
            m_LinearGauge.BackgroundFill = New NStockGradientFill(NColor.DarkGray, NColor.Black)
            m_LinearGauge.CapEffect = New NGelCapEffect()
            m_LinearGauge.Border = CreateBorder()
            m_LinearGauge.Padding = New NMargins(20)
            m_LinearGauge.BorderThickness = New NMargins(6)

            controlStack.Add(m_LinearGauge)

            Dim markerIndicator As NMarkerValueIndicator = New NMarkerValueIndicator()
            m_LinearGauge.Indicators.Add(markerIndicator)

            InitSections(m_LinearGauge)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            Dim dialRim As NEdgeDialRim = New NEdgeDialRim()
            dialRim.OuterBevelWidth = 2.0
            dialRim.InnerBevelWidth = 2.0
            dialRim.MiddleBevelWidth = 2.0
            m_RadialGauge.Dial = New NDial(ENDialShape.CutCircle, dialRim)
            m_RadialGauge.Dial.BackgroundFill = New NStockGradientFill(NColor.DarkGray, NColor.Black)
            m_RadialGauge.InnerRadius = 15

            Dim glassCapEffect As NGlassCapEffect = New NGlassCapEffect()
            glassCapEffect.LightDirection = New NAngle(130, NUnit.Degree)
            glassCapEffect.EdgeOffset = 0
            glassCapEffect.EdgeDepth = 0.30
            m_RadialGauge.CapEffect = glassCapEffect

            controlStack.Add(m_RadialGauge)

            Dim needleIndicator As NNeedleValueIndicator = New NNeedleValueIndicator()
            m_RadialGauge.Indicators.Add(needleIndicator)
            m_RadialGauge.SweepAngle = New NAngle(180, NUnit.Degree)

            InitSections(m_RadialGauge)

            m_DataFeedTimer = New NTimer()
            m_DataFeedTimer.Tick += New [Function](AddressOf OnDataFeedTimerTick)
            m_DataFeedTimer.Start()

            Return stack
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        Protected Overrides Sub OnUnregistered()
            MyBase.OnUnregistered()

            m_DataFeedTimer.Stop()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            m_BlueSectionBeginUpDown = CreateUpDown(0.0)
            propertyStack.Add(New NPairBox("Begin:", m_BlueSectionBeginUpDown, True))

            m_BlueSectionEndUpDown = CreateUpDown(20.0)
            propertyStack.Add(New NPairBox("End:", m_BlueSectionEndUpDown, True))

            m_RedSectionBeginUpDown = CreateUpDown(80.0)
            propertyStack.Add(New NPairBox("Begin:", m_RedSectionBeginUpDown, True))

            m_RedSectionEndUpDown = CreateUpDown(100.0)
            propertyStack.Add(New NPairBox("End:", m_RedSectionEndUpDown, True))

            m_StopStartTimerButton = New NButton("Stop Timer")
            propertyStack.Add(m_StopStartTimerButton)


            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to create scale sections. Scale sections allow you to modify the appearance of scale elements if they fall in certain range.</p>"
        End Function

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' 
        ''' </summary>
        Private Sub OnDataFeedTimerTick()
            ' update linear gauge
            Dim gauges = New NGauge() {m_RadialGauge, m_LinearGauge}

            For i = 0 To gauges.Length - 1
                Dim gauge = gauges(i)

                Dim valueIndicator = CType(gauge.Indicators(0), NValueIndicator)
                Dim scale = CType(gauge.Axes(0).Scale, NStandardScale)

                Dim blueSection = scale.Sections(0)
                Dim redSection = scale.Sections(1)

                m_FirstIndicatorAngle += 0.02
                valueIndicator.Value = 50.0 - Math.Cos(m_FirstIndicatorAngle) * 50.0

                ' FIX: Smart Shapes
                If blueSection.Range.Contains(valueIndicator.Value) Then
                    valueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Blue)
                    valueIndicator.Stroke = New NStroke(NColor.Blue)
                ElseIf redSection.Range.Contains(valueIndicator.Value) Then
                    valueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
                    valueIndicator.Stroke = New NStroke(NColor.Red)
                Else
                    valueIndicator.Fill = New NColorFill(NColor.LightGreen)
                    valueIndicator.Stroke = New NStroke(NColor.DarkGreen)
                End If
            Next
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="sender"></param>
        ''' <paramname="e"></param>
        Private Sub OnStopStartTimerButtonClick(sender As Object, e As EventArgs)
            If m_DataFeedTimer.IsStarted Then
                m_DataFeedTimer.Stop()
                m_StopStartTimerButton.Content = New NLabel("Start Timer")
            Else
                m_DataFeedTimer.Start()
                m_StopStartTimerButton.Content = New NLabel("Stop Timer")
            End If
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub UpdateSections(arg As NValueChangeEventArgs)
            Dim gauges = New NGauge() {m_RadialGauge, m_LinearGauge}

            For i = 0 To gauges.Length - 1
                Dim gauge = gauges(i)

                Dim axis = gauge.Axes(0)
                Dim scale = CType(axis.Scale, NStandardScale)

                If scale.Sections.Count = 2 Then
                    Dim blueSection = scale.Sections(0)
                    blueSection.Range = New NRange(m_BlueSectionBeginUpDown.Value, m_BlueSectionEndUpDown.Value)

                    Dim redSection = scale.Sections(1)
                    redSection.Range = New NRange(m_RedSectionBeginUpDown.Value, m_RedSectionEndUpDown.Value)
                End If
            Next
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="value"></param>
        ''' <returns></returns>
        Private Function CreateUpDown(value As Double) As NNumericUpDown
            Dim numericUpDown As NNumericUpDown = New NNumericUpDown()

            numericUpDown.Minimum = 0.0
            numericUpDown.Maximum = 100.0
            numericUpDown.Value = value
            numericUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf UpdateSections)

            Return numericUpDown
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="gauge"></param>
        Private Sub InitSections(gauge As NGauge)
            gauge.Axes.Clear()
            Dim axis As NGaugeAxis = New NGaugeAxis()
            gauge.Axes.Add(axis)

            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top)

            Dim scale = CType(axis.Scale, NStandardScale)

            ' init text style for regular labels
            scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 10, ENFontStyle.Bold)

            ' init ticks
            scale.MajorGridLines.Visible = True
            scale.MinTickDistance = 25
            scale.MinorTickCount = 1
            scale.SetPredefinedScale(ENPredefinedScaleStyle.Scientific)

            ' create sections
            Dim blueSection As NScaleSection = New NScaleSection()
            blueSection.Range = New NRange(0, 20)
            blueSection.RangeFill = New NColorFill(NColor.FromColor(NColor.Blue, 0.5F))
            blueSection.MajorGridStroke = New NStroke(NColor.Blue)
            blueSection.MajorTickStroke = New NStroke(NColor.DarkBlue)
            blueSection.MinorTickStroke = New NStroke(1, NColor.Blue, ENDashStyle.Dot)

            Dim labelStyle As NTextStyle = New NTextStyle()
            labelStyle.Fill = New NColorFill(NColor.Blue)
            labelStyle.Font = New NFont("Arimo", 10, ENFontStyle.Bold)
            blueSection.LabelTextStyle = labelStyle

            scale.Sections.Add(blueSection)

            Dim redSection As NScaleSection = New NScaleSection()
            redSection.Range = New NRange(80, 100)

            redSection.RangeFill = New NColorFill(NColor.FromColor(NColor.Red, 0.5F))
            redSection.MajorGridStroke = New NStroke(NColor.Red)
            redSection.MajorTickStroke = New NStroke(NColor.DarkRed)
            redSection.MinorTickStroke = New NStroke(1, NColor.Red, ENDashStyle.Dot)

            labelStyle = New NTextStyle()
            labelStyle.Fill = New NColorFill(NColor.Red)
            labelStyle.Font = New NFont("Arimo", 10.0, ENFontStyle.Bold)
            redSection.LabelTextStyle = labelStyle

            scale.Sections.Add(redSection)
        End Sub

#End Region

#Region "Fields"


        Private m_BlueSectionBeginUpDown As NNumericUpDown
        Private m_BlueSectionEndUpDown As NNumericUpDown

        Private m_RedSectionBeginUpDown As NNumericUpDown
        Private m_RedSectionEndUpDown As NNumericUpDown

        Private m_RadialGauge As NRadialGauge
        Private m_LinearGauge As NLinearGauge

        Private m_DataFeedTimer As NTimer
        Private m_StopStartTimerButton As NButton
        Private m_FirstIndicatorAngle As Double

#End Region

#Region "Schema"

        Public Shared ReadOnly NScaleSectionsExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Protected Function CreateBorder() As NBorder
            Return NBorder.CreateThreeColorBorder(NColor.LightGray, NColor.White, NColor.DarkGray, 10, 10)
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)
        Private Shared ReadOnly defaultLinearVerticalGaugeSize As NSize = New NSize(100, 300)

#End Region
    End Class
End Namespace
