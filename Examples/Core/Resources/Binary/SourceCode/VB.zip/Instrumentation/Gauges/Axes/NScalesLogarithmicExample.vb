Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    '''  This example demonstrates how to use logarithmic and reversed scales. 
    ''' </summary>
    Public Class NScalesLogarithmicExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NScalesLogarithmicExampleSchema = NSchema.Create(GetType(NScalesLogarithmicExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()

            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            m_RadialGauge.Dial = New NDial(ENDialShape.CutCircle, New NEdgeDialRim())

            m_RadialGauge.SweepAngle = New NAngle(-180, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(-1, NUnit.Degree)

            Dim advancedGradient As NAdvancedGradientFill = New NAdvancedGradientFill()
            advancedGradient.BackgroundColor = NColor.DarkCyan
            advancedGradient.Points.Add(New NAdvancedGradientPoint(NColor.LightSteelBlue, New NAngle(10, NUnit.Degree), 0.1F, 0, 1.0F, ENAdvancedGradientPointShape.Circle))
            m_RadialGauge.Dial.BackgroundFill = advancedGradient

            ' configure scale
            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_RadialGauge.Axes.Clear()
            m_RadialGauge.Axes.Add(axis)

            axis.Range = New NRange(1, 100)
            axis.Scale = New NLogarithmicScale()

            m_Scale = CType(axis.Scale, NLogarithmicScale)
            m_Scale.SetPredefinedScale(ENPredefinedScaleStyle.Standard)
            m_Scale.MajorTickMode = ENMajorTickMode.CustomStep
            m_Scale.CustomStep = 1
            m_Scale.MinTickDistance = 30
            m_Scale.Ruler.Stroke.Width = 0
            m_Scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.Black)
            m_Scale.Labels.Style.TextStyle.Font = New NFont("Microsoft Sans Serif", 8, ENFontStyle.Bold)
            m_Scale.OuterMajorTicks.Fill = New NColorFill(NColor.White)

            ' needle value indicator
            m_ValueIndicator = New NNeedleValueIndicator()
            m_ValueIndicator.Value = 59
            m_ValueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
            m_ValueIndicator.Stroke.Color = NColor.Red
            m_ValueIndicator.EnableDampening = True
            m_ValueIndicator.OffsetFromCenter = -10
            m_RadialGauge.Indicators.Add(m_ValueIndicator)

            ' add radial gauge
            controlStack.Add(m_RadialGauge)

            ' Timer
            m_Timer = New NTimer()
            m_Timer.Interval = 200
            m_Timer.Tick += New [Function](AddressOf OnTimerTick)
            m_Timer.Start()

            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            ' reversed scale check box
            m_ReverseScaleCheckBox = New NCheckBox("Reversed")
            m_ReverseScaleCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnReverseCheckBoxCheckedChange)
            m_ReverseScaleCheckBox.Checked = True
            propertyStack.Add(m_ReverseScaleCheckBox)

            ' logarithmic base 
            m_LogarithmicBaseComboBox = New NComboBox()
            m_LogarithmicBaseComboBox.Items.Add(New NComboBoxItem("10"))
            m_LogarithmicBaseComboBox.Items.Add(New NComboBoxItem("5"))
            m_LogarithmicBaseComboBox.Items.Add(New NComboBoxItem("2"))
            m_LogarithmicBaseComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnLogarithmicBaseComboBoxIndexChanged)
            m_LogarithmicBaseComboBox.SelectedIndex = 2
            propertyStack.Add(New NPairBox("Logarithmic Base:", m_LogarithmicBaseComboBox, True))

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>In this example, the logarithm base is limited to a few predefined values, 
                    but it is possible to set the logarithm base to any integer value.</p>"
        End Function

#End Region

#Region "Event Handlers"
        Private Sub OnTimerTick()
            m_FirstIndicatorAngle += 0.02
            Dim needleValue = 50.0 - Math.Cos(m_FirstIndicatorAngle) * 50.0
            m_ValueIndicator.Value = needleValue
        End Sub

        Private Sub OnReverseCheckBoxCheckedChange(arg As NValueChangeEventArgs)
            Dim enableInvert As Boolean = arg.NewValue

            m_RadialGauge.Axes(0).Scale.Invert = enableInvert
        End Sub

        Private Sub OnLogarithmicBaseComboBoxIndexChanged(arg As NValueChangeEventArgs)
            Dim logBase As Integer = arg.NewValue

            Select Case logBase
                Case 0
                    m_Scale.LogarithmBase = 10

                Case 1
                    m_Scale.LogarithmBase = 5

                Case 2
                    m_Scale.LogarithmBase = 2
            End Select
        End Sub

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_ValueIndicator As NNeedleValueIndicator
        Private m_Scale As NLogarithmicScale

        Private m_Timer As NTimer

        Private m_ReverseScaleCheckBox As NCheckBox
        Private m_LogarithmicBaseComboBox As NComboBox

        Private m_FirstIndicatorAngle As Double
#End Region

#Region "Schema"

        Public Shared ReadOnly NScalesLogarithmicExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace
