Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports Nevron.Nov.Layout

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to control the size of the gauge axes
    ''' </summary>
    Public Class NGaugeScaleLabelsOrientationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NGaugeScaleLabelsOrientationExampleSchema = NSchema.Create(GetType(NGaugeScaleLabelsOrientationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            controlStack.Direction = ENHVDirection.LeftToRight
            stack.Add(controlStack)

            m_LinearGauge = New NLinearGauge()
            m_LinearGauge.Orientation = ENLinearGaugeOrientation.Vertical
            m_LinearGauge.PreferredSize = defaultLinearVerticalGaugeSize
            m_LinearGauge.CapEffect = New NGelCapEffect()
            m_LinearGauge.Border = CreateBorder()
            m_LinearGauge.Padding = New NMargins(20)
            m_LinearGauge.BorderThickness = New NMargins(6)

            controlStack.Add(m_LinearGauge)

            ' create the background panel
            Dim advGradient As NAdvancedGradientFill = New NAdvancedGradientFill()
            advGradient.BackgroundColor = NColor.Black
            advGradient.Points.Add(New NAdvancedGradientPoint(NColor.LightGray, New NAngle(10, NUnit.Degree), 0.1F, 0, 1.0F, ENAdvancedGradientPointShape.Circle))
            m_LinearGauge.BackgroundFill = advGradient
            '          FIX m_LinearGauge.BorderStyle = new NEdgeBorderStyle(BorderShape.RoundedRect);

            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_LinearGauge.Axes.Add(axis)
            axis.Anchor = New NModelGaugeAxisAnchor(10, ENVerticalAlignment.Center, ENScaleOrientation.Left)
            ConfigureScale(CType(axis.Scale, NLinearScale))

            ' add some indicators
            AddRangeIndicatorToGauge(m_LinearGauge)
            m_LinearGauge.Indicators.Add(New NMarkerValueIndicator(60))

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.CapEffect = New NGlassCapEffect()
            m_RadialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            controlStack.Add(m_RadialGauge)

            ' create the radial gauge
            m_RadialGauge.SweepAngle = New NAngle(270, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(-90, NUnit.Degree)

            ' set some background
            advGradient = New NAdvancedGradientFill()
            advGradient.BackgroundColor = NColor.Black
            advGradient.Points.Add(New NAdvancedGradientPoint(NColor.White, New NAngle(10, NUnit.Degree), 0.1F, 0, 1.0F, ENAdvancedGradientPointShape.Circle))
            m_RadialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            m_RadialGauge.Dial.BackgroundFill = advGradient

            ' configure the axis
            axis = New NGaugeAxis()
            m_RadialGauge.Axes.Add(axis)
            axis.Range = New NRange(0, 100)
            axis.Anchor.ScaleOrientation = ENScaleOrientation.Right
            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, ENScaleOrientation.Right, 0.0F, 100.0F)

            ConfigureScale(CType(axis.Scale, NLinearScale))

            ' add some indicators
            AddRangeIndicatorToGauge(m_RadialGauge)

            Dim needle As NNeedleValueIndicator = New NNeedleValueIndicator(60)
            needle.OffsetOriginMode = ENIndicatorOffsetOriginMode.ScaleMiddle
            needle.OffsetFromScale = 15.0
            m_RadialGauge.Indicators.Add(needle)


            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            m_AngleModeComboBox = New NComboBox()
            m_AngleModeComboBox.FillFromEnum(Of ENScaleLabelAngleMode)()
            m_AngleModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf UpdateScaleLabelAngle)
            propertyStack.Add(New NPairBox("Angle Mode:", m_AngleModeComboBox, True))

            m_CustomAngleNumericUpDown = New NNumericUpDown()
            m_CustomAngleNumericUpDown.Minimum = -360
            m_CustomAngleNumericUpDown.Maximum = 360
            m_CustomAngleNumericUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf UpdateScaleLabelAngle)
            propertyStack.Add(New NPairBox("Custom Angle:", m_CustomAngleNumericUpDown, True))

            m_AllowTextFlipCheckBox = New NCheckBox("Allow Text to Flip")
            m_AllowTextFlipCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf UpdateScaleLabelAngle)
            propertyStack.Add(m_AllowTextFlipCheckBox)

            m_BeginAngleScrollBar = New NHScrollBar()
            m_BeginAngleScrollBar.Minimum = -360
            m_BeginAngleScrollBar.Maximum = 360
            m_BeginAngleScrollBar.Value = m_RadialGauge.BeginAngle.ToDegrees()
            m_BeginAngleScrollBar.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnBeginAngleScrollBarValueChanged)
            propertyStack.Add(New NPairBox("Begin Angle:", m_BeginAngleScrollBar, True))

            m_SweepAngleScrollBar = New NHScrollBar()
            m_SweepAngleScrollBar.Minimum = -360.0
            m_SweepAngleScrollBar.Maximum = 360.0
            m_SweepAngleScrollBar.Value = m_RadialGauge.SweepAngle.ToDegrees()
            m_SweepAngleScrollBar.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSweepAngleScrollBarValueChanged)
            propertyStack.Add(New NPairBox("Sweep Angle:", m_SweepAngleScrollBar, True))

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to control the Gauge scale labels orientation.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub UpdateScaleLabelAngle(arg As NValueChangeEventArgs)
            Dim angle As NScaleLabelAngle = New NScaleLabelAngle(m_AngleModeComboBox.SelectedIndex, m_CustomAngleNumericUpDown.Value, m_AllowTextFlipCheckBox.Checked)

            ' apply angle to radial gauge axis
            Dim axis = m_RadialGauge.Axes(0)
            Dim scale = CType(axis.Scale, NLinearScale)
            scale.Labels.Style.Angle = angle

            ' apply angle to linear gauge axis
            axis = m_LinearGauge.Axes(0)
            scale = CType(axis.Scale, NLinearScale)
            scale.Labels.Style.Angle = angle
        End Sub


        Private Sub OnBeginAngleScrollBarValueChanged(arg As NValueChangeEventArgs)
            m_RadialGauge.BeginAngle = New NAngle(m_BeginAngleScrollBar.Value, NUnit.Degree)
        End Sub

        Private Sub OnSweepAngleScrollBarValueChanged(arg As NValueChangeEventArgs)
            m_RadialGauge.SweepAngle = New NAngle(m_SweepAngleScrollBar.Value, NUnit.Degree)
        End Sub

        Private Sub OnAngleModeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_RadialGauge.SweepAngle = New NAngle(m_SweepAngleScrollBar.Value, NUnit.Degree)
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="scale"></param>
        Private Sub ConfigureScale(scale As NLinearScale)
            scale.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            scale.Labels.OverlapResolveLayouts = New NDomArray(Of ENLevelLabelsLayout)()
            scale.MinorTickCount = 3
            scale.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.White, 0.4F))
            scale.OuterMajorTicks.Fill = New NColorFill(NColor.Orange)
            scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 12, ENFontStyle.Bold)
            scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="gauge"></param>
        Private Sub AddRangeIndicatorToGauge(gauge As NGauge)
            ' add some indicators
            Dim rangeIndicator As NRangeIndicator = New NRangeIndicator(New NRange(75, 100))
            rangeIndicator.Fill = New NColorFill(NColor.Red)
            rangeIndicator.Stroke.Width = 0.0
            rangeIndicator.BeginWidth = 5.0
            rangeIndicator.EndWidth = 10.0
            rangeIndicator.PaintOrder = ENIndicatorPaintOrder.BeforeScale

            gauge.Indicators.Add(rangeIndicator)
        End Sub

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_LinearGauge As NLinearGauge

        Private m_AngleModeComboBox As NComboBox
        Private m_CustomAngleNumericUpDown As NNumericUpDown
        Private m_AllowTextFlipCheckBox As NCheckBox

        Private m_BeginAngleScrollBar As NHScrollBar
        Private m_SweepAngleScrollBar As NHScrollBar


#End Region

#Region "Schema"

        Public Shared ReadOnly NGaugeScaleLabelsOrientationExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateBorder() As NBorder
            Return NBorder.CreateThreeColorBorder(NColor.LightGray, NColor.White, NColor.DarkGray, 10, 10)
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultLinearVerticalGaugeSize As NSize = New NSize(100, 300)

#End Region
    End Class
End Namespace
