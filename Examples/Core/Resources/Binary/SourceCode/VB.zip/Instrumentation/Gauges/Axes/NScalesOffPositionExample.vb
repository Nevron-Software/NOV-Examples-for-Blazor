Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrated how to use a minimum scale pin to define pointer's "Off Poisition"
    ''' </summary>
    Public Class NScalesOffPositionExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NScalesOffPositionExampleSchema = NSchema.Create(GetType(NScalesOffPositionExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            controlStack.Padding = New NMargins(20)
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            m_RadialGauge.NeedleCap.Visible = True
            m_RadialGauge.NeedleCap.Size = New NSize(30, 30)

            m_RadialGauge.SweepAngle = New NAngle(270, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(135, NUnit.Degree)

            controlStack.Add(m_RadialGauge)

            ' add axis 
            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_RadialGauge.Axes.Clear()
            m_RadialGauge.Axes.Add(axis)
            axis.Range = New NRange(-10, 100)
            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, ENScaleOrientation.Left, 0.0F, 100.0F)

            ' add scale
            m_Scale = CType(axis.Scale, NLinearScale)
            m_Scale.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            m_Scale.Labels.Style.TextStyle.Font = New NFont("Microsoft Sans Serif", 15, ENFontStyle.Bold)
            m_Scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.CornflowerBlue)

            m_Scale.MajorTickMode = ENMajorTickMode.CustomStep
            m_Scale.CustomStep = 10
            m_Scale.OuterMinorTicks.Visible = True
            m_Scale.OuterMajorTicks.Length = 10
            m_Scale.OuterMajorTicks.Width = 7
            m_Scale.OuterMajorTicks.Fill = New NColorFill(NColor.CornflowerBlue)
            m_Scale.MinorTickCount = 5
            m_Scale.OuterMinorTicks.Length = 4
            m_Scale.OuterMinorTicks.Width = 3
            m_Scale.OuterMinorTicks.Fill = New NColorFill(NColor.Gray)

            ' create a custom label "Off"
            Dim label As NCustomValueLabel = New NCustomValueLabel(-10, "Off")
            label.LabelStyle.ZOrder = 1
            m_Scale.CustomLabelOverlapResolveLayouts = New NDomArray(Of ENLevelLabelsLayout)(New ENLevelLabelsLayout() {ENLevelLabelsLayout.RemoveOverlap})
            m_Scale.CreateNewLevelForCustomLabels = False
            m_Scale.CustomLabels.Add(label)

            ' needle value 
            m_NeedleIndicator = New NNeedleValueIndicator()
            m_NeedleIndicator.ScaleAxis = axis
            m_NeedleIndicator.Fill = New NColorFill(NColor.CornflowerBlue)
            m_NeedleIndicator.EnableDampening = True
            m_RadialGauge.Indicators.Add(m_NeedleIndicator)

            ' Timer
            m_Timer = New NTimer()
            m_Timer.Interval = 200
            m_Timer.Tick += New [Function](AddressOf OnTimerTick)
            m_Timer.Start()

            Return stack
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            Dim toggleTimerButton As NButton = New NButton("Turn off")
            toggleTimerButton.Click += AddressOf OnToggleTimerButtonClick
            toggleTimerButton.Tag = 1
            stack.Add(toggleTimerButton)

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to use a minimum scale pin to define a pointer's off position.</p>"
        End Function

#End Region

#Region "Event Handlers"
        Private Sub OnToggleTimerButtonClick(arg As NEventArgs)
            Dim button = CType(arg.TargetNode, NButton)
            If CInt(button.Tag) = 0 Then
                m_Timer.Start()

                button.Content = New NLabel("Turn On")
                button.Tag = 1
            Else
                m_Timer.Stop()

                button.Content = New NLabel("Turn Off")
                button.Tag = 0

                m_NeedleIndicator.Value = -10
            End If
        End Sub
        Private Sub OnTimerTick()
            ' update the indicator 
            m_FirstIndicatorAngle += Math.PI / 180.0
            Dim value = 50 + Math.Sin(m_FirstIndicatorAngle) * (20 + rand.Next(30))

            m_NeedleIndicator.Value = value
        End Sub

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_Scale As NLinearScale
        Private m_NeedleIndicator As NNeedleValueIndicator

        Private m_Timer As NTimer

        Private rand As Random = New Random()
        Private m_FirstIndicatorAngle As Double

#End Region

#Region "Schema"

        Public Shared ReadOnly NScalesOffPositionExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace
