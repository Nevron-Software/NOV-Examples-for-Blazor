Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' 
    ''' </summary>
    Public Class NScaleMultiplierExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NScaleMultiplierExampleSchema = NSchema.Create(GetType(NScaleMultiplierExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            m_RadialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            m_RadialGauge.SweepAngle = New NAngle(270, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(-225, NUnit.Degree)

            Dim advancedGradient As NAdvancedGradientFill = New NAdvancedGradientFill()
            advancedGradient.BackgroundColor = NColor.Black
            advancedGradient.Points.Add(New NAdvancedGradientPoint(NColor.CadetBlue, New NAngle(10, NUnit.Degree), 0.1F, 0, 1.0F, ENAdvancedGradientPointShape.Circle))
            m_RadialGauge.Dial.BackgroundFill = advancedGradient
            m_RadialGauge.CapEffect = New NGlassCapEffect(ENCapEffectShape.Ellipse)

            controlStack.Add(m_RadialGauge)

            ' configure scale
            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_RadialGauge.Axes.Add(axis)
            axis.Range = New NRange(0, 10000)

            ' add Scale
            m_Scale = CType(axis.Scale, NLinearScale)
            m_Scale.SetPredefinedScale(ENPredefinedScaleStyle.Presentation)
            m_Scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 10, ENFontStyle.Bold)
            m_Scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            m_Scale.MajorTickMode = ENMajorTickMode.CustomStep
            m_Scale.CustomStep = 1000
            m_Scale.MinorTickCount = 10
            m_Scale.Ruler.Fill = New NColorFill(NColor.Gray)

            ' add radial gauge indicators
            m_ValueIndicator = New NNeedleValueIndicator()
            m_ValueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
            m_ValueIndicator.Width = 7
            m_ValueIndicator.OffsetFromScale = -10
            m_RadialGauge.Indicators.Add(m_ValueIndicator)

            Dim verticalStack As NStackPanel = New NStackPanel()
            verticalStack.Direction = ENHVDirection.TopToBottom
            verticalStack.Padding = New NMargins(80, 230, 80, 0)

            ' add Numeric Led dusplay 
            m_NumericLedDisplay = New NNumericLedDisplay()
            m_NumericLedDisplay.CellCountMode = ENDisplayCellCountMode.Fixed
            m_NumericLedDisplay.CellCount = 7
            m_NumericLedDisplay.BackgroundFill = New NColorFill(NColor.Black)
            m_NumericLedDisplay.Border = NBorder.CreateSunken3DBorder(New NUIThemeColorMap(ENUIThemeScheme.Brick))
            m_NumericLedDisplay.BorderThickness = New NMargins(6)
            m_NumericLedDisplay.Margins = New NMargins(5)
            m_NumericLedDisplay.VerticalPlacement = ENVerticalPlacement.Bottom
            m_NumericLedDisplay.PreferredSize = New NSize(30, 50)

            verticalStack.Add(m_NumericLedDisplay)

            m_RadialGauge.Content = verticalStack

            ' timer 
            m_DataFeedTimer = New NTimer()
            m_DataFeedTimer.Tick += New [Function](AddressOf OnDataFeedTimerTick)
            m_DataFeedTimer.Start()

            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_MultiplierRadioGroup = New NRadioButtonGroup()
            Me.m_MultiplierRadioGroup.SelectedIndexChanged += AddressOf OnMultiplierRadioGroupIndexChanged

            Dim radioStack As NStackPanel = New NStackPanel()
            m_MultiplierRadioGroup.Content = radioStack

            radioStack.Add(New NRadioButton("10"))
            radioStack.Add(New NRadioButton("1"))
            radioStack.Add(New NRadioButton("0.1"))
            radioStack.Add(New NRadioButton("0.01"))
            radioStack.Add(New NRadioButton("0.001"))
            CType(radioStack(1), NRadioButton).Checked = True
            stack.Add(New NGroupBox("Multiplier Value: ", m_MultiplierRadioGroup))

            Return stack
        End Function


        Protected Overrides Function GetExampleDescription() As String
            Return "<p> An RPM gauge is displayed using a mlutiplier, which allows for the increase or decrease in scale labels.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnMultiplierRadioGroupIndexChanged(arg As NValueChangeEventArgs)
            Dim selectedIndex = m_MultiplierRadioGroup.SelectedIndex

            Select Case selectedIndex
                Case 0
                    ' handle "10" radio button
                    m_RadialGauge.Axes(0).Range = New NRange(0, 100000)
                    m_Scale.CustomStep = 10000

                    ' create a scale title  - RPM X 10
                    m_RadialGauge.Axes(0).Scale.Title.Text = "RPM X 10"
                    m_RadialGauge.Axes(0).Scale.Title.TextStyle = New NTextStyle(NColor.Red)

                Case 1
                    ' handle "1" radio button
                    m_RadialGauge.Axes(0).Range = New NRange(0, 10000)
                    m_Scale.CustomStep = 1000

                    ' create a scale title  - RPM 
                    m_RadialGauge.Axes(0).Scale.Title.Text = "RPM"
                    m_RadialGauge.Axes(0).Scale.Title.TextStyle = New NTextStyle(NColor.Red)

                Case 2
                    ' handle "0.1" radio button
                    m_RadialGauge.Axes(0).Range = New NRange(0, 1000)
                    m_Scale.CustomStep = 100

                    ' create a scale title  - RPM X 0.1 
                    m_RadialGauge.Axes(0).Scale.Title.Text = "RPM X 0.1"
                    m_RadialGauge.Axes(0).Scale.Title.TextStyle = New NTextStyle(NColor.Red)

                Case 3
                    ' handle "0.01" radio button
                    m_RadialGauge.Axes(0).Range = New NRange(0, 100)
                    m_Scale.CustomStep = 10

                    ' create a scale title  - RPM X 0.01 
                    m_RadialGauge.Axes(0).Scale.Title.Text = "RPM X 0.01"
                    m_RadialGauge.Axes(0).Scale.Title.TextStyle = New NTextStyle(NColor.Red)

                Case 4
                    ' handle "0.001" radio button
                    m_RadialGauge.Axes(0).Range = New NRange(0, 10)
                    m_Scale.CustomStep = 1

                    ' create a scale title  - RPM X 0.001
                    m_RadialGauge.Axes(0).Scale.Title.Text = "RPM X 0.001"
                    m_RadialGauge.Axes(0).Scale.Title.TextStyle = New NTextStyle(NColor.Red)
            End Select
        End Sub

        Private Sub OnDataFeedTimerTick()
            Dim selectedIndex = m_MultiplierRadioGroup.SelectedIndex

            ' update the indicator
            m_FirstIndicatorAngle += 0.02
            Dim value = 50.0 - Math.Cos(m_FirstIndicatorAngle) * 50.0
            m_ValueIndicator.Value = value

            Select Case selectedIndex
                Case 0
                    ' handle "10" radio button
                    m_ValueIndicator.Value = value * 1000
                    m_NumericLedDisplay.Value = m_ValueIndicator.Value

                Case 1
                    ' handle "1" radio button
                    m_ValueIndicator.Value = value * 100
                    m_NumericLedDisplay.Value = m_ValueIndicator.Value

                Case 2
                    ' handle "0.1" radio button
                    m_ValueIndicator.Value = value * 10
                    m_NumericLedDisplay.Value = m_ValueIndicator.Value

                Case 3
                    ' handle "0.01" radio button
                    m_ValueIndicator.Value = value
                    m_NumericLedDisplay.Value = m_ValueIndicator.Value

                Case 4
                    ' handle "0.001" radio button
                    m_ValueIndicator.Value = value * 0.1
                    m_NumericLedDisplay.Value = m_ValueIndicator.Value
            End Select
        End Sub

#End Region

#Region "Implementation"


#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_Scale As NLinearScale
        Private m_ValueIndicator As NNeedleValueIndicator

        Private m_NumericLedDisplay As NNumericLedDisplay
        Private m_MultiplierRadioGroup As NRadioButtonGroup

        Private m_DataFeedTimer As NTimer
        Private m_FirstIndicatorAngle As Double

#End Region

#Region "Schema"

        Public Shared ReadOnly NScaleMultiplierExampleSchema As NSchema

#End Region

#Region "Static Methods"

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace
