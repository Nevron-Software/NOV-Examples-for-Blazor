Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' 
    ''' </summary>
    Public Class NValueIndicatorsStyleExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' 
        ''' </summary>

        Shared Sub New()
            NValueIndicatorsStyleExampleSchema = NSchema.Create(GetType(NValueIndicatorsStyleExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            controlStack.Add(m_RadialGauge)

            m_RadialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            m_RadialGauge.Dial.BackgroundFill = New NStockGradientFill(NColor.DarkGray, NColor.Black)

            Dim gelEffect As NGelCapEffect = New NGelCapEffect(ENCapEffectShape.Ellipse)
            gelEffect.Margins = New NMargins(0, 0, 0, 0.5)

            m_RadialGauge.Axes.Clear()

            m_RadialGauge.SweepAngle = New NAngle(360, NUnit.Degree)

            ' create the first axis
            Dim axis1 As NGaugeAxis = New NGaugeAxis()
            axis1.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, 0, 70)

            m_RadialGauge.Axes.Add(axis1)

            ' Scale 
            Dim scale1 = CType(axis1.Scale, NStandardScale)
            scale1.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            scale1.MinorTickCount = 3
            scale1.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.White, 0.4F))
            scale1.OuterMajorTicks.Fill = New NColorFill(NColor.Orange)
            scale1.Labels.Style.TextStyle.Font = New NFont("Arimo", 12, ENFontStyle.Bold)
            scale1.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            scale1.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)

            ' create the second axis
            Dim axis2 As NGaugeAxis = New NGaugeAxis()
            axis2.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, False, 75, 95)

            m_RadialGauge.Axes.Add(axis2)

            ' scale
            Dim scale2 = CType(axis2.Scale, NStandardScale)
            scale2.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            scale2.MinorTickCount = 3
            scale2.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.White, 0.4F))
            scale2.OuterMajorTicks.Fill = New NColorFill(NColor.Blue)
            scale2.Labels.Style.TextStyle.Font = New NFont("Arimo", 12, ENFontStyle.Bold)
            scale2.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            scale2.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)

            ' add range indicators
            Dim rangeIndicator As NRangeIndicator = New NRangeIndicator()
            rangeIndicator.OriginMode = ENRangeIndicatorOriginMode.ScaleMax
            rangeIndicator.Value = 100
            rangeIndicator.Palette = New NThreeColorPalette(NColor.Green, NColor.Red, NColor.Orange, 50.0)
            rangeIndicator.Stroke.Width = 0
            rangeIndicator.OffsetFromScale = 3
            rangeIndicator.BeginWidth = 15
            rangeIndicator.EndWidth = 25

            m_RadialGauge.Indicators.Add(rangeIndicator)

            ' needle value indicator1
            m_ValueIndicator = New NNeedleValueIndicator()
            m_ValueIndicator.Value = 79
            m_ValueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
            m_ValueIndicator.Stroke.Color = NColor.Red
            m_ValueIndicator.ScaleAxis = axis1
            m_ValueIndicator.OffsetFromScale = 2

            m_RadialGauge.Indicators.Add(m_ValueIndicator)

            ' needle value indicator2
            m_ValueIndicator1 = New NNeedleValueIndicator()
            m_ValueIndicator1.Value = 79
            m_ValueIndicator1.ScaleAxis = axis2
            m_ValueIndicator1.OffsetFromScale = 2

            m_RadialGauge.Indicators.Add(m_ValueIndicator1)

            ' timer
            m_DataFeedTimer = New NTimer()
            m_DataFeedTimer.Tick += New [Function](AddressOf OnDataFeedTimerTick)
            m_DataFeedTimer.Start()

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            ' pointer properties group
            Dim controlsGroupBox As NGroupBox = New NGroupBox("Controls")
            propertyStack.Add(controlsGroupBox)
            Dim controlsGroupBoxContent As NStackPanel = New NStackPanel()
            controlsGroupBox.Content = New NUniSizeBoxGroup(controlsGroupBoxContent)

            ' value indicator 1 shape Combo
            m_ValueIndicatorShapeComboBox = New NComboBox()
            m_ValueIndicatorShapeComboBox.FillFromEnum(Of ENNeedleShape)()
            m_ValueIndicatorShapeComboBox.SelectedIndex = m_ValueIndicator.Shape
            m_ValueIndicatorShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnValueIndicatorShapeComboBoxSelectedIndexChanged)
            controlsGroupBoxContent.Add(New NPairBox("Value Indicator 1 Shape:", m_ValueIndicatorShapeComboBox, True))

            ' value indicator 1 width 
            m_ValueIndicatorWidthUpDown = New NNumericUpDown()
            m_ValueIndicatorWidthUpDown.Value = m_ValueIndicator.Width
            m_ValueIndicatorWidthUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnValueIndicatorWidthUpDownValueChanged)
            controlsGroupBoxContent.Add(New NPairBox("Value Indicator 1 Width:", m_ValueIndicatorWidthUpDown, True))

            ' value indicator 2 shape Combo
            m_ValueIndicator1ShapeComboBox = New NComboBox()
            m_ValueIndicator1ShapeComboBox.FillFromEnum(Of ENNeedleShape)()
            m_ValueIndicator1ShapeComboBox.SelectedIndex = m_ValueIndicator1.Shape
            m_ValueIndicator1ShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnValueIndicatorShape1ComboBoxSelectedIndexChanged)
            controlsGroupBoxContent.Add(New NPairBox("Value Indicator 2 Shape:", m_ValueIndicator1ShapeComboBox, True))

            ' value indicator 2 width 
            m_ValueIndicator1WidthUpDown = New NNumericUpDown()
            m_ValueIndicator1WidthUpDown.Value = m_ValueIndicator.Width
            m_ValueIndicator1WidthUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnValueIndicator1WidthUpDownValueChanged)
            controlsGroupBoxContent.Add(New NPairBox("Value Indicator 2 Width:", m_ValueIndicator1WidthUpDown, True))

            ' needle cap visability
            m_CheckBoxShowNeedleCap = New NCheckBox("Show Needle Cap")
            m_CheckBoxShowNeedleCap.Checked = m_CheckBoxShowNeedleCap.Checked
            m_CheckBoxShowNeedleCap.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowNeedleCapChecked)
            controlsGroupBoxContent.Add(m_CheckBoxShowNeedleCap)

            ' cap size
            m_UpDownNeedleCapSize = New NNumericUpDown()
            m_UpDownNeedleCapSize.Value = m_UpDownNeedleCapSize.Value
            m_UpDownNeedleCapSize.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpDownNeedleCapSizeChanged)
            controlsGroupBoxContent.Add(New NPairBox("Change Cap Size", m_UpDownNeedleCapSize, True))

            ' scroll bar
            m_ScrollBar = New NHScrollBar()
            m_ScrollBar.Value = 70.0
            m_ScrollBar.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnScrollBarValueChanged)
            propertyStack.Add(New NPairBox("Percent:", m_ScrollBar, True))

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how use the begin and end percent properties of the anchor in order to change the gauge axis size.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnValueIndicatorShapeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_ValueIndicator.Shape = CType(m_ValueIndicatorShapeComboBox.SelectedIndex, ENNeedleShape)
        End Sub
        Private Sub OnValueIndicatorWidthUpDownValueChanged(arg As NValueChangeEventArgs)
            If Not (TypeOf arg.NewValue Is Double) Then Return

            m_ValueIndicator.Width = CDbl(arg.NewValue)

        End Sub
        Private Sub OnValueIndicatorShape1ComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_ValueIndicator1.Shape = CType(m_ValueIndicator1ShapeComboBox.SelectedIndex, ENNeedleShape)
        End Sub
        Private Sub OnValueIndicator1WidthUpDownValueChanged(arg As NValueChangeEventArgs)
            If Not (TypeOf arg.NewValue Is Double) Then Return

            m_ValueIndicator1.Width = CDbl(arg.NewValue)
        End Sub
        Private Sub OnShowNeedleCapChecked(arg As NValueChangeEventArgs)
            m_RadialGauge.NeedleCap.Visible = m_CheckBoxShowNeedleCap.Checked
        End Sub

        Private Sub OnUpDownNeedleCapSizeChanged(arg As NValueChangeEventArgs)
            Dim capSize = m_UpDownNeedleCapSize.Value
            m_RadialGauge.NeedleCap.Size = New NSize(capSize, capSize)
        End Sub

        Private Sub OnScrollBarValueChanged(arg As NValueChangeEventArgs)
            Dim axis1 = m_RadialGauge.Axes(0)
            Dim axis2 = m_RadialGauge.Axes(1)

            axis1.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, 0, m_ScrollBar.Value - 5)
            axis2.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, False, m_ScrollBar.Value, 95)
            '			 RedAxisTextBox.Text = m_ScrollBar.Value.ToString();
        End Sub
        Private Sub OnDataFeedTimerTick()
            ' update the indicator 
            m_FirstIndicatorAngle += 0.02
            Dim value = 50.0 - Math.Cos(m_FirstIndicatorAngle) * 50.0

            m_ValueIndicator.Value = value
            m_ValueIndicator1.Value = value
        End Sub

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_ScrollBar As NHScrollBar
        Private m_ValueIndicator As NNeedleValueIndicator
        Private m_ValueIndicator1 As NNeedleValueIndicator

        Private m_ValueIndicatorShapeComboBox As NComboBox
        Private m_CheckBoxShowNeedleCap As NCheckBox
        Private m_ValueIndicator1ShapeComboBox As NComboBox

        Private m_ValueIndicatorWidthUpDown As NNumericUpDown
        Private m_ValueIndicator1WidthUpDown As NNumericUpDown
        Private m_UpDownNeedleCapSize As NNumericUpDown

        Private m_DataFeedTimer As NTimer
        Private m_FirstIndicatorAngle As Double


#End Region

#Region "Schema"

        Public Shared ReadOnly NValueIndicatorsStyleExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace
