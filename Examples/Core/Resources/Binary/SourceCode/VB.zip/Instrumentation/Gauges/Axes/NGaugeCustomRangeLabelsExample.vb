Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports Nevron.Nov.Layout

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to control the size of the gauge axes
    ''' </summary>
    Public Class NGaugeCustomRangeLabelsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NGaugeCustomRangeLabelsExampleSchema = NSchema.Create(GetType(NGaugeCustomRangeLabelsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            controlStack.Direction = ENHVDirection.LeftToRight
            stack.Add(controlStack)

            m_LinearGauge = New NLinearGauge()
            m_LinearGauge.Orientation = ENLinearGaugeOrientation.Vertical
            m_LinearGauge.PreferredSize = defaultLinearVerticalGaugeSize
            m_LinearGauge.CapEffect = New NGelCapEffect()
            m_LinearGauge.Border = CreateBorder()
            m_LinearGauge.Padding = New NMargins(20)
            m_LinearGauge.BorderThickness = New NMargins(6)
            controlStack.Add(m_LinearGauge)

            ' create the background panel
            Dim advGradient As NAdvancedGradientFill = New NAdvancedGradientFill()
            advGradient.BackgroundColor = NColor.Black
            advGradient.Points.Add(New NAdvancedGradientPoint(NColor.LightGray, New NAngle(10, NUnit.Degree), 0.1F, 0, 1.0F, ENAdvancedGradientPointShape.Circle))
            m_LinearGauge.BackgroundFill = advGradient

            m_LinearGauge.Axes.Clear()
            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_LinearGauge.Axes.Add(axis)
            axis.Anchor = New NModelGaugeAxisAnchor(24.0, ENVerticalAlignment.Center, ENScaleOrientation.Left)

            ConfigureScale(CType(axis.Scale, NLinearScale))

            ' add some indicators
            m_LinearGauge.Indicators.Add(New NMarkerValueIndicator(60))

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            controlStack.Add(m_RadialGauge)

            m_RadialGauge.CapEffect = New NGlassCapEffect()
            m_RadialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())

            ' set some background
            advGradient = New NAdvancedGradientFill()
            advGradient.BackgroundColor = NColor.Black
            advGradient.Points.Add(New NAdvancedGradientPoint(NColor.LightGray, New NAngle(10, NUnit.Degree), 0.1F, 0, 1.0F, ENAdvancedGradientPointShape.Circle))
            m_RadialGauge.Dial.BackgroundFill = advGradient
            m_RadialGauge.CapEffect = New NGlassCapEffect(ENCapEffectShape.Ellipse)

            ' create the radial gauge
            m_RadialGauge.SweepAngle = New NAngle(270, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(-90, NUnit.Degree)

            Dim scale As NStandardScale = TryCast(axis.Scale, NStandardScale)
            scale.MajorTickMode = ENMajorTickMode.AutoMinDistance
            scale.MinTickDistance = 50

            ' configure the axis
            m_RadialGauge.Axes.Clear()
            axis = New NGaugeAxis()
            axis.Range = New NRange(0, 100)
            axis.Anchor.ScaleOrientation = ENScaleOrientation.Right
            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, ENScaleOrientation.Right, 0, 100)
            m_RadialGauge.Axes.Add(axis)

            ConfigureScale(CType(axis.Scale, NLinearScale))

            ' add some indicators
            Dim needle As NNeedleValueIndicator = New NNeedleValueIndicator(60)
            needle.OffsetOriginMode = ENIndicatorOffsetOriginMode.ScaleMiddle
            needle.OffsetFromScale = 15
            m_RadialGauge.Indicators.Add(needle)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            ' begin angle scroll
            m_BeginAngleScrollBar = New NHScrollBar()
            m_BeginAngleScrollBar.Minimum = -360
            m_BeginAngleScrollBar.Maximum = 360
            m_BeginAngleScrollBar.Value = m_RadialGauge.BeginAngle.ToDegrees()
            propertyStack.Add(New NPairBox("Begin Angle:", m_BeginAngleScrollBar))

            ' sweep angle scroll
            m_SweepAngleScrollBar = New NHScrollBar()
            m_SweepAngleScrollBar.Minimum = -360
            m_SweepAngleScrollBar.Maximum = 360
            m_SweepAngleScrollBar.Value = m_RadialGauge.SweepAngle.ToDegrees()
            propertyStack.Add(New NPairBox("Sweep Angle:", m_SweepAngleScrollBar))

            ' show max check box
            m_ShowMinRangeCheckBox = New NCheckBox("Show Min Range")
            m_ShowMinRangeCheckBox.Checked = True
            propertyStack.Add(m_ShowMinRangeCheckBox)

            ' show min check box
            m_ShowMaxRangeCheckBox = New NCheckBox("Show Max Range")
            m_ShowMaxRangeCheckBox.Checked = True
            propertyStack.Add(m_ShowMaxRangeCheckBox)

            m_BeginAngleScrollBar.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnBeginAngleScrollBarValueChanged)
            m_SweepAngleScrollBar.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSweepAngleScrollBarValueChanged)
            m_ShowMinRangeCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowMinRangeCheckBoxCheckedChanged)
            m_ShowMaxRangeCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowMaxRangeCheckBoxCheckedChanged)

            UpdateAxisRanges()

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to create range labels on the gauge scale.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub ConfigureScale(scale As NLinearScale)
            scale.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            scale.Labels.OverlapResolveLayouts = New NDomArray(Of ENLevelLabelsLayout)()
            scale.MinorTickCount = 3
            scale.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.White, 0.4F))
            scale.OuterMajorTicks.Fill = New NColorFill(NColor.Orange)
            scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 10.0, ENFontStyle.Bold)
            scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
        End Sub
        Private Sub UpdateAxisRanges()
            Dim linearGaugeScale As NLinearScale = TryCast(m_LinearGauge.Axes(0).Scale, NLinearScale)
            Dim radialGaugeScale As NLinearScale = TryCast(m_RadialGauge.Axes(0).Scale, NLinearScale)

            linearGaugeScale.CustomLabels.Clear()
            linearGaugeScale.Sections.Clear()

            radialGaugeScale.CustomLabels.Clear()
            radialGaugeScale.Sections.Clear()

            If m_ShowMinRangeCheckBox.Checked Then
                ApplyScaleSectionToAxis(linearGaugeScale, "Min", New NRange(0, 20), NColor.LightBlue)
                ApplyScaleSectionToAxis(radialGaugeScale, "Min", New NRange(0, 20), NColor.LightBlue)
            End If

            If m_ShowMaxRangeCheckBox.Checked Then
                ApplyScaleSectionToAxis(linearGaugeScale, "Max", New NRange(80, 100), NColor.Red)
                ApplyScaleSectionToAxis(radialGaugeScale, "Max", New NRange(80, 100), NColor.Red)
            End If
        End Sub
        Private Sub ApplyScaleSectionToAxis(scale As NLinearScale, text As String, range As NRange, color As NColor)
            Dim scaleSection As NScaleSection = New NScaleSection()

            scaleSection.Range = range
            scaleSection.LabelTextStyle = New NTextStyle()
            scaleSection.LabelTextStyle.Fill = New NColorFill(color)
            scaleSection.LabelTextStyle.Font = New NFont("Arimo", 10, ENFontStyle.Bold Or ENFontStyle.Italic)
            scaleSection.MajorTickStroke = New NStroke(color)

            scale.Sections.Add(scaleSection)

            Dim rangeLabel As NCustomRangeLabel = New NCustomRangeLabel(range, text)

            rangeLabel.LabelStyle.AlwaysInsideScale = False
            rangeLabel.LabelStyle.VisibilityMode = ENScaleLabelVisibilityMode.TextInRuler
            rangeLabel.LabelStyle.Stroke.Color = color
            rangeLabel.LabelStyle.TextStyle.Fill = New NColorFill(NColor.White)
            rangeLabel.LabelStyle.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)
            rangeLabel.LabelStyle.TickMode = ENRangeLabelTickMode.Center

            scale.CustomLabels.Add(rangeLabel)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnShowMaxRangeCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            UpdateAxisRanges()
        End Sub

        Private Sub OnShowMinRangeCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            UpdateAxisRanges()
        End Sub

        Private Sub OnSweepAngleScrollBarValueChanged(arg As NValueChangeEventArgs)
            m_RadialGauge.SweepAngle = New NAngle(m_SweepAngleScrollBar.Value, NUnit.Degree)
        End Sub

        Private Sub OnBeginAngleScrollBarValueChanged(arg As NValueChangeEventArgs)
            m_RadialGauge.BeginAngle = New NAngle(m_BeginAngleScrollBar.Value, NUnit.Degree)
        End Sub

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_LinearGauge As NLinearGauge

        Private m_BeginAngleScrollBar As NHScrollBar
        Private m_SweepAngleScrollBar As NHScrollBar

        Private m_ShowMinRangeCheckBox As NCheckBox
        Private m_ShowMaxRangeCheckBox As NCheckBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NGaugeCustomRangeLabelsExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Protected Function CreateBorder() As NBorder
            Return NBorder.CreateThreeColorBorder(NColor.LightGray, NColor.White, NColor.DarkGray, 10, 10)
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultLinearVerticalGaugeSize As NSize = New NSize(100, 300)

#End Region
    End Class
End Namespace
