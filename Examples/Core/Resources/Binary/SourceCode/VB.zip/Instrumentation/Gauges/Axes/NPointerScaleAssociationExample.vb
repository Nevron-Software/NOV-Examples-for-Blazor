Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how pointers and ranges can be associated with different scales.
    ''' </summary>
    Public Class NPointerScaleAssociationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' 
        ''' </summary>

        Shared Sub New()
            NPointerScaleAssociationExampleSchema = NSchema.Create(GetType(NPointerScaleAssociationExample), NExampleBaseSchema)

        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            controlStack.Add(m_RadialGauge)

            m_RadialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            m_RadialGauge.Dial.BackgroundFill = New NStockGradientFill(NColor.Silver, NColor.LightSteelBlue)

            Dim gelEffect As NGelCapEffect = New NGelCapEffect(ENCapEffectShape.Ellipse)
            gelEffect.Margins = New NMargins(0, 0, 0, 0.5)

            m_RadialGauge.Axes.Clear()

            ' create the radial gauge
            m_RadialGauge.SweepAngle = New NAngle(360, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(-90, NUnit.Degree)

            ' needle cap size
            m_RadialGauge.NeedleCap.Size = New NSize(25, 25)

            ' create the first axis
            Dim axis1 As NGaugeAxis = New NGaugeAxis()
            axis1.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, 10, 40)

            m_RadialGauge.Axes.Add(axis1)

            ' scale 1
            Dim scale1 = CType(axis1.Scale, NStandardScale)
            scale1.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            scale1.MinorTickCount = 3
            scale1.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.Black, 0.4F))
            scale1.OuterMajorTicks.Fill = New NColorFill(NColor.Orange)
            scale1.Labels.Style.TextStyle.Font = New NFont("Arimo", 12, ENFontStyle.Bold)
            scale1.Labels.Style.TextStyle.Fill = New NColorFill(NColor.DarkSlateBlue)
            scale1.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)

            '  create the second axis
            Dim axis2 As NGaugeAxis = New NGaugeAxis()
            axis2.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, False, 60, 90)

            m_RadialGauge.Axes.Add(axis2)

            ' scale 2 
            Dim scale2 = CType(axis2.Scale, NStandardScale)
            scale2.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            scale2.MinorTickCount = 3
            scale2.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.Black, 0.4F))
            scale2.OuterMajorTicks.Fill = New NColorFill(NColor.Blue)
            scale2.Labels.Style.TextStyle.Font = New NFont("Arimo", 12, ENFontStyle.Bold)
            scale2.Labels.Style.TextStyle.Fill = New NColorFill(NColor.DarkSlateBlue)
            scale2.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)

            ' range indicator
            m_RangeIndicator = New NRangeIndicator()
            m_RangeIndicator.Value = 80
            m_RangeIndicator.Palette = New NTwoColorPalette(NColor.Transparent, NColor.OrangeRed)
            m_RangeIndicator.OriginMode = ENRangeIndicatorOriginMode.ScaleMax
            m_RangeIndicator.Stroke.Width = 0
            m_RangeIndicator.OffsetFromScale = 3
            m_RangeIndicator.BeginWidth = 15
            m_RangeIndicator.EndWidth = 25

            m_RadialGauge.Indicators.Add(m_RangeIndicator)

            ' marker indicator
            m_MarkerIndicator = New NMarkerValueIndicator()
            m_MarkerIndicator.ScaleAxis = axis2
            m_MarkerIndicator.AllowDragging = True
            m_MarkerIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.Orange, NColor.Yellow)

            m_RadialGauge.Indicators.Add(m_MarkerIndicator)

            ' needle value indicator1
            m_ValueIndicator = New NNeedleValueIndicator()
            m_ValueIndicator.Value = 79
            m_ValueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
            m_ValueIndicator.Stroke.Color = NColor.Red
            m_ValueIndicator.OffsetFromScale = 2
            m_ValueIndicator.Shape = ENNeedleShape.Triangle

            m_RadialGauge.Indicators.Add(m_ValueIndicator)

            ' timer 
            m_DataFeedTimer = New NTimer()
            m_DataFeedTimer.Tick += New [Function](AddressOf OnDataFeedTimerTick)
            m_DataFeedTimer.Start()

            Return stack
        End Function

        Private Sub OnDataFeedTimerTick()
            m_FirstIndicatorAngle += 0.02
            Dim value = 50.0 - Math.Cos(m_FirstIndicatorAngle) * 50.0

            m_ValueIndicator.Value = value
            m_MarkerIndicator.Value = value
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            ' pointer properties group
            Dim controlsGroupBox As NGroupBox = New NGroupBox("Controls")
            propertyStack.Add(controlsGroupBox)
            Dim controlsGroupBoxContent As NStackPanel = New NStackPanel()
            controlsGroupBox.Content = New NUniSizeBoxGroup(controlsGroupBoxContent)

            m_NeedlePointerScaleComboBox = New NComboBox()
            m_NeedlePointerScaleComboBox.Items.Add(New NComboBoxItem("Left Scale"))
            m_NeedlePointerScaleComboBox.Items.Add(New NComboBoxItem("Right Scale"))
            m_NeedlePointerScaleComboBox.SelectedIndex = 0
            m_NeedlePointerScaleComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnNeedlePointerScaleComboBoxChanged)

            controlsGroupBoxContent.Add(New NPairBox("Needle Pointer Scale:", m_NeedlePointerScaleComboBox, True))

            m_MarkerPointerScaleComboBox = New NComboBox()
            m_MarkerPointerScaleComboBox.Items.Add(New NComboBoxItem("Left Scale"))
            m_MarkerPointerScaleComboBox.Items.Add(New NComboBoxItem("Right Scale"))
            m_MarkerPointerScaleComboBox.SelectedIndex = 1
            m_MarkerPointerScaleComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMarkerPointerScaleComboBoxChanged)
            controlsGroupBoxContent.Add(New NPairBox("Marker Pointer Scale:", m_MarkerPointerScaleComboBox, True))

            m_RangeScaleComboBox = New NComboBox()
            m_RangeScaleComboBox.Items.Add(New NComboBoxItem("Left Scale"))
            m_RangeScaleComboBox.Items.Add(New NComboBoxItem("Right Scale"))
            m_RangeScaleComboBox.SelectedIndex = 0
            m_RangeScaleComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRangeScaleComboBoxChanged)
            controlsGroupBoxContent.Add(New NPairBox("Range Scale:", m_RangeScaleComboBox, True))

            Return stack
        End Function


        Protected Overrides Function GetExampleDescription() As String
            Return "<p> The example demonstrates how pointers and ranges can be associated with different scales. </p>"
        End Function

#End Region

#Region "Event Handlers    "

        Private Sub OnRangeScaleComboBoxChanged(arg As NValueChangeEventArgs)
            Dim axis = m_RadialGauge.Axes(m_RangeScaleComboBox.SelectedIndex)
            m_RangeIndicator.ScaleAxis = axis

        End Sub
        Private Sub OnMarkerPointerScaleComboBoxChanged(arg As NValueChangeEventArgs)
            Dim axis = m_RadialGauge.Axes(m_MarkerPointerScaleComboBox.SelectedIndex)
            m_MarkerIndicator.ScaleAxis = axis
        End Sub
        Private Sub OnNeedlePointerScaleComboBoxChanged(arg As NValueChangeEventArgs)
            Dim axis = m_RadialGauge.Axes(m_NeedlePointerScaleComboBox.SelectedIndex)
            m_ValueIndicator.ScaleAxis = axis
        End Sub

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_ValueIndicator As NNeedleValueIndicator
        Private m_RangeIndicator As NRangeIndicator
        Private m_MarkerIndicator As NMarkerValueIndicator

        Private m_NeedlePointerScaleComboBox As NComboBox
        Private m_MarkerPointerScaleComboBox As NComboBox
        Private m_RangeScaleComboBox As NComboBox

        Private m_DataFeedTimer As NTimer
        Private m_FirstIndicatorAngle As Double

#End Region

#Region "Schema"

        Public Shared ReadOnly NPointerScaleAssociationExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace
