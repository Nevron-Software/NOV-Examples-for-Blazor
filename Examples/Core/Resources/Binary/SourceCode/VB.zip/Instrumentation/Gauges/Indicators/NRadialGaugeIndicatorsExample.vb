Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to add indicators to a radial gauge 
    ''' </summary>
    Public Class NRadialGaugeIndicatorsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NRadialGaugeIndicatorsExampleSchema = NSchema.Create(GetType(NRadialGaugeIndicatorsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()

            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            m_RadialGauge.CapEffect = New NGlassCapEffect()
            m_RadialGauge.Dial = New NDial(ENDialShape.CutCircle, New NEdgeDialRim())
            m_RadialGauge.Dial.BackgroundFill = New NStockGradientFill(NColor.DarkGray, NColor.Black)

            ' configure scale
            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_RadialGauge.Axes.Add(axis)

            Dim scale = CType(axis.Scale, NLinearScale)

            scale.SetPredefinedScale(ENPredefinedScaleStyle.Presentation)
            scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 10, ENFontStyle.Bold)
            scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            scale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 90.0)
            scale.MinorTickCount = 4
            scale.Ruler.Stroke.Width = 0
            scale.Ruler.Fill = New NColorFill(NColor.DarkGray)

            ' add radial gauge indicators
            m_RangeIndicator = New NRangeIndicator()
            m_RangeIndicator.Value = 20
            m_RangeIndicator.Palette = New NTwoColorPalette(NColor.Green, NColor.Red)
            m_RangeIndicator.Stroke = Nothing
            m_RangeIndicator.EndWidth = 20

            m_RadialGauge.Indicators.Add(m_RangeIndicator)

            m_ValueIndicator = New NNeedleValueIndicator()
            m_ValueIndicator.Value = 79
            m_ValueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
            m_ValueIndicator.Stroke.Color = NColor.Red
            m_ValueIndicator.EnableDampening = True


            m_ValueIndicator.OffsetFromCenter = -20

            m_RadialGauge.Indicators.Add(m_ValueIndicator)
            m_RadialGauge.SweepAngle = New NAngle(270.0, NUnit.Degree)

            ' add radial gauge
            controlStack.Add(m_RadialGauge)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            ' value indicator properties
            Dim valueIndicatorGroupBox As NGroupBox = New NGroupBox("Value")
            propertyStack.Add(valueIndicatorGroupBox)
            Dim valueIndicatorGroupBoxContent As NStackPanel = New NStackPanel()
            valueIndicatorGroupBox.Content = New NUniSizeBoxGroup(valueIndicatorGroupBoxContent)

            Dim markerValueIndicator As NMarkerValueIndicator = New NMarkerValueIndicator()
            markerValueIndicator.Value = 10
            m_RadialGauge.Indicators.Add(markerValueIndicator)

            m_ValueIndicatorUpDown = New NNumericUpDown()
            m_ValueIndicatorUpDown.Value = m_ValueIndicator.Value
            m_ValueIndicatorUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnValueIndicatorUpDownValueChanged)
            valueIndicatorGroupBoxContent.Add(New NPairBox("Value:", m_ValueIndicatorUpDown, True))

            m_ValueIndicatorWidthUpDown = New NNumericUpDown()
            m_ValueIndicatorWidthUpDown.Value = m_ValueIndicator.Width
            m_ValueIndicatorWidthUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnValueIndicatorWidthUpDownValueChanged)
            valueIndicatorGroupBoxContent.Add(New NPairBox("Width:", m_ValueIndicatorWidthUpDown, True))

            m_ValueIndicatorOffsetFromCenterUpDown = New NNumericUpDown()
            m_ValueIndicatorOffsetFromCenterUpDown.Value = m_ValueIndicator.OffsetFromCenter
            m_ValueIndicatorOffsetFromCenterUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnValueIndicatorOffsetFromCenterUpDownValueChanged)
            valueIndicatorGroupBoxContent.Add(New NPairBox("Offset From Center:", m_ValueIndicatorOffsetFromCenterUpDown, True))

            m_ValueIndicatorShapeComboBox = New NComboBox()
            m_ValueIndicatorShapeComboBox.FillFromEnum(Of ENNeedleShape)()
            m_ValueIndicatorShapeComboBox.SelectedIndex = m_ValueIndicator.Shape
            m_ValueIndicatorShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnValueIndicatorShapeComboBoxSelectedIndexChanged)
            valueIndicatorGroupBoxContent.Add(New NPairBox("Shape:", m_ValueIndicatorShapeComboBox, True))

            ' Range indicator properties
            Dim rangeIndicatorGroupBox As NGroupBox = New NGroupBox("Range")
            propertyStack.Add(rangeIndicatorGroupBox)
            Dim rangeIndicatorGroupBoxContent As NStackPanel = New NStackPanel()
            rangeIndicatorGroupBox.Content = New NUniSizeBoxGroup(rangeIndicatorGroupBoxContent)

            m_RangeIndicatorOriginModeComboBox = New NComboBox()
            m_RangeIndicatorOriginModeComboBox.FillFromEnum(Of ENRangeIndicatorOriginMode)()
            m_RangeIndicatorOriginModeComboBox.SelectedIndex = m_RangeIndicator.OriginMode
            rangeIndicatorGroupBoxContent.Add(New NPairBox("Origin Mode:", m_RangeIndicatorOriginModeComboBox, True))

            m_RangeIndicatorOriginUpDown = New NNumericUpDown()
            m_RangeIndicatorOriginUpDown.Value = m_RangeIndicator.Origin
            m_RangeIndicatorOriginUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRangeIndicatorOriginUpDownValueChanged)
            rangeIndicatorGroupBoxContent.Add(New NPairBox("Origin:", m_RangeIndicatorOriginUpDown, True))

            m_RangeIndicatorValueUpDown = New NNumericUpDown()
            m_RangeIndicatorValueUpDown.Value = m_RangeIndicator.Value
            m_RangeIndicatorValueUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRangeIndicatorValueUpDownValueChanged)
            rangeIndicatorGroupBoxContent.Add(New NPairBox("Value:", m_RangeIndicatorValueUpDown, True))

            m_BeginAngleUpDown = New NNumericUpDown()
            m_BeginAngleUpDown.Maximum = 360
            m_BeginAngleUpDown.Minimum = -360
            m_BeginAngleUpDown.Value = m_RadialGauge.BeginAngle.ToDegrees()
            m_BeginAngleUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnBeginAngleUpDownValueChanged)
            propertyStack.Add(New NPairBox("Begin Angle:", m_BeginAngleUpDown, True))

            m_SweepAngleUpDown = New NNumericUpDown()
            m_SweepAngleUpDown.Maximum = 360
            m_SweepAngleUpDown.Minimum = -360
            m_SweepAngleUpDown.Value = m_RadialGauge.SweepAngle.ToDegrees()
            m_SweepAngleUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSweepAngleUpDownValueChanged)
            propertyStack.Add(New NPairBox("Sweep Angle:", m_SweepAngleUpDown, True))

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to create range and needle gauge indicators.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnValueIndicatorWidthUpDownValueChanged(arg As NValueChangeEventArgs)
            m_ValueIndicator.Width = m_ValueIndicatorWidthUpDown.Value
        End Sub

        Private Sub OnValueIndicatorOffsetFromCenterUpDownValueChanged(arg As NValueChangeEventArgs)
            m_ValueIndicator.OffsetFromCenter = m_ValueIndicatorOffsetFromCenterUpDown.Value
        End Sub

        Private Sub OnValueIndicatorShapeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_ValueIndicator.Shape = CType(m_ValueIndicatorShapeComboBox.SelectedIndex, ENNeedleShape)
        End Sub

        Private Sub OnValueIndicatorUpDownValueChanged(arg As NValueChangeEventArgs)
            m_ValueIndicator.Value = m_ValueIndicatorUpDown.Value
        End Sub

        Private Sub OnRangeIndicatorValueUpDownValueChanged(arg As NValueChangeEventArgs)
            m_RangeIndicator.Value = m_RangeIndicatorValueUpDown.Value
        End Sub
        Private Sub OnRangeIndicatorOriginUpDownValueChanged(arg As NValueChangeEventArgs)
            m_RangeIndicator.Origin = m_RangeIndicatorOriginUpDown.Value
        End Sub

        Private Sub OnSweepAngleUpDownValueChanged(arg As NValueChangeEventArgs)
            m_RadialGauge.SweepAngle = New NAngle(m_SweepAngleUpDown.Value, NUnit.Degree)
        End Sub
        Private Sub OnBeginAngleUpDownValueChanged(arg As NValueChangeEventArgs)
            m_RadialGauge.BeginAngle = New NAngle(m_BeginAngleUpDown.Value, NUnit.Degree)
        End Sub

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_RangeIndicator As NRangeIndicator
        Private m_ValueIndicator As NNeedleValueIndicator

        Private m_RangeIndicatorOriginModeComboBox As NComboBox
        Private m_RangeIndicatorOriginUpDown As NNumericUpDown
        Private m_RangeIndicatorValueUpDown As NNumericUpDown

        Private m_ValueIndicatorUpDown As NNumericUpDown
        Private m_ValueIndicatorWidthUpDown As NNumericUpDown
        Private m_ValueIndicatorOffsetFromCenterUpDown As NNumericUpDown
        Private m_ValueIndicatorShapeComboBox As NComboBox

        Private m_BeginAngleUpDown As NNumericUpDown
        Private m_SweepAngleUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NRadialGaugeIndicatorsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace
