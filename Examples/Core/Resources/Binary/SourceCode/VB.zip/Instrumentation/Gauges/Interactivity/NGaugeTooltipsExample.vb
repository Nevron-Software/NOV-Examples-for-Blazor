Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to add tooltips to gauge indicators
    ''' </summary>
    Public Class NGaugeTooltipsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NGaugeTooltipsExampleSchema = NSchema.Create(GetType(NGaugeTooltipsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            Dim radialGauge As NRadialGauge = New NRadialGauge()
            radialGauge.PreferredSize = defaultRadialGaugeSize
            radialGauge.CapEffect = New NGlassCapEffect()
            radialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            radialGauge.Dial.BackgroundFill = NAdvancedGradientFill.Create(ENAdvancedGradientColorScheme.Ocean2, 0)

            ' configure scale
            Dim axis As NGaugeAxis = New NGaugeAxis()
            radialGauge.Axes.Add(axis)
            Dim scale As NLinearScale = TryCast(axis.Scale, NLinearScale)
            scale.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            scale.Labels.OverlapResolveLayouts = New NDomArray(Of ENLevelLabelsLayout)()
            scale.MinorTickCount = 3
            scale.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.White, 0.4F))
            scale.OuterMajorTicks.Fill = New NColorFill(NColor.Orange)
            scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 12.0, ENFontStyle.Bold Or ENFontStyle.Italic)
            scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)

            m_Axis = radialGauge.Axes(0)

            controlStack.Add(radialGauge)

            m_Indicator1 = New NRangeIndicator()
            m_Indicator1.Value = 50
            m_Indicator1.Fill = New NColorFill(NColor.LightBlue)
            m_Indicator1.Stroke.Color = NColor.DarkBlue
            m_Indicator1.EndWidth = 20
            m_Indicator1.AllowDragging = True
            radialGauge.Indicators.Add(m_Indicator1)

            m_Indicator2 = New NNeedleValueIndicator()
            m_Indicator2.Value = 79
            m_Indicator2.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
            m_Indicator2.Stroke.Color = NColor.Red
            m_Indicator2.AllowDragging = True
            radialGauge.Indicators.Add(m_Indicator2)

            m_Indicator3 = New NMarkerValueIndicator()
            m_Indicator3.Value = 90
            m_Indicator3.AllowDragging = True
            radialGauge.Indicators.Add(m_Indicator3)

            radialGauge.SweepAngle = New NAngle(270.0, NUnit.Degree)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            m_RangeTooltipTextBox = New NTextBox()
            m_RangeTooltipTextBox.Text = "Range Tooltip"
            propertyStack.Add(New NPairBox("Range Tooltip:", m_RangeTooltipTextBox, True))

            m_NeedleTooltipTextBox = New NTextBox()
            m_NeedleTooltipTextBox.Text = "Needle Tooltip"
            propertyStack.Add(New NPairBox("Needle Tooltip:", m_NeedleTooltipTextBox, True))

            m_MarkerTooltipTextBox = New NTextBox()
            m_MarkerTooltipTextBox.Text = "Marker Tooltip"
            propertyStack.Add(New NPairBox("Marker Tooltip:", m_MarkerTooltipTextBox, True))

            m_ScaleTooltipTextBox = New NTextBox()
            m_ScaleTooltipTextBox.Text = "Scale Tooltip"
            propertyStack.Add(New NPairBox("Scale Tooltip:", m_ScaleTooltipTextBox, True))

            m_RangeTooltipTextBox.TextChanged += New [Function](Of NValueChangeEventArgs)(AddressOf UpdateTooltips)
            m_NeedleTooltipTextBox.TextChanged += New [Function](Of NValueChangeEventArgs)(AddressOf UpdateTooltips)
            m_MarkerTooltipTextBox.TextChanged += New [Function](Of NValueChangeEventArgs)(AddressOf UpdateTooltips)
            m_ScaleTooltipTextBox.TextChanged += New [Function](Of NValueChangeEventArgs)(AddressOf UpdateTooltips)

            UpdateTooltips(Nothing)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to assign tooltips to different gauge elements.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub UpdateTooltips(arg As NValueChangeEventArgs)
            If m_Axis Is Nothing Then Return

            m_Indicator1.Tooltip = New NTooltip(m_RangeTooltipTextBox.Text)
            m_Indicator2.Tooltip = New NTooltip(m_NeedleTooltipTextBox.Text)
            m_Indicator3.Tooltip = New NTooltip(m_MarkerTooltipTextBox.Text)
        End Sub

#End Region

#Region "Fields"

        Private m_Indicator1 As NRangeIndicator
        Private m_Indicator2 As NNeedleValueIndicator
        Private m_Indicator3 As NMarkerValueIndicator
        Private m_Axis As NGaugeAxis

        Private m_RangeTooltipTextBox As NTextBox
        Private m_NeedleTooltipTextBox As NTextBox
        Private m_MarkerTooltipTextBox As NTextBox
        Private m_ScaleTooltipTextBox As NTextBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NGaugeTooltipsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace
