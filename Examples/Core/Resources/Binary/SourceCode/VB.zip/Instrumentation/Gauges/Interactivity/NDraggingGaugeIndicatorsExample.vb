Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to configure the gauge so that the user can drag gauge indicators
    ''' </summary>
    Public Class NDraggingGaugeIndicatorsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NDraggingGaugeIndicatorsExampleSchema = NSchema.Create(GetType(NDraggingGaugeIndicatorsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            ' create the radial gauge
            Dim radialGauge As NRadialGauge = New NRadialGauge()
            controlStack.Add(radialGauge)

            radialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            radialGauge.PreferredSize = defaultRadialGaugeSize
            radialGauge.Dial.BackgroundFill = New NStockGradientFill(NColor.DarkGray, NColor.Black)
            radialGauge.CapEffect = New NGlassCapEffect()

            ' configure the axis
            Dim axis As NGaugeAxis = New NGaugeAxis()
            radialGauge.Axes.Add(axis)

            Dim scale = CType(axis.Scale, NStandardScale)

            scale.SetPredefinedScale(ENPredefinedScaleStyle.Scientific)
            scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            scale.Labels.Style.TextStyle.Font = New NFont("Tinos", 10, ENFontStyle.Italic Or ENFontStyle.Bold)

            scale.OuterMajorTicks.Stroke.Color = NColor.White
            scale.OuterMajorTicks.Length = 6

            scale.OuterMinorTicks.Stroke.Color = NColor.White
            scale.OuterMinorTicks.Length = 4

            scale.Ruler.Stroke.Color = NColor.White
            scale.MinorTickCount = 4

            ' add some indicators
            m_RangeIndicator = New NRangeIndicator()
            m_RangeIndicator.Value = 50
            m_RangeIndicator.Palette = New NTwoColorPalette(NColor.DarkBlue, NColor.LightBlue)
            m_RangeIndicator.Stroke = Nothing
            m_RangeIndicator.EndWidth = 20
            m_RangeIndicator.AllowDragging = True
            radialGauge.Indicators.Add(m_RangeIndicator)

            m_NeedleIndicator = New NNeedleValueIndicator()
            m_NeedleIndicator.Value = 79
            m_NeedleIndicator.AllowDragging = True
            radialGauge.Indicators.Add(m_NeedleIndicator)
            radialGauge.SweepAngle = New NAngle(270, NUnit.Degree)

            m_MarkerIndicator = New NMarkerValueIndicator()
            m_MarkerIndicator.Value = 90
            m_MarkerIndicator.AllowDragging = True
            m_MarkerIndicator.OffsetOriginMode = ENIndicatorOffsetOriginMode.ScaleEnd
            m_MarkerIndicator.OffsetFromScale = 0.0
            radialGauge.Indicators.Add(m_MarkerIndicator)

            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            m_IndicatorSnapModeComboBox = New NComboBox()
            m_IndicatorSnapModeComboBox.FillFromArray(New String() {"None", "Ruler", "Major ticks", "Minor ticks", "Ruler Min/Max", "Numeric"})
            m_IndicatorSnapModeComboBox.SelectedIndex = 0
            m_IndicatorSnapModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUdpdateIndicatorValueSnapper)
            propertyStack.Add(New NPairBox("Indicator Snap Mode:", m_IndicatorSnapModeComboBox, True))

            m_StepNumericUpDown = New NNumericUpDown()
            m_StepNumericUpDown.Enabled = False
            m_StepNumericUpDown.Value = 5.0
            m_StepNumericUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUdpdateIndicatorValueSnapper)
            propertyStack.Add(New NPairBox("Step:", m_StepNumericUpDown, True))

            m_AllowDraggingRangeIndicator = New NCheckBox("Allow Dragging Range")
            m_AllowDraggingRangeIndicator.Checked = m_RangeIndicator.AllowDragging
            m_AllowDraggingRangeIndicator.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnAllowDraggingRangeIndicator)
            propertyStack.Add(m_AllowDraggingRangeIndicator)

            m_AllowDraggingNeedleIndicator = New NCheckBox("Allow Dragging Needle")
            m_AllowDraggingNeedleIndicator.Checked = m_NeedleIndicator.AllowDragging
            m_AllowDraggingNeedleIndicator.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnAllowDraggingNeedleIndicator)
            propertyStack.Add(m_AllowDraggingNeedleIndicator)

            m_AllowDraggingMarkerIndicator = New NCheckBox("Allow Dragging Marker")
            m_AllowDraggingMarkerIndicator.Checked = m_MarkerIndicator.AllowDragging
            m_AllowDraggingMarkerIndicator.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnAllowDraggingMarkerIndicator)
            propertyStack.Add(m_AllowDraggingMarkerIndicator)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to enable dragging of gauge indicators.</p>"
        End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates an indicator value snapper
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateValueSnapper() As NValueSnapper
            Select Case m_IndicatorSnapModeComboBox.SelectedIndex
                Case 0 'None, snapping is disabled
                    Return Nothing
                Case 1 ' Ruler, values are constrained to the ruler begin and end values.
                    Return New NAxisRulerClampSnapper()
                Case 2 ' Major ticks, values are snapped to axis major ticks
                    Return New NAxisMajorTickSnapper()
                Case 3 ' Minor ticks, values are snapped to axis minor ticks
                    Return New NAxisMinorTickSnapper()
                Case 4 ' Ruler Min Max, values are snapped to the ruler min and max values
                    Return New NAxisRulerMinMaxSnapper()
                Case 5
                    Return New NNumericValueSnapper(0.0, m_StepNumericUpDown.Value)
                Case Else
                    Return Nothing
            End Select
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnAllowDraggingMarkerIndicator(arg As NValueChangeEventArgs)
            m_MarkerIndicator.AllowDragging = m_AllowDraggingMarkerIndicator.Checked
        End Sub

        Private Sub OnAllowDraggingNeedleIndicator(arg As NValueChangeEventArgs)
            m_NeedleIndicator.AllowDragging = m_AllowDraggingNeedleIndicator.Checked
        End Sub

        Private Sub OnAllowDraggingRangeIndicator(arg As NValueChangeEventArgs)
            m_RangeIndicator.AllowDragging = m_AllowDraggingRangeIndicator.Checked
        End Sub

        Private Sub OnUdpdateIndicatorValueSnapper(arg As NValueChangeEventArgs)
            m_RangeIndicator.ValueSnapper = CreateValueSnapper()
            m_NeedleIndicator.ValueSnapper = CreateValueSnapper()
            m_MarkerIndicator.ValueSnapper = CreateValueSnapper()
        End Sub

        Private Sub OnAllowDragRangeIndicatorsCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            ' m_Indicator1.AllowDragging = m_AllowDragRangeIndicatorsCheckBox.Checked;
        End Sub

#End Region

#Region "Fields"

        Private m_RangeIndicator As NRangeIndicator
        Private m_NeedleIndicator As NNeedleValueIndicator
        Private m_MarkerIndicator As NMarkerValueIndicator

        Private m_StepNumericUpDown As NNumericUpDown

        Private m_IndicatorSnapModeComboBox As NComboBox
        Private m_AllowDraggingRangeIndicator As NCheckBox
        Private m_AllowDraggingNeedleIndicator As NCheckBox
        Private m_AllowDraggingMarkerIndicator As NCheckBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NDraggingGaugeIndicatorsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace
