Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates the functionality of the NTextLedDisplayExample.
    ''' </summary>
    Public Class NTextLedDisplayExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NTextLedDisplayExampleSchema = NSchema.Create(GetType(NTextLedDisplayExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            m_TextDisplay1 = CreateTextLedDisplay()
            stack.Add(m_TextDisplay1)

            m_TextDisplay2 = CreateTextLedDisplay()
            stack.Add(m_TextDisplay2)

            m_TextDisplay3 = CreateTextLedDisplay()
            stack.Add(m_TextDisplay3)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            m_CellCountUpDown = New NNumericUpDown()
            Me.m_CellCountUpDown.ValueChanged += AddressOf OnCellCountValueChanged
            m_CellCountUpDown.Value = 20
            propertyStack.Add(NPairBox.Create("Cell Count:", m_CellCountUpDown))

            ' init form controls
            m_CellSizeComboBox = New NComboBox()
            propertyStack.Add(New NPairBox("Cell Size:", m_CellSizeComboBox, True))

            m_CellSizeComboBox.Items.Add(New NComboBoxItem("Small"))
            m_CellSizeComboBox.Items.Add(New NComboBoxItem("Normal"))
            m_CellSizeComboBox.Items.Add(New NComboBoxItem("Large"))
            m_CellSizeComboBox.SelectedIndex = 1
            m_CellSizeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnCellSizeComboBoxSelectedIndexChanged)

            m_DisplayStyleComboBox = New NComboBox()
            propertyStack.Add(New NPairBox("Display Style:", m_DisplayStyleComboBox, True))
            m_DisplayStyleComboBox.FillFromEnum(Of ENDisplayStyle)()
            m_DisplayStyleComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnDisplayStyleComboBoxSelectedIndexChanged)
            m_DisplayStyleComboBox.SelectedIndex = CInt(ENDisplayStyle.MatrixCircle)


            Dim litFillButton As NButton = New NButton("Lit Fill")
            litFillButton.Click += New [Function](Of NEventArgs)(AddressOf OnLitFillButtonClick)
            propertyStack.Add(litFillButton)

            Dim dimFillButton As NButton = New NButton("Dim Fill")
            dimFillButton.Click += New [Function](Of NEventArgs)(AddressOf OnDimFillButtonClick)
            propertyStack.Add(dimFillButton)


            Dim textBox1 As NTextBox = New NTextBox()
            textBox1.TextChanged += AddressOf OnTextBox1TextChanged
            textBox1.Text = "Custom Text 1"
            propertyStack.Add(NPairBox.Create("Text 1", textBox1))

            Dim textBox2 As NTextBox = New NTextBox()
            textBox2.TextChanged += AddressOf OnTextBox2TextChanged
            textBox2.Text = "Custom Text 2"
            propertyStack.Add(NPairBox.Create("Text 2", textBox2))

            Dim textBox3 As NTextBox = New NTextBox()
            textBox3.TextChanged += AddressOf OnTextBox3TextChanged
            textBox3.Text = "Custom Text 3"
            propertyStack.Add(NPairBox.Create("Text 3", textBox3))

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates the properties of the text led display.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateTextLedDisplay() As NTextLedDisplay
            Dim textLedDisply As NTextLedDisplay = New NTextLedDisplay()

            textLedDisply.CellCountMode = ENDisplayCellCountMode.Fixed
            textLedDisply.CellCount = 7
            textLedDisply.BackgroundFill = New NColorFill(NColor.Black)

            textLedDisply.Border = NBorder.CreateSunken3DBorder(New NUIThemeColorMap(ENUIThemeScheme.WindowsClassic))
            textLedDisply.BorderThickness = New NMargins(6)
            textLedDisply.Margins = New NMargins(5)
            textLedDisply.Padding = New NMargins(5)
            textLedDisply.CapEffect = New NGelCapEffect()

            Return textLedDisply
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnLitFillButtonClick(arg As NEventArgs)
            Call NEditorWindow.CreateForType(CType(m_TextDisplay1.LitFill.DeepClone(), NFill), Nothing, m_TextDisplay1.DisplayWindow, False, New [Function](Of T)(AddressOf OnLitFillEdited)).Open()


        End Sub

        Private Sub OnLitFillEdited(fill As NFill)
            m_TextDisplay1.LitFill = CType((fill.DeepClone()), NFill)
            m_TextDisplay2.LitFill = CType((fill.DeepClone()), NFill)
            m_TextDisplay3.LitFill = CType((fill.DeepClone()), NFill)
        End Sub

        Private Sub OnDimFillButtonClick(arg As NEventArgs)
            Call NEditorWindow.CreateForType(CType(m_TextDisplay1.DimFill.DeepClone(), NFill), Nothing, m_TextDisplay1.DisplayWindow, False, New [Function](Of T)(AddressOf OnDimFillEdited)).Open()


        End Sub

        Private Sub OnDimFillEdited(fill As NFill)
            m_TextDisplay1.DimFill = CType((fill.DeepClone()), NFill)
            m_TextDisplay2.DimFill = CType((fill.DeepClone()), NFill)
            m_TextDisplay3.DimFill = CType((fill.DeepClone()), NFill)
        End Sub

        Private Sub OnCellSizeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim segmentWidth = 0.0
            Dim segmentGap = 0.0
            Dim cellSize As NSize = New NSize(0.0, 0.0)

            Select Case m_CellSizeComboBox.SelectedIndex
                Case 0 ' small
                    segmentWidth = 2.0
                    segmentGap = 1.0
                    cellSize = New NSize(15, 30)
                Case 1 ' normal
                    segmentWidth = 3
                    segmentGap = 1
                    cellSize = New NSize(20, 40)
                Case 2 ' large
                    segmentWidth = 4
                    segmentGap = 2
                    cellSize = New NSize(26, 52)
            End Select

            Dim displays = New NTextLedDisplay() {m_TextDisplay1, m_TextDisplay2, m_TextDisplay3}

            For i = 0 To displays.Length - 1
                Dim display = displays(i)

                display.CellSize = cellSize
                display.SegmentGap = segmentGap
                display.SegmentWidth = segmentWidth
            Next
        End Sub

        Private Sub OnDisplayStyleComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_TextDisplay1.DisplayStyle = CType(m_DisplayStyleComboBox.SelectedIndex, ENDisplayStyle)
            m_TextDisplay2.DisplayStyle = CType(m_DisplayStyleComboBox.SelectedIndex, ENDisplayStyle)
            m_TextDisplay3.DisplayStyle = CType(m_DisplayStyleComboBox.SelectedIndex, ENDisplayStyle)
        End Sub

        Private Sub OnTextBox1TextChanged(arg As NValueChangeEventArgs)
            m_TextDisplay1.Text = CStr(arg.NewValue)
        End Sub

        Private Sub OnTextBox2TextChanged(arg As NValueChangeEventArgs)
            m_TextDisplay2.Text = CStr(arg.NewValue)
        End Sub

        Private Sub OnTextBox3TextChanged(arg As NValueChangeEventArgs)
            m_TextDisplay3.Text = CStr(arg.NewValue)
        End Sub

        Private Sub OnCellCountValueChanged(arg As NValueChangeEventArgs)
            m_TextDisplay1.CellCount = CInt(m_CellCountUpDown.Value)
            m_TextDisplay2.CellCount = CInt(m_CellCountUpDown.Value)
            m_TextDisplay3.CellCount = CInt(m_CellCountUpDown.Value)
        End Sub

#End Region

#Region "Fields"

        Private m_DisplayStyleComboBox As NComboBox
        Private m_TextDisplay1 As NTextLedDisplay
        Private m_TextDisplay2 As NTextLedDisplay
        Private m_TextDisplay3 As NTextLedDisplay
        Private m_CellSizeComboBox As NComboBox

        Private m_CellCountUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NTextLedDisplayExampleSchema As NSchema

#End Region
    End Class
End Namespace
