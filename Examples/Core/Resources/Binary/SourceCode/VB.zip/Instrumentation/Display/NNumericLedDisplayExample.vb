Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates the functionality of the NNumericDisplayPanel.
    ''' </summary>
    Public Class NNumericLedDisplayExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NNumericLedDisplayExampleSchema = NSchema.Create(GetType(NNumericLedDisplayExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.Unregistered += AddressOf OnStackUnregistered

            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            m_NumericDisplay1 = CreateNumericLedDisplay()
            stack.Add(m_NumericDisplay1)

            m_NumericDisplay2 = CreateNumericLedDisplay()
            stack.Add(m_NumericDisplay2)

            m_NumericDisplay3 = CreateNumericLedDisplay()
            stack.Add(m_NumericDisplay3)

            m_DataFeedTimer = New NTimer()
            m_DataFeedTimer.Tick += New [Function](AddressOf OnDataFeedTimerTick)
            m_DataFeedTimer.Start()

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            ' init form controls
            m_CellSizeComboBox = New NComboBox()
            propertyStack.Add(New NPairBox("Cell Size:", m_CellSizeComboBox, True))

            m_CellSizeComboBox.Items.Add(New NComboBoxItem("Small"))
            m_CellSizeComboBox.Items.Add(New NComboBoxItem("Normal"))
            m_CellSizeComboBox.Items.Add(New NComboBoxItem("Large"))
            m_CellSizeComboBox.SelectedIndex = 1
            m_CellSizeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnCellSizeComboBoxSelectedIndexChanged)

            m_DisplayStyleComboBox = New NComboBox()
            propertyStack.Add(New NPairBox("Display Style:", m_DisplayStyleComboBox, True))
            m_DisplayStyleComboBox.FillFromEnum(Of ENDisplayStyle)()
            m_DisplayStyleComboBox.SelectedIndex = m_NumericDisplay1.DisplayStyle
            m_DisplayStyleComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnDisplayStyleComboBoxSelectedIndexChanged)

            m_ContentAlignmentComboBox = New NComboBox()
            propertyStack.Add(New NPairBox("Content Alignment:", m_ContentAlignmentComboBox, True))

            m_ContentAlignmentComboBox.FillFromEnum(Of ENContentAlignment)()
            m_ContentAlignmentComboBox.SelectedIndex = m_NumericDisplay1.ContentAlignment
            m_ContentAlignmentComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnContentAlignmentComboBoxSelectedIndexChanged)

            m_SignModeComboBox = New NComboBox()
            propertyStack.Add(New NPairBox("Sign Mode", m_SignModeComboBox, True))

            m_SignModeComboBox.FillFromEnum(Of ENDisplaySignMode)()
            m_SignModeComboBox.SelectedIndex = m_NumericDisplay1.SignMode
            m_SignModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSignModeComboBoxSelectedIndexChanged)

            m_ShowLeadingZerosCheckBox = New NCheckBox("Show Leading Zeroes")
            propertyStack.Add(m_ShowLeadingZerosCheckBox)
            m_ShowLeadingZerosCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowLeadingZerosCheckBoxCheckedChanged)

            m_AttachSignToNumberCheckBox = New NCheckBox("Attach Sign to Number")
            propertyStack.Add(m_AttachSignToNumberCheckBox)
            m_AttachSignToNumberCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnAttachSignToNumberCheckBoxCheckedChanged)

            Dim litFillButton As NButton = New NButton("Lit Fill")
            litFillButton.Click += New [Function](Of NEventArgs)(AddressOf OnLitFillButtonClick)
            propertyStack.Add(litFillButton)

            Dim dimFillButton As NButton = New NButton("Dim Fill")
            dimFillButton.Click += New [Function](Of NEventArgs)(AddressOf OnDimFillButtonClick)
            propertyStack.Add(dimFillButton)

            m_StopStartTimerButton = New NButton("Stop Timer")
            Me.m_StopStartTimerButton.Click += AddressOf OnStopStartTimerButtonClick
            propertyStack.Add(m_StopStartTimerButton)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates the properties of the numeric led display.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateNumericLedDisplay() As NNumericLedDisplay
            Dim numericLedDisplay As NNumericLedDisplay = New NNumericLedDisplay()

            numericLedDisplay.Value = 0.0
            numericLedDisplay.CellCountMode = ENDisplayCellCountMode.Fixed
            numericLedDisplay.CellCount = 7
            numericLedDisplay.BackgroundFill = New NColorFill(NColor.Black)

            numericLedDisplay.Border = NBorder.CreateSunken3DBorder(New NUIThemeColorMap(ENUIThemeScheme.WindowsClassic))
            numericLedDisplay.BorderThickness = New NMargins(6)
            numericLedDisplay.Margins = New NMargins(5)
            numericLedDisplay.Padding = New NMargins(5)
            numericLedDisplay.CapEffect = New NGelCapEffect()

            Return numericLedDisplay
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnStopStartTimerButtonClick(arg As NEventArgs)
            Dim label = CType(CType(arg.TargetNode, NButton).Content, NLabel)
            If label.Text.StartsWith("Stop") Then
                label.Text = "Start Timer"
                m_DataFeedTimer.Stop()
            Else
                label.Text = "Stop Timer"
                m_DataFeedTimer.Start()
            End If
        End Sub

        Private Sub OnDataFeedTimerTick()
            Dim value1 = -50 + m_Random.Next(10000) / 100.0
            m_NumericDisplay1.Value = value1

            Dim value2 As Double

            If m_Counter Mod 4 = 0 Then
                value2 = -50 + m_Random.Next(10000) / 100.0
                m_NumericDisplay2.Value = value2
            End If

            Dim value3 As Double
            If m_Counter Mod 8 = 0 Then
                value3 = 200 + m_Random.Next(10000) / 100.0
                m_NumericDisplay3.Value = value3
            End If

            m_Counter += 1
        End Sub

        Private Sub OnLitFillButtonClick(arg As NEventArgs)
            Call NEditorWindow.CreateForType(CType(m_NumericDisplay1.LitFill.DeepClone(), NFill), Nothing, m_NumericDisplay1.DisplayWindow, False, New [Function](Of T)(AddressOf OnLitFillEdited)).Open()


        End Sub

        Private Sub OnLitFillEdited(fill As NFill)
            m_NumericDisplay1.LitFill = CType((fill.DeepClone()), NFill)
            m_NumericDisplay2.LitFill = CType((fill.DeepClone()), NFill)
            m_NumericDisplay3.LitFill = CType((fill.DeepClone()), NFill)
        End Sub

        Private Sub OnDimFillButtonClick(arg As NEventArgs)
            Call NEditorWindow.CreateForType(CType(m_NumericDisplay1.DimFill.DeepClone(), NFill), Nothing, m_NumericDisplay1.DisplayWindow, False, New [Function](Of T)(AddressOf OnDimFillEdited)).Open()


        End Sub

        Private Sub OnDimFillEdited(fill As NFill)
            m_NumericDisplay1.DimFill = CType((fill.DeepClone()), NFill)
            m_NumericDisplay1.DecimalDimFill = CType((fill.DeepClone()), NFill)

            m_NumericDisplay2.DimFill = CType((fill.DeepClone()), NFill)
            m_NumericDisplay2.DecimalDimFill = CType((fill.DeepClone()), NFill)

            m_NumericDisplay3.DimFill = CType((fill.DeepClone()), NFill)
            m_NumericDisplay3.DecimalDimFill = CType((fill.DeepClone()), NFill)
        End Sub

        Private Sub OnCellSizeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim segmentWidth = 0.0
            Dim segmentGap = 0.0
            Dim cellSize As NSize = New NSize(0.0, 0.0)

            Select Case m_CellSizeComboBox.SelectedIndex
                Case 0 ' small
                    segmentWidth = 2.0
                    segmentGap = 1.0
                    cellSize = New NSize(15, 30)
                Case 1 ' normal
                    segmentWidth = 3
                    segmentGap = 1
                    cellSize = New NSize(20, 40)
                Case 2 ' large
                    segmentWidth = 4
                    segmentGap = 2
                    cellSize = New NSize(26, 52)
            End Select

            Dim displays = New NNumericLedDisplay() {m_NumericDisplay1, m_NumericDisplay2, m_NumericDisplay3}

            For i = 0 To displays.Length - 1
                Dim display = displays(i)

                display.CellSize = cellSize
                display.SegmentGap = segmentGap
                display.SegmentWidth = segmentWidth

                display.DecimalCellSize = cellSize
                display.DecimalSegmentGap = segmentGap
                display.DecimalSegmentWidth = segmentWidth
            Next
        End Sub

        Private Sub OnDisplayStyleComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_NumericDisplay1.DisplayStyle = CType(m_DisplayStyleComboBox.SelectedIndex, ENDisplayStyle)
            m_NumericDisplay2.DisplayStyle = CType(m_DisplayStyleComboBox.SelectedIndex, ENDisplayStyle)
            m_NumericDisplay3.DisplayStyle = CType(m_DisplayStyleComboBox.SelectedIndex, ENDisplayStyle)
        End Sub

        Private Sub OnContentAlignmentComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_NumericDisplay1.ContentAlignment = CType(m_ContentAlignmentComboBox.SelectedIndex, ENContentAlignment)
            m_NumericDisplay2.ContentAlignment = CType(m_ContentAlignmentComboBox.SelectedIndex, ENContentAlignment)
            m_NumericDisplay3.ContentAlignment = CType(m_ContentAlignmentComboBox.SelectedIndex, ENContentAlignment)
        End Sub

        Private Sub OnStopStartTimerButtonClick(sender As Object, e As EventArgs)
            If m_DataFeedTimer.IsStarted Then
                m_DataFeedTimer.Stop()
                m_StopStartTimerButton.Content = New NLabel("Start Timer")
            Else
                m_DataFeedTimer.Start()
                m_StopStartTimerButton.Content = New NLabel("Stop Timer")
            End If
        End Sub

        Private Sub OnSignModeComboBoxSelectedIndexChanged(arg As NValueChangeEventArgs)
            m_NumericDisplay1.SignMode = CType(m_SignModeComboBox.SelectedIndex, ENDisplaySignMode)
            m_NumericDisplay2.SignMode = CType(m_SignModeComboBox.SelectedIndex, ENDisplaySignMode)
            m_NumericDisplay3.SignMode = CType(m_SignModeComboBox.SelectedIndex, ENDisplaySignMode)
        End Sub

        Private Sub OnShowLeadingZerosCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_NumericDisplay1.ShowLeadingZeros = m_ShowLeadingZerosCheckBox.Checked
            m_NumericDisplay2.ShowLeadingZeros = m_ShowLeadingZerosCheckBox.Checked
            m_NumericDisplay3.ShowLeadingZeros = m_ShowLeadingZerosCheckBox.Checked
        End Sub

        Private Sub OnAttachSignToNumberCheckBoxCheckedChanged(arg As NValueChangeEventArgs)
            m_NumericDisplay1.AttachSignToNumber = m_AttachSignToNumberCheckBox.Checked
            m_NumericDisplay2.AttachSignToNumber = m_AttachSignToNumberCheckBox.Checked
            m_NumericDisplay3.AttachSignToNumber = m_AttachSignToNumberCheckBox.Checked
        End Sub

        Private Sub OnStackUnregistered(arg As NEventArgs)
            m_DataFeedTimer.Stop()
        End Sub

#End Region

#Region "Fields"

        Private m_StopStartTimerButton As NButton
        Private m_AttachSignToNumberCheckBox As NCheckBox
        Private m_ShowLeadingZerosCheckBox As NCheckBox
        Private m_SignModeComboBox As NComboBox
        Private m_ContentAlignmentComboBox As NComboBox
        Private m_DisplayStyleComboBox As NComboBox

        Private m_NumericDisplay1 As NNumericLedDisplay
        Private m_NumericDisplay2 As NNumericLedDisplay
        Private m_NumericDisplay3 As NNumericLedDisplay
        Private m_DataFeedTimer As NTimer
        Private m_CellSizeComboBox As NComboBox
        Private m_Counter As Integer = 0
        Private m_Random As Random = New Random()

#End Region

#Region "Schema"

        Public Shared ReadOnly NNumericLedDisplayExampleSchema As NSchema

#End Region
    End Class
End Namespace
