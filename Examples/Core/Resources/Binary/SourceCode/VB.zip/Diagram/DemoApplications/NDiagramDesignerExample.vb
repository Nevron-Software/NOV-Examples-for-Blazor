Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.UI
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NDiagramDesignerExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NDiagramDesignerExampleSchema = NSchema.Create(GetType(NDiagramDesignerExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a library browser that displays all predefined shape factories
            m_LibraryBrowser = New NLibraryBrowser()
            m_LibraryBrowser.LibraryViewType = ENLibraryViewType.Thumbnails

            ' create pan and zoom
            m_PanAndZoom = New NPanAndZoomView()
            m_PanAndZoom.PreferredSize = New NSize(150, 150)

            ' create side bar
            m_SideBar = New NSideBar()

            ' create a drawing view
            m_DrawingView = New NDrawingView()
            m_DrawingView.HorizontalPlacement = ENHorizontalPlacement.Fit
            m_DrawingView.VerticalPlacement = ENVerticalPlacement.Fit

            ' bind components to drawing view
            m_LibraryBrowser.DrawingView = m_DrawingView
            m_LibraryBrowser.ResetLibraries()
            m_PanAndZoom.DrawingView = m_DrawingView
            m_SideBar.DrawingView = m_DrawingView

            ' create splitters
            Dim libraryPanSplitter As NSplitter = New NSplitter()
            libraryPanSplitter.Orientation = ENHVOrientation.Vertical
            libraryPanSplitter.SplitMode = ENSplitterSplitMode.OffsetFromFarSide
            libraryPanSplitter.Pane1.Content = m_LibraryBrowser
            libraryPanSplitter.Pane2.Content = m_PanAndZoom

            Dim leftSplitter As NSplitter = New NSplitter()
            leftSplitter.Orientation = ENHVOrientation.Horizontal
            leftSplitter.SplitMode = ENSplitterSplitMode.OffsetFromNearSide
            leftSplitter.SplitOffset = 370
            leftSplitter.Pane1.Content = libraryPanSplitter
            leftSplitter.Pane2.Content = m_DrawingView

            Dim rightSplitter As NSplitter = New NSplitter()
            rightSplitter.Orientation = ENHVOrientation.Horizontal
            rightSplitter.SplitMode = ENSplitterSplitMode.OffsetFromFarSide
            rightSplitter.SplitOffset = 370
            rightSplitter.Pane1.Content = leftSplitter
            rightSplitter.Pane2.Content = m_SideBar

            ' Create the ribbon UI
            Dim builder As NDiagramRibbonBuilder = New NDiagramRibbonBuilder()
            Return builder.CreateUI(rightSplitter, m_DrawingView)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates how to create a Diagram Designer Application</p>"
        End Function

#End Region

#Region "Fields"

        Private m_LibraryBrowser As NLibraryBrowser
        Private m_DrawingView As NDrawingView
        Private m_PanAndZoom As NPanAndZoomView
        Private m_SideBar As NSideBar

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDiagramDesignerExample.
        ''' </summary>
        Public Shared ReadOnly NDiagramDesignerExampleSchema As NSchema

#End Region
    End Class
End Namespace
