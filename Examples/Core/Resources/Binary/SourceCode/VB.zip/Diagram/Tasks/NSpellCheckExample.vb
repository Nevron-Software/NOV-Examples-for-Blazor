Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NSpellCheckExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NSpellCheckExampleSchema = NSchema.Create(GetType(NSpellCheckExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim enableSpellCheck As NCheckBox = New NCheckBox("Enable Spell Check")
            enableSpellCheck.Click += New [Function](Of NEventArgs)(AddressOf OnEnableSpellCheckButtonClick)
            stack.Add(enableSpellCheck)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>
						Demonstrates how to enable the build in spell check.
					</p>"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            ' Hide the grid
            Dim drawing = drawingDocument.Content
            drawing.ScreenVisibility.ShowGrid = False

            Dim basicShapesFactory As NBasicShapeFactory = New NBasicShapeFactory()

            Dim shape1 = basicShapesFactory.CreateShape(ENBasicShape.Rectangle)
            shape1.SetBounds(10, 10, 200, 200)
            shape1.TextBlock = New NTextBlock()
            shape1.TextBlock.Padding = New NMargins(20)
            shape1.TextBlock.Text = "This text cantains many typpos. This text contuins manyy typos."
            drawing.ActivePage.Items.Add(shape1)
        End Sub

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' Called when the user presses the find all button
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnEnableSpellCheckButtonClick(arg As NEventArgs)
            m_DrawingView.SpellChecker.Enabled = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NSpellCheckExample.
        ''' </summary>
        Public Shared ReadOnly NSpellCheckExampleSchema As NSchema

#End Region
    End Class
End Namespace
