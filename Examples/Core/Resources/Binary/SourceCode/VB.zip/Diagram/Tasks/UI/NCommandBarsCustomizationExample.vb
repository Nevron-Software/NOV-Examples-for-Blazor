Imports Nevron.Nov.Dom
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.DrawingCommands
Imports Nevron.Nov.UI
Imports Nevron.Nov.Diagram.Shapes

Namespace Nevron.Nov.Examples.Diagram
    Public Class NCommandBarsCustomizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCommandBarsCustomizationExampleSchema = NSchema.Create(GetType(NCommandBarsCustomizationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            m_DrawingView = New NDrawingView()

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            ' Create and customize a command bar UI builder
            m_CommandBarBuilder = New NDiagramCommandBarBuilder()

            ' Add the custom command action to the drawing view's commander
            m_DrawingView.Commander.Add(New CustomCommandAction())

            ' Remove the "Edit" menu and insert a custom one
            m_CommandBarBuilder = New NDiagramCommandBarBuilder()
            m_CommandBarBuilder.MenuDropDownBuilders.Remove(NDiagramCommandBarBuilder.MenuEditName)
            m_CommandBarBuilder.MenuDropDownBuilders.Insert(1, New CustomMenuBuilder())

            ' Remove the "Standard" toolbar and insert a custom one
            m_CommandBarBuilder.ToolBarBuilders.Remove(NDiagramCommandBarBuilder.ToolbarStandardName)
            m_CommandBarBuilder.ToolBarBuilders.Insert(0, New CustomToolBarBuilder())

            Return m_CommandBarBuilder.CreateUI(m_DrawingView)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to customize the NOV diagram command bars (menus and toolbars).</p>
"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim factory As NBasicShapeFactory = New NBasicShapeFactory()
            Dim shape = factory.CreateShape(ENBasicShape.Rectangle)
            shape.SetBounds(100, 100, 150, 100)
            drawingDocument.Content.ActivePage.Items.Add(shape)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_CommandBarBuilder As NDiagramCommandBarBuilder

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCommandBarsCustomizationExample.
        ''' </summary>
        Public Shared ReadOnly NCommandBarsCustomizationExampleSchema As NSchema

#End Region

#Region "Constants"

        Public Shared ReadOnly CustomCommand As NCommand = NCommand.Create(GetType(NCommandBarsCustomizationExample), "CustomCommand", "Custom Command")

#End Region

#Region "Nested Types"

        Public Class CustomMenuBuilder
            Inherits NMenuDropDownBuilder
            Public Sub New()
                MyBase.New("Custom Menu")
            End Sub

            Protected Overrides Sub AddItems(items As NMenuItemCollection)
                ' Add the "Copy" menu item
                items.Add(CreateMenuItem(Presentation.NResources.Image_Edit_Copy_png, NDrawingView.CopyCommand))

                ' Add the custom command menu item
                items.Add(CreateMenuItem(NResources.Image_Ribbon_16x16_smiley_png, CustomCommand))
            End Sub
        End Class

        Public Class CustomToolBarBuilder
            Inherits NToolBarBuilder
            Public Sub New()
                MyBase.New("Custom Toolbar")
            End Sub

            Protected Overrides Sub AddItems(items As NCommandBarItemCollection)
                ' Add the "Copy" button
                items.Add(MyBase.CreateButton(Presentation.NResources.Image_Edit_Copy_png, NDrawingView.CopyCommand))

                ' Add the custom command button
                items.Add(CreateButton(NResources.Image_Ribbon_16x16_smiley_png, CustomCommand))
            End Sub
        End Class

        Public Class CustomCommandAction
            Inherits NDrawingCommandAction
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomCommandActionSchema = NSchema.Create(GetType(CustomCommandAction), NDrawingCommandActionSchema)
            End Sub

#End Region

#Region "Public Overrides"

            ''' <summary>
            ''' Gets the command associated with this command action.
            ''' </summary>
            ''' <returns></returns>
            Public Overrides Function GetCommand() As NCommand
                Return CustomCommand
            End Function
            ''' <summary>
            ''' Executes the command action.
            ''' </summary>
            ''' <paramname="target"></param>
            ''' <paramname="parameter"></param>
            Public Overrides Sub Execute(target As NNode, parameter As Object)
                Dim drawingView = GetDrawingView(target)

                NMessageBox.Show("Drawing Custom Command executed!", "Custom Command", ENMessageBoxButtons.OK, ENMessageBoxIcon.Information)
            End Sub

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomCommandAction.
            ''' </summary>
            Public Shared ReadOnly CustomCommandActionSchema As NSchema

#End Region
        End Class

#End Region
    End Class
End Namespace
