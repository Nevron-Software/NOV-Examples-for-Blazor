Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.DrawingCommands
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NContextMenuCustomizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NContextMenuCustomizationExampleSchema = NSchema.Create(GetType(NContextMenuCustomizationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            m_DrawingView = New NDrawingView()

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            ' Add the custom command action to the drawing view's commander
            m_DrawingView.Commander.Add(New CustomCommandAction())

            ' Change the context menu factory to the custom one
            m_DrawingView.ContextMenu = New CustomContextMenu()

            Dim ribbonBuilder As NDiagramRibbonBuilder = New NDiagramRibbonBuilder()
            Return ribbonBuilder.CreateUI(m_DrawingView)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to customize the NOV drawing view's context menu. A custom command is added
at the end of the context menu.</p>
"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim factory As NBasicShapeFactory = New NBasicShapeFactory()
            Dim shape = factory.CreateShape(ENBasicShape.Rectangle)
            shape.SetBounds(100, 100, 150, 100)
            drawingDocument.Content.ActivePage.Items.Add(shape)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NContextMenuCustomizationExample.
        ''' </summary>
        Public Shared ReadOnly NContextMenuCustomizationExampleSchema As NSchema

#End Region

#Region "Constants"

        Public Shared ReadOnly CustomCommand As NCommand = NCommand.Create(GetType(NContextMenuCustomizationExample), "CustomCommand", "Custom Command")

#End Region

#Region "Nested Types"

        Public Class CustomContextMenu
            Inherits NDrawingContextMenu
            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub
            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomContextMenuSchema = NSchema.Create(GetType(CustomContextMenu), NDrawingContextMenuSchema)
            End Sub

            Protected Overrides Sub CreateCustomCommands(menu As NMenu, builder As NContextMenuBuilder)
                MyBase.CreateCustomCommands(menu, builder)

                ' Add a custom command
                builder.AddMenuItem(menu, NResources.Image_Ribbon_16x16_smiley_png, CustomCommand)
            End Sub

            ''' <summary>
            ''' Schema associated with CustomContextMenu.
            ''' </summary>
            Public Shared ReadOnly CustomContextMenuSchema As NSchema
        End Class

        Public Class CustomCommandAction
            Inherits NDrawingCommandAction
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomCommandActionSchema = NSchema.Create(GetType(CustomCommandAction), NDrawingCommandActionSchema)
            End Sub

#End Region

#Region "Public Overrides"

            ''' <summary>
            ''' Gets the command associated with this command action.
            ''' </summary>
            ''' <returns></returns>
            Public Overrides Function GetCommand() As NCommand
                Return CustomCommand
            End Function
            ''' <summary>
            ''' Executes the command action.
            ''' </summary>
            ''' <paramname="target"></param>
            ''' <paramname="parameter"></param>
            Public Overrides Sub Execute(target As NNode, parameter As Object)
                Dim drawingView = GetDrawingView(target)

                NMessageBox.Show("Drawing Custom Command executed!", "Custom Command", ENMessageBoxButtons.OK, ENMessageBoxIcon.Information)
            End Sub

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomCommandAction.
            ''' </summary>
            Public Shared ReadOnly CustomCommandActionSchema As NSchema

#End Region
        End Class

#End Region
    End Class
End Namespace
