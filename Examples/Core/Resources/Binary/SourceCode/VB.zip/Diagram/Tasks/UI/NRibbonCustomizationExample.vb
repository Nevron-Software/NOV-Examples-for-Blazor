Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.DrawingCommands
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Diagram.UI
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NRibbonCustomizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRibbonCustomizationExampleSchema = NSchema.Create(GetType(NRibbonCustomizationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            m_DrawingView = New NDrawingView()

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            ' Create and customize a ribbon UI builder
            m_RibbonBuilder = New NDiagramRibbonBuilder()

            ' Add the custom command action to the drawing view's commander
            m_DrawingView.Commander.Add(New CustomCommandAction())

            ' Rename the "Home" ribbon tab page
            Dim homeTabBuilder = m_RibbonBuilder.TabPageBuilders(NDiagramRibbonBuilder.TabPageHomeName)
            homeTabBuilder.Name = "Start"

            ' Rename the "Text" ribbon group of the "Home" tab page
            Dim fontGroupBuilder = homeTabBuilder.RibbonGroupBuilders(NHomeTabPageBuilder.GroupTextName)
            fontGroupBuilder.Name = "Custom Name"

            ' Remove the "Clipboard" ribbon group from the "Home" tab page
            homeTabBuilder.RibbonGroupBuilders.Remove(NHomeTabPageBuilder.GroupClipboardName)

            ' Insert the custom ribbon group at the beginning of the home tab page
            homeTabBuilder.RibbonGroupBuilders.Insert(0, New CustomRibbonGroupBuilder())

            Return m_RibbonBuilder.CreateUI(m_DrawingView)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to customize the NOV diagram ribbon.</p>"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim factory As NBasicShapeFactory = New NBasicShapeFactory()
            Dim shape = factory.CreateShape(ENBasicShape.Rectangle)
            shape.SetBounds(100, 100, 150, 100)
            drawingDocument.Content.ActivePage.Items.Add(shape)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_RibbonBuilder As NDiagramRibbonBuilder

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRibbonCustomizationExample.
        ''' </summary>
        Public Shared ReadOnly NRibbonCustomizationExampleSchema As NSchema

#End Region

#Region "Constants"

        Public Shared ReadOnly CustomCommand As NCommand = NCommand.Create(GetType(NRibbonCustomizationExample), "CustomCommand", "Custom Command")

#End Region

#Region "Nested Types"

        Public Class CustomRibbonGroupBuilder
            Inherits NRibbonGroupBuilder
#Region "Constructors"

            Public Sub New()
                MyBase.New("Custom Group", NResources.Image_Ribbon_16x16_smiley_png)
            End Sub

#End Region

#Region "Protected Overrides"

            Protected Overrides Sub AddRibbonGroupItems(items As NRibbonGroupItemCollection)
                ' Add the "Copy" command
                items.Add(CreateRibbonButton(NResources.Image_Ribbon_32x32_clipboard_copy_png, Presentation.NResources.Image_Edit_Copy_png, NDrawingView.CopyCommand))

                ' Add the custom command
                items.Add(CreateRibbonButton(NResources.Image_Ribbon_32x32_smiley_png, NResources.Image_Ribbon_16x16_smiley_png, CustomCommand))
            End Sub

#End Region
        End Class

        Public Class CustomCommandAction
            Inherits NDrawingCommandAction
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomCommandActionSchema = NSchema.Create(GetType(CustomCommandAction), NDrawingCommandActionSchema)
            End Sub

#End Region

#Region "Public Overrides"

            ''' <summary>
            ''' Gets the command associated with this command action.
            ''' </summary>
            ''' <returns></returns>
            Public Overrides Function GetCommand() As NCommand
                Return CustomCommand
            End Function
            ''' <summary>
            ''' Executes the command action.
            ''' </summary>
            ''' <paramname="target"></param>
            ''' <paramname="parameter"></param>
            Public Overrides Sub Execute(target As NNode, parameter As Object)
                Dim drawingView = GetDrawingView(target)

                NMessageBox.Show("Drawing Custom Command executed!", "Custom Command", ENMessageBoxButtons.OK, ENMessageBoxIcon.Information)
            End Sub

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomCommandAction.
            ''' </summary>
            Public Shared ReadOnly CustomCommandActionSchema As NSchema

#End Region
        End Class

#End Region
    End Class
End Namespace
