Imports System

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' The NGenericTreeTemplate class represents a generic tree template
    ''' </summary>
    Public Class NGenericTreeTemplate
        Inherits NGraphTemplate
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
            MyBase.New("Generic Tree")
            m_nLevels = 3
            m_nBranchNodes = 2
            m_nVertexSizeDeviation = 0.0F
            m_bBalanced = True
            m_LayoutDirection = ENHVDirection.TopToBottom
            m_LayoutType = ENTreeLayoutType.Layered
            m_ConnectorShape = ENConnectorShape.RoutableConnector
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the count of the child nodes for each branch
        ''' </summary>
        ''' <remarks>
        ''' By default set to 2
        ''' </remarks>
        Public Property BranchNodes As Integer
            Get
                Return m_nBranchNodes
            End Get
            Set(value As Integer)
                If value = m_nBranchNodes Then Return

                If value < 1 Then Throw New ArgumentOutOfRangeException("The value must be > 0.")

                m_nBranchNodes = value
                OnTemplateChanged()
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the tree levels count
        ''' </summary>
        ''' <remarks>
        ''' By default set to 3 
        ''' </remarks>
        Public Property Levels As Integer
            Get
                Return m_nLevels
            End Get
            Set(value As Integer)
                If value = m_nLevels Then Return

                If value < 1 Then Throw New ArgumentOutOfRangeException("The value must be > 0.")

                m_nLevels = value
                OnTemplateChanged()
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets if the tree is balanced or not
        ''' </summary>
        ''' <remarks>
        ''' By default set to true 
        ''' </remarks>
        Public Property Balanced As Boolean
            Get
                Return m_bBalanced
            End Get
            Set(value As Boolean)
                If m_bBalanced <> value Then
                    m_bBalanced = value
                    OnTemplateChanged()
                End If
            End Set
        End Property
        ''' <summary>
        ''' Specifies the tree layout expand
        ''' </summary>
        ''' <remarks>
        ''' By default set to TopToBottom
        ''' </remarks>
        Public Property LayoutDirection As ENHVDirection
            Get
                Return m_LayoutDirection
            End Get
            Set(value As ENHVDirection)
                If value Is m_LayoutDirection Then Return

                m_LayoutDirection = value
                OnTemplateChanged()
            End Set
        End Property
        ''' <summary>
        ''' Specifies the tree layout scheme
        ''' </summary>
        ''' <remarks>
        ''' By default set to NormalCompressed
        ''' </remarks>
        Public Property LayoutType As ENTreeLayoutType
            Get
                Return m_LayoutType
            End Get
            Set(value As ENTreeLayoutType)
                If value Is m_LayoutType Then Return

                m_LayoutType = value
                OnTemplateChanged()
            End Set
        End Property
        ''' <summary>
        ''' Specifies the edge connector type
        ''' </summary>
        ''' <remarks>
        ''' By default set to DynamicPolyline
        ''' </remarks>
        Public Property ConnectorType As ENConnectorShape
            Get
                Return m_ConnectorShape
            End Get
            Set(value As ENConnectorShape)
                If m_ConnectorShape IsNot value Then
                    m_ConnectorShape = value
                    OnTemplateChanged()
                End If
            End Set
        End Property
        ''' <summary>
        ''' Specifies the deviation of the vertex size according to the VerticesSize (0 for none)
        ''' </summary>
        ''' <remarks>
        ''' By default set to 0
        ''' </remarks>
        Public Property VertexSizeDeviation As Double
            Get
                Return m_nVertexSizeDeviation
            End Get
            Set(value As Double)
                If value < 0 Then Throw New ArgumentOutOfRangeException("Negative values are not allowed.")

                If m_nVertexSizeDeviation <> value Then
                    m_nVertexSizeDeviation = value
                    OnTemplateChanged()
                End If
            End Set
        End Property

#End Region

#Region "Overrides"

        ''' <summary>
        ''' Overriden to return the tree description
        ''' </summary>
        Public Overrides Function GetDescription() As String
            Dim description = String.Format("##Tree with {0} levels and {1} branch elements.", m_nLevels, m_nBranchNodes)
            Return description
        End Function

#End Region

#Region "Protected overrides"

        ''' <summary>
        ''' Overriden to create the tree template
        ''' </summary>
        ''' <paramname="document">document in which to create the template</param>
        Protected Overrides Sub CreateTemplate(document As NDrawingDocument)
            ' create the tree
            Dim elements = CreateTree(document)
            If m_LayoutType Is ENTreeLayoutType.None Then Return

            ' layout the tree
            Dim layout As NLayeredTreeLayout = New NLayeredTreeLayout()

            ' sync measurement unit 
            layout.OrthogonalEdgeRouting = False

            Select Case m_LayoutType
                Case ENTreeLayoutType.Layered
                    layout.VertexSpacing = m_fHorizontalSpacing
                    layout.LayerSpacing = m_fVerticalSpacing

                Case ENTreeLayoutType.LayeredLeftAligned
                    layout.VertexSpacing = m_fHorizontalSpacing
                    layout.LayerSpacing = m_fVerticalSpacing
                    layout.ParentPlacement.Anchor = ENParentAnchor.SubtreeNear
                    layout.ParentPlacement.Alignment = ENRelativeAlignment.Near

                Case ENTreeLayoutType.LayeredRightAligned
                    layout.VertexSpacing = m_fHorizontalSpacing
                    layout.LayerSpacing = m_fVerticalSpacing
                    layout.ParentPlacement.Anchor = ENParentAnchor.SubtreeFar
                    layout.ParentPlacement.Alignment = ENRelativeAlignment.Far
            End Select

            ' apply layout
            Dim context As NDrawingLayoutContext = New NDrawingLayoutContext(document, New NRectangle(Origin, NSize.Zero))
            layout.Arrange(elements.CastAll(Of Object)(), context)
        End Sub

#End Region

#Region "Protected overridable"

        ''' <summary>
        ''' Gets the size for a new vertex taking into account the VertexSizeDeviation property.
        ''' </summary>
        ''' <returns></returns>
        Protected Overridable Function GetSize(rnd As Random) As NSize
            If m_nVertexSizeDeviation = 0 Then Return m_VertexSize

            Dim factor = m_nVertexSizeDeviation + 1

            Dim width As Double = rnd.Next(CInt(m_VertexSize.Width / factor), CInt(m_VertexSize.Width * factor))
            Dim height As Double = rnd.Next(CInt(m_VertexSize.Height / factor), CInt(m_VertexSize.Height * factor))

            Return New NSize(width, height)
        End Function
        ''' <summary>
        ''' Creates a tree in the specified document
        ''' </summary>
        ''' <paramname="document">document in which to create a tree</param>
        ''' <returns>tree elements</returns>
        Protected Overridable Function CreateTree(document As NDrawingDocument) As NList(Of NShape)
            Dim page = document.Content.ActivePage
            Dim elements As NList(Of NShape) = New NList(Of NShape)()

            Dim cur As NShape = Nothing
            Dim edge As NShape = Nothing

            Dim curRowVertices As NList(Of NShape) = Nothing
            Dim prevRowVertices As NList(Of NShape) = Nothing

            Dim i, j, level As Integer
            Dim childrenCount, levelNodesCount As Integer
            Dim rnd As Random = New Random()

            For level = 1 To m_nLevels
                curRowVertices = New NList(Of NShape)()

                If m_bBalanced Then
                    'Create a balanced tree
                    levelNodesCount = CInt(Math.Pow(m_nBranchNodes, level - 1))
                    For i = 0 To levelNodesCount - 1
                        ' create the cur node
                        cur = CreateVertex(m_VertexShape)
                        cur.SetBounds(New NRectangle(m_Origin, GetSize(rnd)))

                        page.Items.AddChild(cur)
                        elements.Add(cur)

                        ' connect with ancestor
                        If level > 1 Then
                            edge = CreateEdge(m_ConnectorShape)
                            page.Items.AddChild(edge)

                            Dim parentIndex As Integer = Math.Floor(i / m_nBranchNodes)
                            edge.GlueBeginToGeometryIntersection(prevRowVertices(parentIndex))
                            edge.GlueEndToShape(cur)
                        End If

                        curRowVertices.Add(cur)
                    Next
                Else
                    'Create an unbalanced tree
                    If level = 1 Then
                        ' Create the current node
                        cur = CreateVertex(m_VertexShape)
                        cur.SetBounds(New NRectangle(m_Origin, GetSize(rnd)))

                        page.Items.AddChild(cur)
                        elements.Add(cur)

                        curRowVertices.Add(cur)
                    Else
                        levelNodesCount = prevRowVertices.Count
                        Do
                            ' Ensure that the desired level depth is reached
                            For i = 0 To levelNodesCount - 1
                                childrenCount = rnd.Next(0, m_nBranchNodes + 1)
                                For j = 0 To childrenCount - 1
                                    ' Create the current node
                                    cur = CreateVertex(m_VertexShape)
                                    cur.SetBounds(New NRectangle(m_Origin, GetSize(rnd)))

                                    page.Items.AddChild(cur)
                                    elements.Add(cur)
                                    curRowVertices.Add(cur)

                                    ' Connect with ancestor
                                    edge = CreateEdge(m_ConnectorShape)
                                    page.Items.AddChild(edge)

                                    edge.GlueBeginToGeometryIntersection(prevRowVertices(i))
                                    edge.GlueEndToShape(cur)
                                Next
                            Next
                        Loop While level < m_nLevels AndAlso curRowVertices.Count = 0
                    End If
                End If

                prevRowVertices = curRowVertices
            Next

            Return elements
        End Function

#End Region

#Region "Fields"

        Friend m_nLevels As Integer
        Friend m_nBranchNodes As Integer
        Friend m_bBalanced As Boolean
        Friend m_LayoutDirection As ENHVDirection
        Friend m_LayoutType As ENTreeLayoutType
        Friend m_ConnectorShape As ENConnectorShape
        Friend m_nVertexSizeDeviation As Double

#End Region
    End Class
End Namespace
