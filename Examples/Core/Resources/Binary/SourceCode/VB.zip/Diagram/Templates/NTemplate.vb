Imports System

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Graphics

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' The NTemplate abstract class serves as base class for all programmable templates
    ''' </summary>
    Public MustInherit Class NTemplate
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
            Initialize("Template")
        End Sub

        ''' <summary>
        ''' Initializer contructor
        ''' </summary>
        ''' <paramname="name">name of the template</param>
        Public Sub New(name As String)
            Initialize(name)
        End Sub

#End Region

#Region "Events"

        ''' <summary>
        ''' Fired when the template has been changed
        ''' </summary>
        Public Event TemplateChanged As EventHandler

#End Region

#Region "Properties"

        ''' <summary>
        ''' Gets/set the template node
        ''' </summary>
        Public Property Name As String
            Get
                Return m_sName
            End Get
            Set(value As String)
                If Equals(value, Nothing) Then Throw New NullReferenceException()

                If Equals(value, m_sName) Then Return

                m_sName = value
                OnTemplateChanged()
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the template origin
        ''' </summary>
        ''' <remarks>
        ''' The origin defines the location at which the template will be instanciated in the document
        ''' </remarks>
        Public Property Origin As NPoint
            Get
                Return m_Origin
            End Get
            Set(value As NPoint)
                If value Is m_Origin Then Return

                m_Origin = value
                OnTemplateChanged()
            End Set
        End Property

        ''' <summary>
        ''' Specifies the history transaction description 
        ''' </summary>
        Public Property TransactionDescription As String
            Get
                Return m_sTransactionDescription
            End Get
            Set(value As String)
                If Equals(value, m_sTransactionDescription) Then Return

                If Equals(value, Nothing) Then Throw New NullReferenceException()

                m_sTransactionDescription = value
            End Set
        End Property


#End Region

#Region "Overridable"

        ''' <summary>
        ''' Creates the template in the specified document
        ''' </summary>
        ''' <remarks>
        ''' This method will call the CreateTemplate method. 
        ''' The call will be embraced in a transaction with the specified TransactionDescription
        ''' </remarks>
        ''' <paramname="document">document in which to create the template</param>
        ''' <returns>true if the template was successfully created, otherwise false</returns> 
        Public Overridable Function Create(document As NDrawingDocument) As Boolean
            If document Is Nothing Then Throw New ArgumentNullException("document")

            document.StartHistoryTransaction(m_sTransactionDescription)

            Try
                CreateTemplate(document)
            Catch ex As Exception
                NDebug.WriteLine("Failed to create template. Exception was: " & ex.Message)
                document.RollbackHistoryTransaction()
                Return False
            End Try

            document.CommitHistoryTransaction()
            Return True
        End Function

        ''' <summary>
        ''' Obtains a dynamic human readable description of the template
        ''' </summary>
        ''' <returns>template description</returns>
        Public MustOverride Function GetDescription() As String

#End Region

#Region "Protected overridable"

        ''' <summary>
        ''' Must override to create the template
        ''' </summary>
        ''' <paramname="document">document in which to create the template</param>
        Protected MustOverride Sub CreateTemplate(document As NDrawingDocument)
        ''' <summary>
        ''' Called when the template has changed
        ''' </summary>
        ''' <remarks>
        ''' This implementation will raise the TemplateChanged event
        ''' </remarks>
        Protected Overridable Sub OnTemplateChanged()
            RaiseEvent TemplateChanged(Me, Nothing)
        End Sub

#End Region

#Region "Private"

        Private Sub Initialize(name As String)
            If Equals(name, Nothing) Then Throw New ArgumentNullException("name")

            ' props
            m_sTransactionDescription = "Create Template"
            m_sName = name
            m_Origin = New NPoint()
        End Sub


#End Region

#Region "Fields"

        Friend m_sName As String
        Friend m_sTransactionDescription As String
        Friend m_Origin As NPoint

#End Region
    End Class
End Namespace
