Imports System

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Graphics

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' The NEllipticalGridTemplate class represents a rectangular grid template
    ''' </summary>
    Public Class NRectangularGridTemplate
        Inherits NGraphTemplate
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
            MyBase.New("Rectangular Grid")
            m_nRows = 3
            m_nColumns = 3
            m_bConnectGrid = True
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the columns count
        ''' </summary>
        ''' <remarks>
        ''' By default set to 3
        ''' </remarks>
        Public Property ColumnCount As Integer
            Get
                Return m_nColumns
            End Get
            Set(value As Integer)
                If value = m_nColumns Then Return

                If value < 1 Then Throw New ArgumentOutOfRangeException("The value must be > 0.")

                m_nColumns = value
                OnTemplateChanged()
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the rows count
        ''' </summary>
        ''' <remarks>
        ''' By default set to 3
        ''' </remarks>
        Public Property RowCount As Integer
            Get
                Return m_nRows
            End Get
            Set(value As Integer)
                If value = m_nRows Then Return

                If value < 1 Then Throw New ArgumentOutOfRangeException("The value must be > 0.")

                m_nRows = value
                OnTemplateChanged()
            End Set
        End Property

        ''' <summary>
        ''' Specifies whether the grid vertices are connected
        ''' </summary>
        ''' <remarks>
        ''' By default set to true
        ''' </remarks>
        Public Property ConnectGrid As Boolean
            Get
                Return m_bConnectGrid
            End Get
            Set(value As Boolean)
                If value = m_bConnectGrid Then Return

                m_bConnectGrid = value
                OnTemplateChanged()
            End Set
        End Property


#End Region

#Region "Overrides"

        ''' <summary>
        ''' Overriden to return the rectangular grid description
        ''' </summary>
        Public Overrides Function GetDescription() As String
            Dim description = String.Format("##Rectangular grid graph with {0} columns and {1} rows.", m_nColumns, m_nRows)

            If m_bConnectGrid Then description += " " & "##Each cell is connected with the horizontally and vertically adjacent cells."

            Return description
        End Function

        ''' <summary>
        ''' Overriden to create the rectangular grid template in the specified document
        ''' </summary>
        ''' <paramname="document">document in which to create the template</param>
        Protected Overrides Sub CreateTemplate(document As NDrawingDocument)
            Dim page = document.Content.ActivePage
            Dim edge As NShape = Nothing
            Dim vertex As NShape
            Dim vertexGrid = New NShape(m_nRows - 1, m_nColumns - 1) {}

            For row = 0 To m_nRows - 1
                For col = 0 To m_nColumns - 1
                    ' create the vertex
                    vertex = CreateVertex(m_VertexShape)
                    vertex.SetBounds(New NRectangle(m_Origin.X + col * (m_VertexSize.Width + m_fHorizontalSpacing), m_Origin.Y + row * (m_VertexSize.Height + m_fVerticalSpacing), m_VertexSize.Width, m_VertexSize.Height))
                    page.Items.AddChild(vertex)

                    ' connect it with its X and Y predecessors
                    If m_bConnectGrid = False Then Continue For

                    vertexGrid(row, col) = vertex

                    ' connect X 
                    If col > 0 Then
                        edge = CreateEdge(ENConnectorShape.Line)
                        page.Items.AddChild(edge)
                        edge.GlueBeginToGeometryIntersection(vertexGrid(row, col - 1))
                        edge.GlueEndToShape(vertex)
                    End If

                    ' connect Y
                    If row > 0 Then
                        edge = CreateEdge(ENConnectorShape.Line)
                        page.Items.AddChild(edge)
                        edge.GlueBeginToGeometryIntersection(vertexGrid(row - 1, col))
                        edge.GlueEndToShape(vertex)
                    End If
                Next
            Next
        End Sub


#End Region

#Region "Fields"

        Friend m_nRows As Integer
        Friend m_nColumns As Integer
        Friend m_bConnectGrid As Boolean

#End Region
    End Class
End Namespace
