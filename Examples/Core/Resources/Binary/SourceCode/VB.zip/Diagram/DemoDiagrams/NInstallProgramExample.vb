Imports System

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NInstallProgramExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NInstallProgramExampleSchema = NSchema.Create(GetType(NInstallProgramExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates how to create a flowchart that describes a Software Installation process.</p>"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim sheet As NStyleSheet = New NStyleSheet()
            drawingDocument.StyleSheets.Add(sheet)

            ' create a rule that applies to the geometries of all shapes with user class Connectors
            If True Then
                Dim rule As NRule = sheet.CreateRule(Sub(sb As NSelectorBuilder)
                                                         sb.Type(NGeometry.NGeometrySchema)
                                                         sb.ChildOf()
                                                         sb.UserClass(NDR.StyleSheetNameConnectors)
                                                     End Sub)
                rule.AddValueDeclaration(Of NArrowhead)(NGeometry.EndArrowheadProperty, New NArrowhead(ENArrowheadShape.TriangleNoFill), True)
            End If

            ' create a rule that applies to the TextBlocks of all shapes with user class Connectors
            If True Then
                Dim rule As NRule = sheet.CreateRule(Sub(sb As NSelectorBuilder)
                                                         sb.Type(NTextBlock.NTextBlockSchema)
                                                         sb.ChildOf()
                                                         sb.UserClass(NDR.StyleSheetNameConnectors)
                                                     End Sub)
                rule.AddValueDeclaration(Of NFill)(NShapeBlock.BackgroundFillProperty, New NColorFill(NColor.White))
            End If

            ' create a rule that applies to shapes with user class  "STARTEND"
            If True Then
                Dim rule As NRule = sheet.CreateRule(Sub(sb As NSelectorBuilder)
                                                         sb.Type(NGeometry.NGeometrySchema)
                                                         sb.ChildOf()
                                                         sb.UserClass("STARTEND")
                                                     End Sub)
                rule.AddValueDeclaration(Of NFill)(NGeometry.FillProperty, New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, New NColor(247, 150, 56), New NColor(251, 203, 156)))
            End If

            ' create a rule that applies to shapes with user class  "QUESTION"
            If True Then
                Dim rule As NRule = sheet.CreateRule(Sub(sb As NSelectorBuilder)
                                                         sb.Type(NGeometry.NGeometrySchema)
                                                         sb.ChildOf()
                                                         sb.UserClass("QUESTION")
                                                     End Sub)
                rule.AddValueDeclaration(Of NFill)(NGeometry.FillProperty, New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, New NColor(129, 133, 133), New NColor(192, 194, 194)))
            End If

            ' create a rule that applies to shapes with user class  "ACTION"
            If True Then
                Dim rule As NRule = sheet.CreateRule(Sub(sb As NSelectorBuilder)
                                                         sb.Type(NGeometry.NGeometrySchema)
                                                         sb.ChildOf()
                                                         sb.UserClass("ACTION")
                                                     End Sub)
                rule.AddValueDeclaration(Of NFill)(NGeometry.FillProperty, New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, New NColor(68, 90, 108), New NColor(162, 173, 182)))
            End If

            ' get drawing and active page
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' hide ports and grid
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            Dim basicShapesFactory As NBasicShapeFactory = New NBasicShapeFactory()
            Dim flowChartingShapesFactory As NFlowchartShapeFactory = New NFlowchartShapeFactory()
            Dim connectorShapesFactory As NConnectorShapeFactory = New NConnectorShapeFactory()

            Dim bounds As NRectangle

            Dim vSpacing = 35
            Dim hSpacing = 45
            Dim topMargin = 10
            Dim leftMargin = 10

            Dim shapeWidth = 90
            Dim shapeHeight = 55

            Dim col1 = leftMargin
            Dim col2 = col1 + shapeWidth + hSpacing
            Dim col3 = col2 + shapeWidth + hSpacing
            Dim col4 = col3 + shapeWidth + hSpacing

            Dim row1 = topMargin
            Dim row2 = row1 + shapeHeight + vSpacing
            Dim row3 = row2 + shapeHeight + vSpacing
            Dim row4 = row3 + shapeHeight + vSpacing
            Dim row5 = row4 + shapeHeight + vSpacing
            Dim row6 = row5 + shapeHeight + vSpacing

            bounds = New NRectangle(col2, row1, shapeWidth, shapeHeight)
            Dim start = CreateFlowChartingShape(ENFlowchartingShape.Termination, bounds, "START", "STARTEND")

            ' row 2
            bounds = New NRectangle(col2, row2, shapeWidth, shapeHeight)
            Dim haveSerialNumber = CreateFlowChartingShape(ENFlowchartingShape.Decision, bounds, "Have a serial number?", "QUESTION")

            bounds = New NRectangle(col3, row2, shapeWidth, shapeHeight)
            Dim getSerialNumber = CreateFlowChartingShape(ENFlowchartingShape.Process, bounds, "Get serial number", "ACTION")

            ' row 3
            bounds = New NRectangle(col1, row3, shapeWidth, shapeHeight)
            Dim enterSerialNumber = CreateFlowChartingShape(ENFlowchartingShape.Process, bounds, "Enter serial number", "ACTION")

            bounds = New NRectangle(col2, row3, shapeWidth, shapeHeight)
            Dim haveDiskSpace = CreateFlowChartingShape(ENFlowchartingShape.Decision, bounds, "Have disk space?", "QUESTION")

            bounds = New NRectangle(col3, row3, shapeWidth, shapeHeight)
            Dim freeUpSpace = CreateFlowChartingShape(ENFlowchartingShape.Process, bounds, "Free up space", "ACTION")

            ' row 4
            bounds = New NRectangle(col1, row4, shapeWidth, shapeHeight)
            Dim runInstallRect = CreateFlowChartingShape(ENFlowchartingShape.Process, bounds, "Run install file", "ACTION")

            bounds = New NRectangle(col2, row4, shapeWidth, shapeHeight)
            Dim registerNow = CreateFlowChartingShape(ENFlowchartingShape.Decision, bounds, "Register now?", "QUESTION")

            bounds = New NRectangle(col3, row4, shapeWidth, shapeHeight)
            Dim fillForm = CreateFlowChartingShape(ENFlowchartingShape.Process, bounds, "Fill out form", "ACTION")

            bounds = New NRectangle(col4, row4, shapeWidth, shapeHeight)
            Dim submitForm = CreateFlowChartingShape(ENFlowchartingShape.Process, bounds, "Submit form", "ACTION")

            ' row 5
            bounds = New NRectangle(col1, row5, shapeWidth, shapeHeight)
            Dim finishInstall = CreateFlowChartingShape(ENFlowchartingShape.Process, bounds, "Finish installation", "ACTION")

            bounds = New NRectangle(col2, row5, shapeWidth, shapeHeight)
            Dim restartNeeded = CreateFlowChartingShape(ENFlowchartingShape.Decision, bounds, "Restart needed?", "QUESTION")

            bounds = New NRectangle(col3, row5, shapeWidth, shapeHeight)
            Dim restart = CreateFlowChartingShape(ENFlowchartingShape.Process, bounds, "Restart", "ACTION")

            ' row 6
            bounds = New NRectangle(col2, row6, shapeWidth, shapeHeight)
            Dim run = CreateFlowChartingShape(ENFlowchartingShape.Process, bounds, "RUN", "STARTEND")

            ' create connectors
            CreateConnector(start, "Bottom", haveSerialNumber, "Top", ENConnectorShape.Line, "")
            CreateConnector(getSerialNumber, "Top", haveSerialNumber, "Top", ENConnectorShape.RoutableConnector, "")
            CreateConnector(haveSerialNumber, "Right", getSerialNumber, "Left", ENConnectorShape.Line, "No")
            CreateConnector(haveSerialNumber, "Bottom", enterSerialNumber, "Top", ENConnectorShape.BottomToTop1, "Yes")
            CreateConnector(enterSerialNumber, "Right", haveDiskSpace, "Left", ENConnectorShape.Line, "")
            CreateConnector(freeUpSpace, "Top", haveDiskSpace, "Top", ENConnectorShape.RoutableConnector, "")
            CreateConnector(haveDiskSpace, "Right", freeUpSpace, "Left", ENConnectorShape.Line, "No")
            CreateConnector(haveDiskSpace, "Bottom", runInstallRect, "Top", ENConnectorShape.BottomToTop1, "Yes")
            CreateConnector(registerNow, "Right", fillForm, "Left", ENConnectorShape.Line, "Yes")
            CreateConnector(registerNow, "Bottom", finishInstall, "Top", ENConnectorShape.BottomToTop1, "No")
            CreateConnector(fillForm, "Right", submitForm, "Left", ENConnectorShape.Line, "")
            CreateConnector(submitForm, "Bottom", finishInstall, "Top", ENConnectorShape.BottomToTop1, "")
            CreateConnector(finishInstall, "Right", restartNeeded, "Left", ENConnectorShape.Line, "")
            CreateConnector(restart, "Bottom", run, "Top", ENConnectorShape.BottomToTop1, "")
            CreateConnector(restartNeeded, "Right", restart, "Left", ENConnectorShape.Line, "Yes")
            CreateConnector(restartNeeded, "Bottom", run, "Top", ENConnectorShape.Line, "No")
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates a predefined basic shape
        ''' </summary>
        ''' <paramname="basicShape">basic shape</param>
        ''' <paramname="bounds">bounds</param>
        ''' <paramname="text">default label text</param>
        ''' <paramname="userClass">name of the stylesheet from which to inherit styles</param>
        ''' <returns>new basic shape</returns>
        Private Function CreateBasicShape(basicShape As ENBasicShape, bounds As NRectangle, text As String, userClass As String) As NShape
            ' create shape
            Dim shape As NShape = New NBasicShapeFactory().CreateShape(basicShape)

            ' set bounds, text and user class
            shape.SetBounds(bounds)
            shape.Text = text
            shape.UserClass = userClass

            ' add to active page
            m_DrawingView.ActivePage.Items.Add(shape)
            Return shape
        End Function
        ''' <summary>
        ''' Creates a predefined flow charting shape
        ''' </summary>
        ''' <paramname="flowChartShape">flow charting shape</param>
        ''' <paramname="bounds">bounds</param>
        ''' <paramname="text">default label text</param>
        ''' <paramname="userClass">name of the stylesheet from which to inherit styles</param>
        ''' <returns>new basic shape</returns>
        Private Function CreateFlowChartingShape(flowChartShape As ENFlowchartingShape, bounds As NRectangle, text As String, userClass As String) As NShape
            ' create shape
            Dim shape As NShape = New NFlowchartShapeFactory().CreateShape(flowChartShape)

            ' set bounds, text and user class
            shape.SetBounds(bounds)
            shape.Text = text
            shape.UserClass = userClass

            ' add to active page
            m_DrawingView.ActivePage.Items.Add(shape)
            Return shape
        End Function
        ''' <summary>
        ''' Creates a new connector, which connects the specified shapes
        ''' </summary>
        ''' <paramname="fromShape"></param>
        ''' <paramname="fromPortName"></param>
        ''' <paramname="toShape"></param>
        ''' <paramname="toPortName"></param>
        ''' <paramname="connectorType"></param>
        ''' <paramname="text"></param>
        ''' <returns>new 1D shapes</returns>
        Private Function CreateConnector(fromShape As NShape, fromPortName As String, toShape As NShape, toPortName As String, connectorType As ENConnectorShape, text As String) As NShape
            ' check arguments
            If fromShape Is Nothing Then Throw New ArgumentNullException("fromShape")

            If toShape Is Nothing Then Throw New ArgumentNullException("toShape")

            ' create the connector
            Dim connector As NShape = New NConnectorShapeFactory().CreateShape(connectorType)

            ' set text and user class
            connector.Text = text
            connector.UserClass = NDR.StyleSheetNameConnectors

            ' connect begin
            Dim fromPort = fromShape.Ports.GetPortByName(fromPortName)
            If fromPort IsNot Nothing Then
                connector.GlueBeginToPort(fromPort)
            Else
                connector.GlueBeginToShape(fromShape)
            End If

            ' connect end
            Dim toPort = toShape.Ports.GetPortByName(toPortName)
            If toPort IsNot Nothing Then
                connector.GlueEndToPort(toPort)
            Else
                connector.GlueEndToShape(toShape)
            End If

            ' add to active page
            m_DrawingView.ActivePage.Items.Add(connector)

            Return connector
        End Function

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

        Private m_GridOrigin As NPoint = New NPoint(30, 30)
        Private m_GridCellSize As NSize = New NSize(180, 70)
        Private m_GridSpacing As NSize = New NSize(50, 40)

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NInstallProgramExample.
        ''' </summary>
        Public Shared ReadOnly NInstallProgramExampleSchema As NSchema

#End Region
    End Class
End Namespace
