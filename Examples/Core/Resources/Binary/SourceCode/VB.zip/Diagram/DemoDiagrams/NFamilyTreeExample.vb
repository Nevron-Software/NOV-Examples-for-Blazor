Imports System
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Formats
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.IO
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NFamilyTreeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NFamilyTreeExampleSchema = NSchema.Create(GetType(NFamilyTreeExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            InitDiagram(m_DrawingView.Document)

            ' Load the GEDCOM file format's family tree library (this needs to be done only once)
            Dim libraryFile = NApplication.ResourcesFolder.GetFile(NPath.Current.Combine("ShapeLibraries", "Family Tree", "Family Tree Shapes.nlb"))
            Call NDrawingFormat.Gedcom.LoadFamilyTreeLibraryFromFileAsync(libraryFile).[Then](Sub(ud As NUndefined)
                                                                                                  ' Family tree library loaded successfully, so create the family tree diagram
                                                                                                  CreateFamilyTree(m_DrawingView.ActivePage)
                                                                                                  m_DrawingView.Document.HistoryService.Resume()
                                                                                                  ' Failed to load the family tree library
                                                                                              End Sub, Sub(ex As Exception) m_DrawingView.Document.HistoryService.Resume())

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Get the family tree drawing extension
            Dim familyTreeExtension = CType(m_DrawingView.Content.Extensions.FindByType(NFamilyTreeExtension.FamilyTreeExtensionType), NFamilyTreeExtension)

            ' Create property editors
            Dim propertyEditors = NDesigner.GetDesigner(familyTreeExtension).CreatePropertyEditors(familyTreeExtension, NFamilyTreeExtension.DateFormatProperty, NFamilyTreeExtension.ShowPhotosProperty)

            For i = 0 To propertyEditors.Count - 1
                stack.Add(propertyEditors(i))
            Next

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and arrange Family Tree diagrams. Use the controls
	on the right to change the family tree settings. You can also click the ""Settings"" button
	in the ""Family Tree"" contextual ribbon tab.
</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateShape(familyShape As ENFamilyTreeShape) As NShape
            Dim libraryItem = NDrawingFormat.Gedcom.FamilyTreeLibrary.Items(CInt(familyShape))
            Dim shape = CType(libraryItem.Items(0), NShape)
            Return CType(shape.DeepClone(), NShape)
        End Function
        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            ' Get drawing and the active page
            Dim drawing = drawingDocument.Content

            ' Set the family tree extension to the drawing to activate the "Family Tree" ribbon tab
            drawing.Extensions = New NDiagramExtensionCollection()
            drawing.Extensions.Add(New NFamilyTreeExtension())
        End Sub
        Private Sub CreateFamilyTree(page As NPage)
            ' Create the parents
            Dim fatherShape = CreateShape(ENFamilyTreeShape.Male)
            fatherShape.SetShapePropertyValue("FirstName", "Abraham")
            fatherShape.SetShapePropertyValue("LastName", "Lincoln")
            fatherShape.SetShapePropertyValue("BirthDate", New NMaskedDateTime(1809, 02, 12)) ' NMaskedDateTime
            fatherShape.SetShapePropertyValue("DeathDate", New NMaskedDateTime(1865, 04, 15))
            page.Items.Add(fatherShape)

            Dim motherShape = CreateShape(ENFamilyTreeShape.Female)
            motherShape.SetShapePropertyValue("FirstName", "Mary")
            motherShape.SetShapePropertyValue("LastName", "Todd")
            motherShape.SetShapePropertyValue("BirthDate", New NMaskedDateTime(1811))
            page.Items.Add(motherShape)

            ' Create the children
            Dim childShape1 = CreateShape(ENFamilyTreeShape.Male)
            childShape1.SetShapePropertyValue("FirstName", "Thomas")
            childShape1.SetShapePropertyValue("LastName", "Lincoln")
            childShape1.SetShapePropertyValue("BirthDate", New NMaskedDateTime(1853, 4, 4))
            childShape1.SetShapePropertyValue("DeathDate", New NMaskedDateTime(1871))
            page.Items.Add(childShape1)

            Dim childShape2 = CreateShape(ENFamilyTreeShape.Male)
            childShape2.SetShapePropertyValue("FirstName", "Robert Todd")
            childShape2.SetShapePropertyValue("LastName", "Lincoln")
            childShape2.SetShapePropertyValue("BirthDate", New NMaskedDateTime(1843, 8, 1))
            childShape2.SetShapePropertyValue("DeathDate", New NMaskedDateTime(1926, 7, 26))
            page.Items.Add(childShape2)

            Dim childShape3 = CreateShape(ENFamilyTreeShape.Male)
            childShape3.SetShapePropertyValue("FirstName", "William Wallace")
            childShape3.SetShapePropertyValue("LastName", "Lincoln")
            childShape3.SetShapePropertyValue("BirthDate", New NMaskedDateTime(1850, 12, 21))
            childShape3.SetShapePropertyValue("DeathDate", New NMaskedDateTime(1862, 2, 20))
            page.Items.Add(childShape3)

            Dim childShape4 = CreateShape(ENFamilyTreeShape.Male)
            childShape4.SetShapePropertyValue("FirstName", "Edward Baker")
            childShape4.SetShapePropertyValue("LastName", "Lincoln")
            childShape4.SetShapePropertyValue("BirthDate", New NMaskedDateTime(1846, 3, 10))
            childShape4.SetShapePropertyValue("DeathDate", New NMaskedDateTime(1850, 2, 1))
            page.Items.Add(childShape4)

            ' Create the relationship shape
            Dim relShape = CreateShape(ENFamilyTreeShape.Relationship)
            relShape.SetShapePropertyValue("MarriageDate", New NMaskedDateTime(1842, 11, 4))
            page.Items.Add(relShape)

            page.Items.Add(CreateConnector(fatherShape, relShape))
            page.Items.Add(CreateConnector(motherShape, relShape))

            page.Items.Add(CreateConnector(relShape, childShape1))
            page.Items.Add(CreateConnector(relShape, childShape2))
            page.Items.Add(CreateConnector(relShape, childShape3))
            page.Items.Add(CreateConnector(relShape, childShape4))

            ' Arrange the family tree shapes
            Dim layout As NFamilyGraphLayout = New NFamilyGraphLayout()
            Dim shapes As Object() = page.GetShapes(False).ToArray(Of Object)()
            layout.Arrange(shapes, New NDrawingLayoutContext(page))

            ' Size the page to its content
            page.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NFamilyTreeExample.
        ''' </summary>
        Public Shared ReadOnly NFamilyTreeExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateConnector(fromShape As NShape, toShape As NShape) As NRoutableConnector
            Dim connector As NRoutableConnector = New NRoutableConnector()
            connector.GlueBeginToShape(fromShape)
            connector.GlueEndToShape(toShape)

            Return connector
        End Function

#End Region
    End Class
End Namespace
