Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Import.Map
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

#Region "InternalCode"

' Map data from: http://www.naturalearthdata.com/features/

#End Region

Namespace Nevron.Nov.Examples.Diagram
    Public Class NWorldPopulationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NWorldPopulationExampleSchema = NSchema.Create(GetType(NWorldPopulationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Create radio buttons for the different data groupings
            stack.Add(New NRadioButton("Optimal"))
            stack.Add(New NRadioButton("Equal Interval"))
            stack.Add(New NRadioButton("Equal Distribution"))

            ' Create a radio button group to hold the radio buttons
            Dim group As NRadioButtonGroup = New NRadioButtonGroup(stack)
            group.SelectedIndex = 0
            group.SelectedIndexChanged += AddressOf OnDataGroupingSelectedIndexChanged

            ' Create the data grouping group box
            Dim dataGroupingGroupBox As NGroupBox = New NGroupBox("Data Grouping", group)

            Return dataGroupingGroupBox
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example shows a world population map by countries (darker countries have larger population).
    A fill rule is used to automatically color the countries on the map based on their population attribute.
</p>
<p>
	Upon import of a shape additional information from the DBF file that accompanies the shapefile
	is provided (e.g. Country Name, Population, Currency, GDP, etc.). You can use these values to
	customze the name, the text and the fill of the shape. You can also provide an INShapeCreatedListener
	implementation to the shape importer of the map in order to get notified when a shape is imported
	and use the values from the DBF file for this shape to customize it even further. This example
	demonstrates how to create and use such interface implementation to add tooltips for the shapes.
</p>
"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            ' Configure the document
            Dim drawing = drawingDocument.Content
            drawing.ScreenVisibility.ShowGrid = False

            ' Add styles
            AddStyles(drawingDocument)

            ' Configure the active page
            Dim page = drawing.ActivePage
            page.ZoomMode = ENZoomMode.Fit
            page.BackgroundFill = New NColorFill(NColor.LightBlue)

            ' Create a map importer
            m_MapImporter = New NEsriMapImporter()
            m_MapImporter.MapBounds = NMapBounds.World

            ' Add a shapefile
            Dim countries As NEsriShapefile = New NEsriShapefile(NResources.RBIN_countries_zip)
            countries.NameColumn = "name_long"
            countries.TextColumn = "name_long"
            countries.MinTextZoomPercent = 50
            countries.FillRule = New NMapFillRuleRange("pop_est", NColor.White, New NColor(0, 80, 0), 12)
            m_MapImporter.AddShapefile(countries)

            ' Set the shape created listener
            m_MapImporter.ShapeCreatedListener = New NCustomShapeCreatedListener()

            ' Read the map data
            m_MapImporter.Read()

            ' Import the map to the drawing document
            ImportMap()
        End Sub

#End Region

#Region "Implementation"

        Private Sub AddStyles(document As NDrawingDocument)
            ' Create a style sheet
            Dim styleSheet As NStyleSheet = New NStyleSheet()
            document.StyleSheets.Add(styleSheet)

            ' Add some styling for the shapes
            Dim rule As NRule = New NRule()
            Dim sb As NSelectorBuilder = rule.GetSelectorBuilder()
            sb.Start()
            sb.Type(NGeometry.NGeometrySchema)
            sb.ChildOf()
            sb.Type(NShape.NShapeSchema)
            sb.End()

            rule.Declarations.Add(New NValueDeclaration(Of NStroke)(NGeometry.StrokeProperty, New NStroke(New NColor(80, 80, 80))))
            styleSheet.Add(rule)
        End Sub
        Private Sub ImportMap()
            Dim page = m_DrawingView.ActivePage
            page.Items.Clear()
            page.Bounds = New NRectangle(0, 0, 10000, 10000)

            ' Import the map to the drawing document
            m_MapImporter.Import(m_DrawingView.Document, page.Bounds)

            ' Size page to content
            page.SizeToContent()
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnDataGroupingSelectedIndexChanged(arg As NValueChangeEventArgs)
            Dim fillRule = CType(m_MapImporter.GetShapefileAt(0).FillRule, NMapFillRuleRange)

            Select Case arg.NewValue
                Case 0
                    fillRule.DataGrouping = New NDataGroupingOptimal()
                Case 1
                    fillRule.DataGrouping = New NDataGroupingEqualInterval()
                Case 2
                    fillRule.DataGrouping = New NDataGroupingEqualDistribution()
            End Select

            ImportMap()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_MapImporter As NEsriMapImporter

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NWorldPopulationExample.
        ''' </summary>
        Public Shared ReadOnly NWorldPopulationExampleSchema As NSchema

#End Region

#Region "Nested Types"

        Private Class NCustomShapeCreatedListener
            Inherits NShapeCreatedListener
            Public Overrides Function OnMultiPolygonCreated(shape As NShape, feature As NGisFeature) As Boolean
                Return OnPolygonCreated(shape, feature)
            End Function
            Public Overrides Function OnPolygonCreated(shape As NShape, feature As NGisFeature) As Boolean
                Dim row = feature.Attributes
                Dim countryName = CStr(row("name_long"))
                Dim population As Decimal = row("pop_est")

                Dim tooltip = countryName & "'s population: " & population.ToString("N0")
                shape.Tooltip = New NTooltip(tooltip)

                Return True
            End Function
        End Class

#End Region
    End Class
End Namespace
