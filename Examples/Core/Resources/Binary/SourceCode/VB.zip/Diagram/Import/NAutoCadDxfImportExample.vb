Imports System.IO

Imports Nevron.Nov.Compression
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NAutoCadDxfImportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NAutoCadDxfImportExampleSchema = NSchema.Create(GetType(NAutoCadDxfImportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates how to import an AutoCAD Drawing Interchange Drawing (DXF) to NOV Diagram.</p>"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            ' Decompress the ZIP archive that contains the AutoCAD DXF Drawing
            Dim zipDecompressor As NZipDecompressor = New NZipDecompressor()
            Using stream As Stream = New MemoryStream(NResources.RBIN_DXF_FloorPlan_zip.Data)
                NCompression.DecompressZip(stream, zipDecompressor)
            End Using

            ' Import the AutoCAD DXF Drawing
            m_DrawingView.LoadFromStreamAsync(zipDecompressor.Items(0).Stream)

            ' Hide ports
            m_DrawingView.Content.ScreenVisibility.ShowPorts = False
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NAutoCadDxfImportExample.
        ''' </summary>
        Public Shared ReadOnly NAutoCadDxfImportExampleSchema As NSchema

#End Region
    End Class
End Namespace
