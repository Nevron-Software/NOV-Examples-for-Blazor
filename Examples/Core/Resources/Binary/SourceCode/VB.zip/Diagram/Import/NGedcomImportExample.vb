Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Formats
Imports Nevron.Nov.Dom
Imports Nevron.Nov.IO
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NGedcomImportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NGedcomImportExampleSchema = NSchema.Create(GetType(NGedcomImportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	Demonstrates how to import a family tree in GEDCOM format (""*.ged"") in Nevron Diagram.
	Before importing any GEDCOM files, you should set the <b>FamilyTreeLibrary</b> property of
	<b>NDrawingFormat.Gedcom</b> or use its <b>LoadFamilyTreeLibraryFromFile</b> or
	<b>LoadFamilyTreeLibraryFromStream</b> properties. This will also enable the ribbon's
	<b>File -> Import -> GEDCOM</b> menu item and add the GEDCOM drawing format to the
	Open file dialog of the drawing view.
</p>
<p>
	This example imports the family tree of the US president Abraham Lincoln.
</p>"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            ' Load the GEDCOM file format's family tree library (this needs to be done only once)
            Dim libraryFile = NApplication.ResourcesFolder.GetFile(NPath.Current.Combine("ShapeLibraries", "Family Tree", "Family Tree Shapes.nlb"))
            NDrawingFormat.Gedcom.LoadFamilyTreeLibraryFromFileAsync(libraryFile).Then(Sub(ud As NUndefined)
                                                                                           ' The family tree library loaded successfully
                                                                                           ' Import a GEDCOM file
                                                                                           m_DrawingView.LoadFromResourceAsync(NResources.RSTR_LincolnFamily_ged, NDrawingFormat.Gedcom)

                                                                                           ' Hide the ports
                                                                                           drawingDocument.Content.ScreenVisibility.ShowPorts = False
                                                                                       End Sub)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NGedcomImportExample.
        ''' </summary>
        Public Shared ReadOnly NGedcomImportExampleSchema As NSchema

#End Region
    End Class
End Namespace
