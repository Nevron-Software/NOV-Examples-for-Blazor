Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NBrainstormingShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NBrainstormingShapesExampleSchema = NSchema.Create(GetType(NBrainstormingShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the brainstorming shapes, which are created by the NBrainstormingShapesFactory.</p>"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Create all shapes
            Dim factory As NBrainstormingShapeFactory = New NBrainstormingShapeFactory()
            factory.DefaultSize = New NSize(60, 60)

            For i = 0 To factory.ShapeCount - 1
                Dim shape = factory.CreateShape(i)
                shape.HorizontalPlacement = ENHorizontalPlacement.Center
                shape.VerticalPlacement = ENVerticalPlacement.Center
                shape.HorizontalPlacement = ENHorizontalPlacement.Center
                shape.VerticalPlacement = ENVerticalPlacement.Center
                shape.Text = factory.GetShapeInfo(i).Name
                shape.MoveTextBlockBelowShape()
                activePage.Items.Add(shape)
            Next

            ' Arrange them
            Dim shapes = activePage.GetShapes(False)
            Dim layoutContext As NLayoutContext = New NLayoutContext()
            layoutContext.BodyAdapter = New NShapeBodyAdapter(drawingDocument)
            layoutContext.GraphAdapter = New NShapeGraphAdapter()
            layoutContext.LayoutArea = activePage.GetContentEdge()

            Dim tableLayout As NTableFlowLayout = New NTableFlowLayout()
            tableLayout.HorizontalSpacing = 30
            tableLayout.VerticalSpacing = 50
            tableLayout.Direction = ENHVDirection.LeftToRight
            tableLayout.MaxOrdinal = 5

            tableLayout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

            ' size page to content
            activePage.Layout.ContentPadding = New NMargins(40)
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBrainstormingShapesExample.
        ''' </summary>
        Public Shared ReadOnly NBrainstormingShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace
