Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NCountryShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCountryShapesExampleSchema = NSchema.Create(GetType(NCountryShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates the business process shapes, which are created by the NBusinessProcessShapeFactory.
</p>
"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' create all shapes
            Dim factory As NCountryShapeFactory = New NCountryShapeFactory()
            factory.DefaultSize = New NSize(100, 100)

            Dim row = 0, col = 0
            Dim cellWidth As Double = 170
            Dim cellHeight As Double = 150

            Dim i = 0

            While i < factory.ShapeCount
                Dim shape = factory.CreateShape(i)
                shape.HorizontalPlacement = ENHorizontalPlacement.Center
                shape.VerticalPlacement = ENVerticalPlacement.Center
                shape.Text = factory.GetShapeInfo(i).Name
                shape.MoveTextBlockBelowShape()

                activePage.Items.Add(shape)

                If col >= 7 Then
                    row += 1
                    col = 0
                End If

                Dim beginPoint As NPoint = New NPoint(50 + col * cellWidth, 50 + row * cellHeight)
                If shape.ShapeType Is ENShapeType.Shape1D Then
                    Dim endPoint As NPoint = beginPoint + New NPoint(cellWidth - 50, cellHeight - 50)
                    If i = CInt(ENBasicShape.CenterDragCircle) Then
                        beginPoint.Translate(cellWidth / 3, cellHeight / 3)
                        endPoint.Translate(-cellWidth / 3, -cellHeight / 3)
                    End If

                    shape.SetBeginPoint(beginPoint)
                    shape.SetEndPoint(endPoint)
                Else
                    shape.SetBounds(beginPoint.X, beginPoint.Y, shape.Width, shape.Height)
                End If

                i += 1
                col += 1
            End While

            ' size page to content
            activePage.Layout.ContentPadding = New NMargins(50)
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCountryShapesExample.
        ''' </summary>
        Public Shared ReadOnly NCountryShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace
