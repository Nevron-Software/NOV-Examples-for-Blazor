Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NNetworkShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NNetworkShapesExampleSchema = NSchema.Create(GetType(NNetworkShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates the network shapes, which are created by the NNetworkShapesExample.
</p>
"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Create all shapes
            Dim factory As NNetworkShapeFactory = New NNetworkShapeFactory()
            factory.DefaultSize = New NSize(60, 60)

            For i = 0 To factory.ShapeCount - 1
                Dim shape = factory.CreateShape(i)
                shape.HorizontalPlacement = ENHorizontalPlacement.Center
                shape.VerticalPlacement = ENVerticalPlacement.Center
                shape.Text = factory.GetShapeInfo(i).Name
                shape.MoveTextBlockBelowShape()
                activePage.Items.Add(shape)
            Next

            ' Arrange them
            Dim shapes = activePage.GetShapes(False)
            Dim layoutContext As NLayoutContext = New NLayoutContext()
            layoutContext.BodyAdapter = New NShapeBodyAdapter(drawingDocument)
            layoutContext.GraphAdapter = New NShapeGraphAdapter()
            layoutContext.LayoutArea = activePage.GetContentEdge()

            Dim flowLayout As NTableFlowLayout = New NTableFlowLayout()
            flowLayout.HorizontalSpacing = 30
            flowLayout.VerticalSpacing = 50
            flowLayout.Direction = ENHVDirection.LeftToRight
            flowLayout.MaxOrdinal = 5
            flowLayout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

            ' Size page to content
            activePage.Layout.ContentPadding = New NMargins(40)
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NNetworkShapesExample.
        ''' </summary>
        Public Shared ReadOnly NNetworkShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace
