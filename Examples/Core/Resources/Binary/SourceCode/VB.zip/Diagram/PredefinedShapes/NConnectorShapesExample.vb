Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NConnectorShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NConnectorShapesExampleSchema = NSchema.Create(GetType(NConnectorShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates the connector shapes, which are created by the NConnectorShapeFactory.
</p>
"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            drawing.ScreenVisibility.ShowGrid = False

            ' create all shapes
            Dim factory As NConnectorShapeFactory = New NConnectorShapeFactory()
            factory.DefaultSize = New NSize(120, 90)

            Dim row = 0, col = 0
            Dim cellWidth As Double = 300
            Dim cellHeight As Double = 200

            Dim i = 0

            While i < factory.ShapeCount
                Dim shape = factory.CreateShape(i)
                shape.Text = factory.GetShapeInfo(i).Name
                activePage.Items.Add(shape)

                If col >= 4 Then
                    row += 1
                    col = 0
                End If

                Dim beginPoint As NPoint = New NPoint(50 + col * cellWidth, 50 + row * cellHeight)
                Dim endPoint As NPoint = beginPoint + New NPoint(cellWidth - 50, cellHeight - 50)
                shape.SetBeginPoint(beginPoint)
                shape.SetEndPoint(endPoint)
                i += 1
                col += 1
            End While

            ' size page to content
            activePage.Layout.ContentPadding = New NMargins(50)
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NConnectorShapesExample.
        ''' </summary>
        Public Shared ReadOnly NConnectorShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace
