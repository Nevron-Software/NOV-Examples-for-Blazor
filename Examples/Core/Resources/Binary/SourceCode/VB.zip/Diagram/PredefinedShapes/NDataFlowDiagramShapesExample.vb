Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NDfdShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NDfdShapesExampleSchema = NSchema.Create(GetType(NDfdShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the data flow shapes, which are created by the NDfdShapeFactory.</p>"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Const XStep As Double = 150
            Const YStep As Double = 200

            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Create all shapes
            Dim factory As NDataFlowDiagramShapesFactory = New NDataFlowDiagramShapesFactory()
            factory.DefaultSize = New NSize(80, 60)

            Dim x As Double = 0
            Dim y As Double = 0

            For i = 0 To factory.ShapeCount - 1
                Dim shape = factory.CreateShape(i)
                shape.HorizontalPlacement = ENHorizontalPlacement.Center
                shape.VerticalPlacement = ENVerticalPlacement.Center
                Dim name = factory.GetShapeInfo(i).Name
                shape.Tooltip = New NTooltip(name)
                shape.Text = factory.GetShapeInfo(i).Name
                shape.MoveTextBlockBelowShape()

                activePage.Items.Add(shape)

                If shape.ShapeType Is ENShapeType.Shape1D Then
                    shape.SetBeginPoint(New NPoint(x, y))
                    shape.SetEndPoint(New NPoint(x + shape.Width, y))
                Else
                    shape.SetBounds(x, y, shape.Width, shape.Height)
                End If

                x += XStep
                If x > activePage.Width Then
                    x = 0
                    y += YStep
                End If
            Next

            ' size page to content
            activePage.Layout.ContentPadding = New NMargins(50)
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDfdShapesExample.
        ''' </summary>
        Public Shared ReadOnly NDfdShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace
