Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' Summary description for NRoutableConnectors.
    ''' </summary>
    Public Class NRoutableConnectorsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRoutableConnectorsExampleSchema = NSchema.Create(GetType(NRoutableConnectorsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates routable connectors and routing.
</p>
<p>
	Routing is the process of finding a path between two points, which strives not 
	to cross any obstacles and also tries to obey certain aesthetic criteria (such 
	as minimal number of turns, port orientation etc.).
</p>
<p>
    Routing works with three corner stone objects: routable connector, obstacle shapes and router. 
    A routable connector tries to avoid the current set of obstacle shapes (residing in the page) by obtaining routing points from the router. 
    The router is responsible for creating and maintaining a routing graph for the current set of obstacle shapes existing in the page.    
</p>
<p>
	A routable connector can be automatically rerouted in three modes:
	<ul>
		<li>
			<b>Never</b> - the connector is never automatically rerouted. You can still reroute the 
			route by executing the Reroute command (from the context menu or from code).
		</li>
		<li>
			<b>Always</b> - the connector is automatically rerouted when any of the obstacles have 
			changed (i.e. there is a possibility for the route to be rerouted in a better way).
		</li>
		<li>
			<b>When Needed</b> - the connector is automatically rerouted when an obstacle is placed on it 
			(i.e. the route needs to be rerouted cause it crosses an obstacle).
		</li>
	</ul>
</p>
"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' create a stylesheet for styling the different bricks
            Dim styleSheet As NStyleSheet = New NStyleSheet()
            drawingDocument.StyleSheets.AddChild(styleSheet)

            ' the first rule fills brichs with UserClass BRICK1
            Dim ruleBrick1 As NRule = New NRule()
            styleSheet.Add(ruleBrick1)

            Dim sb As NSelectorBuilder = ruleBrick1.GetSelectorBuilder()
            sb.Start()
            sb.Type(NGeometry.NGeometrySchema)
            sb.ChildOf()
            sb.UserClass("BRICK1")
            sb.End()

            ruleBrick1.Declarations.Add(New NValueDeclaration(Of NFill)(NGeometry.FillProperty, New NHatchFill(ENHatchStyle.HorizontalBrick, NColor.DarkOrange, NColor.Gold)))

            ' the second rule fills brichs with UserClass BRICK2
            Dim ruleBrick2 As NRule = New NRule()
            styleSheet.Add(ruleBrick2)

            sb = ruleBrick2.GetSelectorBuilder()
            sb.Start()
            sb.Type(NGeometry.NGeometrySchema)
            sb.ChildOf()
            sb.UserClass("BRICK2")
            sb.End()

            ruleBrick2.Declarations.Add(New NValueDeclaration(Of NFill)(NGeometry.FillProperty, New NHatchFill(ENHatchStyle.HorizontalBrick, NColor.DarkRed, NColor.Gold)))

            ' create all shapes
            ' create the maze frame
            CreateBrick(New NRectangle(50, 0, 700, 50), "BRICK1")
            CreateBrick(New NRectangle(750, 0, 50, 800), "BRICK1")
            CreateBrick(New NRectangle(50, 750, 700, 50), "BRICK1")
            CreateBrick(New NRectangle(0, 0, 50, 800), "BRICK1")

            ' create the maze obstacles
            CreateBrick(New NRectangle(100, 200, 200, 50), "BRICK2")
            CreateBrick(New NRectangle(300, 50, 50, 200), "BRICK2")
            CreateBrick(New NRectangle(450, 50, 50, 200), "BRICK2")
            CreateBrick(New NRectangle(500, 200, 200, 50), "BRICK2")
            CreateBrick(New NRectangle(50, 300, 250, 50), "BRICK2")
            CreateBrick(New NRectangle(500, 300, 250, 50), "BRICK2")
            CreateBrick(New NRectangle(350, 350, 100, 100), "BRICK2")
            CreateBrick(New NRectangle(50, 450, 250, 50), "BRICK2")
            CreateBrick(New NRectangle(500, 450, 250, 50), "BRICK2")
            CreateBrick(New NRectangle(100, 550, 200, 50), "BRICK2")
            CreateBrick(New NRectangle(300, 550, 50, 200), "BRICK2")
            CreateBrick(New NRectangle(450, 550, 50, 200), "BRICK2")
            CreateBrick(New NRectangle(500, 550, 200, 50), "BRICK2")

            ' create the first set of start/end shapes
            Dim start As NShape = CreateEllipse(New NRectangle(100, 100, 50, 50), "START")
            Dim [end] As NShape = CreateEllipse(New NRectangle(650, 650, 50, 50), "END")

            ' connect them with a dynamic HV routable connector, 
            ' which is rerouted whenever the obstacles have changed
            Dim routableConnector As NRoutableConnector = New NRoutableConnector()
            routableConnector.RerouteMode = ENRoutableConnectorRerouteMode.Always
            routableConnector.Geometry.Stroke = New NStroke(3, NColor.Black)
            activePage.Items.Add(routableConnector)

            ' connect the start and end shapes
            routableConnector.GlueBeginToShape(start)
            routableConnector.GlueEndToShape([end])

            ' reroute the connector
            routableConnector.RequestReroute()

            ' size document to fit the maze
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates a brick shape (Rectangle) and applies the specified class to ut 
        ''' </summary>
        ''' <paramname="bounds"></param>
        ''' <paramname="userClass"></param>
        ''' <returns></returns>
        Private Function CreateBrick(bounds As NRectangle, userClass As String) As NShape
            Dim factory As NBasicShapeFactory = New NBasicShapeFactory()
            Dim shape = factory.CreateShape(ENBasicShape.Rectangle)
            shape.SetBounds(bounds)
            shape.UserClass = userClass
            m_DrawingView.ActivePage.Items.Add(shape)
            Return shape
        End Function
        ''' <summary>
        ''' Creates an ellipse shapeand applies the specified class to ut (used for Start and End shapes)
        ''' </summary>
        ''' <paramname="bounds"></param>
        ''' <paramname="userClass"></param>
        ''' <returns></returns>
        Private Function CreateEllipse(bounds As NRectangle, userClass As String) As NShape
            Dim factory As NBasicShapeFactory = New NBasicShapeFactory()
            Dim shape = factory.CreateShape(ENBasicShape.Ellipse)
            shape.SetBounds(bounds)
            shape.UserClass = userClass
            m_DrawingView.ActivePage.Items.Add(shape)
            Return shape
        End Function

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRoutableConnectorsExample.
        ''' </summary>
        Public Shared ReadOnly NRoutableConnectorsExampleSchema As NSchema

#End Region
    End Class
End Namespace
