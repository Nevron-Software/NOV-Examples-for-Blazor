Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' 
    ''' </summary>
    Public Class NGeometryCornerRoundingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NGeometryCornerRoundingExampleSchema = NSchema.Create(GetType(NGeometryCornerRoundingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the geometry corner rounding.
</p>
<p>
    In NOV diagram each geometry can be easily modified to have rounded corners.
</p>
"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' hide the grid
            drawing.ScreenVisibility.ShowGrid = False

            ' plotter commands
            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()
            Dim connectorFactory As NConnectorShapeFactory = New NConnectorShapeFactory()

            ' create a rounded rect
            Dim rectShape = basicShapes.CreateShape(ENBasicShape.Rectangle)
            rectShape.DefaultShapeGlue = ENDefaultShapeGlue.GlueToGeometryIntersection
            rectShape.Geometry.CornerRounding = 10
            rectShape.SetBounds(50, 50, 100, 100)
            activePage.Items.Add(rectShape)

            ' create a rounded pentagram
            Dim pentagramShape = basicShapes.CreateShape(ENBasicShape.Pentagram)
            pentagramShape.DefaultShapeGlue = ENDefaultShapeGlue.GlueToGeometryIntersection
            pentagramShape.Geometry.CornerRounding = 20
            pentagramShape.SetBounds(310, 310, 100, 100)
            activePage.Items.Add(pentagramShape)

            ' create a rounded routable connector
            Dim connector = connectorFactory.CreateShape(ENConnectorShape.RoutableConnector)
            connector.Geometry.CornerRounding = 30
            connector.GlueBeginToShape(rectShape)
            connector.GlueEndToShape(pentagramShape)
            activePage.Items.Add(connector)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NGeometryCornerRoundingExample.
        ''' </summary>
        Public Shared ReadOnly NGeometryCornerRoundingExampleSchema As NSchema

#End Region
    End Class
End Namespace
