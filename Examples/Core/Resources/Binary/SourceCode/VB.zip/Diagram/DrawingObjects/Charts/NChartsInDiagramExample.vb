Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Diagram
    Public Class NChartsInDiagramExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NChartsInDiagramExampleSchema = NSchema.Create(GetType(NChartsInDiagramExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates how to create and host charts in diagram shapes.</p>"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim activePage = drawingDocument.Content.ActivePage

            ' Create a barcode widget
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure title
            chartView.Surface.Titles(0).Text = "Manhattan Bar Chart"

            ' configure chart

            chart.Enable3D = True
            chart.ModelWidth = 60
            chart.ModelHeight = 25
            chart.ModelDepth = 45
            chart.FitMode = ENCartesianChartFitMode.Aspect
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' apply predefined projection and lighting
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.BrightCameraLight)
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.Standard)

            ' add axis labels
            Dim ordinalScale As NOrdinalScale = TryCast(chart.Axes(ENCartesianAxis.Depth).Scale, NOrdinalScale)

            ordinalScale.Labels.TextProvider = New NOrdinalScaleLabelTextProvider(New String() {"Chicago", "Los Angeles", "Miami", "New York"})
            ordinalScale.DisplayDataPointsBetweenTicks = True
            ordinalScale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)

            ordinalScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryX).Scale, NOrdinalScale)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)

            ' add interlace stripe to the Y axis
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            stripStyle.SetShowAtWall(ENChartWall.Back, True)
            stripStyle.SetShowAtWall(ENChartWall.Left, True)
            linearScale.Strips.Add(stripStyle)

            ' add the first bar
            Dim bar1 As NBarSeries = New NBarSeries()
            chart.Series.Add(bar1)
            bar1.MultiBarMode = ENMultiBarMode.Series
            bar1.Name = "Bar1"
            bar1.Stroke = New NStroke(1, NColor.FromRGB(210, 210, 255))

            ' add the second bar
            Dim bar2 As NBarSeries = New NBarSeries()
            chart.Series.Add(bar2)
            bar2.MultiBarMode = ENMultiBarMode.Series
            bar2.Name = "Bar2"
            bar2.Stroke = New NStroke(1, NColor.FromRGB(210, 255, 210))

            ' add the third bar
            Dim bar3 As NBarSeries = New NBarSeries()
            chart.Series.Add(bar3)
            bar3.MultiBarMode = ENMultiBarMode.Series
            bar3.Name = "Bar3"
            bar3.Stroke = New NStroke(1, NColor.FromRGB(255, 255, 210))

            ' add the second bar
            Dim bar4 As NBarSeries = New NBarSeries()
            chart.Series.Add(bar4)
            bar4.MultiBarMode = ENMultiBarMode.Series
            bar4.Name = "Bar4"
            bar4.Stroke = New NStroke(1, NColor.FromRGB(255, 210, 210))

            ' add some data
            Dim random As Random = New Random()
            For i = 0 To 5
                bar1.DataPoints.Add(New NBarDataPoint(random.Next(100)))
                bar2.DataPoints.Add(New NBarDataPoint(random.Next(100)))
                bar3.DataPoints.Add(New NBarDataPoint(random.Next(100)))
                bar4.DataPoints.Add(New NBarDataPoint(random.Next(100)))
            Next

            ' Create a shape and place the barcode widget in it
            Dim shape As NShape = New NShape()
            shape.SetBounds(100, 100, 600, 400)
            shape.Widget = chartView
            activePage.Items.Add(shape)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NChartsInDiagramExample.
        ''' </summary>
        Public Shared ReadOnly NChartsInDiagramExampleSchema As NSchema

#End Region
    End Class
End Namespace
