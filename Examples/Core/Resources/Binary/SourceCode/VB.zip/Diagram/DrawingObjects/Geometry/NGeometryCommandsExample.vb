Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' 
    ''' </summary>
    Public Class NGeometryCommandsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NGeometryCommandsExampleSchema = NSchema.Create(GetType(NGeometryCommandsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the geometry commands that you can use to construct the shapes geometry. 
</p>
<p>
    On the first row you can see the different types of geometry commands that you can use to plot geometry. 
    Plotter commands are designed to be placed in a sequence so that you can create arbitrary geometry by combining 
    MoveTo, LineTo, CubicBezierTo, ArcTo, CircularActTo and EllipticalArcTo commands.
</p>
<p>
    On the second row you can see the different types of draw box commands. 
    These commands are used when you want to output more vertices or generally draw more complex clipart shapes with single geometry commands.
</p>
<p>
    The active page is switched to geometry edit mode, so when you select shapes you can see handles you can move to modify the geometry.
</p>
"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content

            ' switch selected edit mode to geometry
            ' this instructs the diagram to show geometry handles for the selected shapes.
            drawingDocument.Content.ActivePage.SelectionEditMode = ENSelectionEditMode.Geometry
            drawing.ScreenVisibility.ShowGrid = False

            ' plotter commands
            CreateDescriptionPair(0, 0, CreateLineTo(), "Line To")
            CreateDescriptionPair(0, 1, CreateArcTo(), "Arc To")
            CreateDescriptionPair(0, 2, CreateCubicBezierTo(), "Cubic Bezier To")
            CreateDescriptionPair(0, 3, CreateCircularArcTo(), "Circular Arc To")
            CreateDescriptionPair(0, 4, CreateEllipticalArcTo(), "Elliptical Arc To")

            ' draw box commands
            CreateDescriptionPair(1, 0, CreateDrawRectangle(), "Draw Rectangle")
            CreateDescriptionPair(1, 1, CreateDrawEllipse(), "Draw Ellipse")
            CreateDescriptionPair(1, 2, CreateDrawPolygon(0), "Draw Polygon")
            CreateDescriptionPair(1, 3, CreateDrawPolyline(0), "Draw Polyline")
            CreateDescriptionPair(1, 4, CreateDrawPolygon(1), "Draw Polygon With Tension")
            CreateDescriptionPair(1, 5, CreateDrawPolyline(1), "Draw Polyline With Tension")
            CreateDescriptionPair(1, 6, CreateDrawPath(), "Draw Path")
        End Sub

        Private Function CreateLineTo() As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            ' the LineTo command draws a line from the prev plotter command to the command location
            If True Then
                Dim plotFigure = shape.Geometry.RelMoveTo(0, 0)
                shape.Geometry.RelLineTo(1, 1)
                plotFigure.ShowFill = False
            End If

            Return shape
        End Function
        Private Function CreateArcTo() As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            ' the ArcTo command draws a circular arc from the prev plotter command to the command location.
            ' the ArcTo Bow parameter defines the distance of the arc from the line formed by previous command location and the command location
            If True Then
                Dim plotFigure = shape.Geometry.RelMoveTo(0, 0)
                shape.Geometry.RelArcTo(1, 1, 30)
                plotFigure.ShowFill = False
            End If

            Return shape
        End Function
        Private Function CreateCubicBezierTo() As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            ' the CubicBezierTo command draws a cubic bezier from the prev plotter command to the command location.
            ' the cubic bezier curve is controled by two control points.
            If True Then
                Dim plotFigure = shape.Geometry.RelMoveTo(0, 0)
                shape.Geometry.RelCubicBezierTo(1, 1, 1, 0, 0, 1)
                plotFigure.ShowFill = False
            End If

            Return shape
        End Function
        Private Function CreateCircularArcTo() As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            ' the CircularAcrTo command draws a circular arc from the prev plotter command to the command location.
            ' the circular acr curve is controled by a control point which defines the circle trough which the arc passes.
            If True Then
                Dim plotFigure = shape.Geometry.RelMoveTo(0, 0)
                shape.Geometry.RelCircularArcTo(1, 1, 1, 0)
                plotFigure.ShowFill = False
            End If

            Return shape
        End Function
        Private Function CreateEllipticalArcTo() As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            ' the EllipticalArcTo command draws an elliptical arc from the prev plotter command to the command location.
            ' the elliptical acr curve is controled by a control point which defines the ellipse trough which the arc passes, 
            ' the angle of the ellipse and the ratio between the ellipse radiuses.
            If True Then
                Dim plotFigure = shape.Geometry.RelMoveTo(0, 0)
                shape.Geometry.RelEllipticalArcTo(1, 1, 1, 0, New NAngle(0, NUnit.Degree), 0.5)
                plotFigure.ShowFill = False
            End If

            Return shape
        End Function

        Private Function CreateDrawRectangle() As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            ' the draw rectangle command draws a rect inside a relative or absolute rect inside the shape coordinate system. 
            ' The following draws a rect that fills the shape.
            Dim drawRectangle As NDrawRectangle = New NDrawRectangle(0, 0, 1, 1)
            shape.Geometry.AddRelative(drawRectangle)

            Return shape
        End Function
        Private Function CreateDrawEllipse() As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            ' the draw ellipse command draws an ellipse inside a relative or absolute rect inside the shape coordinate system. 
            ' The following draws an ellipse that fills the shape.
            Dim drawEllipse As NDrawEllipse = New NDrawEllipse(0, 0, 1, 1)
            shape.Geometry.AddRelative(drawEllipse)

            Return shape
        End Function
        Private Function CreateDrawPolygon(tension As Double) As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            Dim ngon As NGenericNGram = New NGenericNGram(4, 0, 0.5, 0.1, New NPoint(0.5, 0.5))
            Dim points As NPoint() = ngon.CreateVertices()

            ' the draw ellipse command draws an ellipse inside a relative or absolute rect inside the shape coordinate system. 
            ' The following draws an ellipse that fills the shape.
            Dim drawPolygon As NDrawPolygon = New NDrawPolygon(0, 0, 1, 1, points)
            drawPolygon.Tension = tension
            shape.Geometry.AddRelative(drawPolygon)

            Return shape
        End Function
        Private Function CreateDrawPolyline(tension As Double) As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            Dim points As NPoint() = New NPoint() {New NPoint(0, 0), New NPoint(0.25, 1), New NPoint(0.50, 0), New NPoint(0.75, 1), New NPoint(1, 0)}

            ' the draw ellipse command draws an ellipse inside a relative or absolute rect inside the shape coordinate system. 
            ' The following draws an ellipse that fills the shape.
            Dim drawPolyline As NDrawPolyline = New NDrawPolyline(0, 0, 1, 1, points)
            drawPolyline.Tension = tension
            drawPolyline.ShowFill = False
            shape.Geometry.AddRelative(drawPolyline)

            Return shape
        End Function
        Private Function CreateDrawPath() As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddRectangle(0, 0, 0.5, 0.5)
            path.AddEllipse(0.5, 0.5, 0.5, 0.5)

            ' the draw path command draws a path inside a relative or absolute rect inside the shape coordinate system. 
            ' The following draws a path that contains a rectangle and an ellipse that fills the shape.
            Dim drawPath As NDrawPath = New NDrawPath(0, 0, 1, 1, path)
            shape.Geometry.AddRelative(drawPath)

            Return shape
        End Function

        Private Sub CreateDescriptionPair(row As Integer, col As Integer, shape As NShape, text As String)
            Const startX As Double = 20
            Const startY As Double = 100
            Const width As Double = 80
            Const height As Double = 100
            Const spacing As Double = 20

            m_DrawingView.ActivePage.Items.Add(shape)
            shape.SetBounds(New NRectangle(startX + col * (width + spacing), startY + row * (height + spacing), width, height / 2))

            Dim textShape As NShape = New NShape()
            textShape.Init2DShape()
            textShape.Text = text
            textShape.SetBounds(New NRectangle(startX + col * (width + spacing), startY + row * (height + spacing) + height / 2, width, height / 2))
            m_DrawingView.ActivePage.Items.Add(textShape)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NGeometryCommandsExample.
        ''' </summary>
        Public Shared ReadOnly NGeometryCommandsExampleSchema As NSchema

#End Region
    End Class
End Namespace
