Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' The example demonstrates how to connect table ports
    ''' </summary>
    Public Class NTablePortsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTablePortsExampleSchema = NSchema.Create(GetType(NTablePortsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to connect table ports to other shapes.</p>"
        End Function

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' hide the grid
            drawing.ScreenVisibility.ShowGrid = False

            Dim tableDescription = New String() {"Table With Column Ports", "Table With Row Ports", "Table With Cell Ports", "Table With Grid Ports"}
            Dim tablePortDistributionModes = New ENPortsDistributionMode() {ENPortsDistributionMode.ColumnsOnly, ENPortsDistributionMode.RowsOnly, ENPortsDistributionMode.CellBased, ENPortsDistributionMode.GridBased}
            Dim tableBlocks = New NTableBlock(tablePortDistributionModes.Length - 1) {}

            Dim margin As Double = 40
            Dim tableSize As Double = 200
            Dim gap = activePage.Width - margin * 2 - tableSize * 2

            Dim yPos = margin
            Dim portDistributionModeIndex = 0

            For y = 0 To 1
                Dim xPos = margin

                For x = 0 To 1
                    Dim shape As NShape = New NShape()
                    shape.SetBounds(New NRectangle(xPos, yPos, tableSize, tableSize))

                    xPos += tableSize + gap

                    ' create table
                    Dim tableBlock = CreateTableBlock(tableDescription(portDistributionModeIndex))

                    ' collect the block to connect it to the center shape
                    tableBlocks(portDistributionModeIndex) = tableBlock

                    tableBlock.Content.AllowSpacingBetweenCells = False
                    tableBlock.ResizeMode = ENTableBlockResizeMode.FitToShape
                    tableBlock.PortsDistributionMode = tablePortDistributionModes(Math.Min(System.Threading.Interlocked.Increment(portDistributionModeIndex), portDistributionModeIndex - 1))
                    shape.TextBlock = tableBlock

                    drawing.ActivePage.Items.AddChild(shape)
                Next

                yPos += tableSize + gap
            Next

            Dim centerShape As NShape = New NBasicShapeFactory().CreateShape(ENBasicShape.Rectangle)
            centerShape.Text = "Table Ports allow you to connect tables to other shapes"
            centerShape.TextBlock.FontStyleBold = True
            CType(centerShape.TextBlock, NTextBlock).VerticalAlignment = ENVerticalAlignment.Center
            CType(centerShape.TextBlock, NTextBlock).HorizontalAlignment = ENAlign.Center
            activePage.Items.AddChild(centerShape)

            Dim center = drawing.ActivePage.Width / 2.0
            Dim shapeSize As Double = 100
            centerShape.SetBounds(New NRectangle(center - shapeSize / 2.0, center - shapeSize / 2.0, shapeSize, shapeSize))

            ' get the column port for the first column on the bottom side
            Dim columnPort As NTableColumnPort
            If tableBlocks(0).TryGetColumnPort(0, False, columnPort) Then
                Connect(columnPort, centerShape.GetPortByName("Left"))
            End If

            ' get the row port for the second row on the left side
            Dim rowPort As NTableRowPort
            If tableBlocks(1).TryGetRowPort(1, True, rowPort) Then
                Connect(rowPort, centerShape.GetPortByName("Top"))
            End If

            ' get the cell port of the first cell on the top side
            Dim cellPort As NTableCellPort
            If tableBlocks(2).TryGetCellPort(0, 0, ENTableCellPortDirection.Top, cellPort) Then
                Connect(cellPort, centerShape.GetPortByName("Bottom"))
            End If

            ' get the cell port of the first row on the left side
            Dim rowPort1 As NTableRowPort
            If tableBlocks(3).TryGetRowPort(0, True, rowPort1) Then
                Connect(rowPort1, centerShape.GetPortByName("Right"))
            End If
        End Sub
        Private Sub Connect(beginPort As NPort, endPort As NPort)
            Dim connector As NRoutableConnector = New NRoutableConnector()
            connector.RerouteMode = ENRoutableConnectorRerouteMode.Always
            m_DrawingView.ActivePage.Items.AddChild(connector)

            connector.GlueBeginToPort(beginPort)
            connector.GlueEndToPort(endPort)
        End Sub
        Private Function CreateTableBlock(description As String) As NTableBlock
            Dim tableBlock As NTableBlock = New NTableBlock(4, 3, NBorder.CreateFilledBorder(NColor.Black), New NMargins(1))

            Dim tableBlockContent = tableBlock.Content

            Dim tableCell = tableBlock.Content.Rows(0).Cells(0)
            tableCell.ColSpan = Integer.MaxValue

            tableCell.Blocks.Clear()
            Dim par As NParagraph = New NParagraph(description)
            par.FontStyleBold = True
            tableCell.Blocks.Add(par)

            For rowIndex = 1 To tableBlockContent.Rows.Count - 1
                Dim row = tableBlockContent.Rows(rowIndex)

                For colIndex = 0 To tableBlockContent.Columns.Count - 1
                    Dim cell = row.Cells(colIndex)

                    cell.Blocks.Clear()
                    cell.Blocks.Add(New NParagraph("This is a table cell [" & rowIndex.ToString() & ", " & colIndex.ToString() & "]"))
                Next
            Next

            ' make sure all columns are percentage based
            Dim percent = 100 / tableBlockContent.Columns.Count

            For i = 0 To tableBlockContent.Columns.Count - 1
                tableBlockContent.Columns(i).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, percent)
            Next

            Return tableBlock
        End Function

#End Region

#Region "Implementation "

        ''' <summary>
        ''' Adds rich formatted text to the specified text block content
        ''' </summary>
        ''' <paramname="content"></param>
        Private Sub AddFormattedTextToContent(content As NTextBlockContent)
            content.Blocks.Add(GetTitleParagraph("Bullet lists allow you to apply automatic numbering on paragraphs or groups of blocks.", 1))

            ' setting bullet list template type
            If True Then
                content.Blocks.Add(GetTitleParagraph("Following are bullet lists with different formatting", 2))

                Dim values As ENBulletListTemplateType() = NEnum.GetValues(Of ENBulletListTemplateType)()
                Dim names As String() = NEnum.GetNames(Of ENBulletListTemplateType)()

                Dim itemText = "Bullet List Item"

                For i = 0 To values.Length - 1 - 1
                    Dim group As NGroupBlock = New NGroupBlock()
                    content.Blocks.Add(group)
                    group.MarginTop = 10
                    group.MarginBottom = 10

                    Dim bulletList As NBulletList = New NBulletList(values(i))
                    content.BulletLists.Add(bulletList)

                    For j = 0 To 2
                        Dim paragraph As NParagraph = New NParagraph(itemText & j.ToString())
                        Dim bullet As NBulletInline = New NBulletInline()
                        bullet.List = bulletList
                        paragraph.Bullet = bullet

                        group.Blocks.Add(paragraph)
                    Next
                Next
            End If

            ' nested bullet lists
            If True Then
                content.Blocks.Add(GetTitleParagraph("Following is an example of bullets with different bullet level", 2))

                Dim bulletList As NBulletList = New NBulletList(ENBulletListTemplateType.Decimal)
                content.BulletLists.Add(bulletList)

                Dim group As NGroupBlock = New NGroupBlock()
                content.Blocks.Add(group)

                For i = 0 To 2
                    Dim par As NParagraph = New NParagraph("Bullet List Item" & i.ToString(), bulletList, 0)
                    group.Blocks.Add(par)

                    For j = 0 To 1
                        Dim nestedPar As NParagraph = New NParagraph("Nested Bullet List Item" & i.ToString(), bulletList, 1)
                        nestedPar.MarginLeft = 10

                        group.Blocks.Add(nestedPar)
                    Next
                Next
            End If
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <paramname="level"></param>
        ''' <returns></returns>
        Friend Shared Function GetTitleParagraphNoBorder(text As String, level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()

            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle

            Dim textInline As NTextInline = New NTextInline(text)

            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize

            paragraph.Inlines.Add(textInline)

            Return paragraph

        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Friend Shared Function GetTitleParagraph(text As String, level As Integer) As NParagraph
            Dim color = NColor.Black

            Dim paragraph = GetTitleParagraphNoBorder(text, level)
            paragraph.HorizontalAlignment = ENAlign.Left

            paragraph.Border = CreateLeftTagBorder(color)
            paragraph.BorderThickness = New NMargins(5.0, 0.0, 0.0, 0.0)

            Return paragraph
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(color As NColor) As NBorder
            Dim border As NBorder = New NBorder()

            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)

            Return border
        End Function

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTablePortsExample.
        ''' </summary>
        Public Shared ReadOnly NTablePortsExampleSchema As NSchema

#End Region
    End Class
End Namespace
