Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Themes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NThemeBasedShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NThemeBasedShapesExampleSchema = NSchema.Create(GetType(NThemeBasedShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create shapes whose appearance depends on
	the currently selected page theme and page theme variant. To do that, set
	the <b>Tag</b> property of the shapes to a theme based color info.
</p>
<p>
	Select a new page theme or page theme variant from the <b>Design</b> tab of
	the ribbon to see how the style of the shape will change.
</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub InitDiagram(drawingDocument As NDrawingDocument)
            ' Create a rectangle shape
            Dim shape As NShape = New NShape()
            shape.Text = "Shape"
            shape.Geometry.AddRelative(New NDrawRectangle(0, 0, 1, 1))
            shape.SetBounds(100, 100, 200, 150)

            ' Make color1 a theme variant color
            Dim theme = NDrawingTheme.MyDrawNature
            Dim color1 = theme.ColorPalette.Variants(0)(0)
            color1.Tag = New NThemeVariantColorInfo(0)

            ' Make color2 a theme palette color
            Dim color2 As NColor = theme.ColorPalette.Light1
            color2.Tag = New NThemePaletteColorInfo(ENThemeColorName.Light1, 0)

            ' Set the fill of the geometry to a hatch that depends on the theme
            shape.Geometry.Fill = New NHatchFill(ENHatchStyle.DiagonalCross, color1, color2)

            ' Add the theme based shape to the active page of the drawing
            Dim activePage = drawingDocument.Content.ActivePage
            activePage.Items.Add(shape)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NThemeBasedShapesExample.
        ''' </summary>
        Public Shared ReadOnly NThemeBasedShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace
