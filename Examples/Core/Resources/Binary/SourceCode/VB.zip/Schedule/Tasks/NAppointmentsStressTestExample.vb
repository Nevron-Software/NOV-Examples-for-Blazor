Imports System

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Globalization
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NAppointmentsStressTestExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NAppointmentsStressTestExampleSchema = NSchema.Create(GetType(NAppointmentsStressTestExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            Dim scheduleViewWithRibbon As NScheduleViewWithRibbon = New NScheduleViewWithRibbon()
            m_ScheduleView = scheduleViewWithRibbon.View

            m_ScheduleView.Document.PauseHistoryService()
            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Return the commanding widget
            Return scheduleViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return String.Format(NCultureInfo.EnglishUS, "
<p>
    This example demonstrates how NOV Schedule handles {0:N0} appointments.
</p>
", TotalAppointments)
        End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(schedule As NSchedule)
            m_Random = New Random()

            Dim totalDays As Integer = TotalAppointments / AppointmentsPerDay
            Dim [date] = Date.Today.AddDays(-totalDays / 2)

            ' Generate the random appointments
            Dim appointments = schedule.Appointments
            For i = 0 To totalDays - 1
                AddRandomAppointments(appointments, [date])
                [date] = [date].AddDays(1)
            Next

            ' Switch the schedule to week view
            schedule.ViewMode = ENScheduleViewMode.Week
        End Sub
        ''' <summary>
        ''' Adds some random appointments for the given date.
        ''' </summary>
        ''' <paramname="appointments"></param>
        ''' <paramname="date"></param>
        Private Sub AddRandomAppointments(appointments As NAppointmentCollection, [date] As Date)
            For i = 0 To AppointmentsPerDay - 1
                ' Generate random subject
                Dim subject = AppointmentSubjects(m_Random.Next(0, AppointmentSubjects.Length))

                ' Generate random start hour from 0 to 24
                Dim startHour As Double = m_Random.NextDouble() * 24

                ' Generate random duration from 0.5 to 2.5 hours
                Dim duration As Double = 0.5 + m_Random.NextDouble() * 2

                ' Create and add the appointment
                Dim appointment As NAppointment = New NAppointment(subject, [date].AddHours(startHour), [date].AddHours(startHour + duration))
                appointments.Add(appointment)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView
        Private m_Random As Random

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NAppointmentsStressTestExample.
        ''' </summary>
        Public Shared ReadOnly NAppointmentsStressTestExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const AppointmentsPerDay As Integer = 20
        Private Const TotalAppointments As Integer = 100000
        Private Shared ReadOnly AppointmentSubjects As String() = New String() {"Travel to Work", "Meeting with John", "Conference", "Lunch", "News Reading", "Video Presentation", "Web Meeting", "Travel back home", "Family Dinner"}

#End Region
    End Class
End Namespace
