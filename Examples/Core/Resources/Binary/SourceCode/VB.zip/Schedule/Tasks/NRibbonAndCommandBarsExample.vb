Imports System

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NRibbonAndCommandBarsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRibbonAndCommandBarsExampleSchema = NSchema.Create(GetType(NRibbonAndCommandBarsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            m_ScheduleView = New NScheduleView()

            m_ScheduleView.Document.PauseHistoryService()
            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Create and execute a ribbon UI builder
            m_RibbonBuilder = New NScheduleRibbonBuilder()
            Return m_RibbonBuilder.CreateUI(m_ScheduleView)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Switch UI button
            Dim switchUIButton As NButton = New NButton(SwitchToCommandBars)
            switchUIButton.Click += AddressOf OnSwitchUIButtonClick
            stack.Add(switchUIButton)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to switch the NOV Schedule commanding interface between ribbon and command bars.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(schedule As NSchedule)
            Dim start = Date.Now

            ' Create an appointment
            Dim appointment As NAppointment = New NAppointment("Meeting", start, start.AddHours(2))
            schedule.Appointments.Add(appointment)
            schedule.ScrollToTime(start.TimeOfDay)
        End Sub
        Private Sub SetUI(oldUiHolder As NCommandUIHolder, widget As NWidget)
            If TypeOf oldUiHolder.ParentNode Is NTabPage Then
                CType(oldUiHolder.ParentNode, NTabPage).Content = widget
            ElseIf TypeOf oldUiHolder.ParentNode Is NPairBox Then
                CType(oldUiHolder.ParentNode, NPairBox).Box1 = widget
            End If
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnSwitchUIButtonClick(arg As NEventArgs)
            Dim switchUIButton = CType(arg.TargetNode, NButton)
            Dim label = CType(switchUIButton.Content, NLabel)

            ' Remove the schedule view from its parent
            Dim uiHolder As NCommandUIHolder = m_ScheduleView.GetFirstAncestor(Of NCommandUIHolder)()
            m_ScheduleView.ParentNode.RemoveChild(m_ScheduleView)

            If Equals(label.Text, SwitchToRibbon) Then
                ' We are in "Command Bars" mode, so switch to "Ribbon"
                label.Text = SwitchToCommandBars

                ' Create the ribbon
                SetUI(uiHolder, m_RibbonBuilder.CreateUI(m_ScheduleView))
            Else
                ' We are in "Ribbon" mode, so switch to "Command Bars"
                label.Text = SwitchToRibbon

                ' Create the command bars
                If m_CommandBarBuilder Is Nothing Then
                    m_CommandBarBuilder = New NScheduleCommandBarBuilder()
                End If

                SetUI(uiHolder, m_CommandBarBuilder.CreateUI(m_ScheduleView))
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView
        Private m_RibbonBuilder As NScheduleRibbonBuilder
        Private m_CommandBarBuilder As NScheduleCommandBarBuilder

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRibbonAndCommandBarsSwitchingExample.
        ''' </summary>
        Public Shared ReadOnly NRibbonAndCommandBarsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const SwitchToCommandBars As String = "Switch to Command Bars"
        Private Const SwitchToRibbon As String = "Switch to Ribbon"

#End Region
    End Class
End Namespace
