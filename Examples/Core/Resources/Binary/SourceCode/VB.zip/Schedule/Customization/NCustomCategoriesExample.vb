
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NCustomCategoriesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCustomCategoriesExampleSchema = NSchema.Create(GetType(NCustomCategoriesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            Dim scheduleViewWithRibbon As NScheduleViewWithRibbon = New NScheduleViewWithRibbon()
            m_ScheduleView = scheduleViewWithRibbon.View

            m_ScheduleView.Document.PauseHistoryService()
            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Return the commanding widget
            Return scheduleViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create and use custom categories.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(schedule As NSchedule)
            ' Rename the first predefined category
            schedule.Categories(0).Name = NLoc.Get("Renamed Category")

            ' Create and add some custom categories
            Dim category1 As NCategory = New NCategory(NLoc.Get("Custom Category 1"), NColor.Khaki)
            schedule.Categories.Add(category1)

            Dim category2 As NCategory = New NCategory(NLoc.Get("Custom Category 2"), New NHatchFill(ENHatchStyle.DiagonalBrick, NColor.Red, NColor.Orange))
            schedule.Categories.Add(category2)

            ' Remove the second category
            schedule.Categories.RemoveAt(1)

            ' Remove the category called "Green"
            Dim categoryToRemove = schedule.Categories.FindByName(NLoc.Get("Green"))
            If categoryToRemove IsNot Nothing Then
                schedule.Categories.Remove(categoryToRemove)
            End If

            ' Create and add some appointments
            Dim start = Date.Now

            Dim appointment1 As NAppointment = New NAppointment("Meeting 1", start, start.AddHours(2))
            appointment1.Category = category1.Name
            schedule.Appointments.Add(appointment1)

            Dim appointment2 As NAppointment = New NAppointment("Meeting 2", appointment1.End.AddHours(0.5), appointment1.End.AddHours(2.5))
            appointment2.Category = category2.Name
            schedule.Appointments.Add(appointment2)

            ' Scroll the schedule to the start of the first appointment
            schedule.ScrollToTime(start.TimeOfDay)
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCustomCategoriesExample.
        ''' </summary>
        Public Shared ReadOnly NCustomCategoriesExampleSchema As NSchema


#End Region
    End Class
End Namespace
